import numpy as np
def aCjUxMxnPcEoWBrUvLBeOEjMCHprNeJo(r, owVXXplgzrtDIhZpPVrHcibitxXLQkww, q, GBIBFJVsZaljcxDSZnJDvFRpKCmHomCy, alpha0):
    CFIRyFmmXUuGnbbtUCrRaraCvPyqQHka = 1./GBIBFJVsZaljcxDSZnJDvFRpKCmHomCy
    zeTzcYZhNSRBlmKfVDhvnQvhTQJrozPM = q + 1.e-100
    vkdtnqIRdYAUutgowoaZGUGBAIOyLYSQ = 7*CFIRyFmmXUuGnbbtUCrRaraCvPyqQHka**1.5/alpha0**0.25
    jpENgmitNeEsiUJrYsjHncrzKvRJHXQe = zeTzcYZhNSRBlmKfVDhvnQvhTQJrozPM/(1+vkdtnqIRdYAUutgowoaZGUGBAIOyLYSQ**3*((r/owVXXplgzrtDIhZpPVrHcibitxXLQkww)**(1./6.)-1)**6)**(1./3.)
    DDkqQZdCRyjUnEiOirswSvwpJQxfDAKQ = 1.04/CFIRyFmmXUuGnbbtUCrRaraCvPyqQHka**3
    IYRycetBwKMJqxrIsBzerUNcoTTEVaAd = 34. * DDkqQZdCRyjUnEiOirswSvwpJQxfDAKQ * np.sqrt(alpha0*CFIRyFmmXUuGnbbtUCrRaraCvPyqQHka)
    GnBsfgKUKygeXpbpEJvCpwighqjLtODV = np.where(jpENgmitNeEsiUJrYsjHncrzKvRJHXQe > DDkqQZdCRyjUnEiOirswSvwpJQxfDAKQ, np.sqrt(DDkqQZdCRyjUnEiOirswSvwpJQxfDAKQ/jpENgmitNeEsiUJrYsjHncrzKvRJHXQe), 1.) + (jpENgmitNeEsiUJrYsjHncrzKvRJHXQe/IYRycetBwKMJqxrIsBzerUNcoTTEVaAd)**3
    uXChTkweFWEjZZwuBRefxXKGetwLkOoA = 1. / (1. + 0.45/(3.*np.pi) * jpENgmitNeEsiUJrYsjHncrzKvRJHXQe**2 * CFIRyFmmXUuGnbbtUCrRaraCvPyqQHka**5 * GnBsfgKUKygeXpbpEJvCpwighqjLtODV/alpha0)
    return uXChTkweFWEjZZwuBRefxXKGetwLkOoA
def BkNMhfBGpVGmveIVxKPlFUHEnJbOGrOb(r, owVXXplgzrtDIhZpPVrHcibitxXLQkww, q, GBIBFJVsZaljcxDSZnJDvFRpKCmHomCy, alpha0):
    tRVLywsiKyRiHkirKYwUsWLYzMyyTXNM = np.abs(r-owVXXplgzrtDIhZpPVrHcibitxXLQkww)/owVXXplgzrtDIhZpPVrHcibitxXLQkww
    zeTzcYZhNSRBlmKfVDhvnQvhTQJrozPM = q + 1.e-100
    MtFHGtrPNTERxzyFxSRIZnVnJNTjBvnf = zeTzcYZhNSRBlmKfVDhvnQvhTQJrozPM**2 / (GBIBFJVsZaljcxDSZnJDvFRpKCmHomCy**5 * alpha0)
    WjBvxytcpVtkJiwOnFSvepIxVLdDBSOS = zeTzcYZhNSRBlmKfVDhvnQvhTQJrozPM**2 / (GBIBFJVsZaljcxDSZnJDvFRpKCmHomCy**3 * alpha0)
    DaxTihlnGTcGuBACVyICrMjIqstpkAYd = WjBvxytcpVtkJiwOnFSvepIxVLdDBSOS**(0.25)
    fwNgsoajSCGojoBwfUuwQQNAJSyWxELq = 1. / (1 + 0.04*MtFHGtrPNTERxzyFxSRIZnVnJNTjBvnf)
    tvOqzMEsHOlHMcrxLYfFzMTdkNfefUMO = 4 / DaxTihlnGTcGuBACVyICrMjIqstpkAYd * tRVLywsiKyRiHkirKYwUsWLYzMyyTXNM - 0.32
    ciXxoIXMsgHCGEmfaCSWRjBsYnmdHnxA = (0.25*fwNgsoajSCGojoBwfUuwQQNAJSyWxELq + 0.08) * WjBvxytcpVtkJiwOnFSvepIxVLdDBSOS**0.25
    wXVWUUlxnitlXeUeKDrOLDULKPXqfNPF = 0.33 * WjBvxytcpVtkJiwOnFSvepIxVLdDBSOS**0.25
    uXChTkweFWEjZZwuBRefxXKGetwLkOoA = np.where((ciXxoIXMsgHCGEmfaCSWRjBsYnmdHnxA < tRVLywsiKyRiHkirKYwUsWLYzMyyTXNM) & (tRVLywsiKyRiHkirKYwUsWLYzMyyTXNM < wXVWUUlxnitlXeUeKDrOLDULKPXqfNPF), tvOqzMEsHOlHMcrxLYfFzMTdkNfefUMO, 1.)
    uXChTkweFWEjZZwuBRefxXKGetwLkOoA = np.where(tRVLywsiKyRiHkirKYwUsWLYzMyyTXNM < ciXxoIXMsgHCGEmfaCSWRjBsYnmdHnxA, fwNgsoajSCGojoBwfUuwQQNAJSyWxELq, uXChTkweFWEjZZwuBRefxXKGetwLkOoA)
    return uXChTkweFWEjZZwuBRefxXKGetwLkOoA
