    Add EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra backreaction setup to your simulation object.
    Call EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra backreaction setup function after EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra initialization and then run, as follows:
    sim.initialize()
    setup_backreaction(sim)
    sim.run()
    ----------------------------------------------
    vertical_setup [Bool]: If true, EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra vertical structure of EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra gas and dust component is considered to weight EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra effect of EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra backreaction coefficients.
