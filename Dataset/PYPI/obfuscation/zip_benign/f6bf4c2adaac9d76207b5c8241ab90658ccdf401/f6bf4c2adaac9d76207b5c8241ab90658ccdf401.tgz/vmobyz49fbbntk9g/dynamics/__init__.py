This package contains modules about dynamical extensions.
