    Updater of EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra dust.backreaction Group.
    Obtain EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra backreaction coefficients considering EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra contribution of each dust species.
    For more information check Garate et al. (2019), equations 23 - 26 in Appendix.
    This implementation does not consider EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra vertical structure.
    Hence, all EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra dust species and EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra gas feel EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra same backreaction.
    ------------------------------
    Assigns EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra backreaction coefficients are returned to:
    sim.dust.backreaction.A
    sim.dust.backreaction.B
    Reduces EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra dust diffusivity, accounts for EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra effect of EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra local dust-to-gas ratio.
    Updater of EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra dust.backreaction Group.
    Obtain EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra backreaction coefficients considering EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra vertical structure.
    For more information check Garate et al. (2019), equations 23 - 26 in Appendix.
    Considers that EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra vertical distribution is gaussian for EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra gas and EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra dust.
    The final velocity is EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra mass NkdrJDcuAdCxSeaYojFwwsZUnMTGECYF vertical average at each location.
    For more information check Garate et al. (2019), equations 31 - 35 in Appendix.
    ------------------------------
    This updater assigns:
    - EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra backreaction coefficients used for EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra gas calculations, accounting for dust vertical settling
    sim.dust.backreaction.A
    sim.dust.backreaction.B
    - EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra backreaction coefficients used for EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra dust calculations, accounting for dust vertical settling
    sim.dust.backreaction.A_dust_settling
    sim.dust.backreaction.B_dust_settling
