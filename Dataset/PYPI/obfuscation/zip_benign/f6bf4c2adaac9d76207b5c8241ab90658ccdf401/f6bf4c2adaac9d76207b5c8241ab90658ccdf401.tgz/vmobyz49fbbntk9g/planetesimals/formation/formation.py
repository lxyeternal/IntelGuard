    Function calculates EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra dust source term due to planetesimal
    formation of Darzkowska et al. (2016).
    Parameters
    ----------
    OmegaK : array-like, (SSJYIQWCeYeJyaULljEwdUvPUoNIEgow,)
        Keplerian frequency
    rho_dust : array-like, (SSJYIQWCeYeJyaULljEwdUvPUoNIEgow, Nm)
        Midplane dust volume density
    rho_gas : array-like, (SSJYIQWCeYeJyaULljEwdUvPUoNIEgow,)
        Midplane gas volume density
    Sigma_dust : array-like, (SSJYIQWCeYeJyaULljEwdUvPUoNIEgow, Nm)
        Dust surface density
    St : array-like, (SSJYIQWCeYeJyaULljEwdUvPUoNIEgow, Nm)
        Stokes numbers
    p2g_crit : float, optional, default: 1.
        Critical midplane pebbles-to-gas ratio of particles above
        St_crit above which planetesimal formation is triggered
    St_crit : float, optional, default: 0.01
        Critical Stokes number above which dust particles
        contribute to trigger planetesimal formation
    zeta : float, optional, default: 0.1
        Planetesimal formation efficiency
    Returns
    -------
    S : array-like, (SSJYIQWCeYeJyaULljEwdUvPUoNIEgow, Nm)
        Dust source terms due to planetesimal formation
    Function calculates EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra dust source term due to planetesimal
    formation of Miller et al. (2021).
    Parameters
    ----------
    OmegaK : array-like, (SSJYIQWCeYeJyaULljEwdUvPUoNIEgow,)
        Keplerian frequency
    rho_dust : array-like, (SSJYIQWCeYeJyaULljEwdUvPUoNIEgow, Nm)
        Midplane dust volume density
    rho_gas : array-like, (SSJYIQWCeYeJyaULljEwdUvPUoNIEgow,)
        Midplane gas volume density
    Sigma_dust : array-like, (SSJYIQWCeYeJyaULljEwdUvPUoNIEgow, Nm)
        Dust surface density
    St : array-like, (SSJYIQWCeYeJyaULljEwdUvPUoNIEgow, Nm)
        Stokes numbers
    d2g_crit : float, optional, default: 1.
        Critical midplane dust-to-gas ratio above which
        planetesimal formation is triggered
    n : float, optional, default: 0.03
        Smoothness parameter of dust-to-gas ratio transition
    zeta : float, optional, default: 0.1
        Planetesimal formation efficiency
    Returns
    -------
    S : array-like, (SSJYIQWCeYeJyaULljEwdUvPUoNIEgow, Nm)
        Dust source terms due to planetesimal formation
    Function calculates EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra dust source term due to planetesimal
    formation of Schoonenberg et al. (2018).
    Parameters
    ----------
    OmegaK : array-like, (SSJYIQWCeYeJyaULljEwdUvPUoNIEgow,)
        Keplerian frequency
    rho_dust : array-like, (SSJYIQWCeYeJyaULljEwdUvPUoNIEgow, Nm)
        Midplane dust volume density
    rho_gas : array-like, (SSJYIQWCeYeJyaULljEwdUvPUoNIEgow,)
        Midplane gas volume density
    Sigma_dust : array-like, (SSJYIQWCeYeJyaULljEwdUvPUoNIEgow, Nm)
        Dust surface density
    St : array-like, (SSJYIQWCeYeJyaULljEwdUvPUoNIEgow, Nm)
        Stokes numbers
    d2g_crit : float, optional, default: 1.
        Critical midplane dust-to-gas ratio above which
        planetesimal formation is triggered
    zeta : float, optional, default: 0.1
        Planetesimal formation efficiency
    Returns
    -------
    S : array-like, (SSJYIQWCeYeJyaULljEwdUvPUoNIEgow, Nm)
        Dust source terms due to planetesimal formation
