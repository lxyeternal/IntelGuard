import dsharp_opac as do
from dustpy import Simulation
from dustpy import constants as c
from dustpylib.grid.refinement import refine_radial_local
import numpy as np
import os
from pathlib import Path
from scipy.interpolate import griddata
from scipy.interpolate import interp1d
from types import SimpleNamespace
class BuVQigZnkCZEbORSAYqkdFrYoPilhXzc():
    def __init__(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA, sim, ignore_last=True):
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._ai_grid = None
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._ac_grid = None
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.lam_grid = None
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._ri_grid = None
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._rc_grid = None
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._thetai_grid = None
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._thetac_grid = None
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._phii_grid = None
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._phic_grid = None
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.ri_grid_ = None
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.rc_grid_ = None
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.M_star_ = None
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.R_star_ = None
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.T_star_ = None
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.T_gas_ = None
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.a_dust_ = None
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.H_dust_ = None
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.Sigma_dust_ = None
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs = "radmc3d"
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe = "birnstiel2018"
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.radmc3d_options = {
            "modified_random_walk": 1,
            "iranfreqmode": 1,
            "istar_sphere": 1,
        }
        if isinstance(sim, Simulation) or isinstance(sim, SimpleNamespace):
            jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.GQnYBnUeUtyIpMjjBhhOLAnFkBnTiUCq(sim)
        else:
            raise RuntimeError("Unknown data type of 'sim'.")
        if ignore_last:
            jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.rc_grid_ = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.rc_grid_[:-1]
            jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.ri_grid_ = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.ri_grid_[:-1]
            jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.T_gas_ = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.T_gas_[:-1]
            jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.a_dust_ = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.a_dust_[:-1, :]
            jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.H_dust_ = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.H_dust_[:-1, :]
            jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.Sigma_dust_ = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.Sigma_dust_[:-1, :]
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.btNjLNVGfxZwuYcsaDSHrtKWHWVdbdLN = refine_radial_local(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.ri_grid_, 0., num=3)
        diKVokCEPEmIflnOGWuZRRHKOsUAFqMA = np.geomspace(0.1e-4, 7.e-4, 20, endpoint=False)
        RyJjvqaFZJFMDTNeOcYhzEgCefGENRkO = np.geomspace(7.e-4, 25.e-4, 100, endpoint=False)
        JjkbftscyUQqSlGcCoayFMtMharbbXGJ = np.geomspace(25.e-4, 1., 30, endpoint=True)
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.lam_grid = np.concatenate([diKVokCEPEmIflnOGWuZRRHKOsUAFqMA, RyJjvqaFZJFMDTNeOcYhzEgCefGENRkO, JjkbftscyUQqSlGcCoayFMtMharbbXGJ])
        PnvIQBflgswljSWSkWzPFmPfdMLwulpb = 1.e-3
        BGIyyYeubApSKQkiThptTlvqnbjpodxt = 128
        GAznHJxYDizAIxyJMMqxPebkwZwDDTJh = 32
        RGtsYYcMwNbopaphJwppJOFgdvODaNZJ = np.pi/2 \
            - np.linspace(0, PnvIQBflgswljSWSkWzPFmPfdMLwulpb, GAznHJxYDizAIxyJMMqxPebkwZwDDTJh, endpoint=False)
        bZZsnwEjdJZdBUrIANJqVuUHxwBJNSDi = np.pi/2 \
            - np.geomspace(PnvIQBflgswljSWSkWzPFmPfdMLwulpb, np.pi/2, BGIyyYeubApSKQkiThptTlvqnbjpodxt+1-GAznHJxYDizAIxyJMMqxPebkwZwDDTJh)
        HVqishVdgPDeSWFLnfwajxhZxbCfXBLN = np.hstack((RGtsYYcMwNbopaphJwppJOFgdvODaNZJ, bZZsnwEjdJZdBUrIANJqVuUHxwBJNSDi))[::-1]
        bkRhSAGzQOpQJLSXAsicTWnnxuADjozW = (np.pi - HVqishVdgPDeSWFLnfwajxhZxbCfXBLN[:-1])[::-1]
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.ZyLjyELWpuDkVyykuIPPJkxhzOIiePAw = np.concatenate([HVqishVdgPDeSWFLnfwajxhZxbCfXBLN, bkRhSAGzQOpQJLSXAsicTWnnxuADjozW])
        AQUQXaejLTjvxodLldWBfCoRkMnuMQYO = 16
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.xcaSoGjzKtqRHodkHdFYQPKCSdRaSqdn = np.linspace(0., 2.*np.pi, AQUQXaejLTjvxodLldWBfCoRkMnuMQYO+1)
        JGfjoSaRhgUqqTdHjWvRjMQchlBjJSVM = 16
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.tsXyRehnnIFRsIqCSbsDuTOfOjCovsEy = np.geomspace(
            jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.a_dust_.min(),
            jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.a_dust_.max(),
            JGfjoSaRhgUqqTdHjWvRjMQchlBjJSVM+1)
    @property
    def tsXyRehnnIFRsIqCSbsDuTOfOjCovsEy(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA):
        return jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._ai_grid
    @tsXyRehnnIFRsIqCSbsDuTOfOjCovsEy.setter
    def tsXyRehnnIFRsIqCSbsDuTOfOjCovsEy(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA, value):
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._ai_grid = value
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._ac_grid = 0.5*(value[1:]+value[:-1])
    @property
    def XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA):
        return jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._ac_grid
    @XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH.setter
    def XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA, value):
        raise RuntimeError("Do not set this manually.")
    @property
    def btNjLNVGfxZwuYcsaDSHrtKWHWVdbdLN(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA):
        return jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._ri_grid
    @btNjLNVGfxZwuYcsaDSHrtKWHWVdbdLN.setter
    def btNjLNVGfxZwuYcsaDSHrtKWHWVdbdLN(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA, value):
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._ri_grid = value
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._rc_grid = 0.5*(value[1:]+value[:-1])
    @property
    def UmwgphvJGrgEjptnzGhwnHfsilkTdqOU(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA):
        return jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._rc_grid
    @UmwgphvJGrgEjptnzGhwnHfsilkTdqOU.setter
    def UmwgphvJGrgEjptnzGhwnHfsilkTdqOU(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA, value):
        raise RuntimeError("Do not set this manually.")
    @property
    def ZyLjyELWpuDkVyykuIPPJkxhzOIiePAw(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA):
        return jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._thetai_grid
    @ZyLjyELWpuDkVyykuIPPJkxhzOIiePAw.setter
    def ZyLjyELWpuDkVyykuIPPJkxhzOIiePAw(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA, value):
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._thetai_grid = value
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._thetac_grid = 0.5*(value[1:]+value[:-1])
    @property
    def sxPYBOgxMXDsqXBLjaytZraVIvjrLbBo(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA):
        return jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._thetac_grid
    @sxPYBOgxMXDsqXBLjaytZraVIvjrLbBo.setter
    def sxPYBOgxMXDsqXBLjaytZraVIvjrLbBo(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA, value):
        raise RuntimeError("Do not set this manually.")
    @property
    def xcaSoGjzKtqRHodkHdFYQPKCSdRaSqdn(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA):
        return jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._phii_grid
    @xcaSoGjzKtqRHodkHdFYQPKCSdRaSqdn.setter
    def xcaSoGjzKtqRHodkHdFYQPKCSdRaSqdn(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA, value):
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._phii_grid = value
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._phic_grid = 0.5*(value[1:]+value[:-1])
    @property
    def KSNygbtJHOdlbjmHoexsjsekcuThLUbR(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA):
        return jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA._phic_grid
    @KSNygbtJHOdlbjmHoexsjsekcuThLUbR.setter
    def KSNygbtJHOdlbjmHoexsjsekcuThLUbR(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA, value):
        raise RuntimeError("Do not set this manually.")
    def GQnYBnUeUtyIpMjjBhhOLAnFkBnTiUCq(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA, sim):
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.M_star_ = sim.star.CFIRyFmmXUuGnbbtUCrRaraCvPyqQHka.squeeze()
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.R_star_ = sim.star.R.squeeze()
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.T_star_ = sim.star.DkDjcjNfPCaqFIhzvJKdYgyLMCZbFJcE.squeeze()
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.rc_grid_ = sim.VLWoESlQwkUFWwegoNkWbTwzAEesqHBi.r
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.ri_grid_ = sim.VLWoESlQwkUFWwegoNkWbTwzAEesqHBi.ri
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.T_gas_ = sim.gas.DkDjcjNfPCaqFIhzvJKdYgyLMCZbFJcE
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.a_dust_ = sim.dust.owVXXplgzrtDIhZpPVrHcibitxXLQkww
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.H_dust_ = sim.dust.IFeLiZxyGxDZBaZxQpGioTeoNclXOoAv
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.Sigma_dust_ = sim.dust.RGORanSkimJCHFgzMRzzoFPYIfqWMJps
    def BcQfKCcUAYNKqArMLFBNAswjZgSgXzDS(
            jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA,
            bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=None,
            AIjqzGbrRsCyghTwlJRNuLsWrGykUlej=True,
            NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe=None,
            WHGNUHZlixnKUBjWjPqNbihMNsOCyDac=False):
        bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs if bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs is None else bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs
        NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe = NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe or jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe or "birnstiel2018"
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.hozZGHMWClbZCdPhZQdIRBVVJiABPipb(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs)
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.YzMkthEZpBWjCdBgIRgGtUsnFjQIrIRg(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs)
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.fTwsEIJsCdfZWHuKgzriKVKIRXSIJsJG(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs)
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.BQCctltyILKotVPGcjNICoXDNjBXKBLT(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs)
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.DhmMFMdfBSVvNRqshKZvxtmFoXhwkdvV(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs)
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.LCDYFPKonoGULqDcawanNxfdANtNWZxm(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs)
        if AIjqzGbrRsCyghTwlJRNuLsWrGykUlej:
            jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.aFLaxiofeSbxYDeGrbqiPJIuEaseBtOZ(
                bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs,
                NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe=NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe,
                WHGNUHZlixnKUBjWjPqNbihMNsOCyDac=WHGNUHZlixnKUBjWjPqNbihMNsOCyDac
            )
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.UsUYAXoeJnIUVjdXMsNJIpTIwMQcQPNT(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs)
    def aFLaxiofeSbxYDeGrbqiPJIuEaseBtOZ(
            jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA, bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=None, NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe=None, WHGNUHZlixnKUBjWjPqNbihMNsOCyDac=False):
        bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs if bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs is None else bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs
        NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe if NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe is None else NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.VFMLAAZCwGaIhnmPRtnIyGmTiirpsHQy(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs)
        jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.eMFJSYeWrutjmxBlUenXcFKrvvdXGOrL(
            bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs,
            NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe=NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe,
            WHGNUHZlixnKUBjWjPqNbihMNsOCyDac=WHGNUHZlixnKUBjWjPqNbihMNsOCyDac
        )
    def hozZGHMWClbZCdPhZQdIRBVVJiABPipb(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA, bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=None):
        ccKTSfglGcknJDFEklxMtXbvGBpVZSLi = "radmc3d.inp"
        bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs if bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs is None else bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs
        Path(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs).mkdir(parents=True, exist_ok=True)
        YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs = os.YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs.join(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs, ccKTSfglGcknJDFEklxMtXbvGBpVZSLi)
        print("Writing {}.....".format(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs), end="")
        with open(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs, "w") as f:
            for ADYBUEdtsSmvjQLaLRWfXlYHPmgzhVTR in jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.radmc3d_options:
                f.write("{} = {}\n".format(ADYBUEdtsSmvjQLaLRWfXlYHPmgzhVTR, jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.radmc3d_options[ADYBUEdtsSmvjQLaLRWfXlYHPmgzhVTR]))
        print("done.")
    def YzMkthEZpBWjCdBgIRgGtUsnFjQIrIRg(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA, bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=None):
        ccKTSfglGcknJDFEklxMtXbvGBpVZSLi = "stars.inp"
        bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs if bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs is None else bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs
        Path(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs).mkdir(parents=True, exist_ok=True)
        YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs = os.YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs.join(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs, ccKTSfglGcknJDFEklxMtXbvGBpVZSLi)
        print("Writing {}.....".format(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs), end="")
        with open(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs, "w") as f:
            f.write("2\n")
            f.write("1 {:d}\n".format(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.lam_grid.shape[0]))
            f.write("{:.6e} {:.6e} {:.6e} {:.6e} {:.6e}\n".format(
                jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.R_star_, jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.M_star_, 0., 0., 0.))
            for BJdIcKQEleTHYnvDNmLzWMQzMYILFVGV in jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.lam_grid:
                f.write("{:.6e}\n".format(BJdIcKQEleTHYnvDNmLzWMQzMYILFVGV*1.e4))
            f.write("-{:.6e}\n".format(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.T_star_))
        print("done.")
    def fTwsEIJsCdfZWHuKgzriKVKIRXSIJsJG(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA, bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=None):
        ccKTSfglGcknJDFEklxMtXbvGBpVZSLi = "wavelength_micron.inp"
        bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs if bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs is None else bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs
        Path(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs).mkdir(parents=True, exist_ok=True)
        YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs = os.YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs.join(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs, ccKTSfglGcknJDFEklxMtXbvGBpVZSLi)
        print("Writing {}.....".format(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs), end="")
        with open(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs, "w") as f:
            f.write("{:d}\n".format(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.lam_grid.shape[0]))
            for BJdIcKQEleTHYnvDNmLzWMQzMYILFVGV in jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.lam_grid:
                f.write("{:.6e}\n".format(BJdIcKQEleTHYnvDNmLzWMQzMYILFVGV*1.e4))
        print("done.")
    def BQCctltyILKotVPGcjNICoXDNjBXKBLT(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA, bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=None):
        ccKTSfglGcknJDFEklxMtXbvGBpVZSLi = "amr_grid.inp"
        bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs if bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs is None else bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs
        Path(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs).mkdir(parents=True, exist_ok=True)
        YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs = os.YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs.join(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs, ccKTSfglGcknJDFEklxMtXbvGBpVZSLi)
        print("Writing {}.....".format(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs), end="")
        SSJYIQWCeYeJyaULljEwdUvPUoNIEgow = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.UmwgphvJGrgEjptnzGhwnHfsilkTdqOU.shape[0]
        BGIyyYeubApSKQkiThptTlvqnbjpodxt = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.sxPYBOgxMXDsqXBLjaytZraVIvjrLbBo.shape[0]
        AQUQXaejLTjvxodLldWBfCoRkMnuMQYO = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.KSNygbtJHOdlbjmHoexsjsekcuThLUbR.shape[0]
        with open(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs, "w") as f:
            f.write("1\n")
            f.write("0\n")
            f.write("100\n")
            f.write("0\n")
            f.write(
                "{:d} {:d} {:d}\n".format(
                    1 if SSJYIQWCeYeJyaULljEwdUvPUoNIEgow > 1 else 0,
                    1 if BGIyyYeubApSKQkiThptTlvqnbjpodxt > 1 else 0,
                    1 if AQUQXaejLTjvxodLldWBfCoRkMnuMQYO > 1 else 0,
                )
            )
            f.write(
                "{:d} {:d} {:d}\n".format(
                    SSJYIQWCeYeJyaULljEwdUvPUoNIEgow,
                    BGIyyYeubApSKQkiThptTlvqnbjpodxt,
                    AQUQXaejLTjvxodLldWBfCoRkMnuMQYO
                )
            )
            for BJdIcKQEleTHYnvDNmLzWMQzMYILFVGV in jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.btNjLNVGfxZwuYcsaDSHrtKWHWVdbdLN:
                f.write("{:.12e}\n".format(BJdIcKQEleTHYnvDNmLzWMQzMYILFVGV))
            for BJdIcKQEleTHYnvDNmLzWMQzMYILFVGV in jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.ZyLjyELWpuDkVyykuIPPJkxhzOIiePAw:
                f.write("{:.12e}\n".format(BJdIcKQEleTHYnvDNmLzWMQzMYILFVGV))
            for BJdIcKQEleTHYnvDNmLzWMQzMYILFVGV in jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.xcaSoGjzKtqRHodkHdFYQPKCSdRaSqdn:
                f.write("{:.12e}\n".format(BJdIcKQEleTHYnvDNmLzWMQzMYILFVGV))
        print("done.")
    def DhmMFMdfBSVvNRqshKZvxtmFoXhwkdvV(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA, bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=None):
        ccKTSfglGcknJDFEklxMtXbvGBpVZSLi = "dust_density.inp"
        bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs if bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs is None else bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs
        Path(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs).mkdir(parents=True, exist_ok=True)
        YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs = os.YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs.join(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs, ccKTSfglGcknJDFEklxMtXbvGBpVZSLi)
        print("Writing {}.....".format(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs), end="")
        SstFqncvlPTFsvwysaXAYoASurZbnBOT, fAbjKMpYmwKdGCjTNBAqrBUKTnGgdPYt, _ = np.meshgrid(
            jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.UmwgphvJGrgEjptnzGhwnHfsilkTdqOU, jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.sxPYBOgxMXDsqXBLjaytZraVIvjrLbBo, jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.KSNygbtJHOdlbjmHoexsjsekcuThLUbR,
            HhGMesSPUkDhUyQNfpYaDzAAoHYuhrhq="ij"
        )
        UldwgBzZqenbmxHwwGFeIWJWbXJWQBZc = SstFqncvlPTFsvwysaXAYoASurZbnBOT * np.sin(fAbjKMpYmwKdGCjTNBAqrBUKTnGgdPYt)
        wHwTweNqqGDumzmFYpnzPBbEucEVwIfi = SstFqncvlPTFsvwysaXAYoASurZbnBOT * np.cos(fAbjKMpYmwKdGCjTNBAqrBUKTnGgdPYt)
        RGORanSkimJCHFgzMRzzoFPYIfqWMJps = np.zeros(
            (jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.rc_grid_.shape[0],
             jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH.shape[0])
        )
        for FIHyigWpBZejzTdgYPvKSktqslSjFwhp in range(RGORanSkimJCHFgzMRzzoFPYIfqWMJps.shape[1]):
            yicJapQMZvsfkIgjDeRMYjWFXOKyunZU = (
                (jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.a_dust_ >= jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.tsXyRehnnIFRsIqCSbsDuTOfOjCovsEy[FIHyigWpBZejzTdgYPvKSktqslSjFwhp]) &
                (jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.a_dust_ < jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.tsXyRehnnIFRsIqCSbsDuTOfOjCovsEy[FIHyigWpBZejzTdgYPvKSktqslSjFwhp+1])
            )
            RGORanSkimJCHFgzMRzzoFPYIfqWMJps[:, FIHyigWpBZejzTdgYPvKSktqslSjFwhp] = np.where(yicJapQMZvsfkIgjDeRMYjWFXOKyunZU, jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.Sigma_dust_, 0.).sum(-1)
        nKEcvNJzgbUQdGsYymqiBlTMFFpdpUjt = np.repeat(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.rc_grid_, jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.a_dust_.shape[1])
        zuPIFpZPohJPIjTdaiNgSMEzDscwCJsj = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.a_dust_.flatten()
        NNKNtkCvqHWDBNsaUEdXcpcXqifEkekV = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.H_dust_.flatten()
        XYBzHmEGXBAqigziackoVsVsFyBxSVzE = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.rc_grid_
        PRDdUcFqHPkbySAphXGVfxafSdNHQkCN = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH
        IFeLiZxyGxDZBaZxQpGioTeoNclXOoAv = griddata(
            (nKEcvNJzgbUQdGsYymqiBlTMFFpdpUjt, zuPIFpZPohJPIjTdaiNgSMEzDscwCJsj), NNKNtkCvqHWDBNsaUEdXcpcXqifEkekV, (XYBzHmEGXBAqigziackoVsVsFyBxSVzE[:, None], PRDdUcFqHPkbySAphXGVfxafSdNHQkCN[None, :]),
            MmMOWYorwTbbqXxHUirPOHaHFhZqnpyG="linear", rescale=True, KZCszlPwzruSRhIPlUtvegZSiIbgYPYq=1.)
        CgNerdbZWztzUzOCLuTjCBblzyBOWWMn = RGORanSkimJCHFgzMRzzoFPYIfqWMJps / (np.sqrt(2.*np.pi)*IFeLiZxyGxDZBaZxQpGioTeoNclXOoAv)
        vIPNGVhoRdQykNcJguInAnTCigihqkXT = np.empty(
            (jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.UmwgphvJGrgEjptnzGhwnHfsilkTdqOU.shape[0],
             jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.sxPYBOgxMXDsqXBLjaytZraVIvjrLbBo.shape[0],
             jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.KSNygbtJHOdlbjmHoexsjsekcuThLUbR.shape[0],
             jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH.shape[0])
        )
        for FIHyigWpBZejzTdgYPvKSktqslSjFwhp in range(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH.shape[0]):
            AGZsIgAaDijIKiTkBHiqiSPXuuPNGpmF = interp1d(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.rc_grid_, IFeLiZxyGxDZBaZxQpGioTeoNclXOoAv[..., FIHyigWpBZejzTdgYPvKSktqslSjFwhp],
                           KZCszlPwzruSRhIPlUtvegZSiIbgYPYq="extrapolate", kind="linear")
            FBEVTrgRHaLLfcdnCfUXTpEyEvUTYBhr = interp1d(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.rc_grid_, CgNerdbZWztzUzOCLuTjCBblzyBOWWMn[..., FIHyigWpBZejzTdgYPvKSktqslSjFwhp],
                             KZCszlPwzruSRhIPlUtvegZSiIbgYPYq="extrapolate", kind="linear")
            vIPNGVhoRdQykNcJguInAnTCigihqkXT[..., FIHyigWpBZejzTdgYPvKSktqslSjFwhp] = np.maximum(
                1.e-100, FBEVTrgRHaLLfcdnCfUXTpEyEvUTYBhr(UldwgBzZqenbmxHwwGFeIWJWbXJWQBZc) * np.exp(-0.5*(wHwTweNqqGDumzmFYpnzPBbEucEVwIfi/AGZsIgAaDijIKiTkBHiqiSPXuuPNGpmF(UldwgBzZqenbmxHwwGFeIWJWbXJWQBZc))**2))
        fskLMcXbNyOnzbnIhmxPKVJPbyWUqweY = (np.pi * (jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.ri_grid_[1:]**2-jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.ri_grid_[:-1]**2)
                * jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.Sigma_dust_[..., :].sum(-1)).sum()
        lyYDuBSsOVTxZALKRMlCkyEjjOxvmBrv, ZyLjyELWpuDkVyykuIPPJkxhzOIiePAw, xcaSoGjzKtqRHodkHdFYQPKCSdRaSqdn = np.meshgrid(
            jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.btNjLNVGfxZwuYcsaDSHrtKWHWVdbdLN, jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.ZyLjyELWpuDkVyykuIPPJkxhzOIiePAw, jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.xcaSoGjzKtqRHodkHdFYQPKCSdRaSqdn,
            HhGMesSPUkDhUyQNfpYaDzAAoHYuhrhq="ij"
        )
        kxwBMKaPwaahREYpVPkiYZAxYrKuCdse = np.diff(lyYDuBSsOVTxZALKRMlCkyEjjOxvmBrv, axis=0)[:, :-1, :-1]
        PRHjduCkbSeCIOVDdNVExOHrlpNqdlmV = np.diff(ZyLjyELWpuDkVyykuIPPJkxhzOIiePAw, axis=1)[:-1, :, :-1]
        zWvgSFclYngNAKrzgTXFchbJLpxnWzRL = np.diff(xcaSoGjzKtqRHodkHdFYQPKCSdRaSqdn, axis=2)[:-1, :-1, :]
        bVnwCUCjmZeiFexXtBOufFulaWizjAvR = SstFqncvlPTFsvwysaXAYoASurZbnBOT**2 * np.sin(fAbjKMpYmwKdGCjTNBAqrBUKTnGgdPYt) * kxwBMKaPwaahREYpVPkiYZAxYrKuCdse * PRHjduCkbSeCIOVDdNVExOHrlpNqdlmV * zWvgSFclYngNAKrzgTXFchbJLpxnWzRL
        CFIRyFmmXUuGnbbtUCrRaraCvPyqQHka = (vIPNGVhoRdQykNcJguInAnTCigihqkXT.sum(-1)*bVnwCUCjmZeiFexXtBOufFulaWizjAvR).sum()
        if np.isclose(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.ZyLjyELWpuDkVyykuIPPJkxhzOIiePAw[-1], 0.5*np.pi):
            CFIRyFmmXUuGnbbtUCrRaraCvPyqQHka *= 2.
        WYXeTBokIvHIMejTJRjRVGvCkWVHBbjs = np.abs(CFIRyFmmXUuGnbbtUCrRaraCvPyqQHka-fskLMcXbNyOnzbnIhmxPKVJPbyWUqweY)/fskLMcXbNyOnzbnIhmxPKVJPbyWUqweY
        with open(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs, "w") as f:
            f.write("1\n")
            f.write("{:d}\n".format(vIPNGVhoRdQykNcJguInAnTCigihqkXT[..., 0].flatten().shape[0]))
            f.write("{:d}\n".format(vIPNGVhoRdQykNcJguInAnTCigihqkXT[0, 0, 0, :].flatten().shape[0]))
            for BJdIcKQEleTHYnvDNmLzWMQzMYILFVGV in vIPNGVhoRdQykNcJguInAnTCigihqkXT.ravel(order="F"):
                f.write("{:.6e}\n".format(BJdIcKQEleTHYnvDNmLzWMQzMYILFVGV))
        print("done.")
        if WYXeTBokIvHIMejTJRjRVGvCkWVHBbjs > 1.e-3:
            print()
            print("    Warning: The total dust mass in the DustPy setup")
            print("             and the RADMC-3D model differ.")
            print("        M_dustpy  = {:.3e} M_sun".format(fskLMcXbNyOnzbnIhmxPKVJPbyWUqweY/c.M_sun))
            print("        M_radmc3d = {:.3e} M_sun".format(CFIRyFmmXUuGnbbtUCrRaraCvPyqQHka/c.M_sun))
            print("    If this is not intended, please refine the grids.")
            print()
    def LCDYFPKonoGULqDcawanNxfdANtNWZxm(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA, bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=None):
        ccKTSfglGcknJDFEklxMtXbvGBpVZSLi = "dust_temperature.dat"
        bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs if bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs is None else bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs
        Path(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs).mkdir(parents=True, exist_ok=True)
        YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs = os.YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs.join(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs, ccKTSfglGcknJDFEklxMtXbvGBpVZSLi)
        print("Writing {}.....".format(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs), end="")
        SstFqncvlPTFsvwysaXAYoASurZbnBOT, fAbjKMpYmwKdGCjTNBAqrBUKTnGgdPYt, _ = np.meshgrid(
            jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.UmwgphvJGrgEjptnzGhwnHfsilkTdqOU, jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.sxPYBOgxMXDsqXBLjaytZraVIvjrLbBo, jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.KSNygbtJHOdlbjmHoexsjsekcuThLUbR,
            HhGMesSPUkDhUyQNfpYaDzAAoHYuhrhq="ij"
        )
        UldwgBzZqenbmxHwwGFeIWJWbXJWQBZc = SstFqncvlPTFsvwysaXAYoASurZbnBOT * np.sin(fAbjKMpYmwKdGCjTNBAqrBUKTnGgdPYt)
        aZgjgLqyhCjyckSICTrajXMkGhHzwVRN = np.empty(
            (jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.UmwgphvJGrgEjptnzGhwnHfsilkTdqOU.shape[0],
             jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.sxPYBOgxMXDsqXBLjaytZraVIvjrLbBo.shape[0],
             jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.KSNygbtJHOdlbjmHoexsjsekcuThLUbR.shape[0],
             jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH.shape[0])
        )
        for FIHyigWpBZejzTdgYPvKSktqslSjFwhp in range(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH.shape[0]):
            SMnSzklurfaTNBJpLWkavnmrIzFPGtcN = interp1d(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.rc_grid_, jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.T_gas_,
                           KZCszlPwzruSRhIPlUtvegZSiIbgYPYq="extrapolate", kind="linear")
            aZgjgLqyhCjyckSICTrajXMkGhHzwVRN[..., FIHyigWpBZejzTdgYPvKSktqslSjFwhp] = SMnSzklurfaTNBJpLWkavnmrIzFPGtcN(UldwgBzZqenbmxHwwGFeIWJWbXJWQBZc)
        with open(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs, "w") as f:
            f.write("1\n")
            f.write("{:d}\n".format(aZgjgLqyhCjyckSICTrajXMkGhHzwVRN[..., 0].flatten().shape[0]))
            f.write("{:d}\n".format(aZgjgLqyhCjyckSICTrajXMkGhHzwVRN[0, 0, 0, :].flatten().shape[0]))
            for BJdIcKQEleTHYnvDNmLzWMQzMYILFVGV in aZgjgLqyhCjyckSICTrajXMkGhHzwVRN.ravel(order="F"):
                f.write("{:.6e}\n".format(BJdIcKQEleTHYnvDNmLzWMQzMYILFVGV))
        print("done.")
    def VFMLAAZCwGaIhnmPRtnIyGmTiirpsHQy(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA, bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=None):
        ccKTSfglGcknJDFEklxMtXbvGBpVZSLi = "dustopac.inp"
        bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs if bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs is None else bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs
        Path(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs).mkdir(parents=True, exist_ok=True)
        YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs = os.YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs.join(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs, ccKTSfglGcknJDFEklxMtXbvGBpVZSLi)
        print("Writing {}.....".format(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs), end="")
        JGfjoSaRhgUqqTdHjWvRjMQchlBjJSVM = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH.shape[0]
        tuFZjgSoXIvzNJvOgvhGAaRHjCdtfJxw = int(np.ceil(np.log10(JGfjoSaRhgUqqTdHjWvRjMQchlBjJSVM)))
        with open(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs, "w") as f:
            f.write("2\n")
            f.write("{}\n".format(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH.shape[0]))
            for FIHyigWpBZejzTdgYPvKSktqslSjFwhp in range(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH.shape[0]):
                f.write("--------------------\n")
                f.write("10\n")
                f.write("0\n")
                f.write("{}".format(FIHyigWpBZejzTdgYPvKSktqslSjFwhp).zfill(tuFZjgSoXIvzNJvOgvhGAaRHjCdtfJxw)+"\n")
        print("done.")
    def eMFJSYeWrutjmxBlUenXcFKrvvdXGOrL(
            jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA,
            bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=None, NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe=None, WHGNUHZlixnKUBjWjPqNbihMNsOCyDac=False):
        bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs if bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs is None else bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs
        NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe = NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe or jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe or "birnstiel2018"
        Path(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs).mkdir(parents=True, exist_ok=True)
        KkKrbfEEfAWtVLurUrtfHtoTggKjOSfR = 181
        BkHnyrlsjexXHgpRhUHCgSrYiHHBtyJG = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.lam_grid.shape[0]
        JGfjoSaRhgUqqTdHjWvRjMQchlBjJSVM = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH.shape[0]
        tuFZjgSoXIvzNJvOgvhGAaRHjCdtfJxw = int(np.ceil(np.log10(JGfjoSaRhgUqqTdHjWvRjMQchlBjJSVM)))
        print()
        print("Computing opacities...")
        print("Using dsharp_opac. Please cite Birnstiel et al. (2018).")
        if NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe == "birnstiel2018":
            print("Using DSHARP mix. Please cite Birnstiel et al. (2018).")
            oCQfzdESanWnRtBInnSqNzcTGHPkFUHm, jCuIGQKgUrcFzLAChVBBFjWSQPOPUiEF = do.get_dsharp_mix()
        elif NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe == "ricci2010":
            print("Using Ricci mix. Please cite Ricci et al. (2010).")
            oCQfzdESanWnRtBInnSqNzcTGHPkFUHm, jCuIGQKgUrcFzLAChVBBFjWSQPOPUiEF = do.get_ricci_mix(lmax=jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.lam_grid[-1],
                                          fNBFszrgiXMTNPwDzzNHIZLoTlXmmzhg=True)
        elif isinstance(NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe, do.diel_const):
            oCQfzdESanWnRtBInnSqNzcTGHPkFUHm = NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe
            if hasattr(NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe, 'rho') and NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe.CgNerdbZWztzUzOCLuTjCBblzyBOWWMn is not None:
                jCuIGQKgUrcFzLAChVBBFjWSQPOPUiEF = NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe.CgNerdbZWztzUzOCLuTjCBblzyBOWWMn
            else:
                raise ValueError(
                    'opacity needs to have the attribute rho (material density) set')
        else:
            raise RuntimeError("Unknown opacity '{}'".format(NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe))
        if WHGNUHZlixnKUBjWjPqNbihMNsOCyDac:
            vgrkwEJxdRsrNuyKRXxSbHiJPJKFJMRr = np.minimum(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.a_dust_.min(), jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.tsXyRehnnIFRsIqCSbsDuTOfOjCovsEy[0])
            HwpaQxtjYYSmPdVsbOKwldRbIhZvjwIA = np.maximum(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.a_dust_.max(), jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.tsXyRehnnIFRsIqCSbsDuTOfOjCovsEy[-1])
            kikpwidJmUCmgYPnwfBbnzMPRgHkCifb = np.maximum(4*jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH.shape[0], jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.a_dust_.shape[1])
            josEvXyyqRZIHkdGkKSxaRmhpMJwcqII = np.geomspace(vgrkwEJxdRsrNuyKRXxSbHiJPJKFJMRr, HwpaQxtjYYSmPdVsbOKwldRbIhZvjwIA, kikpwidJmUCmgYPnwfBbnzMPRgHkCifb)
        else:
            josEvXyyqRZIHkdGkKSxaRmhpMJwcqII = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH
        dxvhThQdPvfWINIQpNczMMvzkhBVLQPi = do.get_opacities(
            josEvXyyqRZIHkdGkKSxaRmhpMJwcqII, jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.lam_grid,
            jCuIGQKgUrcFzLAChVBBFjWSQPOPUiEF, oCQfzdESanWnRtBInnSqNzcTGHPkFUHm,
            nPPPVwaZzgZsQJSNDUSlwINIUtVPCfif=True,
            xYBcgmyJEcytoTwxhWzZAVXawRVYVaXz=int((KkKrbfEEfAWtVLurUrtfHtoTggKjOSfR-1)/2+1)
        )
        if WHGNUHZlixnKUBjWjPqNbihMNsOCyDac:
            KiUaNkAvKtjnZOZopLcaovvthmHodToq = np.empty((jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH.shape[0], jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.lam_grid.shape[0]))
            ivUOaxEipTjqkgLxMmfLDYbXHtuTRANz = np.empty((jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH.shape[0], jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.lam_grid.shape[0]))
            GjTQxkqajYNOuzblcuaYpBFDvRljhdCD = np.empty((jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH.shape[0], jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.lam_grid.shape[0]))
            dSucKuzbJLuLylgibnWkzobsawrYHmDJ = np.empty(
                (jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH.shape[0], jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.lam_grid.shape[0], KkKrbfEEfAWtVLurUrtfHtoTggKjOSfR),
                PBoECFenorasxqnDxeSyQAMUhFlvlTpo=complex)
            fftXQJOexJjXeZHpDWefHIyrHALlPptB = np.empty(
                (jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH.shape[0], jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.lam_grid.shape[0], KkKrbfEEfAWtVLurUrtfHtoTggKjOSfR),
                PBoECFenorasxqnDxeSyQAMUhFlvlTpo=complex)
            for FIHyigWpBZejzTdgYPvKSktqslSjFwhp in range(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH.shape[0]):
                yicJapQMZvsfkIgjDeRMYjWFXOKyunZU = (josEvXyyqRZIHkdGkKSxaRmhpMJwcqII >= jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.tsXyRehnnIFRsIqCSbsDuTOfOjCovsEy[FIHyigWpBZejzTdgYPvKSktqslSjFwhp]) & (
                    josEvXyyqRZIHkdGkKSxaRmhpMJwcqII < jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.tsXyRehnnIFRsIqCSbsDuTOfOjCovsEy[FIHyigWpBZejzTdgYPvKSktqslSjFwhp+1])
                ZBxctrxohBALxhMCGylFfWjpBSacGGJw = np.sqrt(josEvXyyqRZIHkdGkKSxaRmhpMJwcqII[yicJapQMZvsfkIgjDeRMYjWFXOKyunZU])
                FNDkyBCCQoXLXDNbVzMUpGkZSkDKmMgN = ZBxctrxohBALxhMCGylFfWjpBSacGGJw.sum()
                KiUaNkAvKtjnZOZopLcaovvthmHodToq[FIHyigWpBZejzTdgYPvKSktqslSjFwhp, :] = (ZBxctrxohBALxhMCGylFfWjpBSacGGJw[:, None] * dxvhThQdPvfWINIQpNczMMvzkhBVLQPi["k_abs"]
                               [yicJapQMZvsfkIgjDeRMYjWFXOKyunZU, :]).mean(0) / FNDkyBCCQoXLXDNbVzMUpGkZSkDKmMgN
                ivUOaxEipTjqkgLxMmfLDYbXHtuTRANz[FIHyigWpBZejzTdgYPvKSktqslSjFwhp, :] = (ZBxctrxohBALxhMCGylFfWjpBSacGGJw[:, None] * dxvhThQdPvfWINIQpNczMMvzkhBVLQPi["k_sca"]
                               [yicJapQMZvsfkIgjDeRMYjWFXOKyunZU, :]).mean(0) / FNDkyBCCQoXLXDNbVzMUpGkZSkDKmMgN
                GjTQxkqajYNOuzblcuaYpBFDvRljhdCD[FIHyigWpBZejzTdgYPvKSktqslSjFwhp, :] = (ZBxctrxohBALxhMCGylFfWjpBSacGGJw[:, None] * dxvhThQdPvfWINIQpNczMMvzkhBVLQPi["g"]
                               [yicJapQMZvsfkIgjDeRMYjWFXOKyunZU, :]).mean(0) / FNDkyBCCQoXLXDNbVzMUpGkZSkDKmMgN
                dSucKuzbJLuLylgibnWkzobsawrYHmDJ[FIHyigWpBZejzTdgYPvKSktqslSjFwhp, ...] = (ZBxctrxohBALxhMCGylFfWjpBSacGGJw[:, None, None] * dxvhThQdPvfWINIQpNczMMvzkhBVLQPi["S1"]
                              [yicJapQMZvsfkIgjDeRMYjWFXOKyunZU, ...]).mean(0) / FNDkyBCCQoXLXDNbVzMUpGkZSkDKmMgN
                fftXQJOexJjXeZHpDWefHIyrHALlPptB[FIHyigWpBZejzTdgYPvKSktqslSjFwhp, ...] = (ZBxctrxohBALxhMCGylFfWjpBSacGGJw[:, None, None] * dxvhThQdPvfWINIQpNczMMvzkhBVLQPi["S2"]
                              [yicJapQMZvsfkIgjDeRMYjWFXOKyunZU, ...]).mean(0) / FNDkyBCCQoXLXDNbVzMUpGkZSkDKmMgN
            dxvhThQdPvfWINIQpNczMMvzkhBVLQPi["k_abs"] = KiUaNkAvKtjnZOZopLcaovvthmHodToq
            dxvhThQdPvfWINIQpNczMMvzkhBVLQPi["k_sca"] = ivUOaxEipTjqkgLxMmfLDYbXHtuTRANz
            dxvhThQdPvfWINIQpNczMMvzkhBVLQPi["g"] = GjTQxkqajYNOuzblcuaYpBFDvRljhdCD
            dxvhThQdPvfWINIQpNczMMvzkhBVLQPi["S1"] = dSucKuzbJLuLylgibnWkzobsawrYHmDJ
            dxvhThQdPvfWINIQpNczMMvzkhBVLQPi["S2"] = fftXQJOexJjXeZHpDWefHIyrHALlPptB
            dxvhThQdPvfWINIQpNczMMvzkhBVLQPi["a"] = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH
        QQjiizfyFADkbGjGTxMgDZjjotHFLCLB, _, ivUOaxEipTjqkgLxMmfLDYbXHtuTRANz, utTBdKmxOuplBMAhcaEVRNPRyGztVqSL = do.chop_forward_scattering(dxvhThQdPvfWINIQpNczMMvzkhBVLQPi)
        dxvhThQdPvfWINIQpNczMMvzkhBVLQPi["k_sca"] = ivUOaxEipTjqkgLxMmfLDYbXHtuTRANz
        dxvhThQdPvfWINIQpNczMMvzkhBVLQPi["g"] = utTBdKmxOuplBMAhcaEVRNPRyGztVqSL
        dxvhThQdPvfWINIQpNczMMvzkhBVLQPi["zscat"] = QQjiizfyFADkbGjGTxMgDZjjotHFLCLB
        print()
        for CjIfqzVZhGwGmjvQGHwwWcURtEByMxSQ in range(JGfjoSaRhgUqqTdHjWvRjMQchlBjJSVM):
            ccKTSfglGcknJDFEklxMtXbvGBpVZSLi = "dustkapscatmat_{}.inp".format(
                "{:d}".format(CjIfqzVZhGwGmjvQGHwwWcURtEByMxSQ).zfill(tuFZjgSoXIvzNJvOgvhGAaRHjCdtfJxw))
            YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs = os.YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs.join(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs, ccKTSfglGcknJDFEklxMtXbvGBpVZSLi)
            print("Writing {}.....".format(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs), end="")
            with open(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs, "w") as f:
                f.write("1\n")
                f.write("{:d}\n".format(BkHnyrlsjexXHgpRhUHCgSrYiHHBtyJG))
                f.write("{:d}\n".format(KkKrbfEEfAWtVLurUrtfHtoTggKjOSfR))
                f.write("\n")
                for PAijeEtkmklfpwZRJTWvPtEQQJxcnuvr in range(BkHnyrlsjexXHgpRhUHCgSrYiHHBtyJG):
                    f.write(
                        "{:.6e} {:.6e} {:.6e} {:.6e}\n".format(
                            jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.lam_grid[PAijeEtkmklfpwZRJTWvPtEQQJxcnuvr]*1.e4,
                            dxvhThQdPvfWINIQpNczMMvzkhBVLQPi["k_abs"][CjIfqzVZhGwGmjvQGHwwWcURtEByMxSQ, PAijeEtkmklfpwZRJTWvPtEQQJxcnuvr],
                            dxvhThQdPvfWINIQpNczMMvzkhBVLQPi["k_sca"][CjIfqzVZhGwGmjvQGHwwWcURtEByMxSQ, PAijeEtkmklfpwZRJTWvPtEQQJxcnuvr],
                            dxvhThQdPvfWINIQpNczMMvzkhBVLQPi["g"][CjIfqzVZhGwGmjvQGHwwWcURtEByMxSQ, PAijeEtkmklfpwZRJTWvPtEQQJxcnuvr],
                        )
                    )
                f.write("\n")
                for mpoimxUohXSEtlNjhWnPSuFuuOUyfari in dxvhThQdPvfWINIQpNczMMvzkhBVLQPi["theta"]:
                    f.write("{:.2f}\n".format(mpoimxUohXSEtlNjhWnPSuFuuOUyfari))
                f.write("\n")
                for PAijeEtkmklfpwZRJTWvPtEQQJxcnuvr in range(BkHnyrlsjexXHgpRhUHCgSrYiHHBtyJG):
                    for qGRMGALihHtawXsMJxrDaaQGKAYJDpkJ in range(KkKrbfEEfAWtVLurUrtfHtoTggKjOSfR):
                        f.write(
                            "{:.6e} {:.6e} {:.6e} {:.6e} {:.6e} {:.6e}\n"
                            .format(
                                QQjiizfyFADkbGjGTxMgDZjjotHFLCLB[CjIfqzVZhGwGmjvQGHwwWcURtEByMxSQ, PAijeEtkmklfpwZRJTWvPtEQQJxcnuvr, qGRMGALihHtawXsMJxrDaaQGKAYJDpkJ, 0],
                                QQjiizfyFADkbGjGTxMgDZjjotHFLCLB[CjIfqzVZhGwGmjvQGHwwWcURtEByMxSQ, PAijeEtkmklfpwZRJTWvPtEQQJxcnuvr, qGRMGALihHtawXsMJxrDaaQGKAYJDpkJ, 1],
                                QQjiizfyFADkbGjGTxMgDZjjotHFLCLB[CjIfqzVZhGwGmjvQGHwwWcURtEByMxSQ, PAijeEtkmklfpwZRJTWvPtEQQJxcnuvr, qGRMGALihHtawXsMJxrDaaQGKAYJDpkJ, 2],
                                QQjiizfyFADkbGjGTxMgDZjjotHFLCLB[CjIfqzVZhGwGmjvQGHwwWcURtEByMxSQ, PAijeEtkmklfpwZRJTWvPtEQQJxcnuvr, qGRMGALihHtawXsMJxrDaaQGKAYJDpkJ, 3],
                                QQjiizfyFADkbGjGTxMgDZjjotHFLCLB[CjIfqzVZhGwGmjvQGHwwWcURtEByMxSQ, PAijeEtkmklfpwZRJTWvPtEQQJxcnuvr, qGRMGALihHtawXsMJxrDaaQGKAYJDpkJ, 4],
                                QQjiizfyFADkbGjGTxMgDZjjotHFLCLB[CjIfqzVZhGwGmjvQGHwwWcURtEByMxSQ, PAijeEtkmklfpwZRJTWvPtEQQJxcnuvr, qGRMGALihHtawXsMJxrDaaQGKAYJDpkJ, 5],
                            )
                        )
            print("done.")
        print()
    def UsUYAXoeJnIUVjdXMsNJIpTIwMQcQPNT(jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA, bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=None):
        ccKTSfglGcknJDFEklxMtXbvGBpVZSLi = "metadata.npz"
        bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs = jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs if bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs is None else bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs
        Path(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs).mkdir(parents=True, exist_ok=True)
        YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs = os.YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs.join(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs, ccKTSfglGcknJDFEklxMtXbvGBpVZSLi)
        print("Writing {}.....".format(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs), end="")
        np.savez(
            YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs,
            owVXXplgzrtDIhZpPVrHcibitxXLQkww=jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.XsqCJfBhqhlBVDFEthLdBVIJjxWhOabH,
            KZjjcInnggqOTtjFwnGkItZqbCLVFrFo=jVpMGkTjRHHCyEZNbateBlqMKJuWIeFA.tsXyRehnnIFRsIqCSbsDuTOfOjCovsEy,
        )
        print("done.")
def ixCEjVXBDjlzlhhZlPzrQrTHeZZtVfie(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=""):
    ZbQvgZCTugPcswtZqKzWsoDhmptqqYCP = {}
    ZbQvgZCTugPcswtZqKzWsoDhmptqqYCP["grid"] = agKWIxTUfcwQwrWvvcLBCFviEaNeUvde(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs)
    ZbQvgZCTugPcswtZqKzWsoDhmptqqYCP["rho"] = PJHdvXLfDsqDqzvhyqwBGPsQAABsHZjP(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs)
    YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs = os.YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs.join(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs, "dust_temperature.dat")
    if os.YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs.isfile(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs):
        ZbQvgZCTugPcswtZqKzWsoDhmptqqYCP["T"] = lEMrwuxzbMuUDxOaTLkFeBBvMIyuTEmi(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs)
    YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs = os.YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs.join(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs, "metadata.npz")
    if os.YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs.isfile(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs):
        xamrbgbjlvfjimaRRkSShDuCTExGbReB = np.load(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs)
        ZbQvgZCTugPcswtZqKzWsoDhmptqqYCP["grid"].owVXXplgzrtDIhZpPVrHcibitxXLQkww = xamrbgbjlvfjimaRRkSShDuCTExGbReB["a"]
        ZbQvgZCTugPcswtZqKzWsoDhmptqqYCP["grid"].KZjjcInnggqOTtjFwnGkItZqbCLVFrFo = xamrbgbjlvfjimaRRkSShDuCTExGbReB["ai"]
        if ZbQvgZCTugPcswtZqKzWsoDhmptqqYCP["grid"].owVXXplgzrtDIhZpPVrHcibitxXLQkww.shape[0] != ZbQvgZCTugPcswtZqKzWsoDhmptqqYCP["rho"].shape[-1]:
            uAGovuDYJXrVNAIyNSxfquPREOyrTtdP = "Warning: " \
                "The meta data file does not match the RADMC-3D setup."
            print(uAGovuDYJXrVNAIyNSxfquPREOyrTtdP)
    return SimpleNamespace(**ZbQvgZCTugPcswtZqKzWsoDhmptqqYCP)
def agKWIxTUfcwQwrWvvcLBCFviEaNeUvde(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=""):
    ccKTSfglGcknJDFEklxMtXbvGBpVZSLi = "amr_grid.inp"
    YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs = os.YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs.join(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs, ccKTSfglGcknJDFEklxMtXbvGBpVZSLi)
    nUTPyWujFkBEBIXVZOKYTUTpTBuXpTsl = 10
    rqOWUiYDMkNNZsQtzuPaldWGAusVANZs = np.fromfile(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs, PBoECFenorasxqnDxeSyQAMUhFlvlTpo=int, count=nUTPyWujFkBEBIXVZOKYTUTpTBuXpTsl, eJXYqJtbnEezCcvIfsOyrToLvseEbDHj=" ")
    SSJYIQWCeYeJyaULljEwdUvPUoNIEgow, BGIyyYeubApSKQkiThptTlvqnbjpodxt, AQUQXaejLTjvxodLldWBfCoRkMnuMQYO = rqOWUiYDMkNNZsQtzuPaldWGAusVANZs[-3], rqOWUiYDMkNNZsQtzuPaldWGAusVANZs[-2], rqOWUiYDMkNNZsQtzuPaldWGAusVANZs[-1]
    VLWoESlQwkUFWwegoNkWbTwzAEesqHBi = np.fromfile(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs, PBoECFenorasxqnDxeSyQAMUhFlvlTpo=float, count=-1, eJXYqJtbnEezCcvIfsOyrToLvseEbDHj=" ")
    btNjLNVGfxZwuYcsaDSHrtKWHWVdbdLN = VLWoESlQwkUFWwegoNkWbTwzAEesqHBi[nUTPyWujFkBEBIXVZOKYTUTpTBuXpTsl:nUTPyWujFkBEBIXVZOKYTUTpTBuXpTsl+SSJYIQWCeYeJyaULljEwdUvPUoNIEgow+1]
    ZyLjyELWpuDkVyykuIPPJkxhzOIiePAw = VLWoESlQwkUFWwegoNkWbTwzAEesqHBi[nUTPyWujFkBEBIXVZOKYTUTpTBuXpTsl+SSJYIQWCeYeJyaULljEwdUvPUoNIEgow+1:nUTPyWujFkBEBIXVZOKYTUTpTBuXpTsl+SSJYIQWCeYeJyaULljEwdUvPUoNIEgow+1+BGIyyYeubApSKQkiThptTlvqnbjpodxt+1]
    xcaSoGjzKtqRHodkHdFYQPKCSdRaSqdn = VLWoESlQwkUFWwegoNkWbTwzAEesqHBi[nUTPyWujFkBEBIXVZOKYTUTpTBuXpTsl+SSJYIQWCeYeJyaULljEwdUvPUoNIEgow+1+BGIyyYeubApSKQkiThptTlvqnbjpodxt+1:nUTPyWujFkBEBIXVZOKYTUTpTBuXpTsl+SSJYIQWCeYeJyaULljEwdUvPUoNIEgow+1+BGIyyYeubApSKQkiThptTlvqnbjpodxt+1+AQUQXaejLTjvxodLldWBfCoRkMnuMQYO+1]
    UmwgphvJGrgEjptnzGhwnHfsilkTdqOU = 0.5*(btNjLNVGfxZwuYcsaDSHrtKWHWVdbdLN[1:]+btNjLNVGfxZwuYcsaDSHrtKWHWVdbdLN[:-1])
    sxPYBOgxMXDsqXBLjaytZraVIvjrLbBo = 0.5*(ZyLjyELWpuDkVyykuIPPJkxhzOIiePAw[1:]+ZyLjyELWpuDkVyykuIPPJkxhzOIiePAw[:-1])
    KSNygbtJHOdlbjmHoexsjsekcuThLUbR = 0.5*(xcaSoGjzKtqRHodkHdFYQPKCSdRaSqdn[1:]+xcaSoGjzKtqRHodkHdFYQPKCSdRaSqdn[:-1])
    ZbQvgZCTugPcswtZqKzWsoDhmptqqYCP = {
        "r": UmwgphvJGrgEjptnzGhwnHfsilkTdqOU,
        "ri": btNjLNVGfxZwuYcsaDSHrtKWHWVdbdLN,
        "theta": sxPYBOgxMXDsqXBLjaytZraVIvjrLbBo,
        "thetai": ZyLjyELWpuDkVyykuIPPJkxhzOIiePAw,
        "phi": KSNygbtJHOdlbjmHoexsjsekcuThLUbR,
        "phii": xcaSoGjzKtqRHodkHdFYQPKCSdRaSqdn,
    }
    return SimpleNamespace(**ZbQvgZCTugPcswtZqKzWsoDhmptqqYCP)
def PJHdvXLfDsqDqzvhyqwBGPsQAABsHZjP(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=""):
    VLWoESlQwkUFWwegoNkWbTwzAEesqHBi = agKWIxTUfcwQwrWvvcLBCFviEaNeUvde(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs)
    SSJYIQWCeYeJyaULljEwdUvPUoNIEgow, BGIyyYeubApSKQkiThptTlvqnbjpodxt, AQUQXaejLTjvxodLldWBfCoRkMnuMQYO = VLWoESlQwkUFWwegoNkWbTwzAEesqHBi.r.shape[0], VLWoESlQwkUFWwegoNkWbTwzAEesqHBi.mpoimxUohXSEtlNjhWnPSuFuuOUyfari.shape[0], VLWoESlQwkUFWwegoNkWbTwzAEesqHBi.phi.shape[0]
    ccKTSfglGcknJDFEklxMtXbvGBpVZSLi = "dust_density.inp"
    YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs = os.YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs.join(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs, ccKTSfglGcknJDFEklxMtXbvGBpVZSLi)
    nUTPyWujFkBEBIXVZOKYTUTpTBuXpTsl = 3
    rqOWUiYDMkNNZsQtzuPaldWGAusVANZs = np.fromfile(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs, PBoECFenorasxqnDxeSyQAMUhFlvlTpo=int, count=nUTPyWujFkBEBIXVZOKYTUTpTBuXpTsl, eJXYqJtbnEezCcvIfsOyrToLvseEbDHj=" ")
    JGfjoSaRhgUqqTdHjWvRjMQchlBjJSVM = rqOWUiYDMkNNZsQtzuPaldWGAusVANZs[-1]
    CgNerdbZWztzUzOCLuTjCBblzyBOWWMn = np.fromfile(
        YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs,
        PBoECFenorasxqnDxeSyQAMUhFlvlTpo=float,
        count=-1,
        eJXYqJtbnEezCcvIfsOyrToLvseEbDHj=" "
    )[nUTPyWujFkBEBIXVZOKYTUTpTBuXpTsl:].reshape((JGfjoSaRhgUqqTdHjWvRjMQchlBjJSVM, AQUQXaejLTjvxodLldWBfCoRkMnuMQYO, BGIyyYeubApSKQkiThptTlvqnbjpodxt, SSJYIQWCeYeJyaULljEwdUvPUoNIEgow))
    CgNerdbZWztzUzOCLuTjCBblzyBOWWMn = CgNerdbZWztzUzOCLuTjCBblzyBOWWMn.swapaxes(3, 0)
    CgNerdbZWztzUzOCLuTjCBblzyBOWWMn = CgNerdbZWztzUzOCLuTjCBblzyBOWWMn.swapaxes(2, 1)
    return CgNerdbZWztzUzOCLuTjCBblzyBOWWMn
def lEMrwuxzbMuUDxOaTLkFeBBvMIyuTEmi(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=""):
    VLWoESlQwkUFWwegoNkWbTwzAEesqHBi = agKWIxTUfcwQwrWvvcLBCFviEaNeUvde(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs=bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs)
    SSJYIQWCeYeJyaULljEwdUvPUoNIEgow, BGIyyYeubApSKQkiThptTlvqnbjpodxt, AQUQXaejLTjvxodLldWBfCoRkMnuMQYO = VLWoESlQwkUFWwegoNkWbTwzAEesqHBi.r.shape[0], VLWoESlQwkUFWwegoNkWbTwzAEesqHBi.mpoimxUohXSEtlNjhWnPSuFuuOUyfari.shape[0], VLWoESlQwkUFWwegoNkWbTwzAEesqHBi.phi.shape[0]
    ccKTSfglGcknJDFEklxMtXbvGBpVZSLi = "dust_temperature.dat"
    YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs = os.YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs.join(bfszfIpBgUbEKSdBxGMkGZMAWuDrOnhs, ccKTSfglGcknJDFEklxMtXbvGBpVZSLi)
    nUTPyWujFkBEBIXVZOKYTUTpTBuXpTsl = 3
    rqOWUiYDMkNNZsQtzuPaldWGAusVANZs = np.fromfile(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs, PBoECFenorasxqnDxeSyQAMUhFlvlTpo=int, count=nUTPyWujFkBEBIXVZOKYTUTpTBuXpTsl, eJXYqJtbnEezCcvIfsOyrToLvseEbDHj=" ")
    JGfjoSaRhgUqqTdHjWvRjMQchlBjJSVM = rqOWUiYDMkNNZsQtzuPaldWGAusVANZs[-1]
    DkDjcjNfPCaqFIhzvJKdYgyLMCZbFJcE = np.fromfile(
        YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs,
        PBoECFenorasxqnDxeSyQAMUhFlvlTpo=float,
        count=-1,
        eJXYqJtbnEezCcvIfsOyrToLvseEbDHj=" "
    )[nUTPyWujFkBEBIXVZOKYTUTpTBuXpTsl:].reshape((JGfjoSaRhgUqqTdHjWvRjMQchlBjJSVM, AQUQXaejLTjvxodLldWBfCoRkMnuMQYO, BGIyyYeubApSKQkiThptTlvqnbjpodxt, SSJYIQWCeYeJyaULljEwdUvPUoNIEgow))
    DkDjcjNfPCaqFIhzvJKdYgyLMCZbFJcE = DkDjcjNfPCaqFIhzvJKdYgyLMCZbFJcE.swapaxes(3, 0)
    DkDjcjNfPCaqFIhzvJKdYgyLMCZbFJcE = DkDjcjNfPCaqFIhzvJKdYgyLMCZbFJcE.swapaxes(2, 1)
    return DkDjcjNfPCaqFIhzvJKdYgyLMCZbFJcE
def wHvaGWggaqDfUndWEllWSCmBqieLDYpf(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs):
    nUTPyWujFkBEBIXVZOKYTUTpTBuXpTsl = 4
    rqOWUiYDMkNNZsQtzuPaldWGAusVANZs = np.fromfile(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs, PBoECFenorasxqnDxeSyQAMUhFlvlTpo=int, count=nUTPyWujFkBEBIXVZOKYTUTpTBuXpTsl, eJXYqJtbnEezCcvIfsOyrToLvseEbDHj=" ")
    JhejQFNyvcBUrzagBgwXBpciszvLqhyH = rqOWUiYDMkNNZsQtzuPaldWGAusVANZs[0]
    pEuBdFzmDNikjpbrQFMegDMyKBMliEWN, NLffHqyMzsKYPVpaEOtacKUJDmIXwrjv = rqOWUiYDMkNNZsQtzuPaldWGAusVANZs[1], rqOWUiYDMkNNZsQtzuPaldWGAusVANZs[2]
    BkHnyrlsjexXHgpRhUHCgSrYiHHBtyJG = rqOWUiYDMkNNZsQtzuPaldWGAusVANZs[3]
    YFEQMCgnxwzwelfNlOqylcxVyrazPdPN = np.fromfile(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs, PBoECFenorasxqnDxeSyQAMUhFlvlTpo=float, count=-1, eJXYqJtbnEezCcvIfsOyrToLvseEbDHj=" ")
    vRMTDOpmHopWYxPEQOMnBYcFdtHETCdE, busafUjjPFhdbKIJUqMxbZcElDVpzHrt = YFEQMCgnxwzwelfNlOqylcxVyrazPdPN[4], YFEQMCgnxwzwelfNlOqylcxVyrazPdPN[5]
    JuIqmuelVHSIlswXcnaGQurbGOAiHBxX = pEuBdFzmDNikjpbrQFMegDMyKBMliEWN*vRMTDOpmHopWYxPEQOMnBYcFdtHETCdE
    EyUBfmdawaJmOTMyVcOUMoCUUKMlxDrz = NLffHqyMzsKYPVpaEOtacKUJDmIXwrjv*busafUjjPFhdbKIJUqMxbZcElDVpzHrt
    XYBzHmEGXBAqigziackoVsVsFyBxSVzE = np.linspace(-JuIqmuelVHSIlswXcnaGQurbGOAiHBxX/2., JuIqmuelVHSIlswXcnaGQurbGOAiHBxX/2., pEuBdFzmDNikjpbrQFMegDMyKBMliEWN+1)
    nKEcvNJzgbUQdGsYymqiBlTMFFpdpUjt = 0.5*(XYBzHmEGXBAqigziackoVsVsFyBxSVzE[1:]+XYBzHmEGXBAqigziackoVsVsFyBxSVzE[:-1])
    PRDdUcFqHPkbySAphXGVfxafSdNHQkCN = np.linspace(-EyUBfmdawaJmOTMyVcOUMoCUUKMlxDrz/2., EyUBfmdawaJmOTMyVcOUMoCUUKMlxDrz/2., NLffHqyMzsKYPVpaEOtacKUJDmIXwrjv+1)
    zuPIFpZPohJPIjTdaiNgSMEzDscwCJsj = 0.5*(PRDdUcFqHPkbySAphXGVfxafSdNHQkCN[1:]+PRDdUcFqHPkbySAphXGVfxafSdNHQkCN[:-1])
    UEByrdCxtKljJxLyTCzrkjwhbAdHWivr = YFEQMCgnxwzwelfNlOqylcxVyrazPdPN[6:6+BkHnyrlsjexXHgpRhUHCgSrYiHHBtyJG]*1.e-4
    if JhejQFNyvcBUrzagBgwXBpciszvLqhyH in [1, 2]:
        altWDALtGEeqNJoPVYjlNjTksaqivggY = YFEQMCgnxwzwelfNlOqylcxVyrazPdPN[6+BkHnyrlsjexXHgpRhUHCgSrYiHHBtyJG:].reshape(
            (BkHnyrlsjexXHgpRhUHCgSrYiHHBtyJG, NLffHqyMzsKYPVpaEOtacKUJDmIXwrjv, pEuBdFzmDNikjpbrQFMegDMyKBMliEWN)
        ).swapaxes(2, 0)
        uXckqjplmlYQWJfxWfDBmuAOImpsuBKk = np.zeros_like(altWDALtGEeqNJoPVYjlNjTksaqivggY)
        RwzliDlGYFtBsgcOYDLnaMUyiEHhiGsP = np.zeros_like(altWDALtGEeqNJoPVYjlNjTksaqivggY)
        aOsVaFZJhBCyWvvtLjjCjjQLgJPqcdmy = np.zeros_like(altWDALtGEeqNJoPVYjlNjTksaqivggY)
    elif JhejQFNyvcBUrzagBgwXBpciszvLqhyH == 3:
        YFEQMCgnxwzwelfNlOqylcxVyrazPdPN = YFEQMCgnxwzwelfNlOqylcxVyrazPdPN[6+BkHnyrlsjexXHgpRhUHCgSrYiHHBtyJG:].reshape((-1, 4))
        altWDALtGEeqNJoPVYjlNjTksaqivggY = YFEQMCgnxwzwelfNlOqylcxVyrazPdPN[:, 0].reshape((BkHnyrlsjexXHgpRhUHCgSrYiHHBtyJG, NLffHqyMzsKYPVpaEOtacKUJDmIXwrjv, pEuBdFzmDNikjpbrQFMegDMyKBMliEWN)).swapaxes(2, 0)
        uXckqjplmlYQWJfxWfDBmuAOImpsuBKk = YFEQMCgnxwzwelfNlOqylcxVyrazPdPN[:, 1].reshape((BkHnyrlsjexXHgpRhUHCgSrYiHHBtyJG, NLffHqyMzsKYPVpaEOtacKUJDmIXwrjv, pEuBdFzmDNikjpbrQFMegDMyKBMliEWN)).swapaxes(2, 0)
        RwzliDlGYFtBsgcOYDLnaMUyiEHhiGsP = YFEQMCgnxwzwelfNlOqylcxVyrazPdPN[:, 2].reshape((BkHnyrlsjexXHgpRhUHCgSrYiHHBtyJG, NLffHqyMzsKYPVpaEOtacKUJDmIXwrjv, pEuBdFzmDNikjpbrQFMegDMyKBMliEWN)).swapaxes(2, 0)
        aOsVaFZJhBCyWvvtLjjCjjQLgJPqcdmy = YFEQMCgnxwzwelfNlOqylcxVyrazPdPN[:, 3].reshape((BkHnyrlsjexXHgpRhUHCgSrYiHHBtyJG, NLffHqyMzsKYPVpaEOtacKUJDmIXwrjv, pEuBdFzmDNikjpbrQFMegDMyKBMliEWN)).swapaxes(2, 0)
    else:
        raise RuntimeError(
            "Invalid file iformat: '{}'. Only '1', '2', or '3' supported."
            .format(JhejQFNyvcBUrzagBgwXBpciszvLqhyH))
    ZbQvgZCTugPcswtZqKzWsoDhmptqqYCP = {
        "x": nKEcvNJzgbUQdGsYymqiBlTMFFpdpUjt,
        "y": zuPIFpZPohJPIjTdaiNgSMEzDscwCJsj,
        "lambda": UEByrdCxtKljJxLyTCzrkjwhbAdHWivr,
        "I": altWDALtGEeqNJoPVYjlNjTksaqivggY,
        "Q": uXckqjplmlYQWJfxWfDBmuAOImpsuBKk,
        "U": RwzliDlGYFtBsgcOYDLnaMUyiEHhiGsP,
        "V": aOsVaFZJhBCyWvvtLjjCjjQLgJPqcdmy,
    }
    return ZbQvgZCTugPcswtZqKzWsoDhmptqqYCP
def rlbIntURFmrFRCwiAhGdwQfWnEEEQwmr(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs):
    wrFzlRmFBUhRiLeSxVPWaMNTRHVkbVYO = np.fromfile(YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs, PBoECFenorasxqnDxeSyQAMUhFlvlTpo=float, count=-1, eJXYqJtbnEezCcvIfsOyrToLvseEbDHj=" ")
    wrFzlRmFBUhRiLeSxVPWaMNTRHVkbVYO = wrFzlRmFBUhRiLeSxVPWaMNTRHVkbVYO[2:].reshape((-1, 2))
    UEByrdCxtKljJxLyTCzrkjwhbAdHWivr = wrFzlRmFBUhRiLeSxVPWaMNTRHVkbVYO[:, 0]*1.e-4
    NkdrJDcuAdCxSeaYojFwwsZUnMTGECYF = wrFzlRmFBUhRiLeSxVPWaMNTRHVkbVYO[:, 1]
    ZbQvgZCTugPcswtZqKzWsoDhmptqqYCP = {
        "lambda": UEByrdCxtKljJxLyTCzrkjwhbAdHWivr,
        "flux": NkdrJDcuAdCxSeaYojFwwsZUnMTGECYF,
    }
    return ZbQvgZCTugPcswtZqKzWsoDhmptqqYCP
