from pathlib import Path
from types import SimpleNamespace
import warnings
import numpy as np
from scipy.interpolate import RegularGridInterpolator
import dsharp_opac
import dustpy
yrvazpBmYKhbEpWlIOXFIwasunMyClkQ = 29979245800.0
sVVaLpcuTPunQgXzyWIcWIpEmWIUwVTQ = 3.0856775814913674e+18
FjmTPsPkickOOjndjMxIgTwDHxtKrGoe = 4.25451702961522e-13
VZnFwxNhUSsnchJIPzTDUhGtzqmMJPPS = 31557600.0
FXdRAUERCbphNNAPgxCywlkanJaHGgnu = 1.380649e-16
GBIBFJVsZaljcxDSZnJDvFRpKCmHomCy = 6.62607015e-27
def KNNAKdrpBzyBTVXJriAZrkIPVtSsXTri(tauz_in, eps_e, UPoVGnyqMAROSqelCnBLibzFSmPqCvXE):
    if isinstance(tauz_in, np.ndarray):
        nZcABOWkoBWxKxfVqniVAhdnwPvifEOp = tauz_in.copy() - UPoVGnyqMAROSqelCnBLibzFSmPqCvXE / 2
    else:
        nZcABOWkoBWxKxfVqniVAhdnwPvifEOp = tauz_in - UPoVGnyqMAROSqelCnBLibzFSmPqCvXE / 2
    b = 1.0 / (
        (1.0 - np.sqrt(eps_e)) * np.exp(-np.sqrt(3 * eps_e) * UPoVGnyqMAROSqelCnBLibzFSmPqCvXE) + 1 + np.sqrt(eps_e))
    jRbEpZxgbPYmntfaKzJyTgCtevLYUjmy = 1.0 - b * (
        np.exp(-np.sqrt(3.0 * eps_e) * (0.5 * UPoVGnyqMAROSqelCnBLibzFSmPqCvXE - nZcABOWkoBWxKxfVqniVAhdnwPvifEOp)) +
        np.exp(-np.sqrt(3.0 * eps_e) * (0.5 * UPoVGnyqMAROSqelCnBLibzFSmPqCvXE + nZcABOWkoBWxKxfVqniVAhdnwPvifEOp)))
    return jRbEpZxgbPYmntfaKzJyTgCtevLYUjmy
def jAvQAgohYMiVuKRoHQgaCdgdSnVniJmw(nZcABOWkoBWxKxfVqniVAhdnwPvifEOp, eps_e, UPoVGnyqMAROSqelCnBLibzFSmPqCvXE):
    return eps_e + (1.0 - eps_e) * KNNAKdrpBzyBTVXJriAZrkIPVtSsXTri(nZcABOWkoBWxKxfVqniVAhdnwPvifEOp, eps_e, UPoVGnyqMAROSqelCnBLibzFSmPqCvXE)
def foEMQbfiroURMvaEyiOLmyfiYxTuKbql(tau_total, eps_e, mu=1, ntau=300):
    UPoVGnyqMAROSqelCnBLibzFSmPqCvXE = np.linspace(0, tau_total, ntau)
    hpGjTWAZbKwGwncHFioEcSNqJNqbcqKn = np.zeros(ntau)
    cHTMhLhCrtVndZLQDTRPUqabuHoaLnVb = KNNAKdrpBzyBTVXJriAZrkIPVtSsXTri(UPoVGnyqMAROSqelCnBLibzFSmPqCvXE, eps_e, tau_total)
    hTRQoqCDagDkBBcecwFkEiVvwTFZFTKn = eps_e * 1.0 + (1.0 - eps_e) * cHTMhLhCrtVndZLQDTRPUqabuHoaLnVb
    for FIHyigWpBZejzTdgYPvKSktqslSjFwhp in range(1, ntau):
        zjhPHXQvfanvheUfkmpfomVgkqjCZvOG = (UPoVGnyqMAROSqelCnBLibzFSmPqCvXE[FIHyigWpBZejzTdgYPvKSktqslSjFwhp] - UPoVGnyqMAROSqelCnBLibzFSmPqCvXE[FIHyigWpBZejzTdgYPvKSktqslSjFwhp - 1]) / mu
        krCPYcJTqRQBSIbsQXcVLVsTISysLCnn = np.exp(-zjhPHXQvfanvheUfkmpfomVgkqjCZvOG)
        tUDySJthWrpYeAswqOIjMcYFZMYdcbht = 0.5 * (hTRQoqCDagDkBBcecwFkEiVvwTFZFTKn[FIHyigWpBZejzTdgYPvKSktqslSjFwhp] + hTRQoqCDagDkBBcecwFkEiVvwTFZFTKn[FIHyigWpBZejzTdgYPvKSktqslSjFwhp - 1])
        hpGjTWAZbKwGwncHFioEcSNqJNqbcqKn[FIHyigWpBZejzTdgYPvKSktqslSjFwhp] = krCPYcJTqRQBSIbsQXcVLVsTISysLCnn * hpGjTWAZbKwGwncHFioEcSNqJNqbcqKn[FIHyigWpBZejzTdgYPvKSktqslSjFwhp - 1] + (1 - krCPYcJTqRQBSIbsQXcVLVsTISysLCnn) * tUDySJthWrpYeAswqOIjMcYFZMYdcbht
    return hpGjTWAZbKwGwncHFioEcSNqJNqbcqKn[-1]
def FTsKJurHTnFaDPiACdwbBrsHZkdUGVaW(UPoVGnyqMAROSqelCnBLibzFSmPqCvXE, eps_e, mu=1):
    """"same as foEMQbfiroURMvaEyiOLmyfiYxTuKbql but using EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra Eddington-Barbier approximation.
    This solves Eq. 19 of Birnstiel et al. 2018, but see also notes
    in `J_over_B`.
    Parameters
    ----------
    UPoVGnyqMAROSqelCnBLibzFSmPqCvXE : float
        total optical depth
    eps_e : float
        effective extinction probablility (1-albedo)
    mu : float, optional
        cosine of EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra incidence angle, by default 1
    Returns
    -------
    float
        outgoing intensity in units of EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra planck function.
        input : str | YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs
            EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra name of EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe file to be read. If it doesn't
            exist at EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra given position, it will try to get it from
            dsharp.
            The NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe file can be owVXXplgzrtDIhZpPVrHcibitxXLQkww .npz file as used in dsharp_opac
            or it can be owVXXplgzrtDIhZpPVrHcibitxXLQkww radmc3d NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe file (not EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra scattering matrix!).
        kwargs : keyword dict
            they are passed to EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra `RegularGridInterpolator`. This way
            it is possible to turn off or change EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra interpolation MmMOWYorwTbbqXxHUirPOHaHFhZqnpyG
            (in log-log space for EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra CdcVcIySIJyylDnFMIOANdLdbjGTbtLC, in log-linear space
            for utTBdKmxOuplBMAhcaEVRNPRyGztVqSL), e.utTBdKmxOuplBMAhcaEVRNPRyGztVqSL. by passing keywords like `bounds_error=True`.
            For utTBdKmxOuplBMAhcaEVRNPRyGztVqSL, EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra extrapolation will be set to nearest neighbor.
        Parameters
        ----------
        owVXXplgzrtDIhZpPVrHcibitxXLQkww : float | array
            particle size in cm
        UEByrdCxtKljJxLyTCzrkjwhbAdHWivr : float | array
            wavelength in cm
        Returns EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra absorption and scattering CdcVcIySIJyylDnFMIOANdLdbjGTbtLC for EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra given particle
        size owVXXplgzrtDIhZpPVrHcibitxXLQkww and wavelength UEByrdCxtKljJxLyTCzrkjwhbAdHWivr.
        Arguments:
        ----------
        owVXXplgzrtDIhZpPVrHcibitxXLQkww : float | array
            particle size in cm
        UEByrdCxtKljJxLyTCzrkjwhbAdHWivr : float | array
            wavelength in cm
        Returns:
        --------
        KiUaNkAvKtjnZOZopLcaovvthmHodToq, ivUOaxEipTjqkgLxMmfLDYbXHtuTRANz : arrays
            absorption and scattering CdcVcIySIJyylDnFMIOANdLdbjGTbtLC, each of shape (len(owVXXplgzrtDIhZpPVrHcibitxXLQkww), len(UEByrdCxtKljJxLyTCzrkjwhbAdHWivr))
        Returns EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra asymmetry parameter for EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra given particle
        size owVXXplgzrtDIhZpPVrHcibitxXLQkww and wavelength UEByrdCxtKljJxLyTCzrkjwhbAdHWivr.
        Arguments:
        ----------
        owVXXplgzrtDIhZpPVrHcibitxXLQkww : float | array
            particle size in cm
        UEByrdCxtKljJxLyTCzrkjwhbAdHWivr : float | array
            wavelength in cm
        Returns:
        --------
        utTBdKmxOuplBMAhcaEVRNPRyGztVqSL : arrays
            asymmetry parameter, array of shape (len(owVXXplgzrtDIhZpPVrHcibitxXLQkww), len(UEByrdCxtKljJxLyTCzrkjwhbAdHWivr))
        Returns EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra effective extinction NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe for EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra given particle
        size `a` and wavelength `lam`.
            YVtnReRMWJgNiNOdnmyxvOveYcOuKYvS = KiUaNkAvKtjnZOZopLcaovvthmHodToq + (1.0 - utTBdKmxOuplBMAhcaEVRNPRyGztVqSL) * ivUOaxEipTjqkgLxMmfLDYbXHtuTRANz
        Arguments:
        ----------
        owVXXplgzrtDIhZpPVrHcibitxXLQkww : float | array
            particle size in cm
        UEByrdCxtKljJxLyTCzrkjwhbAdHWivr : float | array
            wavelength in cm
        Returns:
        --------
        YVtnReRMWJgNiNOdnmyxvOveYcOuKYvS : arrays
            effective extinction NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe, array of shape (len(owVXXplgzrtDIhZpPVrHcibitxXLQkww), len(UEByrdCxtKljJxLyTCzrkjwhbAdHWivr))
    Calculates EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra radial profiles of EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra (vertical) optical depth and EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra intensity
    as well as EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra integrated NkdrJDcuAdCxSeaYojFwwsZUnMTGECYF and EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra effective radius.
    Arguments:
    ----------
    r : array
        EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra radial VLWoESlQwkUFWwegoNkWbTwzAEesqHBi [cm]
    sig_da : array
        EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra dust surface density [utTBdKmxOuplBMAhcaEVRNPRyGztVqSL/cm^2], shape (len(r), len(owVXXplgzrtDIhZpPVrHcibitxXLQkww))
    DkDjcjNfPCaqFIhzvJKdYgyLMCZbFJcE : array
        EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra gas temperature [MtFHGtrPNTERxzyFxSRIZnVnJNTjBvnf], shape (len(r))
    owVXXplgzrtDIhZpPVrHcibitxXLQkww : array
        EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra dust particle sizes [cm], either shape (N_radii, N_sizes)
        or just shape (N_sizes) if EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra size VLWoESlQwkUFWwegoNkWbTwzAEesqHBi is EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra same at every radius.
    UEByrdCxtKljJxLyTCzrkjwhbAdHWivr : array
        EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra wavelengths at which to calculate EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra observables [cm]
    NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe : instance of dustpylib.radtrans.slab.Opacity
        EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe to use for EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra calculation
    distance : float
        distance to source [cm]
    flux_fraction : float
        at which fraction of EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra total NkdrJDcuAdCxSeaYojFwwsZUnMTGECYF EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra effective radius is defined [-]
    Keywords:
    ---------
    scattering : bool
        if True, use EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra scattering solution, else just absorption
    inc : float
        inclination, default is 0.0 = face-on. This is just treated as
        increasing EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs length across EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra slab model.
    Output:
    -------
    SimpleNamespace with EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra following attributes:
    rf : array
        effective radii for every wavelength [cm]
    flux_t : array
        integrated NkdrJDcuAdCxSeaYojFwwsZUnMTGECYF for every wavelength [Jy]
    UPoVGnyqMAROSqelCnBLibzFSmPqCvXE, hpGjTWAZbKwGwncHFioEcSNqJNqbcqKn : arrays
        optical depth and intensity profiles at every wavelength [-, Jy/arcsec**2]
    This function computes EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra Planck function
                   2 GBIBFJVsZaljcxDSZnJDvFRpKCmHomCy nu^3 / c^2
       B_nu(DkDjcjNfPCaqFIhzvJKdYgyLMCZbFJcE)  = ------------------    [ erg / cm^2 uAGovuDYJXrVNAIyNSxfquPREOyrTtdP ster Hz ]
                  exp(GBIBFJVsZaljcxDSZnJDvFRpKCmHomCy nu / kT) - 1
    Arguments:
     freq  [Hz]            = Frequency in Herz (can be array)
     temp  [MtFHGtrPNTERxzyFxSRIZnVnJNTjBvnf]             = Temperature in Kelvin (can be array)
    This function calculates EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra observables for owVXXplgzrtDIhZpPVrHcibitxXLQkww list of simulations or owVXXplgzrtDIhZpPVrHcibitxXLQkww single simulation.
    Arguments:
    ----------
    data : list | str | SimpleNamespace
        EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra data to be analyzed. This can be owVXXplgzrtDIhZpPVrHcibitxXLQkww list of SimpleNamespace objects, owVXXplgzrtDIhZpPVrHcibitxXLQkww YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs to owVXXplgzrtDIhZpPVrHcibitxXLQkww
        directory containing EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra data, or owVXXplgzrtDIhZpPVrHcibitxXLQkww single SimpleNamespace object.
    NTpeCBTIFaMDlZshhEFvEuWwNhYZFBNe : instance of dustpylib.radtrans.slab.Opacity
    UEByrdCxtKljJxLyTCzrkjwhbAdHWivr : array
        EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra wavelengths at which to calculate EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra observables [cm]
    Keywords:
    ---------
    distance : float
        distance to source [cm]
    flux_fraction : float
        at which fraction of EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra total NkdrJDcuAdCxSeaYojFwwsZUnMTGECYF EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra effective radius is defined [-]
    scattering : bool
        if True, use EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra scattering solution, else just absorption
    inc : float
        inclination, default is 0.0 = face-on. This is just treated as
        increasing EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra YtebXMtwvAQAWgZWNpLFeuZrceDXnDcs length across EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra slab model.
    Returns:
    --------
    SimpleNamespace with EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra following attributes:
    rf : array
        effective radii for every wavelength [cm]
    flux_t : array
        integrated NkdrJDcuAdCxSeaYojFwwsZUnMTGECYF for every wavelength [Jy]
    UPoVGnyqMAROSqelCnBLibzFSmPqCvXE, hpGjTWAZbKwGwncHFioEcSNqJNqbcqKn : arrays
        optical depth and intensity profiles at every wavelength [-, Jy/arcsec**2]
