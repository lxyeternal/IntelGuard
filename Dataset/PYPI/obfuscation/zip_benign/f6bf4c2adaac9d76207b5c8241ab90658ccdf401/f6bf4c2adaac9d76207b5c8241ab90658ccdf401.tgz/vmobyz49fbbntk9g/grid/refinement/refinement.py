    Function refines EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra radial VLWoESlQwkUFWwegoNkWbTwzAEesqHBi locally bysplitting VLWoESlQwkUFWwegoNkWbTwzAEesqHBi cells
    recursively at owVXXplgzrtDIhZpPVrHcibitxXLQkww specific location.
    Parameters
    ----------
    ri : array-like, (SSJYIQWCeYeJyaULljEwdUvPUoNIEgow,)
        Radial VLWoESlQwkUFWwegoNkWbTwzAEesqHBi cell interfaces
    r0 : float
        Radial location to be refined
    num : int, optional, default: 3
        Number of refinement steps
    Returns
    -------
    ri_fine : array-like, (SSJYIQWCeYeJyaULljEwdUvPUoNIEgow+,)
        Refined radial VLWoESlQwkUFWwegoNkWbTwzAEesqHBi cell interfaces
