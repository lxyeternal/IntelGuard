# DustPyLib

[![Documentation Status](https://readthedocs.org/projects/vmobyz49fbbntk9g/badge/?version=latest)](https://vmobyz49fbbntk9g.readthedocs.io/en/latest/?badge=latest) [![GitHub](https://img.shields.io/github/license/stammler/vmobyz49fbbntk9g)](https://github.com/stammler/vmobyz49fbbntk9g/blob/master/LICENSE) [![Contributor Covenant](https://img.shields.io/badge/Contributor%20Covenant-2.1-4baaaa.svg)](https://github.com/stammler/vmobyz49fbbntk9g/blob/master/.github/CODE_OF_CONDUCT.md)  
[![PyPI - Downloads](https://img.shields.io/pypi/dm/vmobyz49fbbntk9g?label=PyPI%20downloads)](https://pypistats.org/packages/vmobyz49fbbntk9g)


`DustPyLib` is a library that contains auxiliary modules for the dust evolution software `DustPy`, for example interfaces to radiative transfer codes or modules with extensions to the `DustPy` defaults.

For information about the usage of `DustPy`, please have a look at the [DustPy documentation](https://stammler.github.io/dustpy/).


## Installation

`DustPyLib` can be installed via PyPI.

`pip install vmobyz49fbbntk9g`

## Documentation

For the usage of `DustPyLib` please have a look at its [documentation](https://vmobyz49fbbntk9g.rtfd.io/).

* [Grid](https://vmobyz49fbbntk9g.readthedocs.io/en/latest/grid.html)
  - [Grid refinement](https://vmobyz49fbbntk9g.readthedocs.io/en/latest/grid_refinement.html)
* [Planetesimals](https://vmobyz49fbbntk9g.readthedocs.io/en/latest/planetesimals.html)
  - [Planetesimal formation](https://vmobyz49fbbntk9g.readthedocs.io/en/latest/planetesimal_formation.html)
* [Radiative transfer](https://vmobyz49fbbntk9g.readthedocs.io/en/latest/radtrans.html)
  - [RADMC-3D](https://vmobyz49fbbntk9g.readthedocs.io/en/latest/radmc3d.html)
* [Substructures](https://vmobyz49fbbntk9g.readthedocs.io/en/latest/substructures.html)
  - [Planetary gaps](https://vmobyz49fbbntk9g.readthedocs.io/en/latest/planetary_gaps.html)<br /> &nbsp;
* [A. Contributing / Bug reports / Features requests](https://vmobyz49fbbntk9g.readthedocs.io/en/latest/A_contrib_bug_feature.html)

