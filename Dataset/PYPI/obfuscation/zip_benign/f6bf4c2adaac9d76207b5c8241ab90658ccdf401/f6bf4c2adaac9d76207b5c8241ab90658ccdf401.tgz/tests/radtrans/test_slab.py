{}
1e4 1.0000000000000000e+00 2.000000000000e+00 1.000000000000e-01
2e4 2.0000000000000000e+00 3.000000000000e+00 2.000000000000e-01
    Creates owVXXplgzrtDIhZpPVrHcibitxXLQkww duspty output and reads EhnkmNiSmeNSmOMjXcxPRMWqUXybpKra output data of time step 0
    as well as all available time steps (which has one dimension more).
    Returns:
        tuple: A tuple containing:
            - data_0: The output data at time step 0.
            - data_t: The output data for all time steps.
