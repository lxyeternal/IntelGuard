import dacy
import spacy
def xfetAPumdiOHhFUPHGqUWVpnhhPzODdj():
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK = spacy.blank("da")
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK.add_pipe("dacy/subjectivity")
    ZYdbsDsBMLJpMFLdVoRLbTuBaTFNQZuS = [
        "Analysen viser, at økonomien bliver forfærdelig dårlig",
        "Jeg tror alligevel, det bliver godt",
        "",
    ]
    NpWpLmBKGEAQSHCFxbjVGBVBOEATrrWs = ["objective", "subjective", None]
    yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ = list(fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK.pipe(ZYdbsDsBMLJpMFLdVoRLbTuBaTFNQZuS))
    for FocsgjCFMXRvYBIETtcBKaqTmldHOXmJ, swytUVqdPaJloRssqPQffJXiajswRcOF in zip(yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ, NpWpLmBKGEAQSHCFxbjVGBVBOEATrrWs):
        if swytUVqdPaJloRssqPQffJXiajswRcOF is None:
            assert FocsgjCFMXRvYBIETtcBKaqTmldHOXmJ._.subjectivity is None
        else:
            assert FocsgjCFMXRvYBIETtcBKaqTmldHOXmJ._.subjectivity == swytUVqdPaJloRssqPQffJXiajswRcOF
def abgwiwZIKsWGdBSjxgVeDdMjtbjeerkt():
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK = spacy.blank("da")
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK.add_pipe("dacy/polarity")
    ZYdbsDsBMLJpMFLdVoRLbTuBaTFNQZuS = [
        "Analysen viser, at økonomien bliver forfærdelig dårlig",
        "Jeg tror alligevel, det bliver godt",
    ]
    yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ = list(fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK.pipe(ZYdbsDsBMLJpMFLdVoRLbTuBaTFNQZuS))
    assert yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ[0]._.polarity_prob["prob"][0] < yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ[1]._.polarity_prob["prob"][0]
def VIPaIIAIkACfytzaPMZHtZBHgZgVsZJT():
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK = spacy.blank("da")
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK.add_pipe("dacy/emotionally_laden")
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK.add_pipe("dacy/emotion")
    dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO = fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK("Der er et træ i haven")
    assert dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO._.emotionally_laden == "no emotion"
    assert dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO._.emotion == "no emotion"
def SvOASdUViUAXHcTQPOMIohWtIIacEgJO():
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK = spacy.blank("da")
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK.add_pipe("dacy/emotionally_laden")
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK.add_pipe("dacy/emotion")
    dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO = fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK("Har i set at Tesla har landet en raket på månen? Det er vildt!!")
    assert dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO._.emotion == "overasket/målløs"
