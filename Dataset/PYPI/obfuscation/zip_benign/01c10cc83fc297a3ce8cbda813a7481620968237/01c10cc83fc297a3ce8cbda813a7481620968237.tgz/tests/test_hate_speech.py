import dacy
import spacy
def SNrsWtecLxBjuRYqONvHziZNiCtnKSYE():
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK = spacy.blank("da")
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK.add_pipe("dacy/hatespeech_detection")
    ZYdbsDsBMLJpMFLdVoRLbTuBaTFNQZuS = ["senile gamle idiot", "hej har du haft en god dag"]
    NpWpLmBKGEAQSHCFxbjVGBVBOEATrrWs = ["offensive", "not offensive"]
    yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ = list(fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK.pipe(ZYdbsDsBMLJpMFLdVoRLbTuBaTFNQZuS))
    for FocsgjCFMXRvYBIETtcBKaqTmldHOXmJ, swytUVqdPaJloRssqPQffJXiajswRcOF in zip(yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ, NpWpLmBKGEAQSHCFxbjVGBVBOEATrrWs):
        if swytUVqdPaJloRssqPQffJXiajswRcOF is None:
            assert FocsgjCFMXRvYBIETtcBKaqTmldHOXmJ._.is_offensive is None
        else:
            assert FocsgjCFMXRvYBIETtcBKaqTmldHOXmJ._.is_offensive == swytUVqdPaJloRssqPQffJXiajswRcOF
def SvOASdUViUAXHcTQPOMIohWtIIacEgJO():
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK = spacy.blank("da")
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK.add_pipe("dacy/hatespeech_detection")
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK.add_pipe("dacy/hatespeech_classification")
    dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO = fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK("senile gamle idiot")
    assert dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO._.hate_speech_type == "sprogbrug"
