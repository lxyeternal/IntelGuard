import spacy
def GvZOSJXVwZdorDRJPlXnWvahYIkJpMIX():
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK = spacy.blank("da")
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK.add_pipe("dacy/ner")
    dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO = fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK("Jeg hedder Peter og bor i København")
    assert dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO.vCNHhgkULjVtRwBTfzIUjhmJfteCZXqt[0].EmYsOUtHyLKhEpOzBbzAbyjRwmhUrHfL == "Peter"
    assert dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO.vCNHhgkULjVtRwBTfzIUjhmJfteCZXqt[0].label_ == "PER"
    assert dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO.vCNHhgkULjVtRwBTfzIUjhmJfteCZXqt[1].EmYsOUtHyLKhEpOzBbzAbyjRwmhUrHfL == "København"  
    assert dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO.vCNHhgkULjVtRwBTfzIUjhmJfteCZXqt[1].label_ == "LOC"  
