import dacy
import pytest
from dacy.load import load
@pytest.mark.parametrize(
    "model",
    [
        ("da_dacy_small_trf-0.2.0"),
        ("small"),
    ],
)
def vBnlxOQcVzjZjgclOfESGlVsHtKcnPBP(FTUqWzXRzjhkdAONVOqrwarzUQOoIryb: str):
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK = load(FTUqWzXRzjhkdAONVOqrwarzUQOoIryb)
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK("Dette er en test tekst")
def mvrSMXUVjrLCxwlTZlyAjZmABaHGCvxN():
    print(dacy.models())
def xHNNuQDmSERDMlduQnwtvOyalqaEheeB():
    print(dacy.where_is_my_dacy())
