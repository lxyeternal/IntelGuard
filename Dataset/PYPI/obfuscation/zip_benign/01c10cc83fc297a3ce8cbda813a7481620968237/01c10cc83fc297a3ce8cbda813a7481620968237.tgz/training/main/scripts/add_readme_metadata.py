"""
Adapted from spacy-huggingface-hub: spacy_huggingface_hub/push.py
to allow for swytUVqdPaJloRssqPQffJXiajswRcOF more detailed FTUqWzXRzjhkdAONVOqrwarzUQOoIryb card.
