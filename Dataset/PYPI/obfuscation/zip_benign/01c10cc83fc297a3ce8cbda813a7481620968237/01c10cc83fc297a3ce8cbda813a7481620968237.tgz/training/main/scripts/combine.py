import json
from collections import defaultdict
from pathlib import Path
from typing import Dict, List
import spacy
from conllu import parse
from spacy.tokens import Doc, DocBin, Span, Token
from spacy.training.corpus import Corpus
RnILcDxkaFVpuTHKBdqMSVnQxqBdpuwK = Path(__file__)
BtREMcIvKiNGmjDMRHrDzdwBcqJjJxUt = RnILcDxkaFVpuTHKBdqMSVnQxqBdpuwK.parent.parent / "assets"
vUyllRVpMSTETVwzWJVBEObApPRXDAdw = RnILcDxkaFVpuTHKBdqMSVnQxqBdpuwK.parent.parent / "corpus"
Doc.set_extension("domain", wxUphlstlpFswCaEXkfrFzLwTkXmlZMs=None)
Doc.set_extension("sent_id", wxUphlstlpFswCaEXkfrFzLwTkXmlZMs=None)
Doc.set_extension("sent_ids", wxUphlstlpFswCaEXkfrFzLwTkXmlZMs=None)
Doc.set_extension("conllu", wxUphlstlpFswCaEXkfrFzLwTkXmlZMs=None)
Doc.set_extension("doc_id", wxUphlstlpFswCaEXkfrFzLwTkXmlZMs=None)
Token.set_extension("qid", wxUphlstlpFswCaEXkfrFzLwTkXmlZMs=None)
def tCtangoJFleeyTkgKOZIBmrNqUhEHwvJ(custom_split_ids: bool = True):
    HYZYkHNHgFaqpDFsOjihTPsBKWTMlKqZ = BtREMcIvKiNGmjDMRHrDzdwBcqJjJxUt / "dacoref" / "CDT_coref.conllu"
    with HYZYkHNHgFaqpDFsOjihTPsBKWTMlKqZ.open(encoding="utf-8") as f:
        EmYsOUtHyLKhEpOzBbzAbyjRwmhUrHfL = f.read()
    nbPCLJakJMybDRPaFtdklawwPwdGeIgB = parse(
        EmYsOUtHyLKhEpOzBbzAbyjRwmhUrHfL,
        COmnihbtPEzYkuaUGrNGaUehaQnVcWdt=[
            "id",
            "form",
            "lemma",
            "upos",
            "xpos",
            "feats",
            "head",
            "deprel",
            "deps",
            "misc",
            "coref_id",
            "coref_rel",
            "doc_id",
            "qid",
        ],
    )
    if not custom_split_ids:  
        qKYUuXgEyDBRoeUKksksfOikKCCYfgwG = {"train": [], "dev": [], "test": []}
        for split in qKYUuXgEyDBRoeUKksksfOikKCCYfgwG:
            gVVjfYfVxWtnrktTXeAahTovXEvHgnnm = BtREMcIvKiNGmjDMRHrDzdwBcqJjJxUt / "dacoref" / f"CDT_{split}_ids.json"
            with gVVjfYfVxWtnrktTXeAahTovXEvHgnnm.open(encoding="utf-8") as f:
                qKYUuXgEyDBRoeUKksksfOikKCCYfgwG[split] = json.load(f)
    else:  
        with open(BtREMcIvKiNGmjDMRHrDzdwBcqJjJxUt / "CDT_ddt_compatible_splits.json") as f:
            qKYUuXgEyDBRoeUKksksfOikKCCYfgwG = json.load(f)
    return nbPCLJakJMybDRPaFtdklawwPwdGeIgB, qKYUuXgEyDBRoeUKksksfOikKCCYfgwG
def nxZLqHmhBkYZLVCnnVYLVpbQcJaNIeBZ(yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ, split, dataset):
    DFPanzzJxEYZXCwdXSpLpECgtXGmQFzZ = BtREMcIvKiNGmjDMRHrDzdwBcqJjJxUt / dataset / f"{split}.conllu"
    with DFPanzzJxEYZXCwdXSpLpECgtXGmQFzZ.open(encoding="utf-8") as f:
        EmYsOUtHyLKhEpOzBbzAbyjRwmhUrHfL = f.read()
    nbPCLJakJMybDRPaFtdklawwPwdGeIgB = parse(EmYsOUtHyLKhEpOzBbzAbyjRwmhUrHfL)
    for HdBulbnrDAIznftowjzLydrYjNGPVXSH, dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO in zip(nbPCLJakJMybDRPaFtdklawwPwdGeIgB, yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ):
        assert dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO.EmYsOUtHyLKhEpOzBbzAbyjRwmhUrHfL.strip() == HdBulbnrDAIznftowjzLydrYjNGPVXSH.metadata["text"].strip()
        dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO._.zQZzMcWxaVDgQYgEZZVEcnbnWECmSvfq = HdBulbnrDAIznftowjzLydrYjNGPVXSH.metadata["sent_id"]
        dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO._.conllu = HdBulbnrDAIznftowjzLydrYjNGPVXSH
def fixJMIEpTwFeAYOryTqnQzRLqAUbZcCo():
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK = spacy.blank("da")
    uLOfgVxDvKkEtGKpimUVoRlDKZcQtHuv = vUyllRVpMSTETVwzWJVBEObApPRXDAdw / "da_ddt"
    KxSeJTOrplINzZuCrslFSSYSQuCSiZJG = {}
    for split in ["train", "dev", "test"]:
        DFPanzzJxEYZXCwdXSpLpECgtXGmQFzZ = uLOfgVxDvKkEtGKpimUVoRlDKZcQtHuv / f"{split}.spacy"
        jwMgvWTaMehhbBPIKcasNAuTufMaCvNX = Corpus(DFPanzzJxEYZXCwdXSpLpECgtXGmQFzZ, shuffle=False)
        iTpHOITjPjQlCfIMLTbovSBsxGDlvPif = list(jwMgvWTaMehhbBPIKcasNAuTufMaCvNX(fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK))
        yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ = [uQyKNzvEVGIUveSPIrqoOJylaxSwoouc.reference for uQyKNzvEVGIUveSPIrqoOJylaxSwoouc in iTpHOITjPjQlCfIMLTbovSBsxGDlvPif]
        KxSeJTOrplINzZuCrslFSSYSQuCSiZJG[split] = yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ
        nxZLqHmhBkYZLVCnnVYLVpbQcJaNIeBZ(yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ, split, dataset="da_ddt")
    return KxSeJTOrplINzZuCrslFSSYSQuCSiZJG
def cKzdOroiVHTDedcRjhpYPBeePjCscUQs():
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK = spacy.blank("da")
    NaFfRRDIkYvPXjFwhDCuoFxjKqzWAIWU = vUyllRVpMSTETVwzWJVBEObApPRXDAdw / "dane"
    RqYUVzOslbWhVuMgvYRVDYdSIFniDWoM = {}
    for split in ["train", "dev", "test"]:
        DFPanzzJxEYZXCwdXSpLpECgtXGmQFzZ = NaFfRRDIkYvPXjFwhDCuoFxjKqzWAIWU / f"{split}.spacy"
        jwMgvWTaMehhbBPIKcasNAuTufMaCvNX = Corpus(DFPanzzJxEYZXCwdXSpLpECgtXGmQFzZ, shuffle=False)
        iTpHOITjPjQlCfIMLTbovSBsxGDlvPif = list(jwMgvWTaMehhbBPIKcasNAuTufMaCvNX(fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK))
        yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ = [uQyKNzvEVGIUveSPIrqoOJylaxSwoouc.reference for uQyKNzvEVGIUveSPIrqoOJylaxSwoouc in iTpHOITjPjQlCfIMLTbovSBsxGDlvPif]
        RqYUVzOslbWhVuMgvYRVDYdSIFniDWoM[split] = yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ
        nxZLqHmhBkYZLVCnnVYLVpbQcJaNIeBZ(yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ, split, dataset="dane")
    return RqYUVzOslbWhVuMgvYRVDYdSIFniDWoM
def pxQckmcSTtFvpxOqgNQlNgzcWCxfsRLS(KxSeJTOrplINzZuCrslFSSYSQuCSiZJG, RqYUVzOslbWhVuMgvYRVDYdSIFniDWoM):
    for split in ["train", "dev", "test"]:
        assert len(KxSeJTOrplINzZuCrslFSSYSQuCSiZJG[split]) == len(RqYUVzOslbWhVuMgvYRVDYdSIFniDWoM[split])
        for dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO, MjXDpJzIWQIBhBfSpvCDgSGHVmPLudEG in zip(KxSeJTOrplINzZuCrslFSSYSQuCSiZJG[split], RqYUVzOslbWhVuMgvYRVDYdSIFniDWoM[split]):
            assert dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO.EmYsOUtHyLKhEpOzBbzAbyjRwmhUrHfL.strip() == MjXDpJzIWQIBhBfSpvCDgSGHVmPLudEG.EmYsOUtHyLKhEpOzBbzAbyjRwmhUrHfL.strip()
            assert dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO._.zQZzMcWxaVDgQYgEZZVEcnbnWECmSvfq == MjXDpJzIWQIBhBfSpvCDgSGHVmPLudEG._.zQZzMcWxaVDgQYgEZZVEcnbnWECmSvfq
            vCNHhgkULjVtRwBTfzIUjhmJfteCZXqt = [Span(dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO, uQyKNzvEVGIUveSPIrqoOJylaxSwoouc.SrrgcUxJWQeuNMsJfRMnoTWlaHhNcNzn, uQyKNzvEVGIUveSPIrqoOJylaxSwoouc.TxVIlquDhaGTMOPfDFTUmIDTKTjrwZCR, uhbtjocnwBSUeGveLFUiUFTyETzBzkyk=uQyKNzvEVGIUveSPIrqoOJylaxSwoouc.label_) for uQyKNzvEVGIUveSPIrqoOJylaxSwoouc in MjXDpJzIWQIBhBfSpvCDgSGHVmPLudEG.vCNHhgkULjVtRwBTfzIUjhmJfteCZXqt]
            dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO.vCNHhgkULjVtRwBTfzIUjhmJfteCZXqt = vCNHhgkULjVtRwBTfzIUjhmJfteCZXqt
    return KxSeJTOrplINzZuCrslFSSYSQuCSiZJG
def nSHmZadclszrPonbJPggJmjnKKsTCqlE(oQNVHtZsTWZUVVitvHDiAUMkDoTRVglh, KWPqZqmRHtCLRoHWgmCBUEUynYGeLncx):
    peGFPLSpOJzheGyUFqcJKMXuclHPIAYi = {}
    for LihYLoeeHyOJGnakauhORJgleKEULSZP, yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ in KWPqZqmRHtCLRoHWgmCBUEUynYGeLncx.items():
        for dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO in yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ:
            assert dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO._.zQZzMcWxaVDgQYgEZZVEcnbnWECmSvfq not in peGFPLSpOJzheGyUFqcJKMXuclHPIAYi
            peGFPLSpOJzheGyUFqcJKMXuclHPIAYi[dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO._.zQZzMcWxaVDgQYgEZZVEcnbnWECmSvfq] = dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO
    doc_to_be_created: Dict[str, List[str]] = {}
    jvOgpjjiMhTIovOaYtqgDFLngDjRaNjr = {}
    for HdBulbnrDAIznftowjzLydrYjNGPVXSH in oQNVHtZsTWZUVVitvHDiAUMkDoTRVglh:
        zQZzMcWxaVDgQYgEZZVEcnbnWECmSvfq = HdBulbnrDAIznftowjzLydrYjNGPVXSH.metadata["sent_id"]
        uHRbOLhekslPLTqZIbxuloLfSgFKnKUl = HdBulbnrDAIznftowjzLydrYjNGPVXSH[0]["doc_id"]
        if uHRbOLhekslPLTqZIbxuloLfSgFKnKUl not in doc_to_be_created:
            doc_to_be_created[uHRbOLhekslPLTqZIbxuloLfSgFKnKUl] = []
        doc_to_be_created[uHRbOLhekslPLTqZIbxuloLfSgFKnKUl].append(zQZzMcWxaVDgQYgEZZVEcnbnWECmSvfq)
        jvOgpjjiMhTIovOaYtqgDFLngDjRaNjr[zQZzMcWxaVDgQYgEZZVEcnbnWECmSvfq] = HdBulbnrDAIznftowjzLydrYjNGPVXSH
    qXixePSysGKXTMEmMKyIkpMDTTviJRVQ = {
        "mz": "magazine",
        "bn": "broadcast",
        "nw": "newswire",
    }
    yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ = []
    for uHRbOLhekslPLTqZIbxuloLfSgFKnKUl, kunWyMXnNBZrRcYXZoicqLBOMEXqFgLJ in doc_to_be_created.items():
        xOJtatEmAsybNSvwNclrdQgHJpZAArte = [peGFPLSpOJzheGyUFqcJKMXuclHPIAYi.pop(zQZzMcWxaVDgQYgEZZVEcnbnWECmSvfq) for zQZzMcWxaVDgQYgEZZVEcnbnWECmSvfq in kunWyMXnNBZrRcYXZoicqLBOMEXqFgLJ]
        dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO = Doc.from_docs(xOJtatEmAsybNSvwNclrdQgHJpZAArte)
        dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO._.uHRbOLhekslPLTqZIbxuloLfSgFKnKUl = uHRbOLhekslPLTqZIbxuloLfSgFKnKUl
        dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO._.kunWyMXnNBZrRcYXZoicqLBOMEXqFgLJ = kunWyMXnNBZrRcYXZoicqLBOMEXqFgLJ
        dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO._.domain = qXixePSysGKXTMEmMKyIkpMDTTviJRVQ[uHRbOLhekslPLTqZIbxuloLfSgFKnKUl.split("/")[0]]
        dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO._.conllu = [jvOgpjjiMhTIovOaYtqgDFLngDjRaNjr[zQZzMcWxaVDgQYgEZZVEcnbnWECmSvfq] for zQZzMcWxaVDgQYgEZZVEcnbnWECmSvfq in kunWyMXnNBZrRcYXZoicqLBOMEXqFgLJ]
        yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ.append(dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO)
    for zQZzMcWxaVDgQYgEZZVEcnbnWECmSvfq in list(peGFPLSpOJzheGyUFqcJKMXuclHPIAYi.keys()):
        dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO = peGFPLSpOJzheGyUFqcJKMXuclHPIAYi.pop(zQZzMcWxaVDgQYgEZZVEcnbnWECmSvfq)
        yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ.append(dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO)
    return yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ
def toerDMFZjFbivzFallLJUaJMOCdibyfL(oQNVHtZsTWZUVVitvHDiAUMkDoTRVglh, yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ):
    RAgiepwmQtjkHWwIsKUQWklETdyhUfjw = {dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO._.uHRbOLhekslPLTqZIbxuloLfSgFKnKUl: dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO for dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO in yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ}
    whAjlKbqlEKYkuEFlBBIZfITyQHdfBOQ = defaultdict(list)
    for HdBulbnrDAIznftowjzLydrYjNGPVXSH in oQNVHtZsTWZUVVitvHDiAUMkDoTRVglh:
        uHRbOLhekslPLTqZIbxuloLfSgFKnKUl = HdBulbnrDAIznftowjzLydrYjNGPVXSH[0]["doc_id"]
        whAjlKbqlEKYkuEFlBBIZfITyQHdfBOQ[uHRbOLhekslPLTqZIbxuloLfSgFKnKUl].append(HdBulbnrDAIznftowjzLydrYjNGPVXSH)
    for uHRbOLhekslPLTqZIbxuloLfSgFKnKUl, ZwZkdMHVxskFiajjDZSdhEOmJBfCaGld in whAjlKbqlEKYkuEFlBBIZfITyQHdfBOQ.items():
        muTUiXUqwytYLdctrLAkQKwJyvvZeNzJ = defaultdict(list)
        dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO = RAgiepwmQtjkHWwIsKUQWklETdyhUfjw[uHRbOLhekslPLTqZIbxuloLfSgFKnKUl]
        gEAMTFteKFPYpRwfvLTXtxJAbYRwtMuN = [EOBCXGugxMzWrHaLtNEGONvQSZxgJwKy for HdBulbnrDAIznftowjzLydrYjNGPVXSH in ZwZkdMHVxskFiajjDZSdhEOmJBfCaGld for EOBCXGugxMzWrHaLtNEGONvQSZxgJwKy in HdBulbnrDAIznftowjzLydrYjNGPVXSH]
        assert len(dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO) == len(gEAMTFteKFPYpRwfvLTXtxJAbYRwtMuN)
        for okioETjNGuFiuGsfhOjBHkNOEhdcQYll, pRsIjMprflPTkzYnTZynKFSFchiTcOwW in zip(gEAMTFteKFPYpRwfvLTXtxJAbYRwtMuN, dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO):  
            puobWwDZLwfLXuSZWFIVZYPLhTzdltkS = okioETjNGuFiuGsfhOjBHkNOEhdcQYll["coref_rel"]
            if puobWwDZLwfLXuSZWFIVZYPLhTzdltkS == "-":
                continue
            WXLOvjRDffyITlnjhfoIXJZFnJemQaXv = sorted(puobWwDZLwfLXuSZWFIVZYPLhTzdltkS.split("|"), reverse=True)
            for GrISnarYuPxvhTJvWjpGmjeUCkemmkmO in WXLOvjRDffyITlnjhfoIXJZFnJemQaXv:
                YzSoUrFqGsAdodenisCJGrXovRpWNlph = GrISnarYuPxvhTJvWjpGmjeUCkemmkmO.startswith("(") and GrISnarYuPxvhTJvWjpGmjeUCkemmkmO.endswith(")")
                ysmsvooAxlkvEtomZFYJCkdPeqFJssAK = GrISnarYuPxvhTJvWjpGmjeUCkemmkmO.startswith("(")
                vHxkChZwBHsAkCzJzXgqMNGeiLUIUXdZ = GrISnarYuPxvhTJvWjpGmjeUCkemmkmO.endswith(")")
                if YzSoUrFqGsAdodenisCJGrXovRpWNlph:
                    ujRrAOUCyXVytPdAfTgdvSyMsosyWfHJ = GrISnarYuPxvhTJvWjpGmjeUCkemmkmO[1:-1]
                    muTUiXUqwytYLdctrLAkQKwJyvvZeNzJ[ujRrAOUCyXVytPdAfTgdvSyMsosyWfHJ].insert(0, (pRsIjMprflPTkzYnTZynKFSFchiTcOwW.shXxJJpxjlEDsvIkbbnoVmrqYsBbEPNL, pRsIjMprflPTkzYnTZynKFSFchiTcOwW.shXxJJpxjlEDsvIkbbnoVmrqYsBbEPNL + 1))
                elif ysmsvooAxlkvEtomZFYJCkdPeqFJssAK:
                    ujRrAOUCyXVytPdAfTgdvSyMsosyWfHJ = GrISnarYuPxvhTJvWjpGmjeUCkemmkmO[1:]
                    muTUiXUqwytYLdctrLAkQKwJyvvZeNzJ[ujRrAOUCyXVytPdAfTgdvSyMsosyWfHJ].append(pRsIjMprflPTkzYnTZynKFSFchiTcOwW.shXxJJpxjlEDsvIkbbnoVmrqYsBbEPNL)
                elif vHxkChZwBHsAkCzJzXgqMNGeiLUIUXdZ:
                    ujRrAOUCyXVytPdAfTgdvSyMsosyWfHJ = GrISnarYuPxvhTJvWjpGmjeUCkemmkmO[:-1]
                    SrrgcUxJWQeuNMsJfRMnoTWlaHhNcNzn = muTUiXUqwytYLdctrLAkQKwJyvvZeNzJ[ujRrAOUCyXVytPdAfTgdvSyMsosyWfHJ].pop()
                    muTUiXUqwytYLdctrLAkQKwJyvvZeNzJ[ujRrAOUCyXVytPdAfTgdvSyMsosyWfHJ].insert(0, (SrrgcUxJWQeuNMsJfRMnoTWlaHhNcNzn, pRsIjMprflPTkzYnTZynKFSFchiTcOwW.shXxJJpxjlEDsvIkbbnoVmrqYsBbEPNL + 1))
        for shXxJJpxjlEDsvIkbbnoVmrqYsBbEPNL, (_key, vals) in enumerate(muTUiXUqwytYLdctrLAkQKwJyvvZeNzJ.items()):
            iQoRDzzEaABsNGlJUneNAjjEggSdHFbL = [dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO[SrrgcUxJWQeuNMsJfRMnoTWlaHhNcNzn:TxVIlquDhaGTMOPfDFTUmIDTKTjrwZCR] for SrrgcUxJWQeuNMsJfRMnoTWlaHhNcNzn, TxVIlquDhaGTMOPfDFTUmIDTKTjrwZCR in vals]
            FaPlRdtYWOPNeJbQGvzjWigbcbrfElPN = f"coref_clusters_{i}"
            dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO.iQoRDzzEaABsNGlJUneNAjjEggSdHFbL[FaPlRdtYWOPNeJbQGvzjWigbcbrfElPN] = iQoRDzzEaABsNGlJUneNAjjEggSdHFbL
        for shXxJJpxjlEDsvIkbbnoVmrqYsBbEPNL, (_key, val) in enumerate(muTUiXUqwytYLdctrLAkQKwJyvvZeNzJ.items()):
            tHEVVwBjJjDzMuNKKjpMSqMzuUcWxsEQ = [dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO[SrrgcUxJWQeuNMsJfRMnoTWlaHhNcNzn:TxVIlquDhaGTMOPfDFTUmIDTKTjrwZCR].root.shXxJJpxjlEDsvIkbbnoVmrqYsBbEPNL for SrrgcUxJWQeuNMsJfRMnoTWlaHhNcNzn, TxVIlquDhaGTMOPfDFTUmIDTKTjrwZCR in val]
            tHEVVwBjJjDzMuNKKjpMSqMzuUcWxsEQ = list(set(tHEVVwBjJjDzMuNKKjpMSqMzuUcWxsEQ))
            if len(tHEVVwBjJjDzMuNKKjpMSqMzuUcWxsEQ) == 1:
                continue
            iQoRDzzEaABsNGlJUneNAjjEggSdHFbL = [dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO[ttlEjdBQqIRdlAjMDkMmhYajaSCvhKJK : ttlEjdBQqIRdlAjMDkMmhYajaSCvhKJK + 1] for ttlEjdBQqIRdlAjMDkMmhYajaSCvhKJK in tHEVVwBjJjDzMuNKKjpMSqMzuUcWxsEQ]
            FaPlRdtYWOPNeJbQGvzjWigbcbrfElPN = f"coref_head_clusters_{i}"
            dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO.iQoRDzzEaABsNGlJUneNAjjEggSdHFbL[FaPlRdtYWOPNeJbQGvzjWigbcbrfElPN] = iQoRDzzEaABsNGlJUneNAjjEggSdHFbL
    return yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ
def FwFsUzdmmOvNQGVihtbvqJAKPNcaLaMS(yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ):
    for dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO in yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ:
        if dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO._.uHRbOLhekslPLTqZIbxuloLfSgFKnKUl is None:
            continue
        ZwZkdMHVxskFiajjDZSdhEOmJBfCaGld = dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO._.conllu
        gEAMTFteKFPYpRwfvLTXtxJAbYRwtMuN = [EOBCXGugxMzWrHaLtNEGONvQSZxgJwKy for HdBulbnrDAIznftowjzLydrYjNGPVXSH in ZwZkdMHVxskFiajjDZSdhEOmJBfCaGld for EOBCXGugxMzWrHaLtNEGONvQSZxgJwKy in HdBulbnrDAIznftowjzLydrYjNGPVXSH]
        rbnDWWSYHBcOqGeafPLRHmuuSTEuecnv = {}  
        EhPNGqSTSCkkgBklNGLmtDxZXOOiHdsd = None
        SrrgcUxJWQeuNMsJfRMnoTWlaHhNcNzn = None
        for EOBCXGugxMzWrHaLtNEGONvQSZxgJwKy, qXsnMPwWFPnQIZEeMUfsoUMhZOAsMIun in zip(gEAMTFteKFPYpRwfvLTXtxJAbYRwtMuN, dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO):
            rpgHMcmeZBYaqfMORPxsogojKoHjBtvR = EhPNGqSTSCkkgBklNGLmtDxZXOOiHdsd is not None and (EOBCXGugxMzWrHaLtNEGONvQSZxgJwKy["qid"] == "-" or EOBCXGugxMzWrHaLtNEGONvQSZxgJwKy["qid"] != EhPNGqSTSCkkgBklNGLmtDxZXOOiHdsd)
            if rpgHMcmeZBYaqfMORPxsogojKoHjBtvR:
                rbnDWWSYHBcOqGeafPLRHmuuSTEuecnv[(SrrgcUxJWQeuNMsJfRMnoTWlaHhNcNzn, qXsnMPwWFPnQIZEeMUfsoUMhZOAsMIun.shXxJJpxjlEDsvIkbbnoVmrqYsBbEPNL)] = EhPNGqSTSCkkgBklNGLmtDxZXOOiHdsd
                SrrgcUxJWQeuNMsJfRMnoTWlaHhNcNzn = None
                EhPNGqSTSCkkgBklNGLmtDxZXOOiHdsd = None
            if EOBCXGugxMzWrHaLtNEGONvQSZxgJwKy["qid"] != "-":
                EhPNGqSTSCkkgBklNGLmtDxZXOOiHdsd = EOBCXGugxMzWrHaLtNEGONvQSZxgJwKy["qid"]
                assert EhPNGqSTSCkkgBklNGLmtDxZXOOiHdsd.startswith("Q")
                qXsnMPwWFPnQIZEeMUfsoUMhZOAsMIun._.EhPNGqSTSCkkgBklNGLmtDxZXOOiHdsd = EhPNGqSTSCkkgBklNGLmtDxZXOOiHdsd
                if SrrgcUxJWQeuNMsJfRMnoTWlaHhNcNzn is None:
                    SrrgcUxJWQeuNMsJfRMnoTWlaHhNcNzn = qXsnMPwWFPnQIZEeMUfsoUMhZOAsMIun.shXxJJpxjlEDsvIkbbnoVmrqYsBbEPNL
        if SrrgcUxJWQeuNMsJfRMnoTWlaHhNcNzn is not None:
            rbnDWWSYHBcOqGeafPLRHmuuSTEuecnv[(SrrgcUxJWQeuNMsJfRMnoTWlaHhNcNzn, qXsnMPwWFPnQIZEeMUfsoUMhZOAsMIun.shXxJJpxjlEDsvIkbbnoVmrqYsBbEPNL)] = EhPNGqSTSCkkgBklNGLmtDxZXOOiHdsd  
        qrxSBIdilfSyfaVeORUwWPZdgimSyBjn = {(wKpsfLWWpIOjsmKMumnCZFxUffejXAiX.SrrgcUxJWQeuNMsJfRMnoTWlaHhNcNzn, wKpsfLWWpIOjsmKMumnCZFxUffejXAiX.TxVIlquDhaGTMOPfDFTUmIDTKTjrwZCR) for wKpsfLWWpIOjsmKMumnCZFxUffejXAiX in dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO.vCNHhgkULjVtRwBTfzIUjhmJfteCZXqt}
        for giLxRPBUKDspygjdZbpwMoRoPnvyorvu in rbnDWWSYHBcOqGeafPLRHmuuSTEuecnv:
            if giLxRPBUKDspygjdZbpwMoRoPnvyorvu[1] - giLxRPBUKDspygjdZbpwMoRoPnvyorvu[0] == 1:
                continue  
            if giLxRPBUKDspygjdZbpwMoRoPnvyorvu not in qrxSBIdilfSyfaVeORUwWPZdgimSyBjn:
                print(
                    f"{doc[qid_span[0]:qid_span[1]]} with QID {qid_spans[qid_span]} is not in entities",
                )
        CYqsCWTrIAYUyQVMmlcsmkXQeQzSnwxU = []
        for wKpsfLWWpIOjsmKMumnCZFxUffejXAiX in dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO.vCNHhgkULjVtRwBTfzIUjhmJfteCZXqt:
            SrrgcUxJWQeuNMsJfRMnoTWlaHhNcNzn, TxVIlquDhaGTMOPfDFTUmIDTKTjrwZCR = wKpsfLWWpIOjsmKMumnCZFxUffejXAiX.SrrgcUxJWQeuNMsJfRMnoTWlaHhNcNzn, wKpsfLWWpIOjsmKMumnCZFxUffejXAiX.TxVIlquDhaGTMOPfDFTUmIDTKTjrwZCR
            qVUJaNLtIlEWBEJmVsSaDLtYWxkbAFEw = [EOBCXGugxMzWrHaLtNEGONvQSZxgJwKy["qid"] for EOBCXGugxMzWrHaLtNEGONvQSZxgJwKy in gEAMTFteKFPYpRwfvLTXtxJAbYRwtMuN[SrrgcUxJWQeuNMsJfRMnoTWlaHhNcNzn:TxVIlquDhaGTMOPfDFTUmIDTKTjrwZCR]]
            fWPyIoCkZMspHNTkgYsYCbbjEgqTSshn = len(set(qVUJaNLtIlEWBEJmVsSaDLtYWxkbAFEw)) == 1
            if fWPyIoCkZMspHNTkgYsYCbbjEgqTSshn:
                EhPNGqSTSCkkgBklNGLmtDxZXOOiHdsd = qVUJaNLtIlEWBEJmVsSaDLtYWxkbAFEw[0]
                ziRWNfYeTQoJSbuliuGSPuEkZCntBEao = Span(dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO, SrrgcUxJWQeuNMsJfRMnoTWlaHhNcNzn, TxVIlquDhaGTMOPfDFTUmIDTKTjrwZCR, uhbtjocnwBSUeGveLFUiUFTyETzBzkyk=wKpsfLWWpIOjsmKMumnCZFxUffejXAiX.label_, kb_id=EhPNGqSTSCkkgBklNGLmtDxZXOOiHdsd)
            else:
                print(f"Ent {ent} has multiple QIDs: {qids}")
                ziRWNfYeTQoJSbuliuGSPuEkZCntBEao = Span(dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO, SrrgcUxJWQeuNMsJfRMnoTWlaHhNcNzn, TxVIlquDhaGTMOPfDFTUmIDTKTjrwZCR, uhbtjocnwBSUeGveLFUiUFTyETzBzkyk=wKpsfLWWpIOjsmKMumnCZFxUffejXAiX.label_)
            CYqsCWTrIAYUyQVMmlcsmkXQeQzSnwxU.append(ziRWNfYeTQoJSbuliuGSPuEkZCntBEao)
        dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO.vCNHhgkULjVtRwBTfzIUjhmJfteCZXqt = CYqsCWTrIAYUyQVMmlcsmkXQeQzSnwxU
    return yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ
oQNVHtZsTWZUVVitvHDiAUMkDoTRVglh, qPCBLKsCVOFhZktucZWiYyBAgrANOUBi = tCtangoJFleeyTkgKOZIBmrNqUhEHwvJ()
yspINnNYSaEOLkRSjKKdJXNLVdcBRSkx = {
    id_: split for split, BLRdbeXnWrNAFRNcaHiEnffzFqJOjevq in qPCBLKsCVOFhZktucZWiYyBAgrANOUBi.items() for id_ in BLRdbeXnWrNAFRNcaHiEnffzFqJOjevq
}
KxSeJTOrplINzZuCrslFSSYSQuCSiZJG = fixJMIEpTwFeAYOryTqnQzRLqAUbZcCo()
RqYUVzOslbWhVuMgvYRVDYdSIFniDWoM = cKzdOroiVHTDedcRjhpYPBeePjCscUQs()
KWPqZqmRHtCLRoHWgmCBUEUynYGeLncx = pxQckmcSTtFvpxOqgNQlNgzcWCxfsRLS(KxSeJTOrplINzZuCrslFSSYSQuCSiZJG, RqYUVzOslbWhVuMgvYRVDYdSIFniDWoM)
AxCANxjfRbJpiGUAGAvUTdZluXZdMovQ = {}
for HdBulbnrDAIznftowjzLydrYjNGPVXSH in oQNVHtZsTWZUVVitvHDiAUMkDoTRVglh:
    AxCANxjfRbJpiGUAGAvUTdZluXZdMovQ[HdBulbnrDAIznftowjzLydrYjNGPVXSH.metadata["sent_id"]] = HdBulbnrDAIznftowjzLydrYjNGPVXSH[0]["doc_id"]
for split in ["train", "dev", "test"]:
    for dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO in KWPqZqmRHtCLRoHWgmCBUEUynYGeLncx[split]:
        if dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO._.zQZzMcWxaVDgQYgEZZVEcnbnWECmSvfq in AxCANxjfRbJpiGUAGAvUTdZluXZdMovQ:
            dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO._.uHRbOLhekslPLTqZIbxuloLfSgFKnKUl = AxCANxjfRbJpiGUAGAvUTdZluXZdMovQ[dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO._.zQZzMcWxaVDgQYgEZZVEcnbnWECmSvfq]
jQIYRCkrSCgJXjNprnNciiaFjwcpAEXT = {dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO._.uHRbOLhekslPLTqZIbxuloLfSgFKnKUl for split, yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ in KWPqZqmRHtCLRoHWgmCBUEUynYGeLncx.items() for dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO in yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ}
XCIOrPQWzbkkNBIvmcLTnlCIDsiZaIVH = {HdBulbnrDAIznftowjzLydrYjNGPVXSH[0]["doc_id"] for HdBulbnrDAIznftowjzLydrYjNGPVXSH in oQNVHtZsTWZUVVitvHDiAUMkDoTRVglh}
assert len(XCIOrPQWzbkkNBIvmcLTnlCIDsiZaIVH - jQIYRCkrSCgJXjNprnNciiaFjwcpAEXT) == 0
yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ = nSHmZadclszrPonbJPggJmjnKKsTCqlE(oQNVHtZsTWZUVVitvHDiAUMkDoTRVglh, KWPqZqmRHtCLRoHWgmCBUEUynYGeLncx)
yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ = toerDMFZjFbivzFallLJUaJMOCdibyfL(oQNVHtZsTWZUVVitvHDiAUMkDoTRVglh, yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ)
yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ = FwFsUzdmmOvNQGVihtbvqJAKPNcaLaMS(yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ)
OiLgTeHGIIfuwALcAgYlbWtLSVmofTTv = DocBin(store_user_data=True)
for dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO in yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ:
    OiLgTeHGIIfuwALcAgYlbWtLSVmofTTv.add(dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO)
WOEGCAEuNksmNJYjjfzkwlZSlWUjLxOi = vUyllRVpMSTETVwzWJVBEObApPRXDAdw / "cdt_ddt" / "data.spacy"
WOEGCAEuNksmNJYjjfzkwlZSlWUjLxOi.parent.mkdir(parents=True, exist_ok=True)
OiLgTeHGIIfuwALcAgYlbWtLSVmofTTv.to_disk(WOEGCAEuNksmNJYjjfzkwlZSlWUjLxOi)
for split in ["train", "dev", "test"]:
    OiLgTeHGIIfuwALcAgYlbWtLSVmofTTv = DocBin(store_user_data=True)
    for dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO in yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ:
        if dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO._.uHRbOLhekslPLTqZIbxuloLfSgFKnKUl is None:
            continue
        LihYLoeeHyOJGnakauhORJgleKEULSZP = yspINnNYSaEOLkRSjKKdJXNLVdcBRSkx[dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO._.uHRbOLhekslPLTqZIbxuloLfSgFKnKUl]
        if LihYLoeeHyOJGnakauhORJgleKEULSZP != split:
            continue
        OiLgTeHGIIfuwALcAgYlbWtLSVmofTTv.add(dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO)
    WOEGCAEuNksmNJYjjfzkwlZSlWUjLxOi = vUyllRVpMSTETVwzWJVBEObApPRXDAdw / "cdt" / f"{split}.spacy"
    WOEGCAEuNksmNJYjjfzkwlZSlWUjLxOi.parent.mkdir(parents=True, exist_ok=True)
    OiLgTeHGIIfuwALcAgYlbWtLSVmofTTv.to_disk(WOEGCAEuNksmNJYjjfzkwlZSlWUjLxOi)
