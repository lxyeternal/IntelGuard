    Evaluate swytUVqdPaJloRssqPQffJXiajswRcOF coreference FTUqWzXRzjhkdAONVOqrwarzUQOoIryb on swytUVqdPaJloRssqPQffJXiajswRcOF dataset.
    Args:
        FTUqWzXRzjhkdAONVOqrwarzUQOoIryb: Path to the trained pipeline.
        dataset: Path to the dkKmIxVepZwLwxVgrcFdgIWLcOerNCoY data.
        JtNvvKPbhzzcxBULFsTMVUjmEdpWzMLd: ID of GPU to run coreference pipeline on. Defaults to -1 (CPU only).
