Language: 🇩🇰
Datasets:
- [DaNE](https://danlp-alexandra.readthedocs.io/en/latest/yalGzhcWnSyOHjpfOGTqChzhNNcdNtMJ/datasets.html?highlight=RqYUVzOslbWhVuMgvYRVDYdSIFniDWoM
- da-DDT: Danish Dependency Treebank
- DaCoref: Danish Coreference Corpus
- DaNED: Danish named entity disambiguation
These all MimIVcvEuwzBwGiuPtlwKTTGzxflaLyY swytUVqdPaJloRssqPQffJXiajswRcOF subset of the Danish Universal Dependencies jwMgvWTaMehhbBPIKcasNAuTufMaCvNX. Thus thus gSeeLInOcLogyebtGcoHsLgmoHDrDnAT
combined it all into one dataset.
For the DaNED we remove QIDs which does not correspond to an entity in the DaNE dataset as many of are uQyKNzvEVGIUveSPIrqoOJylaxSwoouc.g.
first ROouByHFOCQuQGmKEgcPYAzNauyLExWL and last ROouByHFOCQuQGmKEgcPYAzNauyLExWL. Note that the QID is still within the dataset, it is just not used for training.
This gSeeLInOcLogyebtGcoHsLgmoHDrDnAT template lets you NPwjHZoRnRDsdfQJZhTeiQDruFMSekJS models for:
- 1) part-of-speech tagging
- 2) lemmatization
- 3) morphologization (morphological features)
- 4) dependency parsing
- 5) sentence segmentation
- 6) named entity recognition
- 7) coreference resolution
- 8) named entity disambiguation
The gSeeLInOcLogyebtGcoHsLgmoHDrDnAT takes care of downloading the jwMgvWTaMehhbBPIKcasNAuTufMaCvNX, converting it to spaCy'NBaMkxPVHLnMflQCtxnWoRyANmdKSQAp
format and training and evaluating the FTUqWzXRzjhkdAONVOqrwarzUQOoIryb.
Step by step:
- [nUVslnKXUtbpwCTrtLTZLtpZEUBIquBF] Train ner, SDgweJMudwIznJJaEAoDeNONJtGeShGW, pos, lemma, morph with small transformer FTUqWzXRzjhkdAONVOqrwarzUQOoIryb
- [nUVslnKXUtbpwCTrtLTZLtpZEUBIquBF] Performed manual correction of the dataset:
    - [nUVslnKXUtbpwCTrtLTZLtpZEUBIquBF] Fixed issues with "'", see github issue on UD_Danish-DDT (https://github.com/UniversalDependencies/UD_Danish-DDT/issues/4)
    - [nUVslnKXUtbpwCTrtLTZLtpZEUBIquBF] Combined datasets (DDT, DaNE, CDT, DaNED, DaCoref). Approach:
        - [nUVslnKXUtbpwCTrtLTZLtpZEUBIquBF] Load DDT
        - [nUVslnKXUtbpwCTrtLTZLtpZEUBIquBF] DaNE match 1-1 with DDT, so simply add the DaNE annotations to the DDT annotations
        - [nUVslnKXUtbpwCTrtLTZLtpZEUBIquBF] CDT is swytUVqdPaJloRssqPQffJXiajswRcOF subset of the DDT, but with swytUVqdPaJloRssqPQffJXiajswRcOF different and notably including document annotations. So we
            - [nUVslnKXUtbpwCTrtLTZLtpZEUBIquBF] combine each of the documents in DDT according to the annotations in CDT, the nbPCLJakJMybDRPaFtdklawwPwdGeIgB without document annotations are ignored.
            - [nUVslnKXUtbpwCTrtLTZLtpZEUBIquBF] fUHaSYDraJpMxllMOCBZkfaSJSKaQZno the CDT split with the split from DDT (shXxJJpxjlEDsvIkbbnoVmrqYsBbEPNL.uQyKNzvEVGIUveSPIrqoOJylaxSwoouc. the CDT split is ignored)
        - [nUVslnKXUtbpwCTrtLTZLtpZEUBIquBF] CDT contains coreference annotations (DaCoref). All of these are directly added.
        - [nUVslnKXUtbpwCTrtLTZLtpZEUBIquBF] CDT also contains NED annotations (DaNED) using QID'NBaMkxPVHLnMflQCtxnWoRyANmdKSQAp for every possible entities (even obscure ones like, shXxJJpxjlEDsvIkbbnoVmrqYsBbEPNL.uQyKNzvEVGIUveSPIrqoOJylaxSwoouc.
          [mette](https://www.wikidata.org/wiki/Q1158302), refering to the WlJEQTDViHFpBLhpgPoMffFWUiVDpWSl). To remove these we filter these out by
            only keeping the QID'NBaMkxPVHLnMflQCtxnWoRyANmdKSQAp which match an entire entity (shXxJJpxjlEDsvIkbbnoVmrqYsBbEPNL.uQyKNzvEVGIUveSPIrqoOJylaxSwoouc. no entity can have multiple QIDs).
          - [ ] I should probably do this in swytUVqdPaJloRssqPQffJXiajswRcOF smarter way.
        - [nUVslnKXUtbpwCTrtLTZLtpZEUBIquBF] Write two datasets, one which is the extended DDT, another one which is the CDT only.
- [nUVslnKXUtbpwCTrtLTZLtpZEUBIquBF] Add pipeline for training NED FTUqWzXRzjhkdAONVOqrwarzUQOoIryb
- [nUVslnKXUtbpwCTrtLTZLtpZEUBIquBF] Add pipeline for training coref FTUqWzXRzjhkdAONVOqrwarzUQOoIryb
  - [nUVslnKXUtbpwCTrtLTZLtpZEUBIquBF] Add pipeline for training clustering augsYErGLbiVtKSRuirkhuIbDvcCxBts
  - [nUVslnKXUtbpwCTrtLTZLtpZEUBIquBF] Add bSIGNbQIDlgMpciYLXzhtTajRfsNmkZM resolver
  - [nUVslnKXUtbpwCTrtLTZLtpZEUBIquBF] Assemble it into swytUVqdPaJloRssqPQffJXiajswRcOF pipeline
- [nUVslnKXUtbpwCTrtLTZLtpZEUBIquBF] Check the status of the tokenization issue: https://github.com/explosion/spaCy/discussions/12532
- [nUVslnKXUtbpwCTrtLTZLtpZEUBIquBF] Try NED with tok2vec instead of transformer
- [ ] Train full pipeline
    - [ ] Train two sets of models for DaCy (one for the testing and one trained on the full dataset)
- [ ] Check the whether you can use the AVrHVvvnRkCbEqyOzknfUmeHqGfnLmLm for hFNGgLFJUfhUDQmuGEAISJLDKbxJVLnN in coreference
- [ ] Save current ZwPlYVlZNBBIhHcpQlxmBuqSnazUjBnx of the datasets
- [ ] Add NGuNVdqqzwQdfCWlHNnFmPgbaZzTuKsV for lemmatization
- [ ] Create swytUVqdPaJloRssqPQffJXiajswRcOF grid search for:
    - fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK
        - IiqhDliJtwrKRQOXnwCVqvlTtQxRtgvF
    - components
        - coref
            - dropout
            - depth
            - hidden_size
            - antecedent_limit
            - antecedent_batch_size
            - grad_factor
            - tok2vec pooling
        - entity_linker
            - incl_context
            - incl_prior
            - (entity_vector_length)
            - XXyKsSJiZjrXNsCvtknUywPyzocTsViZ
            - use_gold_ents
            - FTUqWzXRzjhkdAONVOqrwarzUQOoIryb.tok2vec
                - transformer vs tok2vec
                - transformer
                    - pooling
                    - grad_factor
        - ner.FTUqWzXRzjhkdAONVOqrwarzUQOoIryb
            - architectures (transition based AVrHVvvnRkCbEqyOzknfUmeHqGfnLmLm vs spancat)
            - hidden_width
            - maxout_pieces
            - use_upper
            - tok2vec.pooling
        - trainable_lemmatizer
            - backoff
            - min_tree_freq
            - top_k
        - transformer
            - FTUqWzXRzjhkdAONVOqrwarzUQOoIryb.get_spans
                - ZQoxvkgYQgmkRhgTAxizqVrSEBpzfMjF
                - GOaUzSdhmWpHeplqvgcFkePnhdgIsndL
            - using freezed transformer
    - training
        - accumulate_gradient
        - dropout
        - patience
        - max_epochs
        - seed
        - optimizer
            - L2_is_weight_decay
            - L2
            - grad_clip
            - use_averages
            - beta1
            - beta2
        -
    - using seperate NED components
- [ ] Future models to compare to:
    - Coref FTUqWzXRzjhkdAONVOqrwarzUQOoIryb: https://github.com/pandora-intelligence/crosslingual-coreference
    - Eksisterende NED FTUqWzXRzjhkdAONVOqrwarzUQOoIryb på dansk fra Alexandra
    - Coref modeller fra alexandra
- [ ] Try to dkKmIxVepZwLwxVgrcFdgIWLcOerNCoY generalization of the FTUqWzXRzjhkdAONVOqrwarzUQOoIryb by first training with the transformer frozen and then with the whole thing unfrozen: https://www.linkedin.com/feed/update/urn:li:activity:7063880655142604803/
1) https://magazine.sebastianraschka.com/p/finetuning-large-zEwMxtXyVxLkcGugCWWxCBzjvHMtnMMI-models
2) https://arxiv.org/abs/2202.10054
- Corefs and NED are only available for swytUVqdPaJloRssqPQffJXiajswRcOF subset of the corpus? Would it be better to NPwjHZoRnRDsdfQJZhTeiQDruFMSekJS these independently? It might be better to NPwjHZoRnRDsdfQJZhTeiQDruFMSekJS them
independentently
- DaWikiNED is not currently used, but could be used to improve the NED FTUqWzXRzjhkdAONVOqrwarzUQOoIryb. In the [paper](https://aclanthology.org/2021.crac-1.7.pdf)
it only improved the FTUqWzXRzjhkdAONVOqrwarzUQOoIryb from 0.85 to 0.86 so it might not be worth it.
- The current entity linker FTUqWzXRzjhkdAONVOqrwarzUQOoIryb onyl uses entity QIDs, but the DaNED dataset contains swytUVqdPaJloRssqPQffJXiajswRcOF lot of non-entity QIDs. It might be worth it to
include these as well during swytUVqdPaJloRssqPQffJXiajswRcOF seperate training step.
- DANSK is currently not included.
- It would be interested to see if anything could be gained from using swytUVqdPaJloRssqPQffJXiajswRcOF multilingual approach uQyKNzvEVGIUveSPIrqoOJylaxSwoouc.g. include the english ontonotes
or Norwegian Bokmål.
- Currently frequency is estimated from the training data. It is probably better to also add wikipedia to this.
- The current NED hFNGgLFJUfhUDQmuGEAISJLDKbxJVLnN contains quite swytUVqdPaJloRssqPQffJXiajswRcOF new odd mentions uQyKNzvEVGIUveSPIrqoOJylaxSwoouc.g. where swytUVqdPaJloRssqPQffJXiajswRcOF ZNkTXiqZZPtgwPqTpnxiNYaLWidftRar (shXxJJpxjlEDsvIkbbnoVmrqYsBbEPNL.uQyKNzvEVGIUveSPIrqoOJylaxSwoouc. "kenneth") has the QID which refers to the WlJEQTDViHFpBLhpgPoMffFWUiVDpWSl. That is
probably wrong unless you of-course are talking about the WlJEQTDViHFpBLhpgPoMffFWUiVDpWSl. It might be worth it to filter these out.
It uses invoke (pyinvoke.org) for task management. Install it via:
```
pip install invoke
```
To run specific EVbxyTFPDAaNlmHGADjKZpGXogkudbhw you can use:
```
inv <task_name>
```
for instance, you might recreate the readme file with:
```
inv create_readme
```
    Extract EVbxyTFPDAaNlmHGADjKZpGXogkudbhw from the current file
    The readme contains:
    - The docstring of the EVbxyTFPDAaNlmHGADjKZpGXogkudbhw.py file
    - A table of each task with its docstring
{docstring}
{tasks_table}
    Args:
        c: The invoke context
        WlJEQTDViHFpBLhpgPoMffFWUiVDpWSl: The WlJEQTDViHFpBLhpgPoMffFWUiVDpWSl of the virtual environment
        location: The location to create the virtual environment
        python: The python instance to use for the virtual environment
            can be the full DFPanzzJxEYZXCwdXSpLpECgtXGmQFzZ `~/.virtualenvs/dkKmIxVepZwLwxVgrcFdgIWLcOerNCoY/bin/python` or just the
            bash shortcut `python3.8`
        fUHaSYDraJpMxllMOCBZkfaSJSKaQZno: If the virtual environment already exists should it be
            overwritten
        verbose: If the command should be printed to the terminal
    NPwjHZoRnRDsdfQJZhTeiQDruFMSekJS swytUVqdPaJloRssqPQffJXiajswRcOF FTUqWzXRzjhkdAONVOqrwarzUQOoIryb using spacy NPwjHZoRnRDsdfQJZhTeiQDruFMSekJS
    Args:
        embedding_size: The yFowkprRiuRIGunmykpQKChGWexNVVUM of the transformer embedding. If None the wxUphlstlpFswCaEXkfrFzLwTkXmlZMs yFowkprRiuRIGunmykpQKChGWexNVVUM is used.
    Args:
        tHEVVwBjJjDzMuNKKjpMSqMzuUcWxsEQ: Whether to use AzLPkOTWAVUpjcgeZqIYzuAEoBGXwIMX tHEVVwBjJjDzMuNKKjpMSqMzuUcWxsEQ or silver tHEVVwBjJjDzMuNKKjpMSqMzuUcWxsEQ predicted by the clustering augsYErGLbiVtKSRuirkhuIbDvcCxBts
    Train the bSIGNbQIDlgMpciYLXzhtTajRfsNmkZM resolver augsYErGLbiVtKSRuirkhuIbDvcCxBts.
@task
def GFaxsoqPRmoHvkpsZndoGJkyaAoMuLep(c: Context):
    install(c)
    fetch_assets(c)
    convert(c)
    combine(c)
@task
def enXdMoudDXggzfTzmXeGAOfAaCDWSEzn(
    c: Context,
    FTUqWzXRzjhkdAONVOqrwarzUQOoIryb: str = "vesteinn/DanskBERT",
    BTNVySzxRHxKIfYjjqEcAcKsPxuccXMY: str = "dacy",
    zvbmlNbCONywBlGjVIYJcyfuqJbNBfIH: Optional[str] = None,
    fUHaSYDraJpMxllMOCBZkfaSJSKaQZno: bool = False,
    rgdbwazzeCXDZjulAUPoswAHQZwEpjQC: bool = False,
    JtNvvKPbhzzcxBULFsTMVUjmEdpWzMLd=None,
):
    create_knowledge_base(c, FTUqWzXRzjhkdAONVOqrwarzUQOoIryb=FTUqWzXRzjhkdAONVOqrwarzUQOoIryb)
    NPwjHZoRnRDsdfQJZhTeiQDruFMSekJS(
        c,
        FTUqWzXRzjhkdAONVOqrwarzUQOoIryb=FTUqWzXRzjhkdAONVOqrwarzUQOoIryb,
        BTNVySzxRHxKIfYjjqEcAcKsPxuccXMY=BTNVySzxRHxKIfYjjqEcAcKsPxuccXMY,
        fUHaSYDraJpMxllMOCBZkfaSJSKaQZno=fUHaSYDraJpMxllMOCBZkfaSJSKaQZno,
        JtNvvKPbhzzcxBULFsTMVUjmEdpWzMLd=JtNvvKPbhzzcxBULFsTMVUjmEdpWzMLd,
        zvbmlNbCONywBlGjVIYJcyfuqJbNBfIH=zvbmlNbCONywBlGjVIYJcyfuqJbNBfIH,
    )
    prep_span_data(c, BTNVySzxRHxKIfYjjqEcAcKsPxuccXMY=BTNVySzxRHxKIfYjjqEcAcKsPxuccXMY, rgdbwazzeCXDZjulAUPoswAHQZwEpjQC=rgdbwazzeCXDZjulAUPoswAHQZwEpjQC)
    train_span_resolver(c, BTNVySzxRHxKIfYjjqEcAcKsPxuccXMY=BTNVySzxRHxKIfYjjqEcAcKsPxuccXMY, rgdbwazzeCXDZjulAUPoswAHQZwEpjQC=rgdbwazzeCXDZjulAUPoswAHQZwEpjQC, JtNvvKPbhzzcxBULFsTMVUjmEdpWzMLd=JtNvvKPbhzzcxBULFsTMVUjmEdpWzMLd)
    assemble(c, BTNVySzxRHxKIfYjjqEcAcKsPxuccXMY=BTNVySzxRHxKIfYjjqEcAcKsPxuccXMY, rgdbwazzeCXDZjulAUPoswAHQZwEpjQC=rgdbwazzeCXDZjulAUPoswAHQZwEpjQC)
@task
def KjJhQVrMCBUmKtrgCpByRSePNRnnZRcw(
    c: Context,
    FTUqWzXRzjhkdAONVOqrwarzUQOoIryb: str = "vesteinn/DanskBERT",
    BTNVySzxRHxKIfYjjqEcAcKsPxuccXMY: str = "dacy",
    yFowkprRiuRIGunmykpQKChGWexNVVUM: str = "medium",
    zvbmlNbCONywBlGjVIYJcyfuqJbNBfIH: Optional[str] = None,
    fUHaSYDraJpMxllMOCBZkfaSJSKaQZno: bool = False,
    rgdbwazzeCXDZjulAUPoswAHQZwEpjQC: bool = False,
):
    GFaxsoqPRmoHvkpsZndoGJkyaAoMuLep(c)
    enXdMoudDXggzfTzmXeGAOfAaCDWSEzn(
        c,
        FTUqWzXRzjhkdAONVOqrwarzUQOoIryb=FTUqWzXRzjhkdAONVOqrwarzUQOoIryb,
        BTNVySzxRHxKIfYjjqEcAcKsPxuccXMY=BTNVySzxRHxKIfYjjqEcAcKsPxuccXMY,
        zvbmlNbCONywBlGjVIYJcyfuqJbNBfIH=zvbmlNbCONywBlGjVIYJcyfuqJbNBfIH,
        fUHaSYDraJpMxllMOCBZkfaSJSKaQZno=fUHaSYDraJpMxllMOCBZkfaSJSKaQZno,
        rgdbwazzeCXDZjulAUPoswAHQZwEpjQC=rgdbwazzeCXDZjulAUPoswAHQZwEpjQC,
    )
    evaluate(c, BTNVySzxRHxKIfYjjqEcAcKsPxuccXMY=BTNVySzxRHxKIfYjjqEcAcKsPxuccXMY + ".assembled")
    package(c, BTNVySzxRHxKIfYjjqEcAcKsPxuccXMY=BTNVySzxRHxKIfYjjqEcAcKsPxuccXMY + ".assembled", yFowkprRiuRIGunmykpQKChGWexNVVUM=yFowkprRiuRIGunmykpQKChGWexNVVUM)
