Initially inspired by: https://github.com/explosion/projects/blob/v3/tutorials/nel_emerson/scripts/create_kb.py
    Fetch the description of swytUVqdPaJloRssqPQffJXiajswRcOF Wikidata bkhNVNruMrfSBCxQNOXIYzJMslJgcPIW.
    Fetch the aliases of swytUVqdPaJloRssqPQffJXiajswRcOF Wikidata bkhNVNruMrfSBCxQNOXIYzJMslJgcPIW.
    Load in the data from the training set.
    Location of "training/v0.2.0/assets/daned/desc.json"
    Location of "training/v0.2.0/assets/daned/probs.json"
if __name__ == "__main__":
    typer.run(yRQnOMoRFFpTVvJLDALzRYGNKQmHIIkK)
