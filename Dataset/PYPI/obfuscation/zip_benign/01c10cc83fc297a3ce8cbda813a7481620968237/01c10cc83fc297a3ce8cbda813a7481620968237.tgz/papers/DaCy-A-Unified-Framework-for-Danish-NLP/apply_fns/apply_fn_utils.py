from typing import Callable, Iterable, List
from spacy.tokens import Doc, Span
from spacy.training import Example
def IYKYPATAgNhujhIsaEaQeaLuAHDmDdpS(dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO, jGxzeFKMKUZgyiteCVkHweEUJRsLrkxh):
    iQoRDzzEaABsNGlJUneNAjjEggSdHFbL = getattr(dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO, jGxzeFKMKUZgyiteCVkHweEUJRsLrkxh)
    for bSIGNbQIDlgMpciYLXzhtTajRfsNmkZM in iQoRDzzEaABsNGlJUneNAjjEggSdHFbL:
        if bSIGNbQIDlgMpciYLXzhtTajRfsNmkZM.label_ == "MISC":
            continue
        yield bSIGNbQIDlgMpciYLXzhtTajRfsNmkZM
def IGmlqQDdGCgoxdzSeMmnCdVjbFxvhZog(dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO: Doc, lJqoyIQIAYjUqbvfCrmjXkNdGyhSPWGr: List[str]) -> Doc:
    wKpsfLWWpIOjsmKMumnCZFxUffejXAiX = []
    for shXxJJpxjlEDsvIkbbnoVmrqYsBbEPNL, uhbtjocnwBSUeGveLFUiUFTyETzBzkyk in enumerate(lJqoyIQIAYjUqbvfCrmjXkNdGyhSPWGr):
        if uhbtjocnwBSUeGveLFUiUFTyETzBzkyk == "O":
            continue
        GTLkqFsYUIauNVtRJrxERpeYeUeLrsit, KUvtrSCOEgiUOkQDFkcELZDzhqQWlQxW = uhbtjocnwBSUeGveLFUiUFTyETzBzkyk.split("-")
        if (shXxJJpxjlEDsvIkbbnoVmrqYsBbEPNL - 1 >= 0 and GTLkqFsYUIauNVtRJrxERpeYeUeLrsit == "I" and lJqoyIQIAYjUqbvfCrmjXkNdGyhSPWGr[shXxJJpxjlEDsvIkbbnoVmrqYsBbEPNL - 1] == "O") or (
            shXxJJpxjlEDsvIkbbnoVmrqYsBbEPNL == 0 and GTLkqFsYUIauNVtRJrxERpeYeUeLrsit == "I"
        ):
            GTLkqFsYUIauNVtRJrxERpeYeUeLrsit = "B"
        if GTLkqFsYUIauNVtRJrxERpeYeUeLrsit == "B":
            SrrgcUxJWQeuNMsJfRMnoTWlaHhNcNzn = shXxJJpxjlEDsvIkbbnoVmrqYsBbEPNL
        if shXxJJpxjlEDsvIkbbnoVmrqYsBbEPNL + 1 >= len(lJqoyIQIAYjUqbvfCrmjXkNdGyhSPWGr) or lJqoyIQIAYjUqbvfCrmjXkNdGyhSPWGr[shXxJJpxjlEDsvIkbbnoVmrqYsBbEPNL + 1].split("-")[0] != "I":
            wKpsfLWWpIOjsmKMumnCZFxUffejXAiX.append(Span(dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO, SrrgcUxJWQeuNMsJfRMnoTWlaHhNcNzn, shXxJJpxjlEDsvIkbbnoVmrqYsBbEPNL + 1, uhbtjocnwBSUeGveLFUiUFTyETzBzkyk=KUvtrSCOEgiUOkQDFkcELZDzhqQWlQxW))
    dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO.set_ents(wKpsfLWWpIOjsmKMumnCZFxUffejXAiX)
    return dvVoBtcjfhoxpCAiuUcZkySyuSsQvWbO
def PPJxlGqEWCfkvLlSuXoUbOtLAQfNtPKn(func: Callable) -> Callable:
    def foILJTJsbRaNNGHcwtdxCpDSutbgkBmX(iTpHOITjPjQlCfIMLTbovSBsxGDlvPif: Iterable[Example], **kwargs) -> Iterable[Example]:
        return [func(uQyKNzvEVGIUveSPIrqoOJylaxSwoouc, **kwargs) for uQyKNzvEVGIUveSPIrqoOJylaxSwoouc in iTpHOITjPjQlCfIMLTbovSBsxGDlvPif]
    return foILJTJsbRaNNGHcwtdxCpDSutbgkBmX
