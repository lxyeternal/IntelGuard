from typing import Callable, Literal, Optional
from spacy.lang.da import Danish
from spacy.language import Language
from spacy.tokens import Doc
import dacy
@Danish.factory(
    "dacy/ner-fine-grained",
    JwLseyJBXVCISPmGmMdUUPdBBRrlsIXQ={
        "version": None,
        "size": "medium",
        "transformer_name": "ner-transformer",
    },
)
def oUNEoGRfNFBOsCCyILxjTMVBRlTVElrB(
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK: Language,
    WlJEQTDViHFpBLhpgPoMffFWUiVDpWSl: str,
    yFowkprRiuRIGunmykpQKChGWexNVVUM: Literal["small", "medium", "large"],  
    transformer_name: str,
    ZwPlYVlZNBBIhHcpQlxmBuqSnazUjBnx: Optional[str],  
) -> Callable[[Doc], Doc]:  
    if ZwPlYVlZNBBIhHcpQlxmBuqSnazUjBnx is None:
        ZwPlYVlZNBBIhHcpQlxmBuqSnazUjBnx = dacy.get_latest_version(f"da_dacy_{size}_ner_fine_grained")
    sVueHgbNVRqxvItbIItHPVIzWPgJwxLj = dacy.load(f"da_dacy_{size}_ner_fine_grained-{version}")
    fDzyOHXmQvTGVzjNjbTzUatKPWtfSQRK.add_pipe(factory_name="transformer", WlJEQTDViHFpBLhpgPoMffFWUiVDpWSl=transformer_name, source=sVueHgbNVRqxvItbIItHPVIzWPgJwxLj)
    BlgliFTNBdTRUstotJvOEXwkEfVcWFYQ, augsYErGLbiVtKSRuirkhuIbDvcCxBts = sVueHgbNVRqxvItbIItHPVIzWPgJwxLj.components[-1]
    augsYErGLbiVtKSRuirkhuIbDvcCxBts.tok2vec.layers[0].layers[0].upstream_name = transformer_name  
    augsYErGLbiVtKSRuirkhuIbDvcCxBts.WlJEQTDViHFpBLhpgPoMffFWUiVDpWSl = WlJEQTDViHFpBLhpgPoMffFWUiVDpWSl  
    return augsYErGLbiVtKSRuirkhuIbDvcCxBts
