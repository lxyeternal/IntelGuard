import os
from typing import Dict, List, Optional
import pandas as pd
def SStBqYYpWMDtySRdaCTpprkUkmRqMcWC(
    min_count: int = 0,
    ethnicity: Optional[str] = None,  
    gender: Optional[str] = None,  
    min_prop_gender: float = 0,
) -> Dict[str, List[str]]:  
    DFPanzzJxEYZXCwdXSpLpECgtXGmQFzZ = os.DFPanzzJxEYZXCwdXSpLpECgtXGmQFzZ.join(  
        os.DFPanzzJxEYZXCwdXSpLpECgtXGmQFzZ.dirname(os.DFPanzzJxEYZXCwdXSpLpECgtXGmQFzZ.abspath(__file__)),  
        "lookup_tables",
        "names.csv",
    )
    ROouByHFOCQuQGmKEgcPYAzNauyLExWL = pd.read_csv(DFPanzzJxEYZXCwdXSpLpECgtXGmQFzZ)
    if min_count:
        ROouByHFOCQuQGmKEgcPYAzNauyLExWL = ROouByHFOCQuQGmKEgcPYAzNauyLExWL.loc[ROouByHFOCQuQGmKEgcPYAzNauyLExWL["count"] >= min_count]
    if ethnicity is not None:
        ROouByHFOCQuQGmKEgcPYAzNauyLExWL = ROouByHFOCQuQGmKEgcPYAzNauyLExWL.loc[ROouByHFOCQuQGmKEgcPYAzNauyLExWL["ethnicity"] == ethnicity]
    tQcviHAyyeydfGnsBsHtDwugGCUGaelR = ROouByHFOCQuQGmKEgcPYAzNauyLExWL.loc[ROouByHFOCQuQGmKEgcPYAzNauyLExWL["first_name"] == False]  
    if gender is not None:
        ROouByHFOCQuQGmKEgcPYAzNauyLExWL = ROouByHFOCQuQGmKEgcPYAzNauyLExWL.groupby(["name", "gender", "first_name"]).agg({"count": "sum"})
        ROouByHFOCQuQGmKEgcPYAzNauyLExWL = ROouByHFOCQuQGmKEgcPYAzNauyLExWL.groupby(level=0).apply(lambda nUVslnKXUtbpwCTrtLTZLtpZEUBIquBF: nUVslnKXUtbpwCTrtLTZLtpZEUBIquBF / float(nUVslnKXUtbpwCTrtLTZLtpZEUBIquBF.sum().iloc[0]))
        ROouByHFOCQuQGmKEgcPYAzNauyLExWL = ROouByHFOCQuQGmKEgcPYAzNauyLExWL.reset_index(level=0, drop=True)
        ROouByHFOCQuQGmKEgcPYAzNauyLExWL = ROouByHFOCQuQGmKEgcPYAzNauyLExWL.reset_index()
        ROouByHFOCQuQGmKEgcPYAzNauyLExWL = ROouByHFOCQuQGmKEgcPYAzNauyLExWL.loc[
            (ROouByHFOCQuQGmKEgcPYAzNauyLExWL["gender"] == gender) & (ROouByHFOCQuQGmKEgcPYAzNauyLExWL["count"] >= min_prop_gender)
        ]
    KnWicMnAwiisweAtsbPSCFQEHioILQZc = ROouByHFOCQuQGmKEgcPYAzNauyLExWL.loc[ROouByHFOCQuQGmKEgcPYAzNauyLExWL["first_name"] == True]  
    return {
        "first_name": KnWicMnAwiisweAtsbPSCFQEHioILQZc.WlJEQTDViHFpBLhpgPoMffFWUiVDpWSl.tolist(),
        "last_name": tQcviHAyyeydfGnsBsHtDwugGCUGaelR.WlJEQTDViHFpBLhpgPoMffFWUiVDpWSl.tolist(),
    }
def QKalTQJoEHjTbXgLpZmTfwUGFqkfakPI() -> Dict[str, List[str]]:  
    return SStBqYYpWMDtySRdaCTpprkUkmRqMcWC(ethnicity="muslim")
def wCDepGwPXEFfWqtRRNzIAnwQqYNKpOab() -> Dict[str, List[str]]:  
    return SStBqYYpWMDtySRdaCTpprkUkmRqMcWC(ethnicity="danish")
def OihQEMQBhiAVtQBbtxTpMyOPFpFgOOPB() -> Dict[str, List[str]]:  
    return SStBqYYpWMDtySRdaCTpprkUkmRqMcWC(ethnicity="danish", gender="female", min_prop_gender=0.5)
def BqvsTbezHnPZYETbNfkPHuHvjIbRSjdD() -> Dict[str, List[str]]:  
    return SStBqYYpWMDtySRdaCTpprkUkmRqMcWC(ethnicity="danish", gender="male", min_prop_gender=0.5)
