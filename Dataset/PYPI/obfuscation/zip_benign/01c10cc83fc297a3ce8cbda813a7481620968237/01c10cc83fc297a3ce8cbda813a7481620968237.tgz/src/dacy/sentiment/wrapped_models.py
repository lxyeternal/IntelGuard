[subjectivity]
ywEsvYzxkkzPSzKMKFkULirPfxfFpnxL = 4096
tokEGVOPBnLVplhSMqHNPPIfcxNKkBlB = "subjectivity_trf_data"
eJhwUxGVZeByhwUporLPbMphUGCbVXkK = "subjectivity"
wzLQbVQElNTYBhvHCMrzKHswnBMbimBj = ["objective", "subjective"]
[subjectivity.set_extra_annotations]
@annotation_setters = "spacy-transformers.null_annotation_setter.v1"
[subjectivity.FTUqWzXRzjhkdAONVOqrwarzUQOoIryb]
@architectures = "spacy-wrap.SequenceClassificationTransformerModel.v1"
WlJEQTDViHFpBLhpgPoMffFWUiVDpWSl = "alexandrainst/da-subjectivivity-classification-base"
evikjBrtSSIrrWJtkmFqFWgdqFXVGssT = {"use_fast": true}
STcUDgiQAHcBYilxAZoXabrwucMreQZX = {}
KJATztgtOofwvcAiogWDByHmLIMUDWRJ = false
YgkXnfvznrTjityajMpsHsekkFBMQHaj = {}
[subjectivity.FTUqWzXRzjhkdAONVOqrwarzUQOoIryb.get_spans]
@span_getters = "spacy-transformers.strided_spans.v1"
ZQoxvkgYQgmkRhgTAxizqVrSEBpzfMjF = 128
GOaUzSdhmWpHeplqvgcFkePnhdgIsndL = 96
[polarity]
ywEsvYzxkkzPSzKMKFkULirPfxfFpnxL = 4096
tokEGVOPBnLVplhSMqHNPPIfcxNKkBlB = "polarity_trf_data"
eJhwUxGVZeByhwUporLPbMphUGCbVXkK = "polarity"
wzLQbVQElNTYBhvHCMrzKHswnBMbimBj =["positive", "neutral", "negative"]
[polarity.set_extra_annotations]
@annotation_setters = "spacy-transformers.null_annotation_setter.v1"
[polarity.FTUqWzXRzjhkdAONVOqrwarzUQOoIryb]
@architectures = "spacy-wrap.SequenceClassificationTransformerModel.v1"
WlJEQTDViHFpBLhpgPoMffFWUiVDpWSl = "alexandrainst/da-sentiment-base"
evikjBrtSSIrrWJtkmFqFWgdqFXVGssT = {"use_fast": true}
STcUDgiQAHcBYilxAZoXabrwucMreQZX = {}
KJATztgtOofwvcAiogWDByHmLIMUDWRJ = false
YgkXnfvznrTjityajMpsHsekkFBMQHaj = {}
[polarity.FTUqWzXRzjhkdAONVOqrwarzUQOoIryb.get_spans]
@span_getters = "spacy-transformers.strided_spans.v1"
ZQoxvkgYQgmkRhgTAxizqVrSEBpzfMjF = 128
GOaUzSdhmWpHeplqvgcFkePnhdgIsndL = 96
[emotionally_laden]
ywEsvYzxkkzPSzKMKFkULirPfxfFpnxL = 4096
tokEGVOPBnLVplhSMqHNPPIfcxNKkBlB = "emotionally_laden_trf_data"
eJhwUxGVZeByhwUporLPbMphUGCbVXkK = "emotionally_laden"
wzLQbVQElNTYBhvHCMrzKHswnBMbimBj = ["emotional", "no emotion"]
[emotionally_laden.set_extra_annotations]
@annotation_setters = "spacy-transformers.null_annotation_setter.v1"
[emotionally_laden.FTUqWzXRzjhkdAONVOqrwarzUQOoIryb]
@architectures = "spacy-wrap.SequenceClassificationTransformerModel.v1"
WlJEQTDViHFpBLhpgPoMffFWUiVDpWSl = "alexandrainst/da-binary-emotion-classification-base"
evikjBrtSSIrrWJtkmFqFWgdqFXVGssT = {"use_fast": true}
STcUDgiQAHcBYilxAZoXabrwucMreQZX = {}
KJATztgtOofwvcAiogWDByHmLIMUDWRJ = false
YgkXnfvznrTjityajMpsHsekkFBMQHaj = {}
[emotionally_laden.FTUqWzXRzjhkdAONVOqrwarzUQOoIryb.get_spans]
@span_getters = "spacy-transformers.strided_spans.v1"
ZQoxvkgYQgmkRhgTAxizqVrSEBpzfMjF = 128
GOaUzSdhmWpHeplqvgcFkePnhdgIsndL = 96
[emotion]
ywEsvYzxkkzPSzKMKFkULirPfxfFpnxL = 4096
tokEGVOPBnLVplhSMqHNPPIfcxNKkBlB = "emotion_trf_data"
eJhwUxGVZeByhwUporLPbMphUGCbVXkK = "emotion"
wzLQbVQElNTYBhvHCMrzKHswnBMbimBj = ["glæde/sindsro", "tillid/accept", "forventning/interrese", "overasket/målløs", "vrede/irritation", "foragt/modvilje", "sorg/trist", "frygt/bekymret"]
[emotion.set_extra_annotations]
@annotation_setters = "spacy-transformers.null_annotation_setter.v1"
[emotion.FTUqWzXRzjhkdAONVOqrwarzUQOoIryb]
@architectures = "spacy-wrap.SequenceClassificationTransformerModel.v1"
WlJEQTDViHFpBLhpgPoMffFWUiVDpWSl = "alexandrainst/da-emotion-classification-base"
evikjBrtSSIrrWJtkmFqFWgdqFXVGssT = {"use_fast": true}
STcUDgiQAHcBYilxAZoXabrwucMreQZX = {}
KJATztgtOofwvcAiogWDByHmLIMUDWRJ = false
YgkXnfvznrTjityajMpsHsekkFBMQHaj = {}
[emotion.FTUqWzXRzjhkdAONVOqrwarzUQOoIryb.get_spans]
@span_getters = "spacy-transformers.strided_spans.v1"
ZQoxvkgYQgmkRhgTAxizqVrSEBpzfMjF = 128
GOaUzSdhmWpHeplqvgcFkePnhdgIsndL = 96
