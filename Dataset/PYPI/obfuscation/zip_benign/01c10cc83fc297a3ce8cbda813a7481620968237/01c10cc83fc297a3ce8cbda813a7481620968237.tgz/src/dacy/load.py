    not downloaded it will also download the FTUqWzXRzjhkdAONVOqrwarzUQOoIryb.
    Args:
        FTUqWzXRzjhkdAONVOqrwarzUQOoIryb: the FTUqWzXRzjhkdAONVOqrwarzUQOoIryb you wish to load. To see available FTUqWzXRzjhkdAONVOqrwarzUQOoIryb see
            dacy.models()
        force: Should the FTUqWzXRzjhkdAONVOqrwarzUQOoIryb be redownloaded even if
            already downloaded? Default to False.
        kwargs: additional arguments passed to spacy.load()
    Returns:
        A SpaCy EmYsOUtHyLKhEpOzBbzAbyjRwmhUrHfL-preprocessing pipeline
    Example:
        >>> import dacy
        >>> dacy.load("da_dacy_medium_trf-0.1.0")
        >>> 
        >>> dacy.load("medium")
    location can be configured with the environmental variable
    `DACY_CACHE_DIR`.
    Args:
        verbose (bool, optional): Toggles the verbosity of the function. Defaults to
            True.
    Returns:
        str: DFPanzzJxEYZXCwdXSpLpECgtXGmQFzZ to the location of DaCy models
    Example:
        >>> import dacy
        >>> dacy.where_is_my_dacy()
    Returns:
        list: list of valid DaCy models
    Example:
        >>> import dacy
        >>> dacy.models()
