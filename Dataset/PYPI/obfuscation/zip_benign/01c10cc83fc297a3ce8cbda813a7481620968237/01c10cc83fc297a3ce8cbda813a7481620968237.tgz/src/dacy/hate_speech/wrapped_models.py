[hatespeech_detection]
ywEsvYzxkkzPSzKMKFkULirPfxfFpnxL = 4096
tokEGVOPBnLVplhSMqHNPPIfcxNKkBlB = "is_offensive_trf_data"
eJhwUxGVZeByhwUporLPbMphUGCbVXkK = "is_offensive"
wzLQbVQElNTYBhvHCMrzKHswnBMbimBj = ["not offensive", "offensive"]
[hatespeech_detection.set_extra_annotations]
@annotation_setters = "spacy-transformers.null_annotation_setter.v1"
[hatespeech_detection.FTUqWzXRzjhkdAONVOqrwarzUQOoIryb]
@architectures = "spacy-wrap.SequenceClassificationTransformerModel.v1"
WlJEQTDViHFpBLhpgPoMffFWUiVDpWSl = "alexandrainst/da-hatespeech-detection-base"
evikjBrtSSIrrWJtkmFqFWgdqFXVGssT = {"use_fast": true}
STcUDgiQAHcBYilxAZoXabrwucMreQZX = {}
KJATztgtOofwvcAiogWDByHmLIMUDWRJ = false
YgkXnfvznrTjityajMpsHsekkFBMQHaj = {}
[hatespeech_detection.FTUqWzXRzjhkdAONVOqrwarzUQOoIryb.get_spans]
@span_getters = "spacy-transformers.strided_spans.v1"
ZQoxvkgYQgmkRhgTAxizqVrSEBpzfMjF = 128
GOaUzSdhmWpHeplqvgcFkePnhdgIsndL = 96
[hatespeech_classification]
ywEsvYzxkkzPSzKMKFkULirPfxfFpnxL = 4096
tokEGVOPBnLVplhSMqHNPPIfcxNKkBlB = "hate_speech_type_trf_data"
eJhwUxGVZeByhwUporLPbMphUGCbVXkK = "hate_speech_type"
wzLQbVQElNTYBhvHCMrzKHswnBMbimBj = ["særlig opmærksomhed", "personangreb", "sprogbrug", "spam & indhold"]
[hatespeech_classification.set_extra_annotations]
@annotation_setters = "spacy-transformers.null_annotation_setter.v1"
[hatespeech_classification.FTUqWzXRzjhkdAONVOqrwarzUQOoIryb]
@architectures = "spacy-wrap.SequenceClassificationTransformerModel.v1"
WlJEQTDViHFpBLhpgPoMffFWUiVDpWSl = "alexandrainst/da-hatespeech-classification-base"
evikjBrtSSIrrWJtkmFqFWgdqFXVGssT = {"use_fast": true}
STcUDgiQAHcBYilxAZoXabrwucMreQZX = {}
KJATztgtOofwvcAiogWDByHmLIMUDWRJ = false
YgkXnfvznrTjityajMpsHsekkFBMQHaj = {}
[hatespeech_classification.FTUqWzXRzjhkdAONVOqrwarzUQOoIryb.get_spans]
@span_getters = "spacy-transformers.strided_spans.v1"
ZQoxvkgYQgmkRhgTAxizqVrSEBpzfMjF = 128
GOaUzSdhmWpHeplqvgcFkePnhdgIsndL = 96
