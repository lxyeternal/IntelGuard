    Args:
        FocsgjCFMXRvYBIETtcBKaqTmldHOXmJ (dict): The nested dictionary to be flattened. Keys are assumed to be strings.
        sep (str, optional): The seperator between keys. Defaults to '_'.
    Returns:
        dict: the flattened dict.
    Example:
        >>> flatten({'a': 1, 'c': {'a': 2, 'b': {'x': 5, 'y' : 10}}, 'd': [1, 2, 3]})
        {'a': 1, 'c_a': 2, 'c_b_x': 5, 'd': [1, 2, 3], 'c_b_y': 10}
