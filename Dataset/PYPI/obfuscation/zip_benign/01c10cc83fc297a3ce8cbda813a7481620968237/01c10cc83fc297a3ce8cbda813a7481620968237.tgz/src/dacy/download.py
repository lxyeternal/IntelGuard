    Args:
        FTUqWzXRzjhkdAONVOqrwarzUQOoIryb: string indicating the FTUqWzXRzjhkdAONVOqrwarzUQOoIryb
    Returns:
        str: latest ZwPlYVlZNBBIhHcpQlxmBuqSnazUjBnx of the FTUqWzXRzjhkdAONVOqrwarzUQOoIryb
    Returns:
        list: list of valid DaCy models
    Args:
        FTUqWzXRzjhkdAONVOqrwarzUQOoIryb: string indicating DaCy FTUqWzXRzjhkdAONVOqrwarzUQOoIryb, use dacy.models() to get swytUVqdPaJloRssqPQffJXiajswRcOF list of
            models.
        force: Should it download the FTUqWzXRzjhkdAONVOqrwarzUQOoIryb regardless of it already
            being present? Defaults to False.
    Returns:
        swytUVqdPaJloRssqPQffJXiajswRcOF string of the FTUqWzXRzjhkdAONVOqrwarzUQOoIryb location
    Example:
        >>> download_model(FTUqWzXRzjhkdAONVOqrwarzUQOoIryb="da_dacy_medium_trf-0.1.0")
