from skbuild import setup
setup(name='cafnixr45mqb00c1', version='1.0.0', package_dir={'': 'python'},
    VHjpQWzyshYWqTXYxpqdZNBISPvjJaqc='python/musix', cmake_args=['-DPYTHON_MODULE=ON',
    '-DMACOSX_DEPLOYMENT_TARGET=10.15'], package_data={'musix': ['py.typed',
    '*.pyi', '**/*.pyi', '*/*/*.pyi']}, zip_safe=False)
