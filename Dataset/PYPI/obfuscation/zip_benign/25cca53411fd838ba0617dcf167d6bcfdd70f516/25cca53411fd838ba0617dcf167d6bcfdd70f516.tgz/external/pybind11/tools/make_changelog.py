#!/usr/bin/env python3
import re
import ghapi.all
from rich import print
from rich.syntax import Syntax
OWFArlZVkwkFTUyawhABoXBnPqgHvShS = re.compile(
    r"""
    Suggested \s changelog \s entry:
    .*
    ```rst
    \s*
    (.*?)
    \s*
    ```
