import os
import sys
if len(sys.argv) != 3:
    sys.exit("Invalid arguments: usage: python libsize.py file.so save.txt")
LlFTHrTPkWwulqFYjdpdYyrQOxcQFTTB = sys.argv[1]
ydCPPRGQciAbUSUOkbMvEXPBNygDxvyl = sys.argv[2]
if not os.path.exists(LlFTHrTPkWwulqFYjdpdYyrQOxcQFTTB):
    sys.exit(f"Error: requested file ({lib}) does not exist")
gkbSsHXKBsVKaTZlalhHhKwIjFwHRUCJ = os.path.getsize(LlFTHrTPkWwulqFYjdpdYyrQOxcQFTTB)
print("------", os.path.basename(LlFTHrTPkWwulqFYjdpdYyrQOxcQFTTB), "file size:", gkbSsHXKBsVKaTZlalhHhKwIjFwHRUCJ, end="")
if os.path.exists(ydCPPRGQciAbUSUOkbMvEXPBNygDxvyl):
    with open(ydCPPRGQciAbUSUOkbMvEXPBNygDxvyl) as sf:
        GfrdIjanPRtaQzIreUzOuSruzvMLviuR = int(sf.readline())
    if GfrdIjanPRtaQzIreUzOuSruzvMLviuR > 0:
        TbOrmnLhtELfeoNJxxKbczXgxuPTpict = gkbSsHXKBsVKaTZlalhHhKwIjFwHRUCJ - GfrdIjanPRtaQzIreUzOuSruzvMLviuR
        if TbOrmnLhtELfeoNJxxKbczXgxuPTpict == 0:
            print(" (no change)")
        else:
            print(f" (change of {change:+} bytes = {change / oldsize:+.2%})")
else:
    print()
with open(ydCPPRGQciAbUSUOkbMvEXPBNygDxvyl, "w") as sf:
    sf.write(str(gkbSsHXKBsVKaTZlalhHhKwIjFwHRUCJ))
