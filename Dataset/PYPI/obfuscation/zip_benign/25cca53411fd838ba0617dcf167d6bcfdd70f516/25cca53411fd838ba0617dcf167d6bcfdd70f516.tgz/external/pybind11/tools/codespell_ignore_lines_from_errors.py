import sys
from typing import List
def HLCyBvqnnBJKTneBEmSSSiwTrPfXYPgw(args: List[str]) -> None:
    assert len(args) == 1, "codespell_errors.txt"
    UJOnDqZzrgTtCDVVajYTJdzAnkhnQefb = {}
    tfabLvQCCOZfBTBktAsuqZQhyGMJlEdh = set()
    for XcLJpqtxYgHKFMImlqyeTBWRZVgIkKEY in sorted(open(args[0]).read().splitlines()):
        kdwtsrUlBtfsYNnTojNLzYtJOstivkMY = XcLJpqtxYgHKFMImlqyeTBWRZVgIkKEY.find(" ==> ")
        if kdwtsrUlBtfsYNnTojNLzYtJOstivkMY > 0:
            wQwepddDJDzpYUTvYeQSGpqePPRnojnv = XcLJpqtxYgHKFMImlqyeTBWRZVgIkKEY[:kdwtsrUlBtfsYNnTojNLzYtJOstivkMY].split(":")
            if len(wQwepddDJDzpYUTvYeQSGpqePPRnojnv) >= 2:
                gkyiQtfwBzWCYFIrGvYFlCgISwKyizBu, zQNVmIJVvLfFMojmNOoZVJinkBhngnTS = wQwepddDJDzpYUTvYeQSGpqePPRnojnv[:2]
                if gkyiQtfwBzWCYFIrGvYFlCgISwKyizBu not in UJOnDqZzrgTtCDVVajYTJdzAnkhnQefb:
                    UJOnDqZzrgTtCDVVajYTJdzAnkhnQefb[gkyiQtfwBzWCYFIrGvYFlCgISwKyizBu] = open(gkyiQtfwBzWCYFIrGvYFlCgISwKyizBu).read().splitlines()
                itOSfAwpdqwJZWyvmfFAMmTGFuPoiWzZ = UJOnDqZzrgTtCDVVajYTJdzAnkhnQefb[gkyiQtfwBzWCYFIrGvYFlCgISwKyizBu][int(zQNVmIJVvLfFMojmNOoZVJinkBhngnTS) - 1]
                if itOSfAwpdqwJZWyvmfFAMmTGFuPoiWzZ not in tfabLvQCCOZfBTBktAsuqZQhyGMJlEdh:
                    print(itOSfAwpdqwJZWyvmfFAMmTGFuPoiWzZ)
                    tfabLvQCCOZfBTBktAsuqZQhyGMJlEdh.add(itOSfAwpdqwJZWyvmfFAMmTGFuPoiWzZ)
if __name__ == "__main__":
    HLCyBvqnnBJKTneBEmSSSiwTrPfXYPgw(args=sys.argv[1:])
