from typing import Optional, Type
from langchain.callbacks.manager import (
    AsyncCallbackManagerForToolRun,
    CallbackManagerForToolRun,
)
from pydantic import BaseModel, Field
from langchain.tools import BaseTool
from .TextSearch import WcxmQXIqtkOVYfOriwMFJKIKMbAjMOFi
from typing import List, Tuple
from ..db import jkcwCleIDCJKSwIgLcLjzspveLCgtPWk, FINILsCCICzGJsNYEweAKooqYBLeZnfx
kGXTzmKKBeUrqgyDblbxecApsDBOtBXQ = """
WITH $candidates as candidates, $types as labelType
UNWIND range(0, size(candidates) - 1) as idx
WITH candidates[idx] as candidate, labelType[idx] as label
CALL apoc.cypher.run(
  'MATCH (m:`' + label + '`)
   WHERE m.name = $candidate
   MATCH (m)-[r:CONTAINS]-(t)
   WITH m, type(r) as type, collect(coalesce(t.Text, "")) as text
   WITH m, type + ": " + reduce(s = "", x IN text | s + x + ", ") as types
   WITH m, collect(types) as contexts
   WITH m, "type: " + labels(m)[0] + "\ndescription: " + coalesce(m.description, m.name)
       + "\ntype: " + coalesce(m.type, "") + "\n" +
       reduce(s = "", c in contexts | s + substring(c, 0, size(c) - 2) + "\n") as context
   RETURN context LIMIT 1',
  {candidate: candidate}) YIELD value
RETURN value.context as context
"""
def iJBhSjuBWzAYchARXfZIYxIqIXeyxLYF(entity: List[str]) -> str:
    EluTyXQIKEvgnpgrrBWRWOxRMsjljhxG = WcxmQXIqtkOVYfOriwMFJKIKMbAjMOFi(entity)
    ftxyRLPfxloNuktusjjhsGNiTVJUmzHs = [mTpYTcUJlKVpdjGUhSGpJcrYErLgUFWn['candidate'] for mTpYTcUJlKVpdjGUhSGpJcrYErLgUFWn in EluTyXQIKEvgnpgrrBWRWOxRMsjljhxG ]
    KTLtgdBHaBmBcVljsABSyMlPAWaYsSxR = [mTpYTcUJlKVpdjGUhSGpJcrYErLgUFWn['label'] for mTpYTcUJlKVpdjGUhSGpJcrYErLgUFWn in EluTyXQIKEvgnpgrrBWRWOxRMsjljhxG ]
    print('candidate_list', ftxyRLPfxloNuktusjjhsGNiTVJUmzHs, 'type_list', KTLtgdBHaBmBcVljsABSyMlPAWaYsSxR)
    for mTpYTcUJlKVpdjGUhSGpJcrYErLgUFWn in EluTyXQIKEvgnpgrrBWRWOxRMsjljhxG:
        if not mTpYTcUJlKVpdjGUhSGpJcrYErLgUFWn['candidate']:
            return f"No information was found about the gene {candidate['candidate']} in the database"
        elif isinstance(mTpYTcUJlKVpdjGUhSGpJcrYErLgUFWn['candidate'], list):
            cWOJsBkIfzTlblLhpvkiCaeyohPkTWkr = "\n"
            return (
                "Need additional information, which of these "
                f"did you mean: {newline + newline.join(str(d) for d in candidates)}"
            )
    miHSPzedGbVjlSMmrYMnaXhmXDYjzbva = jkcwCleIDCJKSwIgLcLjzspveLCgtPWk(
        ucIzPHgysuiraKANtBIsOVfTmAxKUXde=kGXTzmKKBeUrqgyDblbxecApsDBOtBXQ, parameters={"candidates": ftxyRLPfxloNuktusjjhsGNiTVJUmzHs, "types": KTLtgdBHaBmBcVljsABSyMlPAWaYsSxR}
    )
    sObIqPPjIdtaKPABpsDgaijNUeVRpLOf = [ eFXyXcQqFtEXsKSnaEJYawHRIcUrABSr["context"] for eFXyXcQqFtEXsKSnaEJYawHRIcUrABSr in miHSPzedGbVjlSMmrYMnaXhmXDYjzbva ]
    if not sObIqPPjIdtaKPABpsDgaijNUeVRpLOf:
        return "No functional information was found about these gene entities."
    return sObIqPPjIdtaKPABpsDgaijNUeVRpLOf
class oLLQCyHXUGnaEZSjKXlcaBmwYZToMDAI(BaseModel):
    entity: List[str] = Field(description="gene names mentioned in the question")
class jyEvRxJLJubPgmnCkQpbxxBhorPVwddq(BaseTool):
    name: str = "Function"
    description: str = (
        "If the key term 'function' is in the question then use this tool"
    )
    args_schema: Type[BaseModel] = oLLQCyHXUGnaEZSjKXlcaBmwYZToMDAI
    def JLxirGuDunyabeKOUsiDrvePIJtKbVLt(
        self,
        entity: List[str],
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        return iJBhSjuBWzAYchARXfZIYxIqIXeyxLYF(entity)
    async def oJngXyGYiEjeKtQeEvjiQveVbeyBDPJS(
        self,
        entity: List[str],
        run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> str:
        return iJBhSjuBWzAYchARXfZIYxIqIXeyxLYF(entity)