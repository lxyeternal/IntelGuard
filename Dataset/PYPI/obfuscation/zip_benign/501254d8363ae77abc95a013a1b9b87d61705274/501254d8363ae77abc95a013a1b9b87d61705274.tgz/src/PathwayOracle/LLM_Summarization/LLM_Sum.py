from langchain.docstore.document import Document
from collections import defaultdict
from typing import Literal
import operator
from typing import Annotated, List, TypedDict
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langgraph.constants import Send
from langgraph.graph import END, START, StateGraph
from langchain.chains.combine_documents.reduce import (
            acollapse_docs,
            split_list_of_docs,
        )
from ..db import pgEMtLowTpFZWGUWEQdJhJPrCpcwrtVU
class qfoMRekfXXtepSLAXPOGepcBrHNSToDE:
    AptRFrzlBhTaBTGRFLwrwndHAsqmMlfp = """
    The following are responses from an LLM Agent answering questions about genes specifically to their association with a subject matter: {context}.
    Do the following operations to the document:
    1. Evaluate whether the information provided links the gene to the subject matter directly. If it does not clearly state so.
    2. If the information does link it to the subject matter summarize the information in a clear fashion, it could be useful to understand format of the information and what it means.
        - Function describes all documented specific roles that the gene carries out
        - Genes Involved describes all directly interacting genes with the subject gene.
        - The ontology describes how the subject gene functionally relates to the interacting genes in a biological process.
        - The publication information describes and cites specific publications where the gene is implicated in the subject matter. Maintain the PMID in the summary.
    3. In the event that a gene is relevant, use the publication information to guide your summary response.
    4. In the event that a gene is relevant, provide the expression value in the document metadata to give an evaluation of how differentially expressed it is.
    """
    RWJQZPjSAxdRjKuDnddeffJCHNJaOAsi = """
    The following is a set of summaries:
    {docs}
    Your goal is to explain why the gene is implicated with the subject using this information. Thus, break concepts down.
    Only cover genes that demonstrate substantial evidence to be implicated with the subject matter. 
    On relevant genes cover genes they are associated with. 
    A gene's ontology with another gene shows that they are in direct interaction and describes the functional role of that interaction.
    Create a cohesive summary in paragraph format, that is clear and concise.
    When referencing publications mention the findings and how they are relevant to the subject matter.
    Do not treat every summary equivocally in terms of focus. Instead focus on the relevant summaries with passing mentions to other genes.
    When publication information is referenced maintain the PMID.
    """
    SStwDhZHCXyELCesmrWIaJjOOlUclpVs = """
    You are given a document that includes information about genes and their association with a subject matter.
    Your task is to determine if this document contains substantial conclusive evidence to be considered significant for summarization.
    Be strict in your classification criteria.
    Evaluate the document based on:
    - If there are explicit functional or ontological details or publications linking the gene to the subject matter.
    Return 'retain' if the document should be kept, or 'discard' if it should be ignored.
    Document: {content}
    """
    def __init__(self, groupedDocuments, components_selection, mwpYbcvTSxgfoIrqSsVDYSLbUWyFTKAx, token_max=1000):
        self.groupedDocuments = self.RxUnCdKGDxBRbiKpohjpnqTNlavSnxqz(groupedDocuments)
        self.pgEMtLowTpFZWGUWEQdJhJPrCpcwrtVU = pgEMtLowTpFZWGUWEQdJhJPrCpcwrtVU
        self.mwpYbcvTSxgfoIrqSsVDYSLbUWyFTKAx = mwpYbcvTSxgfoIrqSsVDYSLbUWyFTKAx
        self.app_big = self.bCjfuALugSirGyvnlSKrzYlXJBReLaRW()
        self.KKzTgeEEqYtWeDpIEmKWZMDOISmUPRop = self.eHffekaBoaTSeenxdxjHksjWqWLUKQBd()
        self.token_max = token_max
        self.component_select = components_selection
        if self.component_select:
            self.groupedDocuments = {
                DiULOJqAbAxkiDgPOGsiMMFLaVedySka: {EydiGsfGKXcPStMwgLognNGmdbvtkGuw: faBKGPePYflZtxtHJfyysWFLqUOzDSJh for EydiGsfGKXcPStMwgLognNGmdbvtkGuw, faBKGPePYflZtxtHJfyysWFLqUOzDSJh in ZpzcqIiZkMmiMmLUKfjtPiUZoCwmBpBZ.items() if EydiGsfGKXcPStMwgLognNGmdbvtkGuw in self.component_select[DiULOJqAbAxkiDgPOGsiMMFLaVedySka]}
                for DiULOJqAbAxkiDgPOGsiMMFLaVedySka, ZpzcqIiZkMmiMmLUKfjtPiUZoCwmBpBZ in self.groupedDocuments.items()
                if DiULOJqAbAxkiDgPOGsiMMFLaVedySka in self.component_select
            }
    def RxUnCdKGDxBRbiKpohjpnqTNlavSnxqz(self, AqqVwplifbyGZSbnEqmjsnmGdNaSIslW):
        def RpuHtbYySAgZURKFWvkgzbpCKQCsywDg(mqFPZFJiGAUbIzKulhXdZgYesrhxwsKT):
            return mqFPZFJiGAUbIzKulhXdZgYesrhxwsKT.metadata.get('Exp', 0)
        for vedvykAJNPomlSFuQeWxOfAwAxbXNTHj, dwrnWjuWFZBFZRShFYZobUwLbMvFJgMT in AqqVwplifbyGZSbnEqmjsnmGdNaSIslW.items():
            for iEPyogrlkijHCSxREyzZoChYBQdUhTcC, sQyLPCMTYyyAUgAbpmuBeFiQiuXRnNTN in dwrnWjuWFZBFZRShFYZobUwLbMvFJgMT.items():
                sQyLPCMTYyyAUgAbpmuBeFiQiuXRnNTN.sort(xTNpvuOPrOyXzTPVubqVRHgJYJSHFcAw=RpuHtbYySAgZURKFWvkgzbpCKQCsywDg, reverse=True)
        for vedvykAJNPomlSFuQeWxOfAwAxbXNTHj, dwrnWjuWFZBFZRShFYZobUwLbMvFJgMT in AqqVwplifbyGZSbnEqmjsnmGdNaSIslW.items():
            gbtbNVtrSUGKpqYbXugQFXahFbcNXcGQ = list(dwrnWjuWFZBFZRShFYZobUwLbMvFJgMT.items())
            gbtbNVtrSUGKpqYbXugQFXahFbcNXcGQ.sort(xTNpvuOPrOyXzTPVubqVRHgJYJSHFcAw=lambda sc: max(RpuHtbYySAgZURKFWvkgzbpCKQCsywDg(mqFPZFJiGAUbIzKulhXdZgYesrhxwsKT) for mqFPZFJiGAUbIzKulhXdZgYesrhxwsKT in sc[1]), reverse=True)
            AqqVwplifbyGZSbnEqmjsnmGdNaSIslW[vedvykAJNPomlSFuQeWxOfAwAxbXNTHj] = defaultdict(list, gbtbNVtrSUGKpqYbXugQFXahFbcNXcGQ)
        UnJipXYOQcroddkfeJZvAPkWgeoMnucO = sorted(
            AqqVwplifbyGZSbnEqmjsnmGdNaSIslW.items(),
            xTNpvuOPrOyXzTPVubqVRHgJYJSHFcAw = lambda comp: max(max(RpuHtbYySAgZURKFWvkgzbpCKQCsywDg(mqFPZFJiGAUbIzKulhXdZgYesrhxwsKT) for mqFPZFJiGAUbIzKulhXdZgYesrhxwsKT in sub[1]) for sub in comp[1].items()),
            reverse = True
        )
        AqqVwplifbyGZSbnEqmjsnmGdNaSIslW = defaultdict(list, UnJipXYOQcroddkfeJZvAPkWgeoMnucO)
        return AqqVwplifbyGZSbnEqmjsnmGdNaSIslW
    def bCjfuALugSirGyvnlSKrzYlXJBReLaRW(self):
        def IYtxlFvskNpdlnhsHFxxKbbRxtewgYln(sQyLPCMTYyyAUgAbpmuBeFiQiuXRnNTN: List[Document]) -> int:
            return sum(pgEMtLowTpFZWGUWEQdJhJPrCpcwrtVU.get_num_tokens(mqFPZFJiGAUbIzKulhXdZgYesrhxwsKT.page_content) for mqFPZFJiGAUbIzKulhXdZgYesrhxwsKT in sQyLPCMTYyyAUgAbpmuBeFiQiuXRnNTN)
        SsqWhnQTerwYhbDpCwjHzNwsCQCjSsDr = ChatPromptTemplate([("human", self.AptRFrzlBhTaBTGRFLwrwndHAsqmMlfp)])
        hhLMrqnItZQRvRODbDFEGnKxGVNlGiBE = ChatPromptTemplate([("human", self.RWJQZPjSAxdRjKuDnddeffJCHNJaOAsi)])
        XSJpotPutSGYSTlwuObRwAfZJZZUACkS = SsqWhnQTerwYhbDpCwjHzNwsCQCjSsDr | pgEMtLowTpFZWGUWEQdJhJPrCpcwrtVU | StrOutputParser()
        zLNkqRjpQsUhdmELWEQMGsnopxptAzxv = hhLMrqnItZQRvRODbDFEGnKxGVNlGiBE | pgEMtLowTpFZWGUWEQdJhJPrCpcwrtVU | StrOutputParser()
        class SuZNgaGwpVanaGtAfAqQQrTtHKaumVlm(TypedDict):
            contents: List[Document]
            summaries: Annotated[list, operator.add]
            collapsed_summaries: List[Document]  
            final_summary: str
            retain: bool
        class KsneEfFrvWdTzBtCnKAHaUnpalbwHyNu(TypedDict):
            WEfncDCamPtZsUSDQEiGiGBjgMKvEbnA: str
        async def DnkyihztlgiHsaOFCKrnesiCAmdLQXsn(state: KsneEfFrvWdTzBtCnKAHaUnpalbwHyNu):
            jxORXPZYNENTYTZYHLrnYUZFDLhHfzBx = await XSJpotPutSGYSTlwuObRwAfZJZZUACkS.ainvoke(state["content"])
            return {"summaries": [jxORXPZYNENTYTZYHLrnYUZFDLhHfzBx]}
        def vubLGSiWlxvrIYYwzPCQeSWOXjfezwJL(state: SuZNgaGwpVanaGtAfAqQQrTtHKaumVlm):
            return {
                "collapsed_summaries": [Document(tIBSpinbsnEFXEPOnQLOjsbPaDIKrqML) for tIBSpinbsnEFXEPOnQLOjsbPaDIKrqML in state["summaries"]]
            }
        def bSnJPWmnobZSMiqjJpznuHvtYmXuHiax(state: SuZNgaGwpVanaGtAfAqQQrTtHKaumVlm):
            return [
                Send("generate_summary", {"content": WEfncDCamPtZsUSDQEiGiGBjgMKvEbnA}) for WEfncDCamPtZsUSDQEiGiGBjgMKvEbnA in state["contents"]
            ]
        async def glADXtMkXwzEEJDacoPIDggtDXhUOSXX(state: SuZNgaGwpVanaGtAfAqQQrTtHKaumVlm):
            OLesPZqdDBQLTvCqOfnykypoIbvlcSQP = ChatPromptTemplate([("human", self.SStwDhZHCXyELCesmrWIaJjOOlUclpVs)])
            iiLKLXQXHjrgSNsWapINWKjTQzaAWcVA = OLesPZqdDBQLTvCqOfnykypoIbvlcSQP | pgEMtLowTpFZWGUWEQdJhJPrCpcwrtVU | StrOutputParser()
            jxORXPZYNENTYTZYHLrnYUZFDLhHfzBx = await iiLKLXQXHjrgSNsWapINWKjTQzaAWcVA.ainvoke(state["final_summary"])
            print('Significant: ', jxORXPZYNENTYTZYHLrnYUZFDLhHfzBx.strip().lower())
            if jxORXPZYNENTYTZYHLrnYUZFDLhHfzBx.strip().lower() == 'retain':
                return {"final_summary": state["final_summary"], "retain": True}
            else:
                return {"final_summary": state['final_summary'], "retain": False}
        async def awwlEhDJaXdAKeKJYfiEQmOOsDnSAsVo(state: SuZNgaGwpVanaGtAfAqQQrTtHKaumVlm):
            jxORXPZYNENTYTZYHLrnYUZFDLhHfzBx = await zLNkqRjpQsUhdmELWEQMGsnopxptAzxv.ainvoke(state["collapsed_summaries"])
            return {"final_summary": jxORXPZYNENTYTZYHLrnYUZFDLhHfzBx}
        LcjmDKbcRKZBUJdSoTDoTQcjTfZiyBKd = StateGraph(SuZNgaGwpVanaGtAfAqQQrTtHKaumVlm)
        LcjmDKbcRKZBUJdSoTDoTQcjTfZiyBKd.add_node("generate_summary", DnkyihztlgiHsaOFCKrnesiCAmdLQXsn)  
        LcjmDKbcRKZBUJdSoTDoTQcjTfZiyBKd.add_node("collect_summaries", vubLGSiWlxvrIYYwzPCQeSWOXjfezwJL)
        LcjmDKbcRKZBUJdSoTDoTQcjTfZiyBKd.add_node("generate_final_summary", awwlEhDJaXdAKeKJYfiEQmOOsDnSAsVo)
        LcjmDKbcRKZBUJdSoTDoTQcjTfZiyBKd.add_node("evaluate_final_summary", glADXtMkXwzEEJDacoPIDggtDXhUOSXX)
        async def AGTlqbbLNiWAilIFDOIPobxqGHEUpOJU(state: SuZNgaGwpVanaGtAfAqQQrTtHKaumVlm):
            kwzLjZUlGtXAEYtTLcsDAhcmImBoPsfk = split_list_of_docs(
                state["collapsed_summaries"], IYtxlFvskNpdlnhsHFxxKbbRxtewgYln, self.token_max
            )
            PceyZRxnDiiuiUTFBmuFyAtMYmWfntSk = []
            for jRKWvJFKWYsFNYpvCuVRnksouITifpqp in kwzLjZUlGtXAEYtTLcsDAhcmImBoPsfk:
                PceyZRxnDiiuiUTFBmuFyAtMYmWfntSk.append(await acollapse_docs(jRKWvJFKWYsFNYpvCuVRnksouITifpqp, zLNkqRjpQsUhdmELWEQMGsnopxptAzxv.ainvoke))
            return {"collapsed_summaries": PceyZRxnDiiuiUTFBmuFyAtMYmWfntSk}
        LcjmDKbcRKZBUJdSoTDoTQcjTfZiyBKd.add_node("collapse_summaries", AGTlqbbLNiWAilIFDOIPobxqGHEUpOJU)
        def bnprCkbbIDwUyEafBkjwtSyJVdVtXJOZ(
            state: SuZNgaGwpVanaGtAfAqQQrTtHKaumVlm,
        ) -> Literal["collapse_summaries", "generate_final_summary"]:
            xKRbuxpUvucgUZpsjeDHcchwkXikoXXp = IYtxlFvskNpdlnhsHFxxKbbRxtewgYln(state["collapsed_summaries"])
            if xKRbuxpUvucgUZpsjeDHcchwkXikoXXp > self.token_max:
                return "collapse_summaries"
            else:
                return "generate_final_summary"
        LcjmDKbcRKZBUJdSoTDoTQcjTfZiyBKd.add_conditional_edges(START, bSnJPWmnobZSMiqjJpznuHvtYmXuHiax, ["generate_summary"])
        LcjmDKbcRKZBUJdSoTDoTQcjTfZiyBKd.add_edge("generate_summary", "collect_summaries")
        LcjmDKbcRKZBUJdSoTDoTQcjTfZiyBKd.add_conditional_edges("collect_summaries", bnprCkbbIDwUyEafBkjwtSyJVdVtXJOZ)
        LcjmDKbcRKZBUJdSoTDoTQcjTfZiyBKd.add_conditional_edges("collapse_summaries", bnprCkbbIDwUyEafBkjwtSyJVdVtXJOZ)
        LcjmDKbcRKZBUJdSoTDoTQcjTfZiyBKd.add_edge("generate_final_summary", "evaluate_final_summary")
        LcjmDKbcRKZBUJdSoTDoTQcjTfZiyBKd.add_edge("evaluate_final_summary", END)
        QdWHGCFCxTCSGpreTYECREQptwZQfBUl = LcjmDKbcRKZBUJdSoTDoTQcjTfZiyBKd.compile()
        return QdWHGCFCxTCSGpreTYECREQptwZQfBUl
    def eHffekaBoaTSeenxdxjHksjWqWLUKQBd(self):
        def IYtxlFvskNpdlnhsHFxxKbbRxtewgYln(sQyLPCMTYyyAUgAbpmuBeFiQiuXRnNTN: List[Document]) -> int:
            return sum(pgEMtLowTpFZWGUWEQdJhJPrCpcwrtVU.get_num_tokens(mqFPZFJiGAUbIzKulhXdZgYesrhxwsKT.page_content) for mqFPZFJiGAUbIzKulhXdZgYesrhxwsKT in sQyLPCMTYyyAUgAbpmuBeFiQiuXRnNTN)
        SsqWhnQTerwYhbDpCwjHzNwsCQCjSsDr = ChatPromptTemplate([("human", self.AptRFrzlBhTaBTGRFLwrwndHAsqmMlfp)])
        hhLMrqnItZQRvRODbDFEGnKxGVNlGiBE = ChatPromptTemplate([("human", self.RWJQZPjSAxdRjKuDnddeffJCHNJaOAsi)])
        XSJpotPutSGYSTlwuObRwAfZJZZUACkS = SsqWhnQTerwYhbDpCwjHzNwsCQCjSsDr | pgEMtLowTpFZWGUWEQdJhJPrCpcwrtVU | StrOutputParser()
        zLNkqRjpQsUhdmELWEQMGsnopxptAzxv = hhLMrqnItZQRvRODbDFEGnKxGVNlGiBE | pgEMtLowTpFZWGUWEQdJhJPrCpcwrtVU | StrOutputParser()
        class SuZNgaGwpVanaGtAfAqQQrTtHKaumVlm(TypedDict):
            contents: List[Document]
            summaries: List[str]  
            collapsed_summaries: List[Document]
            final_summary: str
            retain: bool
        class KsneEfFrvWdTzBtCnKAHaUnpalbwHyNu(TypedDict):
            WEfncDCamPtZsUSDQEiGiGBjgMKvEbnA: str
            retain: bool  
        async def DnkyihztlgiHsaOFCKrnesiCAmdLQXsn(state: KsneEfFrvWdTzBtCnKAHaUnpalbwHyNu):
            jxORXPZYNENTYTZYHLrnYUZFDLhHfzBx = await XSJpotPutSGYSTlwuObRwAfZJZZUACkS.ainvoke(state["content"])
            return {"summaries": [jxORXPZYNENTYTZYHLrnYUZFDLhHfzBx]}
        def vubLGSiWlxvrIYYwzPCQeSWOXjfezwJL(state: SuZNgaGwpVanaGtAfAqQQrTtHKaumVlm):
            return {
                "collapsed_summaries": [Document(tIBSpinbsnEFXEPOnQLOjsbPaDIKrqML) for tIBSpinbsnEFXEPOnQLOjsbPaDIKrqML in state["summaries"]]
            }
        async def IpJiNqeVfprIAayqOcNiuTDlDaZaaZgU(state: KsneEfFrvWdTzBtCnKAHaUnpalbwHyNu):
            OLesPZqdDBQLTvCqOfnykypoIbvlcSQP = ChatPromptTemplate([("human", self.SStwDhZHCXyELCesmrWIaJjOOlUclpVs)])
            iiLKLXQXHjrgSNsWapINWKjTQzaAWcVA = OLesPZqdDBQLTvCqOfnykypoIbvlcSQP | pgEMtLowTpFZWGUWEQdJhJPrCpcwrtVU | StrOutputParser()
            jxORXPZYNENTYTZYHLrnYUZFDLhHfzBx = await iiLKLXQXHjrgSNsWapINWKjTQzaAWcVA.ainvoke(state["content"])
            DMitgoDGOclUldHfOrpPHiDZdUiVMTrb = jxORXPZYNENTYTZYHLrnYUZFDLhHfzBx.strip().lower() == 'retain'
            return {"retain": DMitgoDGOclUldHfOrpPHiDZdUiVMTrb, "content": state["content"]}
        def bSnJPWmnobZSMiqjJpznuHvtYmXuHiax(state: SuZNgaGwpVanaGtAfAqQQrTtHKaumVlm):
            return [
                Send("evaluate_summary", {"content": WEfncDCamPtZsUSDQEiGiGBjgMKvEbnA, "retain": None}) for WEfncDCamPtZsUSDQEiGiGBjgMKvEbnA in state["contents"]
            ]
        async def awwlEhDJaXdAKeKJYfiEQmOOsDnSAsVo(state: SuZNgaGwpVanaGtAfAqQQrTtHKaumVlm):
            jxORXPZYNENTYTZYHLrnYUZFDLhHfzBx = await zLNkqRjpQsUhdmELWEQMGsnopxptAzxv.ainvoke({"docs": state["collapsed_summaries"]})
            return {"final_summary": jxORXPZYNENTYTZYHLrnYUZFDLhHfzBx, "retain": state['retain']}
        def xlmocHMnedunxfygbvAVxGiGDHSfpZLf(state: KsneEfFrvWdTzBtCnKAHaUnpalbwHyNu):
            DMitgoDGOclUldHfOrpPHiDZdUiVMTrb = state["retain"]
            if not DMitgoDGOclUldHfOrpPHiDZdUiVMTrb:
                return END
            else:
                return "generate_summary"
        async def AGTlqbbLNiWAilIFDOIPobxqGHEUpOJU(state: SuZNgaGwpVanaGtAfAqQQrTtHKaumVlm):
            kwzLjZUlGtXAEYtTLcsDAhcmImBoPsfk = split_list_of_docs(
                state["collapsed_summaries"], IYtxlFvskNpdlnhsHFxxKbbRxtewgYln, self.token_max
            )
            PceyZRxnDiiuiUTFBmuFyAtMYmWfntSk = []
            for jRKWvJFKWYsFNYpvCuVRnksouITifpqp in kwzLjZUlGtXAEYtTLcsDAhcmImBoPsfk:
                PceyZRxnDiiuiUTFBmuFyAtMYmWfntSk.append(await acollapse_docs(jRKWvJFKWYsFNYpvCuVRnksouITifpqp, zLNkqRjpQsUhdmELWEQMGsnopxptAzxv.ainvoke))
            return {"collapsed_summaries": PceyZRxnDiiuiUTFBmuFyAtMYmWfntSk}
        def bnprCkbbIDwUyEafBkjwtSyJVdVtXJOZ(
            state: SuZNgaGwpVanaGtAfAqQQrTtHKaumVlm,
        ) -> Literal["collapse_summaries", "generate_final_summary"]:
            xKRbuxpUvucgUZpsjeDHcchwkXikoXXp = IYtxlFvskNpdlnhsHFxxKbbRxtewgYln(state["collapsed_summaries"])
            if xKRbuxpUvucgUZpsjeDHcchwkXikoXXp > self.token_max:
                return "collapse_summaries"
            else:
                return "generate_final_summary"
        JMPmbAbYyfXtpvXvXLwcxoJKuGNqHpha = StateGraph(SuZNgaGwpVanaGtAfAqQQrTtHKaumVlm)
        JMPmbAbYyfXtpvXvXLwcxoJKuGNqHpha.add_node("generate_summary", DnkyihztlgiHsaOFCKrnesiCAmdLQXsn)
        JMPmbAbYyfXtpvXvXLwcxoJKuGNqHpha.add_node("collect_summaries", vubLGSiWlxvrIYYwzPCQeSWOXjfezwJL)
        JMPmbAbYyfXtpvXvXLwcxoJKuGNqHpha.add_node("generate_final_summary", awwlEhDJaXdAKeKJYfiEQmOOsDnSAsVo)
        JMPmbAbYyfXtpvXvXLwcxoJKuGNqHpha.add_node("evaluate_summary", IpJiNqeVfprIAayqOcNiuTDlDaZaaZgU)
        JMPmbAbYyfXtpvXvXLwcxoJKuGNqHpha.add_node("collapse_summaries", AGTlqbbLNiWAilIFDOIPobxqGHEUpOJU)
        JMPmbAbYyfXtpvXvXLwcxoJKuGNqHpha.add_conditional_edges(START, bSnJPWmnobZSMiqjJpznuHvtYmXuHiax, ["evaluate_summary"])
        JMPmbAbYyfXtpvXvXLwcxoJKuGNqHpha.add_conditional_edges("evaluate_summary", xlmocHMnedunxfygbvAVxGiGDHSfpZLf)
        JMPmbAbYyfXtpvXvXLwcxoJKuGNqHpha.add_edge("generate_summary", "collect_summaries")
        JMPmbAbYyfXtpvXvXLwcxoJKuGNqHpha.add_conditional_edges("collect_summaries", bnprCkbbIDwUyEafBkjwtSyJVdVtXJOZ)
        JMPmbAbYyfXtpvXvXLwcxoJKuGNqHpha.add_conditional_edges("collapse_summaries", bnprCkbbIDwUyEafBkjwtSyJVdVtXJOZ)
        JMPmbAbYyfXtpvXvXLwcxoJKuGNqHpha.add_edge("generate_final_summary", END)
        KKzTgeEEqYtWeDpIEmKWZMDOISmUPRop = JMPmbAbYyfXtpvXvXLwcxoJKuGNqHpha.compile()
        return KKzTgeEEqYtWeDpIEmKWZMDOISmUPRop
