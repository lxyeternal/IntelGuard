import networkx as nx
def bgprecvKZBWlJZyhdTdhuhjDbLAiMnsy(ovkqFrObhdCMnjxXuIChOPymVgCcMXvJ, nprZXvlCBWsGdqnbGDxQjErHUikbDCTd, ceEWirsUTtUTarfkNGeYktZifTtzMbyX, JszDglcqnmsOUMXUiotdQLFYLYqrIcJO):
    cLoVwafItoZQgDgTIYlmplQYtWyZqwpT = ''
    for dLOKwcVMBSHTijSdbxwZBcosCKjDoNLd in nprZXvlCBWsGdqnbGDxQjErHUikbDCTd:
        cLoVwafItoZQgDgTIYlmplQYtWyZqwpT += f"{intX['gene1']} is a {intX['relat']} of {intX['gene2']} in the {intX['Pathway']} pathway \n"
    def yWlqkgSaskNZqbAUwRtdYBUpijxxhIbu(OntoNet, BaseOnto):
        qxwYWAFTXiNJWYFzDaomViRuoBXlxGRf = []
        for yXxbbYoqCDMNqUkJFzuelAWraqOMdvKH in OntoNet:
            ODokQYNgTSPNaqPxGYaunqBNoDdzzZhb = yXxbbYoqCDMNqUkJFzuelAWraqOMdvKH['fromNodeName']
            tMbYtMAlmenVkAYlAozElHwkXDWVJirH = yXxbbYoqCDMNqUkJFzuelAWraqOMdvKH['toNodeName']
            JzwmofynSLEiKllljJfyYrhwbbfkMDWV = (ODokQYNgTSPNaqPxGYaunqBNoDdzzZhb, tMbYtMAlmenVkAYlAozElHwkXDWVJirH)
            qxwYWAFTXiNJWYFzDaomViRuoBXlxGRf.append(JzwmofynSLEiKllljJfyYrhwbbfkMDWV)
        for lSnjnrEvZCcBdutlWHOHmDRbaeVblDlY in BaseOnto:
            ODokQYNgTSPNaqPxGYaunqBNoDdzzZhb = lSnjnrEvZCcBdutlWHOHmDRbaeVblDlY['geneName']
            tMbYtMAlmenVkAYlAozElHwkXDWVJirH = lSnjnrEvZCcBdutlWHOHmDRbaeVblDlY['baseOnto']
            JzwmofynSLEiKllljJfyYrhwbbfkMDWV = (ODokQYNgTSPNaqPxGYaunqBNoDdzzZhb, tMbYtMAlmenVkAYlAozElHwkXDWVJirH)
            qxwYWAFTXiNJWYFzDaomViRuoBXlxGRf.append(JzwmofynSLEiKllljJfyYrhwbbfkMDWV)
        return qxwYWAFTXiNJWYFzDaomViRuoBXlxGRf
    fGaCWKklozVHxKTSkjEHVJcMAxQjnlsq = yWlqkgSaskNZqbAUwRtdYBUpijxxhIbu(OntoNet = JszDglcqnmsOUMXUiotdQLFYLYqrIcJO, BaseOnto = ceEWirsUTtUTarfkNGeYktZifTtzMbyX)
    HPQfNQjqckBSczXRKJfXJVVdkBvQqDyS = nx.DiGraph()
    HPQfNQjqckBSczXRKJfXJVVdkBvQqDyS.add_edges_from(fGaCWKklozVHxKTSkjEHVJcMAxQjnlsq)
    def KkUtTsziipPTLwZKjhPuabvKvegGbWVJ(target_node, ovkqFrObhdCMnjxXuIChOPymVgCcMXvJ, HPQfNQjqckBSczXRKJfXJVVdkBvQqDyS):
        for UEMbMkKismMvxmkngKZAQeCYFjBwfhiG in ovkqFrObhdCMnjxXuIChOPymVgCcMXvJ:
            if not nx.has_path(HPQfNQjqckBSczXRKJfXJVVdkBvQqDyS, UEMbMkKismMvxmkngKZAQeCYFjBwfhiG, target_node):
                return False
        return True
    def PxwkgEszutgGhvOqhrkFokPgWvecLChJ(ovkqFrObhdCMnjxXuIChOPymVgCcMXvJ, HPQfNQjqckBSczXRKJfXJVVdkBvQqDyS):
        for ZBrmXGQTeTiTcSpDUKRQNkJIwEukUySS in HPQfNQjqckBSczXRKJfXJVVdkBvQqDyS.nodes:
            if ZBrmXGQTeTiTcSpDUKRQNkJIwEukUySS not in ovkqFrObhdCMnjxXuIChOPymVgCcMXvJ and KkUtTsziipPTLwZKjhPuabvKvegGbWVJ(ZBrmXGQTeTiTcSpDUKRQNkJIwEukUySS, ovkqFrObhdCMnjxXuIChOPymVgCcMXvJ, HPQfNQjqckBSczXRKJfXJVVdkBvQqDyS):
                return ZBrmXGQTeTiTcSpDUKRQNkJIwEukUySS
        return None
    gdIYLBxKtxpzPMxgpWkiqOHSQhsJzLDT = PxwkgEszutgGhvOqhrkFokPgWvecLChJ(ovkqFrObhdCMnjxXuIChOPymVgCcMXvJ, HPQfNQjqckBSczXRKJfXJVVdkBvQqDyS)
    cLoVwafItoZQgDgTIYlmplQYtWyZqwpT += f"The common ontology node is: {common_node} \n"
    def QyMTkCfPzzZnOplAfzxHaTphZbskhoBo(ovkqFrObhdCMnjxXuIChOPymVgCcMXvJ, gdIYLBxKtxpzPMxgpWkiqOHSQhsJzLDT, HPQfNQjqckBSczXRKJfXJVVdkBvQqDyS):
        ecovPqCqHSKWEfMYHPgTdslnWfxSGUsj = {}
        for UEMbMkKismMvxmkngKZAQeCYFjBwfhiG in ovkqFrObhdCMnjxXuIChOPymVgCcMXvJ:
            if nx.has_path(HPQfNQjqckBSczXRKJfXJVVdkBvQqDyS, UEMbMkKismMvxmkngKZAQeCYFjBwfhiG, gdIYLBxKtxpzPMxgpWkiqOHSQhsJzLDT):
                RAcsccBlsQrXyBrvyfGTvfkkpnTyQlOF = nx.shortest_path(HPQfNQjqckBSczXRKJfXJVVdkBvQqDyS, source=UEMbMkKismMvxmkngKZAQeCYFjBwfhiG, target=gdIYLBxKtxpzPMxgpWkiqOHSQhsJzLDT)
                ecovPqCqHSKWEfMYHPgTdslnWfxSGUsj[UEMbMkKismMvxmkngKZAQeCYFjBwfhiG] = RAcsccBlsQrXyBrvyfGTvfkkpnTyQlOF
        return ecovPqCqHSKWEfMYHPgTdslnWfxSGUsj
    JtclrUgwaLWCEADKlppWxvwateETWnIx = QyMTkCfPzzZnOplAfzxHaTphZbskhoBo(ovkqFrObhdCMnjxXuIChOPymVgCcMXvJ, gdIYLBxKtxpzPMxgpWkiqOHSQhsJzLDT, HPQfNQjqckBSczXRKJfXJVVdkBvQqDyS)
    for UEMbMkKismMvxmkngKZAQeCYFjBwfhiG, RAcsccBlsQrXyBrvyfGTvfkkpnTyQlOF in JtclrUgwaLWCEADKlppWxvwateETWnIx.items():
        if len(RAcsccBlsQrXyBrvyfGTvfkkpnTyQlOF) > 0:
            oNfdysbsifUwsVABBrozggvcfDqwHGeA = RAcsccBlsQrXyBrvyfGTvfkkpnTyQlOF[0] + ' is involved in ' + ' which is a subclass of '.join(RAcsccBlsQrXyBrvyfGTvfkkpnTyQlOF[1:])
            cLoVwafItoZQgDgTIYlmplQYtWyZqwpT += f"Path from {gene} to {common_node}: {path_parsed} \n"
    return cLoVwafItoZQgDgTIYlmplQYtWyZqwpT
