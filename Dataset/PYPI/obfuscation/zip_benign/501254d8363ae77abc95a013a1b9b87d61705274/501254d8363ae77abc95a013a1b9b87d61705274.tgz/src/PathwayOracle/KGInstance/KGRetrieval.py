from ..AgentFiles.Agent import edmetazHjAqLbtrsRpWWMUsnthfVwTzC
from typing import List, Tuple
from ..db import jkcwCleIDCJKSwIgLcLjzspveLCgtPWk
from collections import defaultdict
from langchain.docstore.document import Document
class tkfWLwGuKyNTDqiwFOdbLyNCNGGdtbHg:
    def __init__(self, mwpYbcvTSxgfoIrqSsVDYSLbUWyFTKAx, ndOpTCZMkNCUDxgTnwbSaDJoIXHsHwia, instance_id):
        self.mwpYbcvTSxgfoIrqSsVDYSLbUWyFTKAx = mwpYbcvTSxgfoIrqSsVDYSLbUWyFTKAx.replace("_", " ")
        self.ndOpTCZMkNCUDxgTnwbSaDJoIXHsHwia = ndOpTCZMkNCUDxgTnwbSaDJoIXHsHwia
        self.instance_id = instance_id
        self.linkDocs, self.genePathwayMap, self.rGpxlQLtUGETnkirJdgyvTmoLnYgPUHv = self.TGZglEUWOUSBDwvAPkzyaINDscMvUwcN()
    def TGZglEUWOUSBDwvAPkzyaINDscMvUwcN(self):
        qsvrXXNleQRTNTsJWTtCKkyMzTIpXtSp = """
        MATCH (i:Instance {instance_id: $instance_id})-[r]->(n:Genes)
        WITH collect(n) as all_nodes, i
        UNWIND all_nodes as node
        MATCH (node:Genes)-[b]-(h)
        WHERE h in all_nodes AND i.instance_id in b.instance_ids
        RETURN DISTINCT node.name as geneName, id(node), id(startNode(b)), id(endNode(b)), id(h), type(b) as relType, h.name as connectedNode, coalesce(b.Pathway, null) as Pathway
        """
        GLZusqWVqxrbrUzfkoEggesItgwyOHfy= jkcwCleIDCJKSwIgLcLjzspveLCgtPWk(ucIzPHgysuiraKANtBIsOVfTmAxKUXde=qsvrXXNleQRTNTsJWTtCKkyMzTIpXtSp, parameters = {'instance_id': self.instance_id})
        print(GLZusqWVqxrbrUzfkoEggesItgwyOHfy)
        ZnPYwNKlCaBozQppdOwvLexbBmgiwUXF = """
        MATCH (i:Instance {instance_id: $instance_id})-[r]->(n:Genes)
        WITH collect(n) as all_nodes, i
        UNWIND all_nodes as node
        MATCH (node:Genes)-[b]-(h:Pathway)
        WHERE i.instance_id in b.instance_ids
        RETURN node.name as geneName, collect(h.name) as Pathways
        """
        expsIIplZMQGTwoJWoGcwxcngATrseeG = """
        MATCH (i:Instance {instance_id: $instance_id})-[r]-(g:Genes)
        RETURN g.name as geneName, r.significance as Sig, r.expression as Exp
        """
        AjkvVstuQIHqeuWcBRmOVqJYBAQKCvgm = jkcwCleIDCJKSwIgLcLjzspveLCgtPWk(ucIzPHgysuiraKANtBIsOVfTmAxKUXde= ZnPYwNKlCaBozQppdOwvLexbBmgiwUXF, parameters= {'instance_id': self.instance_id})
        OmHDCmzeYHhaXvnBuBpThNnuoACCkbSN = jkcwCleIDCJKSwIgLcLjzspveLCgtPWk(ucIzPHgysuiraKANtBIsOVfTmAxKUXde=expsIIplZMQGTwoJWoGcwxcngATrseeG, parameters={'instance_id': self.instance_id})
        rGpxlQLtUGETnkirJdgyvTmoLnYgPUHv = { FkxUycBBNkFltRBgZhbtegYKDQHNtzbr['geneName'] : {'Sig' : float(FkxUycBBNkFltRBgZhbtegYKDQHNtzbr['Sig']), 'Exp': float(FkxUycBBNkFltRBgZhbtegYKDQHNtzbr['Exp'])} for FkxUycBBNkFltRBgZhbtegYKDQHNtzbr in OmHDCmzeYHhaXvnBuBpThNnuoACCkbSN }
        oVvjXywzrruxpqRpDcEVvRzdedcWhMBj = {rKozvbkCiJxrmAbGyGhgCMXDErCkrYOW['geneName'] : rKozvbkCiJxrmAbGyGhgCMXDErCkrYOW['Pathways'] for rKozvbkCiJxrmAbGyGhgCMXDErCkrYOW in AjkvVstuQIHqeuWcBRmOVqJYBAQKCvgm}
        def jOAJcgpirZHKqSfTaGCViLGYSZLggmni(ndOpTCZMkNCUDxgTnwbSaDJoIXHsHwia, linkDocs):
            def bNpuFrgtJBJHCVqSCKChNODIYAYnHNMk(ndOpTCZMkNCUDxgTnwbSaDJoIXHsHwia):
                HVzmltgRXurkJOSpLZlKEfZomsuHyTyE = {}
                for xTNpvuOPrOyXzTPVubqVRHgJYJSHFcAw, heQhJpQsEuBEXgfVKiyIvPiqLuVEqdhj in ndOpTCZMkNCUDxgTnwbSaDJoIXHsHwia.items():
                    tAuSpqHFvLiMEtEZVdixdYjdzeqStnHR = [UEMbMkKismMvxmkngKZAQeCYFjBwfhiG for UEMbMkKismMvxmkngKZAQeCYFjBwfhiG in heQhJpQsEuBEXgfVKiyIvPiqLuVEqdhj if UEMbMkKismMvxmkngKZAQeCYFjBwfhiG.isupper()]
                    if tAuSpqHFvLiMEtEZVdixdYjdzeqStnHR:
                        HVzmltgRXurkJOSpLZlKEfZomsuHyTyE[xTNpvuOPrOyXzTPVubqVRHgJYJSHFcAw] = tAuSpqHFvLiMEtEZVdixdYjdzeqStnHR
                return HVzmltgRXurkJOSpLZlKEfZomsuHyTyE
            HVzmltgRXurkJOSpLZlKEfZomsuHyTyE = bNpuFrgtJBJHCVqSCKChNODIYAYnHNMk(ndOpTCZMkNCUDxgTnwbSaDJoIXHsHwia)
            tHSaVQtiVxEIllQxXAZfIXbwFtFdEFce = defaultdict(list)
            CprbaAyGLmvXOBefCGhVbafpohtaJgEF = defaultdict(list)
            for mqFPZFJiGAUbIzKulhXdZgYesrhxwsKT in linkDocs:
                CJgpRMKbkMMAqRlFaZPZkRhjrqrNswEa = mqFPZFJiGAUbIzKulhXdZgYesrhxwsKT['geneName']
                pBLBcBWNauzswDSypBhQmKjGTfbFdMbI = mqFPZFJiGAUbIzKulhXdZgYesrhxwsKT['connectedNode']
                tHSaVQtiVxEIllQxXAZfIXbwFtFdEFce[CJgpRMKbkMMAqRlFaZPZkRhjrqrNswEa].append(pBLBcBWNauzswDSypBhQmKjGTfbFdMbI)
                tHSaVQtiVxEIllQxXAZfIXbwFtFdEFce[pBLBcBWNauzswDSypBhQmKjGTfbFdMbI].append(CJgpRMKbkMMAqRlFaZPZkRhjrqrNswEa)
                if mqFPZFJiGAUbIzKulhXdZgYesrhxwsKT['id(node)'] == mqFPZFJiGAUbIzKulhXdZgYesrhxwsKT['id(startNode(b))']:  
                    CprbaAyGLmvXOBefCGhVbafpohtaJgEF[CJgpRMKbkMMAqRlFaZPZkRhjrqrNswEa].append(f"Gene {gene1} is a {doc['relType']} of Gene {gene2} in the Pathways: {doc['Pathway']}")
                    CprbaAyGLmvXOBefCGhVbafpohtaJgEF[pBLBcBWNauzswDSypBhQmKjGTfbFdMbI].append(f"Gene {gene1} is a {doc['relType']} of Gene {gene2} in the Pathways: {doc['Pathway']}")
                else:  
                    CprbaAyGLmvXOBefCGhVbafpohtaJgEF[pBLBcBWNauzswDSypBhQmKjGTfbFdMbI].append(f"Gene {gene2} is a {doc['relType']} of Gene {gene1} in the Pathways: {doc['Pathway']}")
                    CprbaAyGLmvXOBefCGhVbafpohtaJgEF[CJgpRMKbkMMAqRlFaZPZkRhjrqrNswEa].append(f"Gene {gene2} is a {doc['relType']} of Gene {gene1} in the Pathways: {doc['Pathway']}")
            mONlVzTWnXvujcnsydWFKezNzDLFVszt = defaultdict(lambda: defaultdict(list))  
            def wlGpSrIfeFmZyFgMTJgYxmiZSnoqgpRa(UEMbMkKismMvxmkngKZAQeCYFjBwfhiG, tHklVGghKrXyxLrtVyaMnmvwGVjqbZBO, UcfyhDQBoyPYcBpOumFpwQJGqIktiqom, genes_in_component):
                AvsrkgudCJwqcajBaQwiBrtCirmPkPze = [UEMbMkKismMvxmkngKZAQeCYFjBwfhiG]
                while AvsrkgudCJwqcajBaQwiBrtCirmPkPze:
                    YxFnxBOhMWHObVPjFvJbeXOVLuHFdAXe = AvsrkgudCJwqcajBaQwiBrtCirmPkPze.pop()
                    if YxFnxBOhMWHObVPjFvJbeXOVLuHFdAXe not in tHklVGghKrXyxLrtVyaMnmvwGVjqbZBO:
                        tHklVGghKrXyxLrtVyaMnmvwGVjqbZBO.add(YxFnxBOhMWHObVPjFvJbeXOVLuHFdAXe)
                        BkdvFxhYFMQsPkKWqRllLUlWAnVktYco = {
                            'name': YxFnxBOhMWHObVPjFvJbeXOVLuHFdAXe,
                            'neighbors':tHSaVQtiVxEIllQxXAZfIXbwFtFdEFce[YxFnxBOhMWHObVPjFvJbeXOVLuHFdAXe],
                            'intString': CprbaAyGLmvXOBefCGhVbafpohtaJgEF[YxFnxBOhMWHObVPjFvJbeXOVLuHFdAXe]
                        }
                        UcfyhDQBoyPYcBpOumFpwQJGqIktiqom.append(BkdvFxhYFMQsPkKWqRllLUlWAnVktYco)
                        for jfsaSAGABOiDmjfuqSppFWEMHnyKRKSE in tHSaVQtiVxEIllQxXAZfIXbwFtFdEFce[YxFnxBOhMWHObVPjFvJbeXOVLuHFdAXe]:
                            if jfsaSAGABOiDmjfuqSppFWEMHnyKRKSE not in tHklVGghKrXyxLrtVyaMnmvwGVjqbZBO and jfsaSAGABOiDmjfuqSppFWEMHnyKRKSE in genes_in_component:
                                AvsrkgudCJwqcajBaQwiBrtCirmPkPze.append(jfsaSAGABOiDmjfuqSppFWEMHnyKRKSE)
            for wOfjfXFzILqJKgZvWGSRhgIsoHiONlkG, dBCAENVKjPtGXKhDznTBozuMbmVeRCCd in HVzmltgRXurkJOSpLZlKEfZomsuHyTyE.items():
                tHklVGghKrXyxLrtVyaMnmvwGVjqbZBO = set()
                ATedMhEbdoEqiITihTjbnkmvpSPGltNk = 0
                for UEMbMkKismMvxmkngKZAQeCYFjBwfhiG in dBCAENVKjPtGXKhDznTBozuMbmVeRCCd:
                    if UEMbMkKismMvxmkngKZAQeCYFjBwfhiG not in tHklVGghKrXyxLrtVyaMnmvwGVjqbZBO:
                        UcfyhDQBoyPYcBpOumFpwQJGqIktiqom = []
                        wlGpSrIfeFmZyFgMTJgYxmiZSnoqgpRa(UEMbMkKismMvxmkngKZAQeCYFjBwfhiG, tHklVGghKrXyxLrtVyaMnmvwGVjqbZBO, UcfyhDQBoyPYcBpOumFpwQJGqIktiqom, dBCAENVKjPtGXKhDznTBozuMbmVeRCCd)  
                        mONlVzTWnXvujcnsydWFKezNzDLFVszt[wOfjfXFzILqJKgZvWGSRhgIsoHiONlkG][ATedMhEbdoEqiITihTjbnkmvpSPGltNk] = UcfyhDQBoyPYcBpOumFpwQJGqIktiqom
                        ATedMhEbdoEqiITihTjbnkmvpSPGltNk += 1
            return mONlVzTWnXvujcnsydWFKezNzDLFVszt
        JAaGxWFBxOLQOtTepDwyjMrVWNoOlbks = jOAJcgpirZHKqSfTaGCViLGYSZLggmni(ndOpTCZMkNCUDxgTnwbSaDJoIXHsHwia= self.ndOpTCZMkNCUDxgTnwbSaDJoIXHsHwia, linkDocs=GLZusqWVqxrbrUzfkoEggesItgwyOHfy)
        return JAaGxWFBxOLQOtTepDwyjMrVWNoOlbks, oVvjXywzrruxpqRpDcEVvRzdedcWhMBj, rGpxlQLtUGETnkirJdgyvTmoLnYgPUHv
    def vVOyWEZJauIXahjHCeavrzaAVIygfCmG(self, NvyqknpoinqfAcIRnNpHXDvVTXKrzQkn: dict[str, list] = None):
        NvyqknpoinqfAcIRnNpHXDvVTXKrzQkn = NvyqknpoinqfAcIRnNpHXDvVTXKrzQkn or {}
        HtcGqPuvmxyGbjJNzfMThSdzRkCQVIws=False
        if len(NvyqknpoinqfAcIRnNpHXDvVTXKrzQkn)==0:
            HtcGqPuvmxyGbjJNzfMThSdzRkCQVIws=True            
        for hIleiStzYvHEwCousVsrFaHtUwSfReQj, iNkSvLDCpOURepqUtUzdurczWRqPgKhm in self.linkDocs.items():
            if hIleiStzYvHEwCousVsrFaHtUwSfReQj not in NvyqknpoinqfAcIRnNpHXDvVTXKrzQkn and HtcGqPuvmxyGbjJNzfMThSdzRkCQVIws:
                NvyqknpoinqfAcIRnNpHXDvVTXKrzQkn[hIleiStzYvHEwCousVsrFaHtUwSfReQj] = list(iNkSvLDCpOURepqUtUzdurczWRqPgKhm.keys())
            elif hIleiStzYvHEwCousVsrFaHtUwSfReQj not in NvyqknpoinqfAcIRnNpHXDvVTXKrzQkn:
                continue
            else:
                pWMtjxnboqoGLJbBtbLeikyMReiqhPbV = NvyqknpoinqfAcIRnNpHXDvVTXKrzQkn[hIleiStzYvHEwCousVsrFaHtUwSfReQj] or iNkSvLDCpOURepqUtUzdurczWRqPgKhm.keys()
                DRTkjAazGreGUWLAndDJxpDtWjCDzWJU = [xTNpvuOPrOyXzTPVubqVRHgJYJSHFcAw for xTNpvuOPrOyXzTPVubqVRHgJYJSHFcAw in pWMtjxnboqoGLJbBtbLeikyMReiqhPbV if xTNpvuOPrOyXzTPVubqVRHgJYJSHFcAw in iNkSvLDCpOURepqUtUzdurczWRqPgKhm]
                GcpXfNaqBcCasceEAQGTOTNMNuNVcTEs = [xTNpvuOPrOyXzTPVubqVRHgJYJSHFcAw for xTNpvuOPrOyXzTPVubqVRHgJYJSHFcAw in pWMtjxnboqoGLJbBtbLeikyMReiqhPbV if xTNpvuOPrOyXzTPVubqVRHgJYJSHFcAw not in iNkSvLDCpOURepqUtUzdurczWRqPgKhm]
                if GcpXfNaqBcCasceEAQGTOTNMNuNVcTEs:
                    print(f"Warning: Subcomponent keys {invalid_keys} not found under '{hIleiStzYvHEwCousVsrFaHtUwSfReQj}'. Valid keys: {inner_dict.keys()}")
                NvyqknpoinqfAcIRnNpHXDvVTXKrzQkn[hIleiStzYvHEwCousVsrFaHtUwSfReQj] = DRTkjAazGreGUWLAndDJxpDtWjCDzWJU
        def LYEeZjWcHmaPqVZEJEXnZQyDcumMVBne(UEMbMkKismMvxmkngKZAQeCYFjBwfhiG, neighborGenes):
            mwpYbcvTSxgfoIrqSsVDYSLbUWyFTKAx = self.mwpYbcvTSxgfoIrqSsVDYSLbUWyFTKAx
            EWtzPbZaeWnQgsAssfKoNKtDUabVqWwO = f'Function: Gene {gene} associates it with the subject {subject}'
            LNpwatgdxOSOzImBguQbvmObIrbCQaxV = f'Ontology: Genes {[gene] + neighborGenes} associates it with the subject {subject}'
            GCgmUqTdfNOImViFWAkfYoTZJSxZdSXH = f'Publication: Gene {gene} associates it with the subject {subject}'
            return [EWtzPbZaeWnQgsAssfKoNKtDUabVqWwO,LNpwatgdxOSOzImBguQbvmObIrbCQaxV,GCgmUqTdfNOImViFWAkfYoTZJSxZdSXH]
        kNWderyvzvEwPhECuOFXFmPjLlHrOEfk = defaultdict(lambda: defaultdict(list))
        for QiXqLVQddERAClsoIbMYgeMprsDFnfSZ, tiWSLGzGcqOTZFUmPVxzLwzQFLjkXkqR in NvyqknpoinqfAcIRnNpHXDvVTXKrzQkn.items():
            for KPbbHnbZFIlEzQdUQEbKkQKeqchgrMUc in tiWSLGzGcqOTZFUmPVxzLwzQFLjkXkqR:
                caBDhOFnqHcQZkwyoMhpRfIxMFDwtDxb = self.linkDocs[QiXqLVQddERAClsoIbMYgeMprsDFnfSZ][KPbbHnbZFIlEzQdUQEbKkQKeqchgrMUc]
                for tmvANGKBqTruhBpSIoGKGqLDWgDajAWP in caBDhOFnqHcQZkwyoMhpRfIxMFDwtDxb:
                    GKUdZGtltFABGkFqKetVIRvZmhjwFJfI = tmvANGKBqTruhBpSIoGKGqLDWgDajAWP['name']
                    IMIObgYZvRDcoOnxtFrMxRhfIeOSJFES = tmvANGKBqTruhBpSIoGKGqLDWgDajAWP['neighbors']
                    VreZPacBMCONKtjqhoBTlfbaupXKyJjn = self.genePathwayMap[GKUdZGtltFABGkFqKetVIRvZmhjwFJfI]
                    EcuvctBdUKVAUhDEnzcncVGWtuhvoPxx = ''
                    EcuvctBdUKVAUhDEnzcncVGWtuhvoPxx += ', '.join(VreZPacBMCONKtjqhoBTlfbaupXKyJjn)
                    EZetWHDUgxLFbSdTRcEOFDLkiyzUnTOf = f'Gene {geneName} is associated with Pathways:' + EcuvctBdUKVAUhDEnzcncVGWtuhvoPxx
                    EZetWHDUgxLFbSdTRcEOFDLkiyzUnTOf = EZetWHDUgxLFbSdTRcEOFDLkiyzUnTOf + "Interactions:\n" + '\n'.join(tmvANGKBqTruhBpSIoGKGqLDWgDajAWP['intString'])
                    chat_history: List[Tuple[str, str]] = [("user", EZetWHDUgxLFbSdTRcEOFDLkiyzUnTOf)]
                    lKUZXFlqmjDSAivxyVWpsrOtkGXyRrkk = LYEeZjWcHmaPqVZEJEXnZQyDcumMVBne(UEMbMkKismMvxmkngKZAQeCYFjBwfhiG = GKUdZGtltFABGkFqKetVIRvZmhjwFJfI, neighborGenes = IMIObgYZvRDcoOnxtFrMxRhfIeOSJFES)
                    for uBchtHxwdyEALFuaQdOgnHIUJVncBMSX in lKUZXFlqmjDSAivxyVWpsrOtkGXyRrkk:
                        chat_history.append(("user", uBchtHxwdyEALFuaQdOgnHIUJVncBMSX))
                        jxORXPZYNENTYTZYHLrnYUZFDLhHfzBx = edmetazHjAqLbtrsRpWWMUsnthfVwTzC.invoke({"input": uBchtHxwdyEALFuaQdOgnHIUJVncBMSX, "chat_history": chat_history})
                        chat_history.append(("assistant", jxORXPZYNENTYTZYHLrnYUZFDLhHfzBx['output']))
                        EZetWHDUgxLFbSdTRcEOFDLkiyzUnTOf = EZetWHDUgxLFbSdTRcEOFDLkiyzUnTOf +'\n'+ jxORXPZYNENTYTZYHLrnYUZFDLhHfzBx['output']
                    EZetWHDUgxLFbSdTRcEOFDLkiyzUnTOf = EZetWHDUgxLFbSdTRcEOFDLkiyzUnTOf + '\n' +'Expression: '+ str(self.rGpxlQLtUGETnkirJdgyvTmoLnYgPUHv[GKUdZGtltFABGkFqKetVIRvZmhjwFJfI]['Exp'])
                    ibplInVsafQDNYfbAXXOQGRloZCZkdXd = Document(page_content=EZetWHDUgxLFbSdTRcEOFDLkiyzUnTOf, metadata={'Name': GKUdZGtltFABGkFqKetVIRvZmhjwFJfI, 'Exp':self.rGpxlQLtUGETnkirJdgyvTmoLnYgPUHv[GKUdZGtltFABGkFqKetVIRvZmhjwFJfI]['Exp'], 'Sig': self.rGpxlQLtUGETnkirJdgyvTmoLnYgPUHv[GKUdZGtltFABGkFqKetVIRvZmhjwFJfI]['Sig']})
                    kNWderyvzvEwPhECuOFXFmPjLlHrOEfk[QiXqLVQddERAClsoIbMYgeMprsDFnfSZ][KPbbHnbZFIlEzQdUQEbKkQKeqchgrMUc].append(ibplInVsafQDNYfbAXXOQGRloZCZkdXd)
        return compoDocs