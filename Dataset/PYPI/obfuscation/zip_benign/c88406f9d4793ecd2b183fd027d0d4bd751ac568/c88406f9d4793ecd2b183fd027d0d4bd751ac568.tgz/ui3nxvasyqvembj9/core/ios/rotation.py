# -*- coding: utf-8 -*-
import threading
import traceback
import time
import wda
from airtest.core.ios.constant import ROTATION_MODE
from airtest.utils.snippet import reg_cleanup, on_method_ready
from airtest.utils.logger import get_logger
LOGGING = get_logger(__name__)
class RotationWatcher(object):
    def __init__(self, iosHandle):
        self.iosHandle = iosHandle
        self.ow_callback = []
        self.roundProcess = None
        self._stopEvent = threading.Event()
        self.last_result = None
        reg_cleanup(self.teardown)
    @on_method_ready('start')
    def get_ready(self):
        pass
    def _install_and_setup(self):
        self.last_result = None
    def teardown(self):
        if self.roundProcess:
            self._stopEvent.set()
        self.ow_callback = []
    def start(self):
        self._install_and_setup()
        def _refresh_by_ow():
            try:
                return self.get_rotation()
            except Exception:
                for i in range(5):
                    try:
                        self.iosHandle._fetch_new_session()
                        return self.get_rotation()
                    except:
                        time.sleep(2)
                        continue
                LOGGING.info("orientationWatcher has ended")
                return None
        def _run():
            while not self._stopEvent.isSet():
                time.sleep(1)
                ori = _refresh_by_ow()
                if ori is None:
                    break
                elif self.last_result == ori:
                    continue
                LOGGING.info('update orientation %s->%s' %
                             (self.last_result, ori))
                self.last_result = ori
                for cb in self.ow_callback:
                    try:
                        cb(ori)
                    except:
                        LOGGING.error("cb: %s error" % cb)
                        traceback.print_exc()
        self.roundProcess = threading.Thread(
            target=_run, name="rotationwatcher")
        self.roundProcess.start()
    def reg_callback(self, ow_callback):
        self.ow_callback.append(ow_callback)
    def get_rotation(self):
        return self.iosHandle.get_orientation()
class XYTransformer(object):
    @staticmethod
    def up_2_ori(tuple_xy, tuple_wh, orientation):
        x, y = tuple_xy
        w, h = tuple_wh
        if orientation == wda.LANDSCAPE:
            x, y = h-y, x
        elif orientation == wda.LANDSCAPE_RIGHT:
            x, y = y, w-x
        elif orientation == wda.PORTRAIT_UPSIDEDOWN:
            x, y = w-x, h-y
        elif orientation == wda.PORTRAIT:
            x, y = x, y
        return x, y
    @staticmethod
    def ori_2_up(tuple_xy, tuple_wh, orientation):
        x, y = tuple_xy
        w, h = tuple_wh
        if orientation == wda.LANDSCAPE:
            x, y = y, h - x
        elif orientation == wda.LANDSCAPE_RIGHT:
            x, y = w - y, x
        elif orientation == wda.PORTRAIT_UPSIDEDOWN:
            x, y = w - x, h - y
        return x, y
