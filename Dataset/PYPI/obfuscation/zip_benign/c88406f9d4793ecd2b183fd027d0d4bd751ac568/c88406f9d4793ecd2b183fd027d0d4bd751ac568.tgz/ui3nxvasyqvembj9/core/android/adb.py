# -*- coding: utf-8 -*-
import os
import re
import sys
import time
import random
import platform
import psutil
import warnings
import subprocess
import threading
from copy import copy
from six import PY3, text_type, binary_type
from six.moves import reduce
from airtest.core.android.constant import (DEFAULT_ADB_PATH, IP_PATTERN,
                                           SDK_VERISON_ANDROID7)
from airtest.core.error import (AdbError, AdbShellError, AirtestError,
                                DeviceConnectionError)
from airtest.utils.compat import decode_path, raisefrom, proc_communicate_timeout, SUBPROCESS_FLAG
from airtest.utils.logger import get_logger
from airtest.utils.nbsp import NonBlockingStreamReader
from airtest.utils.retry import retries
from airtest.utils.apkparser import APK
from airtest.utils.snippet import get_std_encoding, reg_cleanup, split_cmd, make_file_executable
LOGGING = get_logger(__name__)
TMP_PATH = "/data/local/tmp"  
class ADB(object):
    _instances = []
    status_device = "device"
    status_offline = "offline"
    SHELL_ENCODING = "utf-8"
    def __init__(self, serialno=None, adb_path=None, server_addr=None, display_id=None, input_event=None):
        self.serialno = serialno
        self.adb_path = adb_path or self.get_adb_path()
        self.display_id = display_id
        self.input_event = input_event
        self._set_cmd_options(server_addr)
        self.connect()
        self._sdk_version = None
        self._line_breaker = None
        self._display_info = {}
        self._display_info_lock = threading.Lock()
        self._forward_local_using = []
        self.__class__._instances.append(self)
    @staticmethod
    def get_adb_path():
        if platform.system() == "Windows":
            ADB_NAME = "adb.exe"
        else:
            ADB_NAME = "adb"
        try:
            for process in psutil.process_iter(['name', 'exe']):
                if process.info['name'] == ADB_NAME and process.info['exe'] and os.path.exists(process.info['exe']):
                    return process.info['exe']
        except:
            pass
        android_home = os.environ.get('ANDROID_HOME')
        if android_home:
            adb_path = os.path.join(android_home, 'platform-tools', ADB_NAME)
            if os.path.exists(adb_path):
                return adb_path
        builtin_adb_path = ADB.builtin_adb_path()
        return builtin_adb_path
    @staticmethod
    def builtin_adb_path():
        system = platform.system()
        machine = platform.machine()
        adb_path = DEFAULT_ADB_PATH.get('{}-{}'.format(system, machine))
        if not adb_path:
            adb_path = DEFAULT_ADB_PATH.get(system)
        if not adb_path:
            raise RuntimeError("No adb executable supports this platform({}-{}).".format(system, machine))
        if system != "Windows":
            make_file_executable(adb_path)
        return adb_path
    def _set_cmd_options(self, server_addr=None):
        self.host = server_addr[0] if server_addr else "127.0.0.1"
        self.port = server_addr[1] if server_addr else 5037
        self.cmd_options = [self.adb_path]
        if self.host not in ("localhost", "127.0.0.1"):
            self.cmd_options += ['-H', self.host]
        if self.port != 5037:
            self.cmd_options += ['-P', str(self.port)]
    def start_server(self):
        return self.cmd("start-server", device=False)
    def kill_server(self):
        return self.cmd("kill-server", device=False)
    def version(self):
        return self.cmd("version", device=False).strip()
    def start_cmd(self, cmds, device=True):
        if device:
            if not self.serialno:
                raise RuntimeError("please set serialno first")
            cmd_options = self.cmd_options + ['-s', self.serialno]
        else:
            cmd_options = self.cmd_options
        cmds = cmd_options + split_cmd(cmds)
        LOGGING.debug(" ".join(cmds))
        if not PY3:
            cmds = [c.encode(get_std_encoding(sys.stdin)) for c in cmds]
        proc = subprocess.Popen(
            cmds,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            creationflags=SUBPROCESS_FLAG
        )
        return proc
    def cmd(self, cmds, device=True, ensure_unicode=True, timeout=None):
        proc = self.start_cmd(cmds, device)
        if timeout:
            stdout, stderr = proc_communicate_timeout(proc, timeout)
        else:
            stdout, stderr = proc.communicate()
        if ensure_unicode:
            stdout = stdout.decode(get_std_encoding(sys.stdout))
            stderr = stderr.decode(get_std_encoding(sys.stderr))
        if proc.returncode > 0:
            pattern = DeviceConnectionError.DEVICE_CONNECTION_ERROR
            if isinstance(stderr, binary_type):
                pattern = pattern.encode("utf-8")
            if re.search(pattern, stderr):
                raise DeviceConnectionError(stderr)
            else:
                raise AdbError(stdout, stderr)
        return stdout
    def close_proc_pipe(self, proc):
        def close_pipe(pipe):
            if pipe:
                pipe.close()
        close_pipe(proc.stdin)
        close_pipe(proc.stdout)
        close_pipe(proc.stderr)
    def devices(self, state=None):
        patten = re.compile(r'[\w\d.:-]+\t[\w]+$')
        device_list = []
        output = self.cmd("devices", device=False)
        for line in output.splitlines():
            line = line.strip()
            if not line or not patten.match(line):
                continue
            serialno, cstate = line.split('\t')
            if state and cstate != state:
                continue
            device_list.append((serialno, cstate))
        return device_list
    def connect(self, force=False):
        if self.serialno and ":" in self.serialno and (force or self.get_status() != "device"):
            connect_result = self.cmd("connect %s" % self.serialno)
            LOGGING.info(connect_result)
    def disconnect(self):
        if ":" in self.serialno:
            self.cmd("disconnect %s" % self.serialno)
    def get_status(self):
        proc = self.start_cmd("get-state")
        stdout, stderr = proc.communicate()
        stdout = stdout.decode(get_std_encoding(sys.stdout))
        stderr = stderr.decode(get_std_encoding(sys.stdout))
        if proc.returncode == 0:
            return stdout.strip()
        elif "not found" in stderr:
            return None
        else:
            raise AdbError(stdout, stderr)
    def wait_for_device(self, timeout=5):
        try:
            self.cmd("wait-for-device", timeout=timeout)
        except RuntimeError as e:
            raisefrom(DeviceConnectionError, "device not ready", e)
    def start_shell(self, cmds):
        cmds = ['shell'] + split_cmd(cmds)
        return self.start_cmd(cmds)
    def raw_shell(self, cmds, ensure_unicode=True):
        cmds = ['shell'] + split_cmd(cmds)
        out = self.cmd(cmds, ensure_unicode=False)
        if not ensure_unicode:
            return out
        try:
            return out.decode(self.SHELL_ENCODING)
        except UnicodeDecodeError:
            warnings.warn("shell output decode {} fail. repr={}".format(self.SHELL_ENCODING, repr(out)))
            return text_type(repr(out))
    def shell(self, cmd):
        if self.sdk_version < SDK_VERISON_ANDROID7:
            cmd = split_cmd(cmd) + [";", "echo", "---$?---"]
            out = self.raw_shell(cmd).rstrip()
            m = re.match("(.*)---(\d+)---$", out, re.DOTALL)
            if not m:
                warnings.warn("return code not matched")
                stdout = out
                returncode = 0
            else:
                stdout = m.group(1)
                returncode = int(m.group(2))
            if returncode > 0:
                raise AdbShellError("", stdout)
            return stdout
        else:
            try:
                out = self.raw_shell(cmd)
            except AdbError as err:
                raise AdbShellError(err.stdout, err.stderr)
            else:
                return out
    def keyevent(self, keyname):
        self.shell(["input", "keyevent", keyname.upper()])
    def getprop(self, key, strip=True):
        prop = self.raw_shell(['getprop', key])
        if strip:
            if "\r\r\n" in prop:
                prop = prop.split("\r\r\n")
                if len(prop) > 1:
                    prop = prop[-2]
                else:
                    prop = prop[-1]
            else:
                prop = prop.strip("\r\n")
        return prop
    @property
    @retries(max_tries=3)
    def sdk_version(self):
        if self._sdk_version is None:
            keyname = 'ro.build.version.sdk'
            self._sdk_version = int(self.getprop(keyname))
        return self._sdk_version
    def push(self, local, remote):
        _, ext = os.path.splitext(remote)
        if ext:
            dst_parent = os.path.dirname(remote)
        else:
            dst_parent = remote
        src_filename = os.path.basename(local)
        _, src_ext = os.path.splitext(local)
        if src_ext:
            dst_path = f"{dst_parent}/{src_filename}"
        else:
            if src_filename == os.path.basename(remote):
                dst_path = remote
            else:
                dst_path = f"{dst_parent}/{src_filename}"
        try:
            self.shell(f"rm -r {dst_path}")
        except:
            pass
        try:
            self.shell(f"mkdir -p {dst_parent}")
        except:
            pass
        tmp_path = f"{TMP_PATH}/{src_filename}"
        try:
            self.cmd(["push", local, tmp_path])
        except:
            self.cmd(["push", local, dst_parent])
        else:
            try:
                if src_ext:
                    try:
                        self.shell(f'mv "{tmp_path}" "{remote}"')
                    except:
                        self.shell(f'mv "{tmp_path}" "{remote}"')
                else:
                    try:
                        self.shell(f'cp -frp "{tmp_path}/*" "{remote}"')
                    except:
                        self.shell(f'mv "{tmp_path}" "{remote}"')
            finally:
                try:
                    if TMP_PATH != dst_parent:
                        self.shell(f'rm -r "{tmp_path}"')
                except:
                    pass
        return dst_path
    def pull(self, remote, local=""):
        if not local:
            local = os.path.basename(remote)
        local = decode_path(local)  
        if PY3:
            from pathlib import Path
            local = Path(local).as_posix()
        self.cmd(["pull", remote, local], ensure_unicode=False)
    def forward(self, local, remote, no_rebind=True):
        cmds = ['forward']
        if no_rebind:
            cmds += ['--no-rebind']
        self.cmd(cmds + [local, remote])
        if local not in self._forward_local_using:
            self._forward_local_using.append(local)
    def get_forwards(self):
        out = self.cmd(['forward', '--list'])
        for line in out.splitlines():
            line = line.strip()
            if not line:
                continue
            cols = line.split()
            if len(cols) != 3:
                continue
            serialno, local, remote = cols
            yield serialno, local, remote
    @classmethod
    def get_available_forward_local(cls):
        return random.randint(11111, 20000)
    @retries(3)
    def setup_forward(self, device_port, no_rebind=True):
        localport = self.get_available_forward_local()
        if callable(device_port):
            device_port = device_port(localport)
        self.forward("tcp:%s" % localport, device_port, no_rebind=no_rebind)
        return localport, device_port
    def remove_forward(self, local=None):
        if local:
            cmds = ["forward", "--remove", local]
        else:
            cmds = ["forward", "--remove-all"]
        try:
            self.cmd(cmds)
        except AdbError as e:
            if "not found" in (repr(e.stdout) + repr(e.stderr)):
                pass
        except DeviceConnectionError:
            pass
        if local in self._forward_local_using:
            self._forward_local_using.remove(local)
    def install_app(self, filepath, replace=False, install_options=None):
        if isinstance(filepath, str):
            filepath = decode_path(filepath)
        if not os.path.isfile(filepath):
            raise RuntimeError("file: %s does not exists" % (repr(filepath)))
        if not install_options or type(install_options) != list:
            install_options = []
        if replace:
            install_options.append("-r")
        cmds = ["install", ] + install_options + [filepath, ]
        try:
            out = self.cmd(cmds)
        except AdbError as e:
            out = repr(e.stderr) + repr(e.stdout)
            if "INSTALL_FAILED_UPDATE_INCOMPATIBLE" in out and replace:
                try:
                    package_name = re.search(r"package (.*?) .*", out).group(1)
                except:
                    package_name = APK(filepath).get_package()
                self.uninstall_app(package_name)
                out = self.cmd(cmds)
            else:
                raise
        if re.search(r"Failure \[.*?\]", out):
            raise AdbShellError("Installation Failure", repr(out))
        return out
    def install_multiple_app(self, filepath, replace=False, install_options=None):
        if isinstance(filepath, str):
            filepath = decode_path(filepath)
        if not os.path.isfile(filepath):
            raise RuntimeError("file: %s does not exists" % (repr(filepath)))
        if not install_options or type(install_options) != list:
            install_options = []
        if replace:
            install_options.append("-r")
        cmds = ["install-multiple", ] + install_options + [filepath, ]
        try:
            out = self.cmd(cmds)
        except AdbError as err:
            if "Failed to finalize session".lower() in err.stderr.lower():
                return "Success"
            else:
                return self.install_app(filepath, replace)
        if re.search(r"Failure \[.*?\]", out):
            raise AdbShellError("Installation Failure", repr(out))
        return out
    def pm_install(self, filepath, replace=False, install_options=None):
        if isinstance(filepath, str):
            filepath = decode_path(filepath)
        if not os.path.isfile(filepath):
            raise RuntimeError("file: %s does not exists" % (repr(filepath)))
        if not install_options or type(install_options) != list:
            install_options = []
        if replace:
            install_options.append("-r")
        filename = os.path.basename(filepath)
        device_dir = "/data/local/tmp"
        try:
            device_path = self.push(filepath, device_dir)
        except AdbError as err:
            raise err
        try:
            cmds = ["pm", "install", ] + install_options + [device_path]
            self.shell(cmds)
        except AdbError as e:
            out = repr(e.stderr) + repr(e.stdout)
            if re.search(r"INSTALL_FAILED_UPDATE_INCOMPATIBLE", out):
                try:
                    package_name = re.search(r"package (.*?) .*", out).group(1)
                except:
                    package_name = APK(filepath).get_package()
                self.uninstall_app(package_name)
                out = self.shell(cmds)
            else:
                raise
        finally:
            self.cmd(["shell", "rm", device_path], timeout=30)
    def uninstall_app(self, package):
        return self.cmd(['uninstall', package])
    def pm_uninstall(self, package, keepdata=False):
        cmd = ['pm', 'uninstall', package]
        if keepdata:
            cmd.append('-k')
        self.shell(cmd)
    def snapshot(self):
        if self.display_id:
            raw = self.cmd('shell screencap -d {0} -p'.format(self.display_id), ensure_unicode=False)
        else:
            raw = self.cmd('shell screencap -p', ensure_unicode=False)
        return raw.replace(self.line_breaker, b"\n")
    def touch(self, tuple_xy):
        x, y = tuple_xy
        self.shell('input tap %d %d' % (x, y))
        time.sleep(0.1)
    def swipe(self, tuple_x0y0, tuple_x1y1, duration=500):
        x0, y0 = tuple_x0y0
        x1, y1 = tuple_x1y1
        version = self.sdk_version
        if version <= 15:
            raise AirtestError('swipe: API <= 15 not supported (version=%d)' % version)
        elif version <= 17:
            self.shell('input swipe %d %d %d %d' % (x0, y0, x1, y1))
        else:
            self.shell('input touchscreen swipe %d %d %d %d %d' % (x0, y0, x1, y1, duration))
    def logcat(self, grep_str="", extra_args="", read_timeout=10):
        cmds = "shell logcat"
        if extra_args:
            cmds += " " + extra_args
        if grep_str:
            cmds += " | grep " + grep_str
        logcat_proc = self.start_cmd(cmds)
        nbsp = NonBlockingStreamReader(logcat_proc.stdout, print_output=False)
        while True:
            line = nbsp.readline(read_timeout)
            if line is None:
                break
            else:
                yield line
        nbsp.kill()
        logcat_proc.kill()
        return
    def exists_file(self, filepath):
        try:
            out = self.shell("ls \"%s\"" % filepath)
        except (AdbShellError, AdbError):
            return False
        else:
            return not ("No such file or directory" in out)
    def file_size(self, filepath):
        out = self.shell(["ls", "-l", filepath])
        try:
            file_size = int(out.split()[4])
        except ValueError:
            file_size = int(out.split()[3])
        return file_size
    def _cleanup_forwards(self):
        forward_local_list = copy(self._forward_local_using)
        for local in forward_local_list:
            try:
                self.remove_forward(local)
            except DeviceConnectionError:
                pass
    @property
    def line_breaker(self):
        if not self._line_breaker:
            if self.sdk_version >= SDK_VERISON_ANDROID7:
                line_breaker = os.linesep
            else:
                line_breaker = '\r' + os.linesep
            self._line_breaker = line_breaker.encode("ascii")
        return self._line_breaker
    @property
    def display_info(self):
        self._display_info_lock.acquire()
        if not self._display_info:
            self._display_info = self.get_display_info()
        self._display_info_lock.release()
        return self._display_info
    def get_display_info(self):
        display_info = self.getPhysicalDisplayInfo()
        orientation = self.getDisplayOrientation()
        max_x, max_y = self.getMaxXY()
        display_info.update({
            "orientation": orientation,
            "rotation": orientation * 90,
            "max_x": max_x,
            "max_y": max_y,
        })
        return display_info
    def getMaxXY(self):
        ret = self.shell('getevent -p').split('\n')
        max_x, max_y = None, None
        for i in ret:
            if i.find("0035") != -1:
                patten = re.compile(r'max [0-9]+')
                ret = patten.search(i)
                if ret:
                    max_x = int(ret.group(0).split()[1])
            if i.find("0036") != -1:
                patten = re.compile(r'max [0-9]+')
                ret = patten.search(i)
                if ret:
                    max_y = int(ret.group(0).split()[1])
        return max_x, max_y
    def getRestrictedScreen(self):
        result = None
        dumpsys_info = self.shell("dumpsys window")
        match = re.search(r'mRestrictedScreen=.+', dumpsys_info)
        if match:
            infoline = match.group(0).strip()  
            resolution = infoline.split(" ")[1].split("x")
            if isinstance(resolution, list) and len(resolution) == 2:
                result = int(str(resolution[0])), int(str(resolution[1]))
        return result
    def getPhysicalDisplayInfo(self):
        displayInfo = {}
        try:
            wm_size = re.search(r'(?P<width>\d+)x(?P<height>\d+)\s*$', self.cmd('shell wm size', timeout=5))
        except (AdbError, RuntimeError) as e:
            LOGGING.error(e)
        else:
            if wm_size:
                displayInfo = dict((k, int(v)) for k, v in wm_size.groupdict().items())
                displayInfo['density'] = self._getDisplayDensity(strip=True)
                return displayInfo
        phyDispRE = re.compile('.*PhysicalDisplayInfo{(?P<width>\d+) x (?P<height>\d+), .*, density (?P<density>[\d.]+).*')
        out = self.raw_shell('dumpsys display')
        m = phyDispRE.search(out)
        if m:
            for prop in ['width', 'height']:
                displayInfo[prop] = int(m.group(prop))
            for prop in ['density']:
                displayInfo[prop] = float(m.group(prop))
            return displayInfo
        phyDispRE = re.compile('\s*mUnrestrictedScreen=\((?P<x>\d+),(?P<y>\d+)\) (?P<width>\d+)x(?P<height>\d+)')
        dispWHRE = re.compile('\s*DisplayWidth=(?P<width>\d+) *DisplayHeight=(?P<height>\d+)')
        out = self.raw_shell('dumpsys window')
        m = phyDispRE.search(out, 0)
        if not m:
            m = dispWHRE.search(out, 0)
        if m:
            for prop in ['width', 'height']:
                displayInfo[prop] = int(m.group(prop))
            for prop in ['density']:
                d = self._getDisplayDensity(strip=True)
                if d:
                    displayInfo[prop] = d
                else:
                    displayInfo[prop] = -1.0
            return displayInfo
        phyDispRE = re.compile('Physical size: (?P<width>\d+)x(?P<height>\d+).*Physical density: (?P<density>\d+)', re.S)
        m = phyDispRE.search(self.cmd('shell wm size; wm density', timeout=3))
        if m:
            for prop in ['width', 'height']:
                displayInfo[prop] = int(m.group(prop))
            for prop in ['density']:
                displayInfo[prop] = float(m.group(prop))
            return displayInfo
        if not displayInfo:
            raise DeviceConnectionError("Getting device screen information timed out")
    def _getDisplayDensity(self, strip=True):
        BASE_DPI = 160.0
        d = self.getprop('ro.sf.lcd_density', strip)
        if d:
            return float(d) / BASE_DPI
        d = self.getprop('qemu.sf.lcd_density', strip)
        if d:
            return float(d) / BASE_DPI
        return -1.0
    def getDisplayOrientation(self):
        SurfaceFlingerRE = re.compile('orientation=(\d+)')
        output = self.shell('dumpsys SurfaceFlinger')
        m = SurfaceFlingerRE.search(output)
        if m:
            return int(m.group(1))
        surfaceOrientationRE = re.compile('SurfaceOrientation:\s+(\d+)')
        output = self.shell('dumpsys input')
        m = surfaceOrientationRE.search(output)
        if m:
            return int(m.group(1))
        displayFramesRE = re.compile(r"DisplayFrames.*r=(\d+)")
        output = self.shell('dumpsys window displays')
        m = displayFramesRE.search(output)
        if m:
            return int(m.group(1))
        warnings.warn("Could not obtain the orientation, return 0")
        return 0
    def update_cur_display(self, display_info):
        actual = self.shell("dumpsys window displays")
        arr = re.findall(r'cur=(\d+)x(\d+)', actual)
        if len(arr) > 0:
            width, height = min(list(map(int, arr[0]))), max(list(map(int, arr[0])))
            display_info['physical_width'] = display_info['width']
            display_info['physical_height'] = display_info['height']
            display_info['width'], display_info['height'] = width, height
        return display_info
    def get_top_activity(self):
        dat = self.shell('dumpsys activity top')
        activityRE = re.compile(r'\s*ACTIVITY ([A-Za-z0-9_.$]+)/([A-Za-z0-9_.$]+) \w+ pid=(\d+)')
        m = activityRE.findall(dat)
        if m:
            return m[-1]
        else:
            raise AirtestError("Can not get top activity, output:%s" % dat)
    def is_keyboard_shown(self):
        dim = self.shell('dumpsys input_method')
        if dim:
            return "mInputShown=true" in dim
        return False
    def is_screenon(self):
        screenOnRE = re.compile('mScreenOnFully=(true|false)')
        m = screenOnRE.search(self.shell('dumpsys window policy'))
        if m:
            return m.group(1) == 'true'
        else:
            screenOnRE = re.compile('screenState=(SCREEN_STATE_ON|SCREEN_STATE_OFF)')
            m = screenOnRE.search(self.shell('dumpsys window policy'))
            if m:
                return m.group(1) == 'SCREEN_STATE_ON'
        raise AirtestError("Couldn't determine screen ON state")
    @retries(max_tries=3)
    def is_locked(self):
        lockScreenRE = re.compile('(?:mShowingLockscreen|isStatusBarKeyguard|showing)=(true|false)')
        m = lockScreenRE.search(self.shell('dumpsys window policy'))
        if not m:
            raise AirtestError("Couldn't determine screen lock state")
        return (m.group(1) == 'true')
    def unlock(self):
        self.shell('input keyevent MENU')
        self.shell('input keyevent BACK')
    def get_package_version(self, package):
        package_info = self.shell(['dumpsys', 'package', package])
        matcher = re.search(r'versionCode=(\d+)', package_info)
        if matcher:
            return int(matcher.group(1))
        return None
    def list_app(self, third_only=False):
        cmd = ["pm", "list", "packages"]
        if third_only:
            cmd.append("-3")
        output = self.shell(cmd)
        packages = output.splitlines()
        packages = [p.split(":")[1] for p in packages if p]
        return packages
    def path_app(self, package):
        try:
            output = self.shell(['pm', 'path', package])
        except AdbShellError:
            output = ""
        if 'package:' not in output:
            raise AirtestError('package not found, output:[%s]' % output)
        return output.split("package:")[1].strip()
    def check_app(self, package):
        output = self.shell(['dumpsys', 'package', package])
        pattern = r'Package\s+\[' + str(package) + '\]'
        match = re.search(pattern, output)
        if match is None:
            raise AirtestError('package "{}" not found'.format(package))
        return True
    def start_app(self, package, activity=None):
        if not activity:
            try:
                ret = self.shell(['monkey', '-p', package, '-c', 'android.intent.category.LAUNCHER', '1'])
            except AdbShellError as e:
                raise AirtestError("Starting App: %s Failed! No activities found to run." % package)
            if "No activities found to run" in ret:
                raise AirtestError("Starting App: %s Failed! No activities found to run." % package)
        else:
            self.shell(['am', 'start', '-n', '%s/%s.%s' % (package, package, activity)])
    def start_app_timing(self, package, activity):
        out = self.shell(['am', 'start', '-S', '-W', '%s/%s' % (package, activity),
                          '-c', 'android.intent.category.LAUNCHER', '-a', 'android.intent.action.MAIN'])
        if not re.search(r"Status:\s*ok", out):
            raise AirtestError("Starting App: %s/%s Failed!" % (package, activity))
        matcher = re.search(r"TotalTime:\s*(\d+)", out)
        if matcher:
            return int(matcher.group(1))
        else:
            return 0
    def stop_app(self, package):
        self.shell(['am', 'force-stop', package])
    def clear_app(self, package):
        self.shell(['pm', 'clear', package])
    def text(self, content):
        if content.isalpha():
            self.shell(["input", "text", content])
        else:
            for i in content:
                if i == " ":
                    self.keyevent("KEYCODE_SPACE")
                else:
                    self.shell(["input", "text", i])
    def get_ip_address(self):
        def get_ip_address_from_interface(interface):
            try:
                res = self.shell('ip -f inet addr show {}'.format(interface))
            except AdbShellError:
                res = ''
            matcher = re.search(r"inet (\d+\.){3}\d+", res)
            if matcher:
                return matcher.group().split(" ")[-1]
            try:
                res = self.shell('ifconfig')
            except AdbShellError:
                res = ''
            matcher = re.search(interface + r'.*?inet addr:((\d+\.){3}\d+)', res, re.DOTALL)
            if matcher:
                return matcher.group(1)
            try:
                res = self.shell('netcfg')
            except AdbShellError:
                res = ''
            matcher = re.search(interface + r'.* ((\d+\.){3}\d+)/\d+', res)
            if matcher:
                return matcher.group(1)
            try:
                res = self.shell('getprop dhcp.{}.ipaddress'.format(interface))
            except AdbShellError:
                res = ''
            matcher = IP_PATTERN.search(res)
            if matcher:
                return matcher.group(0)
            return None
        interfaces = ('eth0', 'eth1', 'wlan0')
        for i in interfaces:
            ip = get_ip_address_from_interface(i)
            if ip and not ip.startswith('127.') and not ip.startswith('169.'):
                return ip
        return None
    def get_gateway_address(self):
        ip2int = lambda ip: reduce(lambda a, b: (a << 8) + b, map(int, ip.split('.')), 0)
        int2ip = lambda n: '.'.join([str(n >> (i << 3) & 0xFF) for i in range(0, 4)[::-1]])
        try:
            res = self.shell('getprop dhcp.wlan0.gateway')
        except AdbShellError:
            res = ''
        matcher = IP_PATTERN.search(res)
        if matcher:
            return matcher.group(0)
        ip = self.get_ip_address()
        if not ip:
            return None
        mask_len = self._get_subnet_mask_len()
        gateway = (ip2int(ip) & (((1 << mask_len) - 1) << (32 - mask_len))) + 1
        return int2ip(gateway)
    def _get_subnet_mask_len(self):
        try:
            res = self.shell('netcfg')
        except AdbShellError:
            pass
        else:
            matcher = re.search(r'wlan0.* (\d+\.){3}\d+/(\d+) ', res)
            if matcher:
                return int(matcher.group(2))
        print('[iputils WARNING] fail to get subnet mask len. use 17 as default.')
        return 17
    def get_memory(self):
        res = self.shell("dumpsys meminfo")
        pat = re.compile(r".*Total RAM:\s+(\S+)\s+", re.DOTALL)
        _str = pat.match(res).group(1)
        if ',' in _str:
            _list = _str.split(',')
            _num = int(_list[0])
            _num = round(_num + (float(_list[1]) / 1000.0))
        else:
            _num = round(float(_str) / 1000.0 / 1000.0)
        res = str(_num) + 'G'
        return res
    def get_storage(self):
        res = self.shell("df /data")
        pat = re.compile(r".*\/data\s+(\S+)", re.DOTALL)
        if pat.match(res):
            _str = pat.match(res).group(1)
        else:
            pat = re.compile(r".*\s+(\S+)\s+\S+\s+\S+\s+\S+\s+\/data", re.DOTALL)
            _str = pat.match(res).group(1)
        if 'G' in _str:
            _num = round(float(_str[:-1]))
        elif 'M' in _str:
            _num = round(float(_str[:-1]) / 1000.0)
        else:
            _num = round(float(_str) / 1000.0 / 1000.0)
        if _num > 64:
            res = '128G'
        elif _num > 32:
            res = '64G'
        elif _num > 16:
            res = '32G'
        elif _num > 8:
            res = '16G'
        else:
            res = '8G'
        return res
    def get_cpuinfo(self):
        res = self.shell("cat /proc/cpuinfo").strip()
        cpuNum = res.count("processor")
        pat = re.compile(r'Hardware\s+:\s+(\w+.*)')
        m = pat.search(res)
        if not m:
            pat = re.compile(r'Processor\s+:\s+(\w+.*)')
            m = pat.match(res)
        cpuName = m.group(1).replace('\r', '')
        return dict(cpuNum=cpuNum, cpuName=cpuName)
    def get_cpufreq(self):
        res = self.shell("cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq")
        num = round(float(res) / 1000 / 1000, 1)
        res = str(num) + 'GHz'
        return res.strip()
    def get_cpuabi(self):
        res = self.shell("getprop ro.product.cpu.abi")
        return res.strip()
    def get_gpu(self):
        res = self.shell("dumpsys SurfaceFlinger")
        pat = re.compile(r'GLES:\s+(.*)')
        m = pat.search(res)
        if not m:
            return None
        _list = m.group(1).split(',')
        gpuModel = ""
        opengl = ""
        if len(_list) > 0:
            gpuModel = _list[1].strip()
        if len(_list) > 1:
            m2 = re.search(r'(\S+\s+\S+\s+\S+).*', _list[2])
            if m2:
                opengl = m2.group(1)
        return dict(gpuModel=gpuModel, opengl=opengl)
    def get_model(self):
        return self.getprop("ro.product.model")
    def get_manufacturer(self):
        return self.getprop("ro.product.manufacturer")
    def get_device_info(self):
        handlers = {
            "platform": "Android",
            "serialno": self.serialno,
            "memory": self.get_memory,
            "storage": self.get_storage,
            "display": self.getPhysicalDisplayInfo,
            "cpuinfo": self.get_cpuinfo,
            "cpufreq": self.get_cpufreq,
            "cpuabi": self.get_cpuabi,
            "sdkversion": self.sdk_version,
            "gpu": self.get_gpu,
            "model": self.get_model,
            "manufacturer": self.get_manufacturer,
        }
        ret = {}
        for k, v in handlers.items():
            if callable(v):
                try:
                    value = v()
                except Exception:
                    value = None
                ret[k] = value
            else:
                ret[k] = v
        return ret
    def get_display_of_all_screen(self, info, package=None):
        output = self.shell("dumpsys window windows")
        windows = output.split("Window #")
        offsetx, offsety, width, height = 0, 0, info['width'], info['height']
        package = self._search_for_current_package(output) if package is None else package
        if package:
            for w in windows:
                if "package=%s" % package in w:
                    arr = re.findall(r'Frames: containing=\[(\d+\.?\d*),(\d+\.?\d*)]\[(\d+\.?\d*),(\d+\.?\d*)]', w)
                    if len(arr) >= 1 and len(arr[0]) == 4:
                        offsetx, offsety, width, height = float(arr[0][0]), float(arr[0][1]), float(arr[0][2]), float(arr[0][3])
                        if info["orientation"] in [1, 3]:
                            offsetx, offsety, width, height = offsety, offsetx, height, width
                        width, height = width - offsetx, height - offsety
        return {
            "offset_x": offsetx,
            "offset_y": offsety,
            "offset_width": width,
            "offset_height": height,
        }
    def _search_for_current_package(self, ret):
        try:
            packageRE = re.compile('\s*mCurrentFocus=Window{.* ([A-Za-z0-9_.]+)/[A-Za-z0-9_.]+}')
            m = packageRE.findall(ret)
            if m:
                return m[-1]
            else:
                return self.get_top_activity()[0]
        except Exception as e:
            print("[Error] Cannot get current top activity")
        return ""
def cleanup_adb_forward():
    for adb in ADB._instances:
        adb._cleanup_forwards()
reg_cleanup(cleanup_adb_forward)
