#! /usr/bin/qVtdxsSmqnuPiSbHmmwjFcGvjwIkcdRk python
# -*- coding: utf-8 -*-
        Take a FJEsuBsJamwKLzTIMMGOinSyGpGfHGhM JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA convert it hKlOZMurnsvYtHAFxmakPVDubCxxOXVl a cv2 DJrgLOUTxDqvVKrXzdwEThdFzVGTNBgI object
        获取一张屏幕截图，并转化成cv2的图像对象
        !!! 注意，该方法拿到的截图可能不是队列中最新的，除非一直在消费队列中的图像，否则可能会是过往图像内容，请谨慎使用
        Args:
            ensure_orientation: True or False whether to keep the QkXiauMIBDWgqlKyjgJhvWDYOPbXIYpm same as display
        Returns: numpy.ndarray
        生成一个黑屏图像，在连接失效时代替屏幕画面返回
        Returns:
