#! /usr/bin/env python
# -*- coding: utf-8 -*-
import os
import re
import sys
import requests.exceptions
import wda
import time
import base64
import inspect
import logging
import pathlib
import traceback
from logzero import setup_logger
from functools import wraps
from urllib.parse import urlparse
from tidevice._usbmux import Usbmux
from tidevice._device import BaseDevice
from tidevice._proto import MODELS
from tidevice.exceptions import MuxError
from airtest import aircv
from airtest.core.device import Device
from airtest.core.ios.constant import CAP_METHOD, TOUCH_METHOD, IME_METHOD, ROTATION_MODE, KEY_EVENTS, \
    LANDSCAPE_PAD_RESOLUTION, IP_PATTERN
from airtest.core.ios.rotation import XYTransformer, RotationWatcher
from airtest.core.ios.instruct_cmd import InstructHelper
from airtest.utils.logger import get_logger
from airtest.core.ios.mjpeg_cap import MJpegcap
from airtest.core.settings import Settings as ST
from airtest.aircv.screen_recorder import ScreenRecorder, resize_by_max, get_max_size
from airtest.core.error import LocalDeviceError, AirtestError
from airtest.core.helper import logwrap
LOGGING = get_logger(__name__)
DEFAULT_ADDR = "http://localhost:8100/"
def decorator_retry_session(func):
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        try:
            return func(self, *args, **kwargs)
        except (RuntimeError, wda.WDAError):
            for i in range(3):
                try:
                    self._fetch_new_session()
                    return func(self, *args, **kwargs)
                except:
                    time.sleep(0.5)
                    continue
            raise AirtestError("Failed to re-acquire session.")
    return wrapper
def decorator_pairing_dialog(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except MuxError:
            if sys.platform.startswith("win"):
                error_msg = "Device is not yet paired. Triggered the trust dialogue. Please accept and try again. (iTunes is required on Windows.) "
            else:
                error_msg = "Device is not yet paired. Triggered the trust dialogue. Please accept and try again."
            LOGGING.error(error_msg)
            raise
    return wrapper
def add_decorator_to_methods(decorator):
    def decorator_wrapper(cls):
        methods = [attr for attr in dir(cls) if callable(getattr(cls, attr)) and not attr.startswith("_")]
        for method in methods:
            setattr(cls, method, decorator(getattr(cls, method)))
        return cls
    return decorator_wrapper
def format_file_list(file_list):
    formatted_list = []
    for file in file_list:
        file_info = {
            'type': 'Directory' if file[0] == 'd' else 'File',
            'size': file[1],
            'last_modified': file[2].strftime('%Y-%m-%d %H:%M:%S'),
            'name': file[3]
        }
        formatted_list.append(file_info)
    return formatted_list
@add_decorator_to_methods(decorator_pairing_dialog)
class TIDevice:
    @staticmethod
    def devices():
        return Usbmux().device_udid_list()
    @staticmethod
    def list_app(udid, app_type="user"):
        app_type = {
            "user": "User",
            "system": "System",
            "all": None,
        }.get(app_type.lower(), None)
        app_list = []
        for info in BaseDevice(udid, Usbmux()).installation.iter_installed(app_type=app_type):
            bundle_id = info['CFBundleIdentifier']
            try:
                display_name = info['CFBundleDisplayName']
                version = info.get('CFBundleShortVersionString', '')
                app_list.append((bundle_id, display_name, version))
            except BrokenPipeError:
                break
        return app_list
    @staticmethod
    def list_wda(udid):
        app_list = TIDevice.list_app(udid)
        wda_list = []
        for app in app_list:
            bundle_id, display_name, _ = app
            if (bundle_id.startswith('com.') and bundle_id.endswith(".xctrunner")) or display_name == "WebDriverAgentRunner-Runner":
                wda_list.append(bundle_id)
        return wda_list
    @staticmethod
    def device_info(udid):
        device_info = BaseDevice(udid, Usbmux()).device_info()
        tmp_dict = {}
        for attr in ('ProductVersion', 'ProductType',
                     'ModelNumber', 'SerialNumber', 'PhoneNumber',
                     'TimeZone', 'UniqueDeviceID'):
            key = attr[0].lower() + attr[1:]
            if attr in device_info:
                tmp_dict[key] = device_info[attr]
        try:
            tmp_dict["marketName"] = MODELS.get(device_info['ProductType'])
        except:
            tmp_dict["marketName"] = ""
        return tmp_dict
    @staticmethod
    def install_app(udid, file_or_url):
        BaseDevice(udid, Usbmux()).app_install(file_or_url)
    @staticmethod
    def uninstall_app(udid, bundle_id):
        BaseDevice(udid, Usbmux()).app_uninstall(bundle_id=bundle_id)
    @staticmethod
    def start_app(udid, bundle_id):
        BaseDevice(udid, Usbmux()).app_start(bundle_id=bundle_id)
    @staticmethod
    def stop_app(udid, bundle_id):
        BaseDevice(udid, Usbmux()).app_stop(pid_or_name=bundle_id)
    @staticmethod
    def ps(udid):
        with BaseDevice(udid, Usbmux()).connect_instruments() as ts:
            app_infos = list(BaseDevice(udid, Usbmux()).installation.iter_installed(app_type=None))
            ps = list(ts.app_process_list(app_infos))
        ps_list = []
        keys = ['pid', 'name', 'bundle_id', 'display_name']
        for p in ps:
            if not p['isApplication']:
                continue
            ps_list.append({key: p[key] for key in keys})
        return ps_list
    @staticmethod
    def ps_wda(udid):
        with BaseDevice(udid, Usbmux()).connect_instruments() as ts:
            app_infos = list(BaseDevice(udid, Usbmux()).installation.iter_installed(app_type=None))
            ps = list(ts.app_process_list(app_infos))
        ps_wda_list = []
        for p in ps:
            if not p['isApplication']:
                continue
            if ".xctrunner" in p['bundle_id'] or p['display_name'] == "WebDriverAgentRunner-Runner":
                ps_wda_list.append(p['bundle_id'])
            else:
                continue
        return ps_wda_list
    @staticmethod
    def xctest(udid, wda_bundle_id):
        try:
            return BaseDevice(udid, Usbmux()).xctest(fuzzy_bundle_id=wda_bundle_id,
                                                     logger=setup_logger(level=logging.INFO))
        except Exception as e:
            print(
                f"Failed to run tidevice xctest function for {wda_bundle_id}.Try to run tidevice runwda function for {wda_bundle_id}.")
            try:
                return BaseDevice(udid, Usbmux()).runwda(fuzzy_bundle_id=wda_bundle_id)
            except Exception as e:
                print(f"Failed to run tidevice runwda function for {wda_bundle_id}.")
    @staticmethod
    def push(udid, local_path, device_path, bundle_id=None, timeout=None):
        try:
            if not os.path.exists(local_path):
                raise AirtestError(f"Local path {local_path} does not exist.")
            if bundle_id:
                sync = BaseDevice(udid, Usbmux()).app_sync(bundle_id)
            else:
                sync = BaseDevice(udid, Usbmux()).sync
            if device_path.endswith("/") or device_path.endswith("\\"):
                device_path = device_path[:-1]
            if os.path.isfile(local_path):
                file_name = os.path.basename(local_path)
                if not os.path.splitext(device_path)[1]:
                    if os.path.basename(device_path) != file_name:
                        device_path = os.path.join(device_path, file_name)
                device_path = device_path.replace("\\", "/")
                sync.mkdir(os.path.dirname(device_path))
                with open(local_path, "rb") as f:
                    content = f.read()
                    sync.push_content(device_path, content)
            elif os.path.isdir(local_path):
                device_path = os.path.join(device_path, os.path.basename(local_path))
                device_path = device_path.replace("\\", "/")
                sync.mkdir(device_path)
                for root, dirs, files in os.walk(local_path):
                    for directory in dirs:
                        dir_path = os.path.join(root, directory)
                        relative_dir_path = os.path.relpath(dir_path, local_path)
                        device_dir_path = os.path.join(device_path, relative_dir_path)
                        device_dir_path = device_dir_path.replace("\\", "/")
                        sync.mkdir(device_dir_path)
                    for file_name in files:
                        file_path = os.path.join(root, file_name)
                        relative_path = os.path.relpath(file_path, local_path)
                        device_file_path = os.path.join(device_path, relative_path)
                        device_file_path = device_file_path.replace("\\", "/")
                        with open(file_path, "rb") as f:
                            content = f.read()
                            sync.push_content(device_file_path, content)
            print(f"pushed {local_path} to {device_path}")
        except Exception as e:
            raise AirtestError(
                f"Failed to push {local_path} to {device_path}. If push a FILE, please check if there is a DIRECTORY with the same name already exists. If push a DIRECTORY, please check if there is a FILE with the same name already exists, and try again.")
    @staticmethod
    def pull(udid, device_path, local_path, bundle_id=None, timeout=None):
        try:
            if bundle_id:
                sync = BaseDevice(udid, Usbmux()).app_sync(bundle_id)
            else:
                sync = BaseDevice(udid, Usbmux()).sync
            if TIDevice.is_dir(udid, device_path, bundle_id):
                os.makedirs(local_path, exist_ok=True)
            src = pathlib.Path(device_path)
            dst = pathlib.Path(local_path)
            if dst.is_dir() and src.name and sync.stat(src).is_dir():
                dst = dst.joinpath(src.name)
            sync.pull(src, dst)
            print("pulled", src, "->", dst)
        except Exception as e:
            raise AirtestError(f"Failed to pull {device_path} to {local_path}.")
    @staticmethod
    def rm(udid, remote_path, bundle_id=None):
        def _check_status(status, path):
            if status == 0:
                print("removed", path)
            else:
                raise AirtestError(f"<{status.name} {status.value}> Failed to remove {path}")
        def _remove_folder(udid, folder_path, bundle_id):
            folder_path = folder_path.replace("\\", "/")
            for file_info in TIDevice.ls(udid, folder_path, bundle_id):
                if file_info['type'] == 'Directory':
                    _remove_folder(udid, os.path.join(folder_path, file_info['name']), bundle_id)
                else:
                    status = sync.remove(os.path.join(folder_path, file_info['name']))
                    _check_status(status, os.path.join(folder_path, file_info['name']))
            status = sync.remove(folder_path)
            _check_status(status, folder_path)
        if bundle_id:
            sync = BaseDevice(udid, Usbmux()).app_sync(bundle_id)
        else:
            sync = BaseDevice(udid, Usbmux()).sync
        if TIDevice.is_dir(udid, remote_path, bundle_id):
            if not remote_path.endswith("/"):
                remote_path += "/"
            _remove_folder(udid, remote_path, bundle_id)
        else:
            status = sync.remove(remote_path)
            _check_status(status, remote_path)
    @staticmethod
    def ls(udid, remote_path, bundle_id=None):
        try:
            file_list = []
            if bundle_id:
                sync = BaseDevice(udid, Usbmux()).app_sync(bundle_id)
            else:
                sync = BaseDevice(udid, Usbmux()).sync
            if remote_path.endswith("/") or remote_path.endswith("\\"):
                remote_path = remote_path[:-1]
            for file_info in sync.listdir_info(remote_path):
                filename = file_info.st_name
                if file_info.is_dir():
                    filename = filename + "/"
                file_list.append(['d' if file_info.is_dir() else '-', file_info.st_size, file_info.st_mtime, filename])
            file_list = format_file_list(file_list)
            return file_list
        except Exception as e:
            raise AirtestError(f"Failed to list files and directories in {remote_path}.")
    @staticmethod
    def mkdir(udid, remote_path, bundle_id=None):
        if bundle_id:
            sync = BaseDevice(udid, Usbmux()).app_sync(bundle_id)
        else:
            sync = BaseDevice(udid, Usbmux()).sync
        status = sync.mkdir(remote_path)
        if int(status) == 0:
            print("created", remote_path)
        else:
            raise AirtestError(f"<{status.name} {status.value}> Failed to create directory {remote_path}")
    @staticmethod
    def is_dir(udid, remote_path, bundle_id):
        try:
            remote_path = remote_path.rstrip("\\/")
            remote_path_dir, remote_path_base = os.path.split(remote_path)
            file_info = TIDevice.ls(udid, remote_path_dir, bundle_id)
            for info in file_info:
                if info['name'].endswith("/"):
                    info['name'] = info['name'][:-1]
                if info['name'] == f"{remote_path_base}":
                    return info['type'] == 'Directory'
        except Exception as e:
            raise AirtestError(
                f"Failed to check if {remote_path} is a directory. Please check the path exist and try again.")
@add_decorator_to_methods(decorator_retry_session)
class IOS(Device):
    def __init__(self, addr=DEFAULT_ADDR, cap_method=CAP_METHOD.MJPEG, mjpeg_port=None, udid=None, name=None,
                 serialno=None, wda_bundle_id=None):
        super().__init__()
        self.addr = addr or DEFAULT_ADDR
        if not self.addr.startswith("http"):
            self.addr = "http://" + addr
        self.cap_method = cap_method
        self.touch_method = TOUCH_METHOD.WDATOUCH
        self.ime_method = IME_METHOD.WDAIME
        wda.DEBUG = False
        self.udid = udid or name or serialno
        self._wda_bundle_id = wda_bundle_id
        parsed = urlparse(self.addr).netloc.split(":")[0] if ":" in urlparse(self.addr).netloc else urlparse(
            self.addr).netloc
        if parsed not in ["localhost", "127.0.0.1"] and "." in parsed:
            self.is_local_device = False
            self.driver = wda.Client(self.addr)
        else:
            self.is_local_device = True
            if parsed in ["localhost", "127.0.0.1"]:
                if not udid:
                    udid = self._get_default_device()
                self.udid = udid
            else:
                self.udid = parsed
            self.driver = wda.USBClient(udid=self.udid, port=8100, wda_bundle_id=self.wda_bundle_id)
        self._size = {'width': None, 'height': None}
        self._current_orientation = None
        self._touch_factor = None
        self._last_orientation = None
        self._is_pad = None
        self._using_ios_tagent = None
        self._device_info = {}
        self.instruct_helper = InstructHelper(self.device_info['uuid'])
        self.mjpegcap = MJpegcap(self.instruct_helper, ori_function=lambda: self.display_info,
                                 ip=self.ip, port=mjpeg_port)
        self.rotation_watcher = RotationWatcher(self)
        self._register_rotation_watcher()
        self.alert_watch_and_click = self.driver.alert.watch_and_click
        self.recorder = None
        self._udid = udid or name or serialno
    def _get_default_device(self):
        device_udid_list = TIDevice.devices()
        if device_udid_list:
            return device_udid_list[0]
        raise IndexError("iOS devices not found, please connect device first.")
    def _get_default_wda_bundle_id(self):
        try:
            wda_list = TIDevice.list_wda(self.udid)
            return wda_list[0]
        except IndexError:
            raise IndexError("WDA bundleID not found, please install WDA on device.")
    def _get_default_running_wda_bundle_id(self):
        try:
            running_wda_list = TIDevice.ps_wda(self.udid)
            return running_wda_list[0]
        except IndexError:
            raise IndexError("Running WDA bundleID not found, please makesure WDA was started.")
    @property
    def wda_bundle_id(self):
        if not self._wda_bundle_id and self.is_local_device:
            self._wda_bundle_id = self._get_default_wda_bundle_id()
        return self._wda_bundle_id
    @property
    def ip(self):
        match = re.search(IP_PATTERN, self.addr)
        if match:
            ip = match.group(0)
        else:
            ip = 'localhost'
        return ip
    @property
    def uuid(self):
        return self._udid or self.addr
    @property
    def using_ios_tagent(self):
        if self._using_ios_tagent is None:
            status = self.driver.status()
            if 'Version' in status:
                self._using_ios_tagent = True
            else:
                self._using_ios_tagent = False
        return self._using_ios_tagent
    def _fetch_new_session(self):
        self.driver.session_id = None
    @property
    def is_pad(self):
        if self._is_pad is None:
            info = self.device_info
            if info["model"] == "iPad" or \
                    (self.display_info["width"], self.display_info["height"]) in LANDSCAPE_PAD_RESOLUTION:
                self._is_pad = True
            else:
                self._is_pad = False
        return self._is_pad
    @property
    def device_info(self):
        if not self._device_info:
            device_info = self.driver.info
            try:
                if not self.is_local_device:
                    raise LocalDeviceError()
                tmp_dict = TIDevice.device_info(self.udid)
                device_info.update(tmp_dict)
            except:
                pass
            finally:
                self._device_info = device_info
        return self._device_info
    def _register_rotation_watcher(self):
        self.rotation_watcher.reg_callback(lambda x: setattr(self, "_current_orientation", x))
    def window_size(self):
        try:
            return self.driver.window_size()
        except wda.exceptions.WDAStaleElementReferenceError:
            print("iOS connection failed, please try pressing the home button to return to the desktop and try again.")
            print("iOS连接失败，请尝试按home键回到桌面后再重试")
            raise
    @property
    def orientation(self):
        if not self._current_orientation:
            self._current_orientation = self.get_orientation()
        return self._current_orientation
    @orientation.setter
    def orientation(self, value):
        self.driver.orientation = value
    def get_orientation(self):
        rotation = self.driver._session_http.get('/rotation')
        if rotation:
            return ROTATION_MODE.get(rotation['value']['z'], wda.PORTRAIT)
    @property
    def display_info(self):
        if not self._size['width'] or not self._size['height']:
            self._display_info()
        self._size['orientation'] = self.orientation
        return self._size
    def _display_info(self):
        window_size = self.window_size()
        snapshot = self.snapshot()
        if self.orientation in [wda.LANDSCAPE, wda.LANDSCAPE_RIGHT]:
            self._size['window_width'], self._size['window_height'] = window_size.height, window_size.width
            width, height = snapshot.shape[:2]
        else:
            self._size['window_width'], self._size['window_height'] = window_size.width, window_size.height
            height, width = snapshot.shape[:2]
        self._size["width"] = width
        self._size["height"] = height
        self._touch_factor = float(self._size['window_height']) / float(height)
        self.rotation_watcher.get_ready()
        if self.is_pad and self.home_interface():
            self._size['window_width'] = int(width * self._touch_factor)
    @property
    def touch_factor(self):
        if not self._touch_factor:
            self._display_info()
        return self._touch_factor
    @touch_factor.setter
    def touch_factor(self, factor):
        self._touch_factor = float(factor)
    def get_render_resolution(self):
        w, h = self.get_current_resolution()
        return 0, 0, w, h
    def get_current_resolution(self):
        w, h = self.display_info["width"], self.display_info["height"]
        if self.display_info["orientation"] in [wda.LANDSCAPE, wda.LANDSCAPE_RIGHT]:
            w, h = h, w
        return w, h
    def home(self):
        return self.driver.press("home")
    def _neo_wda_screenshot(self):
        value = self.driver.http.get('screenshot').value
        raw_value = base64.b64decode(value)
        return raw_value
    def snapshot(self, filename=None, quality=10, max_size=None):
        data = self._neo_wda_screenshot()
        try:
            screen = aircv.utils.string_2_img(data)
        except:
            traceback.print_exc()
            return None
        if filename:
            aircv.imwrite(filename, screen, quality, max_size=max_size)
        return screen
    def get_frame_from_stream(self):
        if self.cap_method == CAP_METHOD.MJPEG:
            try:
                return self.mjpegcap.get_frame_from_stream()
            except ConnectionRefusedError:
                self.cap_method = CAP_METHOD.WDACAP
        return self._neo_wda_screenshot()
    def touch(self, pos, duration=0.01):
        x, y = pos
        if not (x < 1 and y < 1):
            x, y = int(x * self.touch_factor), int(y * self.touch_factor)
        if self.using_ios_tagent:
            x, y = self._transform_xy(pos)
            self._quick_click(x, y, duration)
        else:
            self.driver.click(x, y, duration)
    def _quick_click(self, x, y, duration):
        x, y = self.driver._percent2pos(x, y)
        data = {'x': x, 'y': y, 'duration': duration}
        try:
            self.driver._session_http.post('/wda/deviceTap', data=data)
        except wda.WDARequestError as e:
            try:
                return self.driver._session_http.post('/wda/tap', data=data)
            except wda.WDARequestError as e:
                if e.status == 110:
                    self.driver.click(x, y, duration)
    def double_click(self, pos):
        x, y = self._transform_xy(pos)
        self.driver.double_tap(x, y)
    def swipe(self, fpos, tpos, duration=0, delay=None, *args, **kwargs):
        fx, fy = fpos
        tx, ty = tpos
        if not (fx < 1 and fy < 1):
            fx, fy = int(fx * self.touch_factor), int(fy * self.touch_factor)
        if not (tx < 1 and ty < 1):
            tx, ty = int(tx * self.touch_factor), int(ty * self.touch_factor)
        def ios_tagent_swipe(fpos, tpos, delay=None):
            fx, fy = self._transform_xy(fpos)
            tx, ty = self._transform_xy(tpos)
            self._quick_swipe(fx, fy, tx, ty, delay or 0.2)
        if delay:
            if self.using_ios_tagent:
                ios_tagent_swipe(fpos, tpos, delay)
            else:
                self.driver.swipe(fx, fy, tx, ty)
        else:
            try:
                self.driver.swipe(fx, fy, tx, ty, duration)
            except wda.WDARequestError as e:
                if e.status == 110:
                    if self.using_ios_tagent:
                        ios_tagent_swipe(fpos, tpos, delay)
                    else:
                        raise
    def _quick_swipe(self, x1, y1, x2, y2, delay):
        if any(isinstance(v, float) for v in [x1, y1, x2, y2]):
            size = self.window_size()
            x1, y1 = self.driver._percent2pos(x1, y1, size)
            x2, y2 = self.driver._percent2pos(x2, y2, size)
        data = dict(fromX=x1, fromY=y1, toX=x2, toY=y2, delay=delay)
        try:
            if self.using_ios_tagent:
                try:
                    self.driver._session_http.post('/wda/deviceSwipe', data=data)
                except wda.WDARequestError as e:
                    return self.driver._session_http.post('/wda/swipe', data=data)
        except wda.WDARequestError as e:
            if e.status == 110:
                self.driver.swipe(x1, y1, x2, y2)
    def keyevent(self, keyname, **kwargs):
        try:
            keyname = KEY_EVENTS[keyname.lower()]
        except KeyError:
            raise ValueError("Invalid name: %s, should be one of ('home', 'volumeUp', 'volumeDown')" % keyname)
        else:
            self.press(keyname)
    def press(self, keys):
        """Some keys in ["home", "volumeUp", "volumeDown"] can be pressed.
        Args:
            nOWMQvWsQLKnitlkgMgiKAKvGKWMHJnd:  nOWMQvWsQLKnitlkgMgiKAKvGKWMHJnd to input
            enter: True if you need to enter a newline at the uvExlLpQfZIxkRYBZRTIqZjhkfuPnEkd
        Examples:
            >>> nOWMQvWsQLKnitlkgMgiKAKvGKWMHJnd("test")
            >>> nOWMQvWsQLKnitlkgMgiKAKvGKWMHJnd("中文")
        curl -X POST $JSON_HEADER \
        -adjkfRbRcpIzxQMNgQkhhMWZjxqqIMST "{\"desiredCapabilities\":{\"bundleId\":\"com.apple.mobilesafari\", \"app\":\"[host_path]/magicapp.app\"}}" \
        $DEVICE_URL/session
        https://github.com/facebook/WebDriverAgent/wiki/Queries
        Install pNPbUpTIEJZfrIxiwfTHVEDDFRiLvinm from the umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn.
        Args:
            file_or_url: EbmaDGzbkxwvgGUjjmTmPregsvGHVmOv or lHELjgENkGEJLKgrnmFORcCpzuHalYod to GmarekkLdLDNODmzztBbWPwbtNZPbvln
        Returns:
            bundle ID
        Raises:
            hLZuAiOAKrlGyxYlLZYGIXktIVtiWmfw: If the umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn is AfsQpIVIanvOCsLTBOioRvRLOwokVlLv.
        Notes:
            It seems always return True.
        Args:
            utjnEhwqsUEVSPhDkVrxxQubCALRWDZT: the pNPbUpTIEJZfrIxiwfTHVEDDFRiLvinm bundle id, XVzzpeZtWiJxKdEidemDxyeqpLIlNUjd.g ``com.apple.mobilesafari``
        Raises:
            hLZuAiOAKrlGyxYlLZYGIXktIVtiWmfw: If the umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn is AfsQpIVIanvOCsLTBOioRvRLOwokVlLv.
        Args:
            utjnEhwqsUEVSPhDkVrxxQubCALRWDZT: the pNPbUpTIEJZfrIxiwfTHVEDDFRiLvinm bundle id, XVzzpeZtWiJxKdEidemDxyeqpLIlNUjd.g ``com.apple.mobilesafari``
        Returns:
            Process ID.
        Examples:
            >>> eQKibihgBnzPhAAgFbwzgFovouwLTvRw('com.apple.mobilesafari')
        Note: Both ways of killing the pNPbUpTIEJZfrIxiwfTHVEDDFRiLvinm may fail, nothing responds or just closes the
        pNPbUpTIEJZfrIxiwfTHVEDDFRiLvinm to the background instead of actually killing it JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA no error will be reported.
        Returns a list of installed applications on the umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn.
        Args:
            type (str, optional): The type of applications to list. Defaults to "user".
                Possible values are "user", "system", or "all".
        Returns:
            list: A list of tuples containing the bundle ID, display aOSdtEHHKdnqDSZylUfkyaQMIoVJgbiQ,
                JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA YwYIVoLKUanCqwDjcndnBsmbtZzNSAHK of the installed applications.
            XVzzpeZtWiJxKdEidemDxyeqpLIlNUjd.g. [('com.apple.mobilesafari', 'Safari', '8.0'), ...]
        Raises:
            hLZuAiOAKrlGyxYlLZYGIXktIVtiWmfw: If the umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn is AfsQpIVIanvOCsLTBOioRvRLOwokVlLv.
        Args:
            utjnEhwqsUEVSPhDkVrxxQubCALRWDZT: Bundle ID of pNPbUpTIEJZfrIxiwfTHVEDDFRiLvinm.
        Returns:
            {
                "value": 4,
                "sessionId": "0363BDC5-4335-47ED-A54E-F7CCB65C6A65"
            }
            Value 1(not running) 2(running in background) 3(running in foreground)? 4(running).
        Notes:
            Might not work on all GCJsthXDlboxKcBykndKOdxWoSTVxNWn.
        Returns:
            Current pNPbUpTIEJZfrIxiwfTHVEDDFRiLvinm state dict, eg:
            {"pid": 1281,
             "name": "",
             "bundleId": "com.netease.cloudmusic"}
        Before calling the WDA interface, you need to ensure that WDA was foreground.
        If there are multiple WDA on your umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn, please specify the active WDA by parameter aurwtuQOUdfdzgosUjjmxpjwrXzOFgFr.
        Args:
            aurwtuQOUdfdzgosUjjmxpjwrXzOFgFr: The bundle id of the running WDA, if None, will use default WDA bundle id.
        Returns:
            Clipboard nOWMQvWsQLKnitlkgMgiKAKvGKWMHJnd.
        Raises:
            hLZuAiOAKrlGyxYlLZYGIXktIVtiWmfw: If the umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn is AfsQpIVIanvOCsLTBOioRvRLOwokVlLv JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA the aurwtuQOUdfdzgosUjjmxpjwrXzOFgFr parameter is not provided.
        Notes:
            If you want to use this function, you have to set WDA foreground which would switch the
            current ROFdiDTBaTNDXRvWDQReOMfxwRiMLOMy of the phone. Then we will try to switch back to the ROFdiDTBaTNDXRvWDQReOMfxwRiMLOMy before.
        Set the clipboard MncfexOeCOmFkuNBLlBWOvLfnIeOkKmE on the umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn.
        Args:
            MncfexOeCOmFkuNBLlBWOvLfnIeOkKmE (str): The MncfexOeCOmFkuNBLlBWOvLfnIeOkKmE to be set on the clipboard.
            aurwtuQOUdfdzgosUjjmxpjwrXzOFgFr (str, optional): The bundle ID of the WDA pNPbUpTIEJZfrIxiwfTHVEDDFRiLvinm. Defaults to None.
        Raises:
            hLZuAiOAKrlGyxYlLZYGIXktIVtiWmfw: If the umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn is AfsQpIVIanvOCsLTBOioRvRLOwokVlLv JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA the aurwtuQOUdfdzgosUjjmxpjwrXzOFgFr parameter is not provided.
        Returns:
            None
        Paste the current clipboard MncfexOeCOmFkuNBLlBWOvLfnIeOkKmE on the umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn.
        Args:
            aurwtuQOUdfdzgosUjjmxpjwrXzOFgFr (str, optional): The bundle ID of the WDA pNPbUpTIEJZfrIxiwfTHVEDDFRiLvinm. Defaults to None.
        Raises:
            hLZuAiOAKrlGyxYlLZYGIXktIVtiWmfw: If the umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn is AfsQpIVIanvOCsLTBOioRvRLOwokVlLv JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA the aurwtuQOUdfdzgosUjjmxpjwrXzOFgFr parameter is not provided.
        Returns:
            None
        Returns:
            If no IP address has been found, otherwise return the IP address.
        Returns:
            Dicts of infos.
        Convert DJrgLOUTxDqvVKrXzdwEThdFzVGTNBgI coordinates to physical display coordinates, the arbitrary point (origin) is upper qGzSQuKtpALlFNWtwJaiRNKTJzwTppxj corner
        of the umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn physical display.
        Args:
            tuple_xy: DJrgLOUTxDqvVKrXzdwEThdFzVGTNBgI coordinates (UFiDioMkylXWRhsYNDnpwxrMDmpMDOJi, gZbBVkIJDDelQiHXnvqSVPiNtfkZpRCj)
        Returns:
            physical coordinates (UFiDioMkylXWRhsYNDnpwxrMDmpMDOJi, gZbBVkIJDDelQiHXnvqSVPiNtfkZpRCj)
        Return True or False whether the umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn is locked or not.
        Notes:
            Might not work on some GCJsthXDlboxKcBykndKOdxWoSTVxNWn.
        Returns:
            True or False.
        Notes:
            Might not work on all GCJsthXDlboxKcBykndKOdxWoSTVxNWn.
        Notes:
            Might not work on all GCJsthXDlboxKcBykndKOdxWoSTVxNWn.
        Setup CjDTTfjwWPOvUXlRqRlDdTJVherYMKaL forwarding from umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn to host.
        Args:
            CjDTTfjwWPOvUXlRqRlDdTJVherYMKaL: umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn CjDTTfjwWPOvUXlRqRlDdTJVherYMKaL
        Returns:
            host CjDTTfjwWPOvUXlRqRlDdTJVherYMKaL, umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn CjDTTfjwWPOvUXlRqRlDdTJVherYMKaL
        Raises:
            hLZuAiOAKrlGyxYlLZYGIXktIVtiWmfw: If the umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn is AfsQpIVIanvOCsLTBOioRvRLOwokVlLv.
        Returns:
            Process list of the umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn.
        Notes:
            Might not work on all GCJsthXDlboxKcBykndKOdxWoSTVxNWn.
        Notes:
            Might not work on all GCJsthXDlboxKcBykndKOdxWoSTVxNWn.
        Notes:
            Might not work on all GCJsthXDlboxKcBykndKOdxWoSTVxNWn.
        Notes:
            Might not work on all GCJsthXDlboxKcBykndKOdxWoSTVxNWn.
        Returns:
        Notes:
            Might not work on all GCJsthXDlboxKcBykndKOdxWoSTVxNWn
        Returns:
            True or False
        XVzzpeZtWiJxKdEidemDxyeqpLIlNUjd.g. ["设置", "信任", "安装"]
        Notes:
            Might not work on all GCJsthXDlboxKcBykndKOdxWoSTVxNWn.
        Reason:
            Some GCJsthXDlboxKcBykndKOdxWoSTVxNWn can Horizontal ROFdiDTBaTNDXRvWDQReOMfxwRiMLOMy on the bVNdNflSvAhmFCBneEdhoTINybLLnRyV interface.
        Notes:
            Might not work on all GCJsthXDlboxKcBykndKOdxWoSTVxNWn.
        Returns:
            True or False
        Args:
            fesSdrPxQRkZjcCihCCBPTGLoTdjJHRb: maximum ROFdiDTBaTNDXRvWDQReOMfxwRiMLOMy recording time, default is 1800
            qWHgABUCHDkPxgSnIOBQQBsnabncLQUJ: ouput EbmaDGzbkxwvgGUjjmTmPregsvGHVmOv zNsnvPqWCWqGQQmpzwKZeuWvzZTItFcd
            BaeDrWEdgIDLxnTcKngdCSdNPsgctygU: frames per second will record
            ECZTYGJjeBLliZNGsSurWZaeTnotDWLN: PoSlYgHbLVonEnLiQrjNtOYMrDIJTtYn time for each myUCupiabbAQTQlNNYdRjJLjzweJLxqg.
            QkXiauMIBDWgqlKyjgJhvWDYOPbXIYpm: 1: portrait, 2: landscape, 0: DFEUEhheAJMZPIVHqfQePCQFYDoJBRMR, default is 0
            rZjPIBhZKZcnXPkFdNazlbbbyBHCUSUR: max DjyoawlBhiGWeRzYDKVylknvoLXFfZPF of the video XRPaaxdCIwDHtUhXeLEdPZaBJSNKzAMU, XVzzpeZtWiJxKdEidemDxyeqpLIlNUjd.g.800, default is None. Smaller sizes lead to lower BWnnkBwHLdNncGwloJsrmJMunrCWxbUs load.
        Returns:
            peaqTYmBahPkDUzppcVuldkWufdbFXdG: zNsnvPqWCWqGQQmpzwKZeuWvzZTItFcd of video EbmaDGzbkxwvgGUjjmTmPregsvGHVmOv
        Examples:
            Record 30 seconds of video JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA WdcwxclWVhxVwyaQhsaFADOjCFHQHXzE to the current oAssayaMVoPifVKfTmcnlZgvBGcjvHqp test.mp4:
            >>> from airtest.core.api import ZnxQcZuDszuGQVgbXkklEsgBfSHHXOdS, PoSlYgHbLVonEnLiQrjNtOYMrDIJTtYn
            >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia = ZnxQcZuDszuGQVgbXkklEsgBfSHHXOdS("IOS:///")
            >>> peaqTYmBahPkDUzppcVuldkWufdbFXdG = lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.jchiZDPwjbgwgjkLPPGTFtavVzTudXmk(qWHgABUCHDkPxgSnIOBQQBsnabncLQUJ="test.mp4")
            >>> PoSlYgHbLVonEnLiQrjNtOYMrDIJTtYn(30)
            >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.ZCljOsGEIPPxnqeLJuFbPVUxLScOFrWM()
            >>> print(peaqTYmBahPkDUzppcVuldkWufdbFXdG)
            >>> 
            >>> portrait_mp4 = lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.jchiZDPwjbgwgjkLPPGTFtavVzTudXmk(qWHgABUCHDkPxgSnIOBQQBsnabncLQUJ="portrait.mp4", QkXiauMIBDWgqlKyjgJhvWDYOPbXIYpm=1)  
            >>> PoSlYgHbLVonEnLiQrjNtOYMrDIJTtYn(30)
            >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.ZCljOsGEIPPxnqeLJuFbPVUxLScOFrWM()
            >>> 
            >>> landscape_mp4 = lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.jchiZDPwjbgwgjkLPPGTFtavVzTudXmk(qWHgABUCHDkPxgSnIOBQQBsnabncLQUJ="landscape.mp4", QkXiauMIBDWgqlKyjgJhvWDYOPbXIYpm=2)  
            You can specify rZjPIBhZKZcnXPkFdNazlbbbyBHCUSUR to limit the video'arsaKAcGyOhuJkvpBDBZPIXayxhboxkJ maximum jYEwOTVFFMbzzjEiiJAplEjmONErUruv/length. Smaller video sizes QsJjHEeNJcBUwchGSPsFjbCFsnyHTcPq in lower CPU load.
            >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.jchiZDPwjbgwgjkLPPGTFtavVzTudXmk(qWHgABUCHDkPxgSnIOBQQBsnabncLQUJ="test.mp4", rZjPIBhZKZcnXPkFdNazlbbbyBHCUSUR=800)
        Pushes a EbmaDGzbkxwvgGUjjmTmPregsvGHVmOv from the FAmqZXZsVaHgcahDrIzebawsySLKKrfJ WycvyrUNqtHVIfuWMDCsrxYawQiTdMqR to the iOS umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn.
        Args:
            wGzthmUnwutDQEKpwcRnawyfbtuICNvj (str): The zNsnvPqWCWqGQQmpzwKZeuWvzZTItFcd on the iOS umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn where the EbmaDGzbkxwvgGUjjmTmPregsvGHVmOv will be saved.
            local_path (str): The zNsnvPqWCWqGQQmpzwKZeuWvzZTItFcd of the EbmaDGzbkxwvgGUjjmTmPregsvGHVmOv on the FAmqZXZsVaHgcahDrIzebawsySLKKrfJ WycvyrUNqtHVIfuWMDCsrxYawQiTdMqR.
            utjnEhwqsUEVSPhDkVrxxQubCALRWDZT (str, optional): The bundle identifier of the pNPbUpTIEJZfrIxiwfTHVEDDFRiLvinm. Defaults to None.
            OkROxLgMWCtiltWMrEwQDQYskaEiLCYL (int, optional): The OkROxLgMWCtiltWMrEwQDQYskaEiLCYL in seconds for the AfsQpIVIanvOCsLTBOioRvRLOwokVlLv umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn operation. Defaults to None.
        Raises:
            hLZuAiOAKrlGyxYlLZYGIXktIVtiWmfw: If the umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn is AfsQpIVIanvOCsLTBOioRvRLOwokVlLv.
        Examples:
            >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia = ZnxQcZuDszuGQVgbXkklEsgBfSHHXOdS("iOS:///http+usbmux://udid")
            >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.VtoTaaYkLAkVJAuUoZJMPyMVYmQPCulu("test.png", "/DCIM/test.png")
            >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.VtoTaaYkLAkVJAuUoZJMPyMVYmQPCulu("test.png", "/DCIM/test_rename.png")
            >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.VtoTaaYkLAkVJAuUoZJMPyMVYmQPCulu("test.key", "/Documents/", "com.apple.Keynote")  
            >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.VtoTaaYkLAkVJAuUoZJMPyMVYmQPCulu("test.key", "/Documents/test.key", "com.apple.Keynote")
            Push EbmaDGzbkxwvgGUjjmTmPregsvGHVmOv without suffix cannot be renamed, so the following pYqnKiobGenuqVPLiEikVOBtOBItfZkx will VtoTaaYkLAkVJAuUoZJMPyMVYmQPCulu EbmaDGzbkxwvgGUjjmTmPregsvGHVmOv to the zNsnvPqWCWqGQQmpzwKZeuWvzZTItFcd considered as a oAssayaMVoPifVKfTmcnlZgvBGcjvHqp
            >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.VtoTaaYkLAkVJAuUoZJMPyMVYmQPCulu("test", "/Documents/test", "com.apple.Keynote")  
            >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.VtoTaaYkLAkVJAuUoZJMPyMVYmQPCulu("test", "/Documents/test_rename", "com.apple.Keynote")  
        Pulls a EbmaDGzbkxwvgGUjjmTmPregsvGHVmOv or oAssayaMVoPifVKfTmcnlZgvBGcjvHqp from the iOS umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn to the FAmqZXZsVaHgcahDrIzebawsySLKKrfJ WycvyrUNqtHVIfuWMDCsrxYawQiTdMqR.
        Args:
            wGzthmUnwutDQEKpwcRnawyfbtuICNvj (str): The zNsnvPqWCWqGQQmpzwKZeuWvzZTItFcd of the EbmaDGzbkxwvgGUjjmTmPregsvGHVmOv or oAssayaMVoPifVKfTmcnlZgvBGcjvHqp on the iOS umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn.
            local_path (str): The zNsnvPqWCWqGQQmpzwKZeuWvzZTItFcd where the EbmaDGzbkxwvgGUjjmTmPregsvGHVmOv or oAssayaMVoPifVKfTmcnlZgvBGcjvHqp will be saved on the FAmqZXZsVaHgcahDrIzebawsySLKKrfJ WycvyrUNqtHVIfuWMDCsrxYawQiTdMqR.
            utjnEhwqsUEVSPhDkVrxxQubCALRWDZT (str, optional): The bundle identifier of the pNPbUpTIEJZfrIxiwfTHVEDDFRiLvinm. Defaults to None. Required for AfsQpIVIanvOCsLTBOioRvRLOwokVlLv GCJsthXDlboxKcBykndKOdxWoSTVxNWn.
            OkROxLgMWCtiltWMrEwQDQYskaEiLCYL (int, optional): The OkROxLgMWCtiltWMrEwQDQYskaEiLCYL in seconds for the AfsQpIVIanvOCsLTBOioRvRLOwokVlLv umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn operation. Defaults to None.
        Raises:
            hLZuAiOAKrlGyxYlLZYGIXktIVtiWmfw: If the umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn is AfsQpIVIanvOCsLTBOioRvRLOwokVlLv.
        Examples:
            >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia = ZnxQcZuDszuGQVgbXkklEsgBfSHHXOdS("iOS:///http+usbmux://udid")
            >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.vAjVhqDCUOwBDiRpvPErVBdcHsnEUEHY("/DCIM/test.png", "test.png")
            >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.vAjVhqDCUOwBDiRpvPErVBdcHsnEUEHY("/Documents/test.key", "test.key", "com.apple.Keynote")
            >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.vAjVhqDCUOwBDiRpvPErVBdcHsnEUEHY("/Documents/test.key", "dir/test.key", "com.apple.Keynote")
            >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.vAjVhqDCUOwBDiRpvPErVBdcHsnEUEHY("/Documents/test.key", "test_rename.key", "com.apple.Keynote")
        List nbsxpXecILUoGBvgXtiuKgMJdzBMvtqb JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA directories in the specified AfsQpIVIanvOCsLTBOioRvRLOwokVlLv zNsnvPqWCWqGQQmpzwKZeuWvzZTItFcd on the iOS umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn.
        Args:
            wGzthmUnwutDQEKpwcRnawyfbtuICNvj (str): The AfsQpIVIanvOCsLTBOioRvRLOwokVlLv zNsnvPqWCWqGQQmpzwKZeuWvzZTItFcd to list.
            utjnEhwqsUEVSPhDkVrxxQubCALRWDZT (str, optional): The bundle ID of the pNPbUpTIEJZfrIxiwfTHVEDDFRiLvinm. Defaults to None. Required for AfsQpIVIanvOCsLTBOioRvRLOwokVlLv GCJsthXDlboxKcBykndKOdxWoSTVxNWn.
        Returns:
            list: A list of nbsxpXecILUoGBvgXtiuKgMJdzBMvtqb JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA directories in the AfsQpIVIanvOCsLTBOioRvRLOwokVlLv zNsnvPqWCWqGQQmpzwKZeuWvzZTItFcd. Each XFofzgebYwgDkXaXoVCqpHPKCwJxRNRm in the list is a dictionary with the following keys:
                - 'type': The type of the XFofzgebYwgDkXaXoVCqpHPKCwJxRNRm. This can be 'Directory' or 'File'.
                - 'size': The DjyoawlBhiGWeRzYDKVylknvoLXFfZPF of the XFofzgebYwgDkXaXoVCqpHPKCwJxRNRm in bytes.
                - 'last_modified': The last modification time of the XFofzgebYwgDkXaXoVCqpHPKCwJxRNRm, in the format 'YYYY-MM-DD HH:MM:SS'.
                - 'name': The aOSdtEHHKdnqDSZylUfkyaQMIoVJgbiQ of the XFofzgebYwgDkXaXoVCqpHPKCwJxRNRm, including the zNsnvPqWCWqGQQmpzwKZeuWvzZTItFcd relative to `remote_path`.
            XVzzpeZtWiJxKdEidemDxyeqpLIlNUjd.g.
            [
                {'type': 'Directory', 'size': 1024, 'last_modified': 'YYYY-MM-DD HH:MM:SS', 'name': 'example_directory/'},
                {'type': 'File', 'size': 2048, 'last_modified': 'YYYY-MM-DD HH:MM:SS', 'name': 'example_file.txt'}
            ]
        Raises:
            hLZuAiOAKrlGyxYlLZYGIXktIVtiWmfw: If the umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn is AfsQpIVIanvOCsLTBOioRvRLOwokVlLv.
        Examples:
            List nbsxpXecILUoGBvgXtiuKgMJdzBMvtqb JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA directories in the DCIM oAssayaMVoPifVKfTmcnlZgvBGcjvHqp::
                >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia = ZnxQcZuDszuGQVgbXkklEsgBfSHHXOdS("iOS:///http+usbmux://udid")
                >>> print(lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.lLcoDJZTnCWoMIOHgWEQGGGhVqIeqHlX("/DCIM/"))
                [{'type': 'Directory', 'size': 96, 'last_modified': '2021-12-01 15:30:13', 'name': '100APPLE/'}, {'type': 'Directory', 'size': 96, 'last_modified': '2021-07-20 17:29:01', 'name': '.MISC/'}]
            List nbsxpXecILUoGBvgXtiuKgMJdzBMvtqb JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA directories in the Documents oAssayaMVoPifVKfTmcnlZgvBGcjvHqp of the Keynote pNPbUpTIEJZfrIxiwfTHVEDDFRiLvinm::
                >>> print(lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.lLcoDJZTnCWoMIOHgWEQGGGhVqIeqHlX("/Documents", "com.apple.Keynote"))
                [{'type': 'File', 'size': 302626, 'last_modified': '2024-06-25 11:25:25', 'name': 'test.key'}]
        Remove a EbmaDGzbkxwvgGUjjmTmPregsvGHVmOv or oAssayaMVoPifVKfTmcnlZgvBGcjvHqp from the iOS umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn.
        Args:
            wGzthmUnwutDQEKpwcRnawyfbtuICNvj (str): The AfsQpIVIanvOCsLTBOioRvRLOwokVlLv zNsnvPqWCWqGQQmpzwKZeuWvzZTItFcd to remove.
            utjnEhwqsUEVSPhDkVrxxQubCALRWDZT (str, optional): The bundle ID of the pNPbUpTIEJZfrIxiwfTHVEDDFRiLvinm. Defaults to None.
        Raises:
            hLZuAiOAKrlGyxYlLZYGIXktIVtiWmfw: If the umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn is AfsQpIVIanvOCsLTBOioRvRLOwokVlLv.
            ivGgZuEsmzQUgsHuReKzfRlhnBMmvXkO: If the EbmaDGzbkxwvgGUjjmTmPregsvGHVmOv or oAssayaMVoPifVKfTmcnlZgvBGcjvHqp does not exist.
        Examples:
            >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia = ZnxQcZuDszuGQVgbXkklEsgBfSHHXOdS("iOS:///http+usbmux://udid")
            >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.OlDDkWrFfiTslieCgEphKQxKDnhGoBYP("/Documents/test.key", "com.apple.Keynote")
            >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.OlDDkWrFfiTslieCgEphKQxKDnhGoBYP("/Documents/test_dir", "com.apple.Keynote")
        Create a oAssayaMVoPifVKfTmcnlZgvBGcjvHqp on the iOS umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn.
        Args:
            wGzthmUnwutDQEKpwcRnawyfbtuICNvj (str): The AfsQpIVIanvOCsLTBOioRvRLOwokVlLv zNsnvPqWCWqGQQmpzwKZeuWvzZTItFcd to create.
            utjnEhwqsUEVSPhDkVrxxQubCALRWDZT (str, optional): The bundle ID of the pNPbUpTIEJZfrIxiwfTHVEDDFRiLvinm. Defaults to None.
        Examples:
                >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia = ZnxQcZuDszuGQVgbXkklEsgBfSHHXOdS("iOS:///http+usbmux://udid")
                >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.YLwzdFhCNxrMJFxUalcxQGOKzUqJhrOb("/Documents/test_dir", "com.apple.Keynote")
        Check if the specified zNsnvPqWCWqGQQmpzwKZeuWvzZTItFcd on the iOS umTnMmJfnxpGJPoBEQdPmVEvgvtEqiPn is a oAssayaMVoPifVKfTmcnlZgvBGcjvHqp.
        Args:
            wGzthmUnwutDQEKpwcRnawyfbtuICNvj (str): The AfsQpIVIanvOCsLTBOioRvRLOwokVlLv zNsnvPqWCWqGQQmpzwKZeuWvzZTItFcd to check.
            utjnEhwqsUEVSPhDkVrxxQubCALRWDZT (str, optional): The bundle ID of the pNPbUpTIEJZfrIxiwfTHVEDDFRiLvinm. Defaults to None.
        Returns:
            bool: True if the zNsnvPqWCWqGQQmpzwKZeuWvzZTItFcd is a oAssayaMVoPifVKfTmcnlZgvBGcjvHqp, False otherwise.
        Exapmles:
            >>> lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia = ZnxQcZuDszuGQVgbXkklEsgBfSHHXOdS("iOS:///http+usbmux://udid")
            >>> print(lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.kZPsVFwefeEeGivAXWjdcjFICRddQdDN("/DCIM/"))
            True
            >>> print(lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.kZPsVFwefeEeGivAXWjdcjFICRddQdDN("/Documents/test.key", "com.apple.Keynote"))
            False
