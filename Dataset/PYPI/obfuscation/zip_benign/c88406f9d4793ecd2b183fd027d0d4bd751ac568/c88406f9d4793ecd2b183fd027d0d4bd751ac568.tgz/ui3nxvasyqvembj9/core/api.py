# -*- coding: utf-8 -*-
import os
import time
from airtest.core.cv import Template, loop_find, try_log_screen
from airtest.core.error import TargetNotFoundError
from airtest.core.settings import Settings as ST
from airtest.utils.compat import script_log_dir
from airtest.utils.snippet import parse_device_uri
from airtest.core.helper import (G, delay_after_operation, import_device_cls,
                                 logwrap, set_logdir, using, log)
from airtest.core.assertions import (assert_exists, assert_not_exists, assert_equal, assert_not_equal,  
                                        assert_true, assert_false, assert_is, assert_is_not,
                                        assert_is_none, assert_is_not_none, assert_in, assert_not_in,
                                        assert_is_instance, assert_not_is_instance
                                     )
def init_device(platform="Android", uuid=None, **kwargs):
    cls = import_device_cls(platform)
    dev = cls(uuid, **kwargs)
    G.add_device(dev)
    return dev
@logwrap
def connect_device(uri):
    platform, uuid, params = parse_device_uri(uri)
    dev = init_device(platform, uuid, **params)
    return dev
def device():
    return G.DEVICE
def set_current(idx):
    dev_dict = {dev.uuid: dev for dev in G.DEVICE_LIST}
    if idx in dev_dict:
        current_dev = dev_dict[idx]
    elif isinstance(idx, int) and idx < len(G.DEVICE_LIST):
        current_dev = G.DEVICE_LIST[idx]
    else:
        raise IndexError("device idx not found in: %s or %s" % (
            list(dev_dict.keys()), list(range(len(G.DEVICE_LIST)))))
    G.DEVICE = current_dev
def auto_setup(basedir=None, devices=None, logdir=None, project_root=None, compress=None):
    if basedir:
        if os.path.isfile(basedir):
            basedir = os.path.dirname(basedir)
        if basedir not in G.BASEDIR:
            G.BASEDIR.append(basedir)
    if logdir:
        logdir = script_log_dir(basedir, logdir)
        set_logdir(logdir)
    if devices:
        for dev in devices:
            connect_device(dev)
    if project_root:
        ST.PROJECT_ROOT = project_root
    if compress:
        ST.SNAPSHOT_QUALITY = compress
@logwrap
def shell(cmd):
    return G.DEVICE.shell(cmd)
@logwrap
def start_app(package, activity=None):
    G.DEVICE.start_app(package, activity)
@logwrap
def stop_app(package):
    G.DEVICE.stop_app(package)
@logwrap
def clear_app(package):
    G.DEVICE.clear_app(package)
@logwrap
def install(filepath, **kwargs):
    return G.DEVICE.install_app(filepath, **kwargs)
@logwrap
def uninstall(package):
    return G.DEVICE.uninstall_app(package)
@logwrap
def snapshot(filename=None, msg="", quality=None, max_size=None):
    if not quality:
        quality = ST.SNAPSHOT_QUALITY
    if not max_size and ST.IMAGE_MAXSIZE:
        max_size = ST.IMAGE_MAXSIZE
    if filename:
        if not os.path.isabs(filename):
            logdir = ST.LOG_DIR or "."
            filename = os.path.join(logdir, filename)
        screen = G.DEVICE.snapshot(filename, quality=quality, max_size=max_size)
        return try_log_screen(screen, quality=quality, max_size=max_size)
    else:
        return try_log_screen(quality=quality, max_size=max_size)
@logwrap
def wake():
    G.DEVICE.wake()
@logwrap
def home():
    G.DEVICE.home()
@logwrap
def touch(v, times=1, **kwargs):
    if isinstance(v, Template):
        pos = loop_find(v, timeout=ST.FIND_TIMEOUT)
    else:
        try_log_screen()
        pos = v
    for _ in range(times):
        pos = G.DEVICE.touch(pos, **kwargs) or pos
        time.sleep(0.05)
    delay_after_operation()
    return pos
click = touch  
@logwrap
def double_click(v):
    if isinstance(v, Template):
        pos = loop_find(v, timeout=ST.FIND_TIMEOUT)
    else:
        try_log_screen()
        pos = v
    pos = G.DEVICE.double_click(pos) or pos
    delay_after_operation()
    return pos
@logwrap
def swipe(v1, v2=None, vector=None, **kwargs):
    if isinstance(v1, Template):
        try:
            pos1 = loop_find(v1, timeout=ST.FIND_TIMEOUT)
        except TargetNotFoundError:
            if v2 and isinstance(v2, Template):
                v2.filepath
            raise
    else:
        try_log_screen()
        pos1 = v1
    if v2:
        if isinstance(v2, Template):
            pos2 = loop_find(v2, timeout=ST.FIND_TIMEOUT_TMP)
        else:
            pos2 = v2
    elif vector:
        if vector[0] <= 1 and vector[1] <= 1:
            w, h = G.DEVICE.get_current_resolution()
            vector = (int(vector[0] * w), int(vector[1] * h))
        pos2 = (pos1[0] + vector[0], pos1[1] + vector[1])
    else:
        raise Exception("no enough params for swipe")
    pos1, pos2 = G.DEVICE.swipe(pos1, pos2, **kwargs) or (pos1, pos2)
    delay_after_operation()
    return pos1, pos2
@logwrap
def pinch(in_or_out='in', center=None, percent=0.5):
    try_log_screen()
    G.DEVICE.pinch(in_or_out=in_or_out, center=center, percent=percent)
    delay_after_operation()
@logwrap
def keyevent(keyname, **kwargs):
    G.DEVICE.keyevent(keyname, **kwargs)
    delay_after_operation()
@logwrap
def text(text, enter=True, **kwargs):
    G.DEVICE.text(text, enter=enter, **kwargs)
    delay_after_operation()
@logwrap
def sleep(secs=1.0):
    time.sleep(secs)
@logwrap
def wait(v, timeout=None, interval=0.5, intervalfunc=None):
    timeout = timeout or ST.FIND_TIMEOUT
    pos = loop_find(v, timeout=timeout, interval=interval, intervalfunc=intervalfunc)
    return pos
@logwrap
def exists(v):
    try:
        pos = loop_find(v, timeout=ST.FIND_TIMEOUT_TMP)
    except TargetNotFoundError:
        return False
    else:
        return pos
@logwrap
def find_all(v):
    screen = G.DEVICE.snapshot(quality=ST.SNAPSHOT_QUALITY)
    return v.match_all_in(screen)
@logwrap
def get_clipboard(*args, **kwargs):
    return G.DEVICE.get_clipboard(*args, **kwargs)
@logwrap
def set_clipboard(content, *args, **kwargs):
    G.DEVICE.set_clipboard(content, *args, **kwargs)
@logwrap
def paste(*args, **kwargs):
    G.DEVICE.paste(*args, **kwargs)
@logwrap
def push(local, remote, *args, **kwargs):
    return G.DEVICE.push(local, remote, *args, **kwargs)
@logwrap
def pull(remote, local, *args, **kwargs):
    return G.DEVICE.pull(remote, local, *args, **kwargs)
