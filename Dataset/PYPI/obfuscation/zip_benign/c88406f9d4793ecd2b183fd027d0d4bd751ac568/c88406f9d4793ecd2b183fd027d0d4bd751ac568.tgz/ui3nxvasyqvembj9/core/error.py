# -*- coding: utf-8 -*-
class BaseError(Exception):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)
class AirtestError(BaseError):
    pass
class InvalidMatchingMethodError(BaseError):
    pass
class TargetNotFoundError(AirtestError):
    pass
class ScriptParamError(AirtestError):
    pass
class AdbError(Exception):
    def __init__(self, stdout, stderr):
        self.stdout = stdout
        self.stderr = stderr
    def __str__(self):
        return "stdout[%s] stderr[%s]" % (self.stdout, self.stderr)
class AdbShellError(AdbError):
    pass
class DeviceConnectionError(BaseError):
    DEVICE_CONNECTION_ERROR = r"error:\s*((device \'\S+\' not found)|(cannot connect to daemon at [\w\:\s\.]+ Connection timed out))"
    pass
class NoDeviceError(BaseError):
    pass
class ICmdError(Exception):
    def __init__(self, stdout, stderr):
        self.stdout = stdout
        self.stderr = stderr
    def __str__(self):
        return "stdout[%s] stderr[%s]" %(self.stdout, self.stderr)
class ScreenError(BaseError):
    pass
class MinicapError(ScreenError):
    pass
class MinitouchError(BaseError):
    pass
class PerformanceError(BaseError):
    pass
class LocalDeviceError(BaseError):
    def __init__(self, value="Can only use this method on a local device."):
        super().__init__(value)
