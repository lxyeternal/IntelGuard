# -*- coding: utf-8 -*-
import time
import socket
import subprocess
import numpy
import mss
import psutil
from functools import wraps
import win32api
import win32clipboard
import pywintypes  
import os
from pywinauto.application import Application
from pywinauto import mouse, keyboard
from pywinauto.win32structures import RECT
from airtest.core.win.ctypesinput import key_press, key_release
from airtest import aircv
from airtest.aircv.screen_recorder import ScreenRecorder, resize_by_max, get_max_size
from airtest.core.device import Device
from airtest.core.settings import Settings as ST
from airtest.utils.snippet import get_absolute_coordinate
from airtest.utils.logger import get_logger
from airtest.core.win.screen import screenshot
LOGGING = get_logger(__name__)
def require_app(func):
    @wraps(func)
    def wrapper(inst, *args, **kwargs):
        if not inst.app:
            raise RuntimeError("Connect to an application first to use %s" % func.__name__)
        return func(inst, *args, **kwargs)
    return wrapper
class Windows(Device):
    def __init__(self, handle=None, dpifactor=1, **kwargs):
        super(Windows, self).__init__()
        self.app = None
        self.handle = int(handle) if handle else None
        self._dpifactor = float(dpifactor)
        self._app = Application()
        self._top_window = None
        self._focus_rect = (0, 0, 0, 0)
        self.mouse = mouse
        self.keyboard = keyboard
        self._init_connect(handle, kwargs)
        self.screen = mss.mss()
        self.monitor = self.screen.monitors[0]  
        self.main_monitor = self.screen.monitors[1]  
    @property
    def uuid(self):
        return self.handle
    def _init_connect(self, handle, kwargs):
        if handle:
            self.connect(handle=handle, **kwargs)
        elif kwargs:
            self.connect(**kwargs)
    def connect(self, handle=None, **kwargs):
        if handle:
            handle = int(handle)
            self.app = self._app.connect(handle=handle)
            self._top_window = self.app.window(handle=handle).wrapper_object()
        else:
            for k in ["process", "timeout"]:
                if k in kwargs:
                    kwargs[k] = int(kwargs[k])
            self.app = self._app.connect(**kwargs)
            self._top_window = self.app.top_window().wrapper_object()
        if kwargs.get("foreground", True) in (True, "True", "true"):
            try:
                self.set_foreground()
            except pywintypes.error as e:
                pass
    def shell(self, cmd):
        return subprocess.check_output(cmd, shell=True)
    def snapshot_old(self, filename=None, quality=10, max_size=None):
        if self.handle:
            screen = screenshot(filename, self.handle)
        else:
            screen = screenshot(filename)
            if self.app:
                rect = self.get_rect()
                rect = self._fix_image_rect(rect)
                screen = aircv.crop_image(screen, [rect.left, rect.top, rect.right, rect.bottom])
        if not screen.any():
            if self.app:
                rect = self.get_rect()
                rect = self._fix_image_rect(rect)
                screen = aircv.crop_image(screenshot(filename), [rect.left, rect.top, rect.right, rect.bottom])
        if self._focus_rect != (0, 0, 0, 0):
            height, width = screen.shape[:2]
            rect = (self._focus_rect[0], self._focus_rect[1], width + self._focus_rect[2], height + self._focus_rect[3])
            screen = aircv.crop_image(screen, rect)
        if filename:
            aircv.imwrite(filename, screen, quality, max_size=max_size)
        return screen
    def snapshot(self, filename=None, quality=10, max_size=None):
        if self.app:
            rect = self.get_rect()
            rect = self._fix_image_rect(rect)
            monitor = {"top": rect.top, "left": rect.left, "width": rect.right - rect.left - abs(self.monitor["left"]),
                       "height": rect.bottom - rect.top, "monitor": 1}
        else:
            monitor = self.screen.monitors[0]
        try:
            with mss.mss() as sct:
                sct_img = sct.grab(monitor)
                screen = numpy.array(sct_img, dtype=numpy.uint8)[..., :3]
                if filename:
                    aircv.imwrite(filename, screen, quality, max_size=max_size)
                return screen
        except:
            return self.snapshot_old(filename, quality, max_size)
    def _fix_image_rect(self, rect):
        rect.right = rect.right - self.monitor["left"]
        rect.top = rect.top - self.monitor["top"]
        rect.bottom = rect.bottom - self.monitor["top"]
        return rect
    def keyevent(self, keyname, **kwargs):
        self.keyboard.SendKeys(keyname)
    def text(self, text, **kwargs):
        self.keyevent(text)
    def _fix_op_pos(self, pos):
        if not self.handle:
            pos = list(pos)
            pos[0] = pos[0] + self.monitor["left"]
            pos[1] = pos[1] + self.monitor["top"]
        return pos
    def key_press(self, key):
        key_press(key)
    def key_release(self, key):
        key_release(key)
    def touch(self, pos, **kwargs):
        duration = kwargs.get("duration", 0.01)
        right_click = kwargs.get("right_click", False)
        button = "right" if right_click else "left"
        steps = kwargs.get("steps", 1)
        offset = kwargs.get("offset", 0)
        start = self._action_pos(win32api.GetCursorPos())
        ori_end = get_absolute_coordinate(pos, self)
        end = self._action_pos(ori_end)
        start_x, start_y = self._fix_op_pos(start)
        end_x, end_y = self._fix_op_pos(end)
        interval = float(duration) / steps
        time.sleep(interval)
        for i in range(1, steps):
            x = int(start_x + (end_x - start_x) * i / steps)
            y = int(start_y + (end_y - start_y) * i / steps)
            self.mouse.move(coords=(x, y))
            time.sleep(interval)
        self.mouse.move(coords=(end_x, end_y))
        for i in range(1, offset + 1):
            self.mouse.move(coords=(end_x + i, end_y + i))
            time.sleep(0.01)
        for i in range(offset):
            self.mouse.move(coords=(end_x + offset - i, end_y + offset - i))
            time.sleep(0.01)
        self.mouse.press(button=button, coords=(end_x, end_y))
        time.sleep(duration)
        self.mouse.release(button=button, coords=(end_x, end_y))
        return ori_end
    def double_click(self, pos):
        ori_pos = get_absolute_coordinate(pos, self)
        coords = self._fix_op_pos(self._action_pos(ori_pos))
        self.mouse.double_click(coords=coords)
        return ori_pos
    def swipe(self, p1, p2, duration=0.8, steps=5, button="left"):
        ori_from = get_absolute_coordinate(p1, self)
        ori_to = get_absolute_coordinate(p2, self)
        from_x, from_y = self._fix_op_pos(self._action_pos(ori_from))
        to_x, to_y = self._fix_op_pos(self._action_pos(ori_to))
        interval = float(duration) / (steps + 1)
        self.mouse.press(coords=(from_x, from_y), button=button)
        time.sleep(interval)
        for i in range(1, steps):
            self.mouse.move(coords=(
                int(from_x + (to_x - from_x) * i / steps),
                int(from_y + (to_y - from_y) * i / steps),
            ))
            time.sleep(interval)
        for i in range(10):
            self.mouse.move(coords=(to_x, to_y))
        time.sleep(interval)
        self.mouse.release(coords=(to_x, to_y), button=button)
        return ori_from, ori_to
    def mouse_move(self, pos):
        if not isinstance(pos, tuple) or len(pos) != 2:  
            raise ValueError('invalid literal for mouse_move: {}'.format(pos))
        try:
            self.mouse.move(coords=self._action_pos(pos))
        except ValueError:  
            raise ValueError('invalid literal for mouse_move: {}'.format(pos))
    def mouse_down(self, button='left'):
        buttons = {'left', 'middle', 'right'}
        if not isinstance(button, str) or button not in buttons:
            raise ValueError('invalid literal for mouse_down(): {}'.format(button))
        else:
            coords = self._action_pos(win32api.GetCursorPos())
            self.mouse.press(button=button, coords=coords)
    def mouse_up(self, button='left'):
        buttons = {'left', 'middle', 'right'}
        if not isinstance(button, str) or button not in buttons:
            raise ValueError('invalid literal for mouse_up(): {}'.format(button))
        else:
            coords = self._action_pos(win32api.GetCursorPos())
            self.mouse.release(button=button, coords=coords)
    def start_app(self, path, *args, **kwargs):
        self.app = self._app.start(path, **kwargs)
    def stop_app(self, pid):
        self._app.connect(process=pid).kill()
    @require_app
    def set_foreground(self):
        self._top_window.set_focus()
    set_focus = set_foreground
    def get_rect(self):
        if self.app and self._top_window:
            return self._top_window.rectangle()
        else:
            return RECT(right=win32api.GetSystemMetrics(0), bottom=win32api.GetSystemMetrics(1))
    @require_app
    def get_title(self):
        return self._top_window.texts()
    @require_app
    def get_pos(self):
        rect = self.get_rect()
        return (rect.left, rect.top)
    @require_app
    def move(self, pos):
        self._top_window.MoveWindow(x=pos[0], y=pos[1])
    @require_app
    def kill(self):
        self.app.kill()
    def set_clipboard(self, text):
        try:
            win32clipboard.OpenClipboard()
        except pywintypes.error as e:
            time.sleep(0.1)
            win32clipboard.OpenClipboard()
        try:
            win32clipboard.EmptyClipboard()
            win32clipboard.SetClipboardData(win32clipboard.CF_UNICODETEXT, text)
        finally:
            win32clipboard.CloseClipboard()
    def get_clipboard(self):
        try:
            win32clipboard.OpenClipboard()
            return win32clipboard.GetClipboardData()
        finally:
            win32clipboard.CloseClipboard()
    def paste(self):
        self.keyevent("^v")
    def _action_pos(self, pos):
        if self.app:
            pos = self._windowpos_to_screenpos(pos)
        pos = (int(pos[0]), int(pos[1]))
        return pos
    @property
    def focus_rect(self):
        return self._focus_rect
    @focus_rect.setter
    def focus_rect(self, value):
        assert len(value) == 4, "focus rect must be in [left, top, right, bottom]"
        self._focus_rect = value
    def get_current_resolution(self):
        rect = self.get_rect()
        w = (rect.right + self._focus_rect[2]) - (rect.left + self._focus_rect[0])
        h = (rect.bottom + self._focus_rect[3]) - (rect.top + self._focus_rect[1])
        return w, h
    def _windowpos_to_screenpos(self, pos):
        rect = self.get_rect()
        pos = (int((pos[0] + rect.left + self._focus_rect[0]) * self._dpifactor),
               int((pos[1] + rect.top + self._focus_rect[1]) * self._dpifactor))
        return pos
    def get_ip_address(self):
        ifaces = psutil.net_if_addrs()
        virtual_iface_keywords = ['vEthernet', 'VirtualBox', 'VMware', 'Hyper-V', 'Wireless', 'VPN', 'Loopback']
        for interface_name, iface_addresses in ifaces.items():
            if any(keyword in interface_name for keyword in virtual_iface_keywords):
                continue
            for iface_address in iface_addresses:
                if iface_address.family == socket.AF_INET:
                    if not iface_address.address.startswith('169.254'):
                        return iface_address.address
        return None
    def start_recording(self, max_time=1800, output=None, fps=10,
                        snapshot_sleep=0.001, orientation=0, max_size=None, *args, **kwargs):
        if fps > 10 or fps < 1:
            LOGGING.warning("fps should be between 1 and 10, becuase of the recording effiency")
            if fps > 10:
                fps = 10
            if fps < 1:
                fps = 1
        if hasattr(self, 'recorder'):
            if self.recorder.is_running():
                LOGGING.warning("recording is already running, please don't call again")
                return None
        logdir = "./"
        if not ST.LOG_DIR is None:
            logdir = ST.LOG_DIR
        if output is None:
            save_path = os.path.join(logdir, "screen_%s.mp4" % (time.strftime("%Y%m%d%H%M%S", time.localtime())))
        else:
            if os.path.isabs(output):
                save_path = output
            else:
                save_path = os.path.join(logdir, output)
        max_size = get_max_size(max_size)
        def get_frame():
            try:
                frame = self.snapshot()
            except numpy.core._exceptions._ArrayMemoryError:
                self.stop_recording()
                raise Exception("memory error!!!!")
            if max_size is not None:
                frame = resize_by_max(frame, max_size)
            return frame
        self.recorder = ScreenRecorder(
            save_path, get_frame, fps=fps,
            snapshot_sleep=snapshot_sleep, orientation=orientation)
        self.recorder.stop_time = max_time
        self.recorder.start()
        LOGGING.info("start recording screen to {}, don't close or resize the app window".format(save_path))
        return save_path
    def stop_recording(self):
        LOGGING.info("stopping recording")
        self.recorder.stop()
        return None
