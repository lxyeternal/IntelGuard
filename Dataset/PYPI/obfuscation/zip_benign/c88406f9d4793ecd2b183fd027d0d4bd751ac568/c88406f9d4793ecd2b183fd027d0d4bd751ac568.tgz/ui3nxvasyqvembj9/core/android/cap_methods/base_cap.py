# -*- coding: utf-8 -*-
import traceback
from airtest import aircv
class BaseCap(object):
    def __init__(self, adb, *args, **kwargs):
        self.adb = adb
    def get_frame_from_stream(self):
        raise NotImplementedError
    def get_frame(self):
        return self.get_frame_from_stream()
    def teardown_stream(self):
        pass
    def snapshot(self, ensure_orientation=True, *args, **kwargs):
        screen = self.get_frame_from_stream()
        try:
            screen = aircv.utils.string_2_img(screen)
        except Exception:
            traceback.print_exc()
            return None
        return screen
