#! /usr/bin/env python
# -*- coding: utf-8 -*-
import time
import os
import shutil
import warnings
from copy import copy
from airtest import aircv
from airtest.core.device import Device
from airtest.core.android.ime import YosemiteIme
from airtest.core.android.yosemite_ext import YosemiteExt
from airtest.core.android.constant import CAP_METHOD, TOUCH_METHOD, IME_METHOD, ORI_METHOD, \
    SDK_VERISON_ANDROID10
from airtest.core.android.adb import ADB
from airtest.core.android.rotation import RotationWatcher, XYTransformer
from airtest.core.android.recorder import Recorder
from airtest.core.android.touch_methods.touch_proxy import TouchProxy
from airtest.core.error import AdbError, AdbShellError
from airtest.core.android.cap_methods.screen_proxy import ScreenProxy
from airtest.core.android.cap_methods.minicap import Minicap  
from airtest.core.android.cap_methods.javacap import Javacap  
from airtest.core.android.touch_methods.minitouch import Minitouch  
from airtest.core.android.touch_methods.maxtouch import Maxtouch  
from airtest.core.settings import Settings as ST
from airtest.aircv.screen_recorder import ScreenRecorder, resize_by_max, get_max_size
from airtest.utils.snippet import get_absolute_coordinate
from airtest.utils.logger import get_logger
LOGGING = get_logger(__name__)
class Android(Device):
    def __init__(self, serialno=None, host=None,
                 cap_method=CAP_METHOD.MINICAP,
                 touch_method=TOUCH_METHOD.MINITOUCH,
                 ime_method=IME_METHOD.YOSEMITEIME,
                 ori_method=ORI_METHOD.MINICAP,
                 display_id=None,
                 input_event=None,
                 adb_path=None,
                 name=None):
        super(Android, self).__init__()
        self.serialno = serialno or self.get_default_device(adb_path=adb_path)
        self._uuid = name or self.serialno
        self._cap_method = cap_method.upper()
        self._touch_method = touch_method.upper()
        self.ime_method = ime_method.upper()
        self.ori_method = ori_method.upper()
        self.display_id = display_id
        self.input_event = input_event
        self.adb = ADB(self.serialno, adb_path=adb_path, server_addr=host, display_id=self.display_id, input_event=self.input_event)
        self.adb.wait_for_device()
        self.sdk_version = self.adb.sdk_version
        if self.sdk_version >= SDK_VERISON_ANDROID10 and self._touch_method == TOUCH_METHOD.MINITOUCH:
            self._touch_method = TOUCH_METHOD.MAXTOUCH
        self._display_info = {}
        self._current_orientation = None
        self.rotation_watcher = RotationWatcher(self.adb, self.ori_method)
        self.yosemite_ime = YosemiteIme(self.adb)
        self.yosemite_recorder = Recorder(self.adb)
        self.yosemite_ext = YosemiteExt(self.adb)
        self._register_rotation_watcher()
        self._touch_proxy = None
        self._screen_proxy = None
        self.recorder = None
        self.recorder_save_path = None
    @property
    def touch_proxy(self):
        if self._touch_proxy:
            return self._touch_proxy
        self._touch_proxy = TouchProxy.auto_setup(self.adb,
                                                  default_method=self._touch_method,
                                                  ori_transformer=self._touch_point_by_orientation,
                                                  size_info=self.display_info,
                                                  input_event=self.input_event)
        return self._touch_proxy
    @touch_proxy.setter
    def touch_proxy(self, touch_method):
        if self._screen_proxy:
            self._screen_proxy.teardown()
        self._touch_proxy = TouchProxy.auto_setup(self.adb,
                                                  default_method=touch_method,
                                                  ori_transformer=self._touch_point_by_orientation,
                                                  size_info=self.display_info,
                                                  input_event=self.input_event)
    @property
    def touch_method(self):
        return self.touch_proxy.method_name
    @touch_method.setter
    def touch_method(self, name):
        warnings.warn("No need to manually specify touch_method, airtest will automatically specify a suitable touch method, when airtest>=1.1.2")
        self.touch_proxy = name
    @property
    def cap_method(self):
        return self.screen_proxy.method_name
    @cap_method.setter
    def cap_method(self, name):
        warnings.warn("No need to manually specify cap_method, airtest will automatically specify a suitable screenshot method, when airtest>=1.1.2")
        self.screen_proxy = name
    @property
    def screen_proxy(self):
        if self._screen_proxy:
            return self._screen_proxy
        self._screen_proxy = ScreenProxy.auto_setup(self.adb, default_method=self._cap_method,
                                                    rotation_watcher=self.rotation_watcher,
                                                    display_id=self.display_id,
                                                    ori_function=lambda: self.display_info)
        return self._screen_proxy
    @screen_proxy.setter
    def screen_proxy(self, cap_method):
        if self._screen_proxy:
            self._screen_proxy.teardown_stream()
        self._screen_proxy = ScreenProxy.auto_setup(self.adb, default_method=cap_method)
    def get_deprecated_var(self, old_name, new_name):
        warnings.simplefilter("always")
        warnings.warn("{old_name} is deprecated, use {new_name} instead".format(old_name=old_name, new_name=new_name),
                      DeprecationWarning)
        return getattr(self, new_name)
    def get_default_device(self, adb_path=None):
        if not ADB(adb_path=adb_path).devices(state="device"):
            raise IndexError("ADB devices not found")
        return ADB(adb_path=adb_path).devices(state="device")[0][0]
    @property
    def uuid(self):
        ult = [self._uuid]
        if self.display_id:
            ult.append(self.display_id)
        if self.input_event:
            ult.append(self.input_event)
        return "_".join(ult)
    def list_app(self, third_only=False):
        return self.adb.list_app(third_only)
    def path_app(self, package):
        assert package, "package name should not be empty"
        return self.adb.path_app(package)
    def check_app(self, package):
        assert package, "package name should not be empty"
        return self.adb.check_app(package)
    def start_app(self, package, activity=None):
        assert package, "package name should not be empty"
        return self.adb.start_app(package, activity)
    def start_app_timing(self, package, activity):
        assert package, "package name should not be empty"
        return self.adb.start_app_timing(package, activity)
    def stop_app(self, package):
        assert package, "package name should not be empty"
        return self.adb.stop_app(package)
    def clear_app(self, package):
        assert package, "package name should not be empty"
        return self.adb.clear_app(package)
    def install_app(self, filepath, replace=False, install_options=None):
        return self.adb.install_app(filepath, replace=replace, install_options=install_options)
    def install_multiple_app(self, filepath, replace=False, install_options=None):
        return self.adb.install_multiple_app(filepath, replace=replace, install_options=install_options)
    def uninstall_app(self, package):
        assert package, "package name should not be empty"
        return self.adb.uninstall_app(package)
    def snapshot(self, filename=None, ensure_orientation=True, quality=10, max_size=None):
        screen = self.screen_proxy.snapshot(ensure_orientation=ensure_orientation)
        if filename:
            aircv.imwrite(filename, screen, quality, max_size=max_size)
        return screen
    def shell(self, *args, **kwargs):
        return self.adb.shell(*args, **kwargs)
    def keyevent(self, keyname, **kwargs):
        self.adb.keyevent(keyname)
    def wake(self):
        self.adb.keyevent("KEYCODE_WAKEUP")
        if self.adb.is_locked():
            self.adb.keyevent("KEYCODE_MENU")
            time.sleep(0.5)
        if self.adb.is_locked():
            self.home()
            self.yosemite_recorder.install_or_upgrade()  
            self.adb.shell(['am', 'start', '-a', 'com.netease.nie.yosemite.ACTION_IDENTIFY'])
            time.sleep(0.5)
            self.home()
    def home(self):
        self.keyevent("HOME")
    def text(self, text, enter=True, **kwargs):
        search = False if "search" not in kwargs else kwargs["search"]
        if self.ime_method == IME_METHOD.YOSEMITEIME:
            try:
                self.yosemite_ime.text(text)
            except AdbError:
                self.adb.text(text)
        else:
            self.adb.text(text)
        if search:
            try:
                self.yosemite_ime.code("3")
            except AdbError:
                self.adb.shell(["input", "keyevent", "84"])
        if enter:
            self.adb.shell(["input", "keyevent", "ENTER"])
    def touch(self, pos, duration=0.01):
        pos = get_absolute_coordinate(pos, self)
        self.touch_proxy.touch(pos, duration)
        return pos
    def double_click(self, pos):
        pos = get_absolute_coordinate(pos, self)
        self.touch(pos)
        time.sleep(0.05)
        self.touch(pos)
        return pos
    def swipe(self, p1, p2, duration=0.5, steps=5, fingers=1):
        p1 = get_absolute_coordinate(p1, self)
        p2 = get_absolute_coordinate(p2, self)
        self.touch_proxy.swipe(p1, p2, duration=duration, steps=steps, fingers=fingers)
        return p1, p2
    def pinch(self, center=None, percent=0.5, duration=0.5, steps=5, in_or_out='in'):
        self.touch_proxy.pinch(center=center, percent=percent, duration=duration, steps=steps, in_or_out=in_or_out)
    def swipe_along(self, coordinates_list, duration=0.8, steps=5):
        coordinates_list = [get_absolute_coordinate(pos, self) for pos in coordinates_list]
        self.touch_proxy.swipe_along(coordinates_list, duration=duration, steps=steps)
    def two_finger_swipe(self, tuple_from_xy, tuple_to_xy, duration=0.8, steps=5, offset=(0, 50)):
        tuple_from_xy = get_absolute_coordinate(tuple_from_xy, self)
        tuple_to_xy = get_absolute_coordinate(tuple_to_xy, self)
        self.touch_proxy.two_finger_swipe(tuple_from_xy, tuple_to_xy, duration=duration, steps=steps, offset=offset)
    def logcat(self, *args, **kwargs):
        return self.adb.logcat(*args, **kwargs)
    def getprop(self, key, strip=True):
        return self.adb.getprop(key, strip)
    def get_ip_address(self):
        return self.adb.get_ip_address()
    def get_top_activity(self):
        return self.adb.get_top_activity()
    def get_top_activity_name(self):
        tanp = self.get_top_activity()
        if tanp:
            return tanp[0] + '/' + tanp[1]
        else:
            return None
    def is_keyboard_shown(self):
        return self.adb.is_keyboard_shown()
    def is_screenon(self):
        return self.adb.is_screenon()
    def is_locked(self):
        return self.adb.is_locked()
    def unlock(self):
        return self.adb.unlock()
    @property
    def display_info(self):
        if not self._display_info:
            self._display_info = self.get_display_info()
        display_info = copy(self._display_info)
        if self._current_orientation is not None:
            display_info.update({
                "rotation": self._current_orientation * 90,
                "orientation": self._current_orientation,
            })
        return display_info
    def get_display_info(self):
        self.rotation_watcher.get_ready()
        return self.adb.get_display_info()
    def get_current_resolution(self):
        w, h = self.display_info["width"], self.display_info["height"]
        if self.display_info["orientation"] in [1, 3]:
            w, h = h, w
        return w, h
    def get_render_resolution(self, refresh=False, package=None):
        if refresh or 'offset_x' not in self._display_info:
            self.adjust_all_screen(package)
        x, y, w, h = self._display_info.get('offset_x', 0), \
            self._display_info.get('offset_y', 0), \
            self._display_info.get('offset_width', 0), \
            self._display_info.get('offset_height', 0)
        if self.display_info["orientation"] in [1, 3]:
            x, y, w, h = y, x, h, w
        return x, y, w, h
    def start_recording(self, max_time=1800, output=None, fps=10, mode="yosemite",
                        snapshot_sleep=0.001, orientation=0, bit_rate_level=None, 
                        bit_rate=None, max_size=None, *args, **kwargs):
        logdir = "./"
        if ST.LOG_DIR is not None:
            logdir = ST.LOG_DIR
        if output is None:
            save_path = os.path.join(logdir, "screen_%s.mp4" % (time.strftime("%Y%m%d%H%M%S", time.localtime())))
        else:
            save_path = output if os.path.isabs(output) else os.path.join(logdir, output)
        self.recorder_save_path = save_path
        if mode == "yosemite":
            if self.yosemite_recorder.recording_proc != None:
                LOGGING.warning(
                    "recording is already running, please don't call again")
                return None
            if not bit_rate:
                if not bit_rate_level:
                    bit_rate_level = 1
                if bit_rate_level > 5:
                    bit_rate_level = 5
                bit_rate = self.display_info['width'] * \
                        self.display_info['height'] * bit_rate_level
            if orientation == 1:
                bool_is_vertical = "true"
            elif orientation == 2:
                bool_is_vertical = "false"
            else:
                bool_is_vertical = "off"
            self.yosemite_recorder.start_recording(
                max_time=max_time, bit_rate=bit_rate, bool_is_vertical=bool_is_vertical)
            return save_path
        if fps > 10 or fps < 1:
            LOGGING.warning("fps should be between 1 and 10, becuase of the recording effiency")
            if fps > 10:
                fps = 10
            if fps < 1:
                fps = 1
        if self.recorder and self.recorder.is_running():
            LOGGING.warning("recording is already running, please don't call again")
            return None
        max_size = get_max_size(max_size)
        def get_frame():
            data = self.screen_proxy.get_frame_from_stream()
            frame = aircv.utils.string_2_img(data)
            if max_size is not None:
                frame = resize_by_max(frame, max_size)
            return frame
        self.recorder = ScreenRecorder(
            save_path, get_frame, fps=fps,
            snapshot_sleep=snapshot_sleep, orientation=orientation)
        self.recorder.stop_time = max_time
        self.recorder.start()
        LOGGING.info("start recording screen to {}".format(save_path))
        return save_path
    def stop_recording(self, output=None, is_interrupted=None):
        if self.yosemite_recorder.recording_proc is not None or self.recorder is None:
            if output is None:
                output = self.recorder_save_path
            return self.yosemite_recorder.stop_recording(output=output, is_interrupted=is_interrupted)
        LOGGING.info("stopping recording")
        self.recorder.stop()
        self.recorder = None
        if output and not is_interrupted:
            shutil.move(self.recorder_save_path, output)
            LOGGING.info("save video to {}".format(output))
        return True
    def get_clipboard(self):
        return self.yosemite_ext.get_clipboard()
    def set_clipboard(self, text):
        self.yosemite_ext.set_clipboard(text)
    def push(self, local, remote):
        return self.adb.push(local, remote)
    def pull(self, remote, local=""):
        return self.adb.pull(remote, local=local)
    def _register_rotation_watcher(self):
        self.rotation_watcher.reg_callback(lambda x: setattr(self, "_current_orientation", x))
    def _touch_point_by_orientation(self, tuple_xy):
        x, y = tuple_xy
        x, y = XYTransformer.up_2_ori(
            (x, y),
            (self.display_info["width"], self.display_info["height"]),
            self.display_info["orientation"]
        )
        return x, y
    def adjust_all_screen(self, package=None):
        info = self.display_info
        ret = self.adb.get_display_of_all_screen(info, package)
        if ret:
            info.update(ret)
            self._display_info = info
    def disconnect(self):
        self.screen_proxy.teardown_stream()
        self.touch_proxy.teardown()
        self.rotation_watcher.teardown()
Android.minicap=property(lambda self: self.get_deprecated_var("minicap", "screen_proxy"))
Android.javacap=property(lambda self: self.get_deprecated_var("javacap", "screen_proxy"))
Android.minitouch=property(lambda self: self.get_deprecated_var("minitouch", "touch_proxy"))
Android.maxtouch=property(lambda self: self.get_deprecated_var("maxtouch", "touch_proxy"))