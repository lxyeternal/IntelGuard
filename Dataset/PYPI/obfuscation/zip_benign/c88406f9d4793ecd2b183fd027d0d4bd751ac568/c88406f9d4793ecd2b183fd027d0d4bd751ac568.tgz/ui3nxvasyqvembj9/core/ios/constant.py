# -*- coding: utf-8 -*-
import os
import re
import wda
from airtest.utils.compat import decode_path
THISPATH = decode_path(os.path.dirname(os.path.realpath(__file__)))
DEFAULT_IPROXY_PATH = {
    "Windows": os.path.join(THISPATH, "iproxy", "windows", "iproxy.exe"),
    "Darwin": os.path.join(THISPATH, "iproxy", "mac", "iproxy"),
}
DEBUG = True
IP_PATTERN = re.compile(r'(\d+\.){3}\d+')
LANDSCAPE_PAD_RESOLUTION = [(1242, 2208)]
class CAP_METHOD(object):
    MINICAP = "MINICAP"
    WDACAP = "WDACAP"
    MJPEG = "MJPEG"
DEFAULT_MJPEG_PORT = 9100
class TOUCH_METHOD(object):
    WDATOUCH = "WDATOUCH"
class IME_METHOD(object):
    WDAIME = "WDAIME"
ROTATION_MODE = {
    0: wda.PORTRAIT,
    270: wda.LANDSCAPE,
    90: wda.LANDSCAPE_RIGHT,
    180: wda.PORTRAIT_UPSIDEDOWN,
}
KEY_EVENTS = {
    "home": "home",
    "volumeup": "volumeUp",
    "volumedown": "volumeDown"
}
