# -*- coding: utf-8 -*-
from collections import OrderedDict
from airtest.core.error import AdbError, ScreenError
from airtest.core.android.cap_methods.base_cap import BaseCap
from airtest.utils.logger import get_logger
LOGGING = get_logger(__name__)
class ScreenProxy(object):
    SCREEN_METHODS = OrderedDict()
    def __init__(self, screen_method):
        self.screen_method = screen_method
    def __getattr__(self, name):
        if hasattr(self.screen_method, name):
            return getattr(self.screen_method, name, None)
        elif name == "method_name":
            return self.screen_method.__class__.__name__.upper()
        else:
            raise NotImplementedError("%s does not support \'%s\' method" %
                                      (getattr(self.screen_method, "METHOD_NAME", ""), name))
    def __setattr__(self, name, value):
        if name == "screen_method":
            object.__setattr__(self, name, value)
        else:
            object.__setattr__(self.screen_method, name, value)
    @classmethod
    def register_method(cls, name, method_class):
        cls.SCREEN_METHODS[name] = method_class
    @classmethod
    def check_frame(cls, cap_method):
        try:
            cap_method.get_frame()
        except (AdbError, ScreenError) as e:
            if isinstance(e, AdbError):
                LOGGING.error(repr(e.stdout))
                LOGGING.error(repr(e.stderr))
            else:
                LOGGING.error(e)
            LOGGING.error("%s setup up failed!" % cap_method.__class__.__name__)
            return False
        else:
            return True
    @classmethod
    def auto_setup(cls, adb, default_method=None, *args, **kwargs):
        screen = None
        if default_method:
            if isinstance(default_method, str) and default_method.upper() in cls.SCREEN_METHODS:
                screen = cls.SCREEN_METHODS[default_method.upper()](adb, *args, **kwargs)
            elif isinstance(default_method, BaseCap):
                screen = default_method
            if screen and cls.check_frame(screen):
                return ScreenProxy(screen)
        for name, screen_class in reversed(cls.SCREEN_METHODS.items()):
            if name == default_method:
                continue
            screen = screen_class(adb, *args, **kwargs)
            if cls.check_frame(screen):
                return ScreenProxy(screen)
        raise ScreenError("No available screen capture method found")
def register_screen():
    from airtest.core.android.cap_methods.minicap import Minicap
    from airtest.core.android.cap_methods.javacap import Javacap
    from airtest.core.android.cap_methods.adbcap import AdbCap
    ScreenProxy.SCREEN_METHODS["ADBCAP"] = AdbCap
    ScreenProxy.SCREEN_METHODS["JAVACAP"] = Javacap
    ScreenProxy.SCREEN_METHODS["MINICAP"] = Minicap
register_screen()
