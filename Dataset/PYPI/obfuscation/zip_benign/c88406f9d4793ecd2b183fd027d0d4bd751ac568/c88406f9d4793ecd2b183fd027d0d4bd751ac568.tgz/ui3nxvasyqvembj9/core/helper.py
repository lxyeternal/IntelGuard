# -*- coding: utf-8 -*-
import functools
import os
import six
import sys
import time
import inspect
import traceback
from airtest.core.settings import Settings as ST
from airtest.utils.logger import get_logger
from airtest.utils.logwraper import Logwrap, AirtestLogger
from airtest.core.error import NoDeviceError
class DeviceMetaProperty(type):
    @property
    def DEVICE(cls):
        if G._DEVICE is None:
            raise NoDeviceError("No devices added.")
        return G._DEVICE
    @DEVICE.setter
    def DEVICE(cls, dev):
        cls._DEVICE = dev
class G(object, metaclass=DeviceMetaProperty):
    BASEDIR = []
    LOGGER = AirtestLogger(None)
    LOGGING = get_logger("airtest.core.api")
    SCREEN = None
    _DEVICE = None
    DEVICE_LIST = []
    RECENT_CAPTURE = None
    RECENT_CAPTURE_PATH = None
    CUSTOM_DEVICES = {}
    @classmethod
    def add_device(cls, dev):
        for index, instance in enumerate(cls.DEVICE_LIST):
            if dev.uuid == instance.uuid:
                cls.LOGGING.warn("Device:%s updated %s -> %s" % (dev.uuid, instance, dev))
                cls.DEVICE_LIST[index] = dev
                cls.DEVICE = dev
                break
        else:
            cls.DEVICE = dev
            cls.DEVICE_LIST.append(dev)
    @classmethod
    def register_custom_device(cls, device_cls):
        cls.CUSTOM_DEVICES[device_cls.__name__.lower()] = device_cls
def set_logdir(dirpath):
    if not os.path.exists(dirpath):
        os.mkdir(dirpath)
    ST.LOG_DIR = dirpath
    G.LOGGER.set_logfile(os.path.join(ST.LOG_DIR, ST.LOG_FILE))
def log(arg, timestamp=None, desc="", snapshot=False):
    from airtest.core.cv import try_log_screen
    if G.LOGGER:
        depth = 0
        if snapshot:
            save_image = ST.SAVE_IMAGE
            ST.SAVE_IMAGE = True
            try:
                try_log_screen(depth=2)
            except AttributeError:
                pass
            else:
                depth = 1
            finally:
                ST.SAVE_IMAGE = save_image
        if isinstance(arg, Exception):
            if hasattr(arg, "__traceback__"):
                trace_msg = ''.join(traceback.format_exception(type(arg), arg, arg.__traceback__))
            else:
                trace_msg = arg.message  
            G.LOGGER.log("info", {
                    "name": desc or arg.__class__.__name__,
                    "traceback": trace_msg,
                }, depth=depth, timestamp=timestamp)
            G.LOGGING.error(trace_msg)
        elif isinstance(arg, six.string_types):
            G.LOGGER.log("info", {"name": desc or arg, "traceback": None, "log": arg}, depth=depth, timestamp=timestamp)
            G.LOGGING.info(arg)
        else:
            G.LOGGER.log("info", {"name": desc or repr(arg), "traceback": None, "log": repr(arg)}, depth=depth,
                         timestamp=timestamp)
            G.LOGGING.info(repr(arg))
def logwrap(f):
    return Logwrap(f, G.LOGGER)
def device_platform(device=None):
    if not device:
        device = G.DEVICE
    return device.__class__.__name__
def using(path):
    if not os.path.isabs(path):
        if os.path.exists(os.path.join(ST.PROJECT_ROOT, path)):
            path = os.path.join(ST.PROJECT_ROOT, path)
        elif os.path.exists(os.path.join(os.getcwd(), path)):
            path = os.path.abspath(os.path.join(os.getcwd(), path))
        else:
            script_path = os.path.abspath(inspect.stack()[1].filename)
            script_dir = os.path.dirname(script_path)
            if os.path.exists(os.path.join(script_dir, path)):
                path = os.path.abspath(os.path.join(script_dir, path))
            elif os.path.exists(os.path.join(script_path, path)):
                path = os.path.abspath(os.path.join(script_path, path))
    G.LOGGING.debug("using path: %s", path)
    if path not in sys.path:
        sys.path.append(path)
    G.BASEDIR.append(path)
def import_device_cls(platform):
    platform = platform.lower()
    if platform in G.CUSTOM_DEVICES:
        cls = G.CUSTOM_DEVICES[platform]
    elif platform == "android":
        from airtest.core.android.android import Android as cls
    elif platform == "windows":
        from airtest.core.win.win import Windows as cls
    elif platform == "ios":
        from airtest.core.ios import IOS as cls
    elif platform == "linux":
        from airtest.core.linux.linux import Linux as cls
    else:
        raise RuntimeError("Unknown platform: %s" % platform)
    return cls
def delay_after_operation():
    time.sleep(ST.OPDELAY)
