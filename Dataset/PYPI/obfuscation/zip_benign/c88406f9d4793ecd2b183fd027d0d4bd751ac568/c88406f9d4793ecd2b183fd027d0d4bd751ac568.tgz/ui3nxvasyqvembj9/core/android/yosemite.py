import traceback
import warnings
from .constant import YOSEMITE_APK, YOSEMITE_PACKAGE
from airtest.utils.snippet import on_method_ready
from airtest.utils.apkparser import APK
from airtest.utils.logger import get_logger
LOGGING = get_logger(__name__)
class Yosemite(object):
    def __init__(self, adb):
        self.adb = adb
    def install_or_upgrade(self):
        self._install_apk_upgrade(YOSEMITE_APK, YOSEMITE_PACKAGE)
    def _install_apk_upgrade(self, apk_path, package):
        apk_version = int(APK(apk_path).androidversion_code)
        installed_version = self.adb.get_package_version(package)
        if installed_version is None or apk_version > int(installed_version):
            LOGGING.info(
                "local version code is {}, installed version code is {}".format(apk_version, installed_version))
            try:
                self.adb.pm_install(apk_path, replace=True, install_options=["-t"])
            except:
                if installed_version is None:
                    raise
                print(traceback.format_exc())
                warnings.warn("Yosemite.apk update failed, please try to reinstall manually(airtest/core/android/static/apks/Yosemite.apk).")
    @on_method_ready('install_or_upgrade')
    def get_ready(self):
        pass
    def uninstall(self):
        self.adb.uninstall_app(YOSEMITE_PACKAGE)
