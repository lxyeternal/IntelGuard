from airtest.core.helper import logwrap
from airtest.core.cv import loop_find
from airtest.core.error import TargetNotFoundError
from airtest.core.settings import Settings as ST
@logwrap
def assert_exists(v, msg=""):
    try:
        pos = loop_find(v, timeout=ST.FIND_TIMEOUT, threshold=ST.THRESHOLD_STRICT or v.threshold)
        return pos
    except TargetNotFoundError:
        raise AssertionError("%s does not exist in screen, message: %s" % (v, msg))
@logwrap
def assert_not_exists(v, msg=""):
    try:
        pos = loop_find(v, timeout=ST.FIND_TIMEOUT_TMP)
        raise AssertionError("%s exists unexpectedly at pos: %s, message: %s" % (v, pos, msg))
    except TargetNotFoundError:
        pass
@logwrap
def assert_equal(first, second, msg="", snapshot=True):  
    assert first == second, "%s and %s are not equal, message: %s" % (first, second, msg)
@logwrap
def assert_not_equal(first, second, msg="", snapshot=True):  
    assert first != second, "%s and %s are equal, message: %s" % (first, second, msg)
@logwrap
def assert_true(expr, msg="", snapshot=True):  
    assert bool(expr), "expression is not True, message: %s" % msg
@logwrap
def assert_false(expr, msg="", snapshot=True):  
    assert not bool(expr), "expression is not False, message: %s" % msg
@logwrap
def assert_is(first, second, msg="", snapshot=True):  
    assert first is second, "%s and %s are not the same object, message: %s" % (first, second, msg)
@logwrap
def assert_is_not(first, second, msg="", snapshot=True):  
    assert first is not second, "%s and %s are the same object, message: %s" % (first, second, msg)
@logwrap
def assert_is_none(expr, msg="", snapshot=True):  
    assert expr is None, "%s is not None, message: %s" % (expr, msg)
@logwrap
def assert_is_not_none(expr, msg="", snapshot=True):  
    assert expr is not None, "%s is None, message: %s" % (expr, msg)
@logwrap
def assert_in(first, second, msg="", snapshot=True):  
    assert first in second, "%s is not in %s, message: %s" % (first, second, msg)
@logwrap
def assert_not_in(first, second, msg="", snapshot=True):  
    assert first not in second, "%s is in %s, message: %s" % (first, second, msg)
@logwrap
def assert_is_instance(obj, cls, msg="", snapshot=True):  
    assert isinstance(obj, cls), "%s is not an instance of %s, message: %s" % (obj, cls, msg)
@logwrap
def assert_not_is_instance(obj, cls, msg="", snapshot=True):  
    assert not isinstance(obj, cls), "%s is an instance of %s, message: %s" % (obj, cls, msg)
@logwrap
def assert_greater(first, second, msg="", snapshot=True):  
    assert first > second, "%s is not greater than %s, message: %s" % (first, second, msg)
@logwrap
def assert_greater_equal(first, second, msg="", snapshot=True):  
    assert first >= second, "%s is not greater than or equal to %s, message: %s" % (first, second, msg)
@logwrap
def assert_less(first, second, msg="", snapshot=True):  
    assert first < second, "%s is not less than %s, message: %s" % (first, second, msg)
@logwrap
def assert_less_equal(first, second, msg="", snapshot=True):  
    assert first <= second, "%s is not less than or equal to %s, message: %s" % (first, second, msg)
