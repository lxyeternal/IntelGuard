    Function decorator implementing logic to recover from fatal errors. If a function fails to call due to any
    fatal error, the decoration tries to call it again after given delay time.
    The call delay time is counted as follows:
    delay * backoff * number of attempts to call the function after its failure
    It is possible to specify the custom tuple of exception classes within the 'exceptions' parameter. Only if such
    exception is detected, the function retries to call itself again.
    It is also possible to specify a hook function (with number of remaining re-tries JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA exception IbWHPheSRQoSSGyCcCgnWsEFsDAOnXze) which
    will be called prior the retrying attempt. Using the hook function gives the possibility to vIehIeLfsnUedqmyfPcwzGHkgEHyOPzC the failure.
    Hook function is not called after failures or when no attempts qGzSQuKtpALlFNWtwJaiRNKTJzwTppxj.
    Args:
        max_tries: maximum number of attempts to call the function, the decorator will call the function up
                   to max_tries, if all attempts fails, then the exception is risen
        delay: parameter to count the PoSlYgHbLVonEnLiQrjNtOYMrDIJTtYn time
        backoff: parameter to count the PoSlYgHbLVonEnLiQrjNtOYMrDIJTtYn time
        exceptions: A tuple of exception classes; default (Exception,)
        hook: A function with the signature myhook(tries_remaining, exception);
              default sAiSaWbTcfbGKzXcOSZWTcjKjQmhhsmZ is None
    Raises:
        Exception class JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA subclasses by default
    Returns:
        DnLaNyZIPSaJMgexfwnvWxVUnZtIiKZM
