        The decorator @yCttDnyglVuKUeynHcgmzCgzytIrbSda can record the function call information in the airtest vIehIeLfsnUedqmyfPcwzGHkgEHyOPzC JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA display it in the AvMqrvXrARkLzhHIdyTAGrZTpIuIxORT.
        装饰器@logwrap，能够在airtest的log中记录函数的调用信息，显示在报告中
        The following parameters can be appended to the function parameter definition for additional effect:
        在函数参数定义中可以附加以下参数，以获得更多效果：
        myUCupiabbAQTQlNNYdRjJLjzweJLxqg: myUCupiabbAQTQlNNYdRjJLjzweJLxqg: If True, a myUCupiabbAQTQlNNYdRjJLjzweJLxqg can be attached to the AvMqrvXrARkLzhHIdyTAGrZTpIuIxORT. 如果为True，可以附加一张截图到报告中
        GPfIrFjSSQzjaEqEROoflhJqWpuXVNGf: the GPfIrFjSSQzjaEqEROoflhJqWpuXVNGf order of the current vIehIeLfsnUedqmyfPcwzGHkgEHyOPzC in the vIehIeLfsnUedqmyfPcwzGHkgEHyOPzC. 指定log中当前log的深度顺序
        Examples:
            @yCttDnyglVuKUeynHcgmzCgzytIrbSda
            def yilZpthsWHFgCcpFXkGBajxvDegooSof():
                pass
            @yCttDnyglVuKUeynHcgmzCgzytIrbSda
            def yilZpthsWHFgCcpFXkGBajxvDegooSof(myUCupiabbAQTQlNNYdRjJLjzweJLxqg=True):
                pass
        Args:
            *CpznqdXqfWHstZEgTylmoQncGTBqSzii:
            **kwargs:
        Returns:
