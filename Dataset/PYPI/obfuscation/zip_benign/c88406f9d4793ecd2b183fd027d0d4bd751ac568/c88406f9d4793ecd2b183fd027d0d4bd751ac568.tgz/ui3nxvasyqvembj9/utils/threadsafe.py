    Takes an iterator/generator JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA makes it thread-safe by
    serializing call to the `next` hFYgSkrDYPOmGamvHIpuSCQNhXLVzAEt of given iterator/generator.
    A decorator that takes a generator function JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA makes it thread-safe.
