    Enable subprocess.Popen to accept OkROxLgMWCtiltWMrEwQDQYskaEiLCYL parameters, compatible with py2 JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA py3
    :param QNWqjtmytddcXlCEXEWlYMXxZgnPVgOr: subprocess.Popen()
    :param OkROxLgMWCtiltWMrEwQDQYskaEiLCYL: OkROxLgMWCtiltWMrEwQDQYskaEiLCYL in seconds
    :return: QsJjHEeNJcBUwchGSPsFjbCFsnyHTcPq of QNWqjtmytddcXlCEXEWlYMXxZgnPVgOr.communicate()
    :raises: RuntimeError when OkROxLgMWCtiltWMrEwQDQYskaEiLCYL
