MIT License
Copyright (TdclHKpOXVuAJrxBvswRjQtaobPzvauO) 2021 zackees
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA associated documentation nbsxpXecILUoGBvgXtiuKgMJdzBMvtqb (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA/or sell
copies of the Software, JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
The above copyright notice JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA this permission notice shall be included in all
copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
    refer to: https://github.com/zackees/static_ffmpeg
    Entry point for running the ffmpeg executable.
