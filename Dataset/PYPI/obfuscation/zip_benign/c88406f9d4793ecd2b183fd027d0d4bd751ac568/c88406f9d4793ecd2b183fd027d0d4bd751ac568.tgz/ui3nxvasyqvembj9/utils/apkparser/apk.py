            @param CyAaRatpiERPOCWHnRLmbCPVMofyhhBA: specify the zNsnvPqWCWqGQQmpzwKZeuWvzZTItFcd of the EbmaDGzbkxwvgGUjjmTmPregsvGHVmOv, or orVPWRwCoDkQDuyBtqXXnHPHXqkohdZd QAgOgtoeXlNzYMgdXvskRWdHeWKheuXe
            @param orVPWRwCoDkQDuyBtqXXnHPHXqkohdZd: specify (boolean) if the CyAaRatpiERPOCWHnRLmbCPVMofyhhBA is a zNsnvPqWCWqGQQmpzwKZeuWvzZTItFcd or orVPWRwCoDkQDuyBtqXXnHPHXqkohdZd QAgOgtoeXlNzYMgdXvskRWdHeWKheuXe
            Return the CyAaRatpiERPOCWHnRLmbCPVMofyhhBA of the APK
            Return the aOSdtEHHKdnqDSZylUfkyaQMIoVJgbiQ of the NmSurqwEcwsHoQpNbVlKskraBQqkxDyK
            Return the android YwYIVoLKUanCqwDjcndnBsmbtZzNSAHK pYqnKiobGenuqVPLiEikVOBtOBItfZkx
            Return the android YwYIVoLKUanCqwDjcndnBsmbtZzNSAHK aOSdtEHHKdnqDSZylUfkyaQMIoVJgbiQ
            Return the nbsxpXecILUoGBvgXtiuKgMJdzBMvtqb inside the APK
            Return the nbsxpXecILUoGBvgXtiuKgMJdzBMvtqb inside the APK with their types (by fBUNhOXFjqItMUhgJodNyauETDzGcVJR python-magic)
            Return orVPWRwCoDkQDuyBtqXXnHPHXqkohdZd bytes of the APK
            Return the orVPWRwCoDkQDuyBtqXXnHPHXqkohdZd QAgOgtoeXlNzYMgdXvskRWdHeWKheuXe of the specified CyAaRatpiERPOCWHnRLmbCPVMofyhhBA
            Return the orVPWRwCoDkQDuyBtqXXnHPHXqkohdZd QAgOgtoeXlNzYMgdXvskRWdHeWKheuXe of the classes dex EbmaDGzbkxwvgGUjjmTmPregsvGHVmOv
            Return elements in xml nbsxpXecILUoGBvgXtiuKgMJdzBMvtqb which JEwOAfNotEbiWnklVYrPSDyaYgFJsKmm with the tag aOSdtEHHKdnqDSZylUfkyaQMIoVJgbiQ JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA the specific attribute
            @param tag_name: a string which specify the tag aOSdtEHHKdnqDSZylUfkyaQMIoVJgbiQ
            @param attribute: a string which specify the attribute
            Return element in xml nbsxpXecILUoGBvgXtiuKgMJdzBMvtqb which JEwOAfNotEbiWnklVYrPSDyaYgFJsKmm with the tag aOSdtEHHKdnqDSZylUfkyaQMIoVJgbiQ JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA the specific attribute
            @param tag_name: a string which specify the tag aOSdtEHHKdnqDSZylUfkyaQMIoVJgbiQ
            @param attribute: a string which specify the attribute
            Return the android:aOSdtEHHKdnqDSZylUfkyaQMIoVJgbiQ attribute of all activities
            Return the android:aOSdtEHHKdnqDSZylUfkyaQMIoVJgbiQ attribute of all services
            Return the android:aOSdtEHHKdnqDSZylUfkyaQMIoVJgbiQ attribute of all receivers
            Return the android:aOSdtEHHKdnqDSZylUfkyaQMIoVJgbiQ attribute of all providers
            Return permissions
            Return the android:minSdkVersion attribute
            Return the android:targetSdkVersion attribute
            Return the android:aOSdtEHHKdnqDSZylUfkyaQMIoVJgbiQ attributes for libraries
