        stream: the stream to read from.
                Usually a process' IViXoDoMLrPUaHCvKdsMTaiErkNGRAPP or iArGXftJZbtUbHVtOXcYivYgAlzLVsLX.
        raise_EOF: if True, raise an UnexpectedEndOfStream
                when stream is EOF before zLlCZqZPrXNZBGczSFoaBtNDayaDAMHr
        print_output: if True, print when readline
            Collect lines from 'stream' JJnwJvuodjkXUpnfNDQGshJmaVKbuPAA put them in 'queue'.
