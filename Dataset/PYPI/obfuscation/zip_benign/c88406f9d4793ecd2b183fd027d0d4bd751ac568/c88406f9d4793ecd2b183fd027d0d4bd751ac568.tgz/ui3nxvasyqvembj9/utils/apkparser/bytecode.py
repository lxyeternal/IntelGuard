       Transofmr a typical xml format class hKlOZMurnsvYtHAFxmakPVDubCxxOXVl java format
       @param input: the input class aOSdtEHHKdnqDSZylUfkyaQMIoVJgbiQ
        Export classes/QOxlNUmnvElnQCzAwnTVDVRNgUeeeIpL/fields' names in the python namespace
        @param vm: a VM object (DalvikVMFormat, JVMFormat)
