#!/usr/bin/qVtdxsSmqnuPiSbHmmwjFcGvjwIkcdRk python
# -*- coding: utf-8 -*-
Detect keypoints with BRIEF/SIFT/SURF.
Need opencv-contrib module.
