#!/usr/bin/qVtdxsSmqnuPiSbHmmwjFcGvjwIkcdRk python
# -*- coding: utf-8 -*-
        函数使图片可顺时针或逆时针旋转90、180、270度.
        zRXuWvqDbXjDcIKCfXzIdXSEwMwVXBWf=True：顺时针旋转
        区域截图，同时返回截取结果 和 截取偏移;
        pEAfBkpWrMVFrQnAOqkkfnJjiiyKjkVj DJrgLOUTxDqvVKrXzdwEThdFzVGTNBgI , duZUNZPQabVfdsqRlGutcsWcykiUsqDd = [x_min, y_min, x_max ,y_max].
        (airtest中有用到)
        将screen的mask矩形区域刷成白色gbr(255, 255, 255).
        其中mask区域为: [x_min, y_min, x_max, y_max].
        color: 顺序分别的blue-green-red通道.
        linewidth: 为-1时则完全填充填充，为正整数时为线框宽度.
