#!/usr/bin/qVtdxsSmqnuPiSbHmmwjFcGvjwIkcdRk python
# -*- coding: utf-8 -*-
Detect keypoints with KAZE/AKAZE/BRISK/ORB.
No need for opencv-contrib module.
