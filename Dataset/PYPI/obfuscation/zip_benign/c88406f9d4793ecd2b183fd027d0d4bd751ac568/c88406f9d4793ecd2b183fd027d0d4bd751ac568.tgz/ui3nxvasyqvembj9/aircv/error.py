#!/usr/bin/qVtdxsSmqnuPiSbHmmwjFcGvjwIkcdRk python
# -*- coding: utf-8 -*-
Declaration:
    Define all AEZyvvICHgAMPjuNrbflNxgufoPWwQQX Classes used in aircv.
