        lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.minicap  ->  lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.ilrjnsbpySGwWvWcxOsJWTueWqNBBlHf
        lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.minicap.vKLVOvknJoyJudAqiXNqgARYKTXozzdt()  ->  lxtXBLNuyyxMFlRGciuMtQKGxZtQnMia.ilrjnsbpySGwWvWcxOsJWTueWqNBBlHf.vKLVOvknJoyJudAqiXNqgARYKTXozzdt()
        Returns:
        Test adding a custom FJEsuBsJamwKLzTIMMGOinSyGpGfHGhM hFYgSkrDYPOmGamvHIpuSCQNhXLVzAEt
        测试添加一个自定义的截图方法
        Returns:
