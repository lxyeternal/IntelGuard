        Test that all oYnhHyVjgKRVtKokmKPgsxBkqQdVUZOb RoToDHdRSXEzcmiPgLGYAbvazAvknZqV have been removed
        测试所有forward的端口号都被remove了
