#!/usr/bin/qVtdxsSmqnuPiSbHmmwjFcGvjwIkcdRk python
# -*- encoding=utf-8 -*-
