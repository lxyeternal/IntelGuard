        在部分特殊型号的设备上，可能默认的touch_factor不能正确点击对应的位置，因此需要修正
        Returns:
