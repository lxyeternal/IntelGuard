from sys import version_info as _swig_python_version_info
if __package__ or "." in __name__:
    from . import _thostmduserapi
else:
    import _thostmduserapi
try:
    import builtins as __builtin__
except ImportError:
    import __builtin__
GpVdYwThSKGxKGhZHEEbUACziGxlGUoE = _thostmduserapi.SWIG_PyInstanceMethod_New
mdsCvDdMvpictcfAPGPlZhTzRWDRZskc = _thostmduserapi.SWIG_PyStaticMethod_New
def LPNJgIUaTCcxRLurdWcgRLrxwdqCdgKX(self):
    try:
        JUHdbItSvJgOiuGhqeXhCBlvBUBPHQZL = "proxy of " + self.this.__repr__()
    except __builtin__.Exception:
        JUHdbItSvJgOiuGhqeXhCBlvBUBPHQZL = ""
    return "<%s.%s; %s >" % (self.__class__.__module__, self.__class__.__name__, JUHdbItSvJgOiuGhqeXhCBlvBUBPHQZL,)
def dYugLltiDvYtLCoqaWsHzQHOwvErRWHz(set):
    def oKnLQjIniRrAjAlrignMQdvTwUxfNunX(self, name, value):
        if name == "this":
            set(self, name, value)
        elif name == "thisown":
            self.this.own(value)
        elif hasattr(self, name) and isinstance(getattr(type(self), name), property):
            set(self, name, value)
        else:
            raise AttributeError("You cannot add instance attributes to %s" % self)
    return oKnLQjIniRrAjAlrignMQdvTwUxfNunX
def SfhrqtsWwyESBgfAfcMSseLKCyGoaOPy(set):
    def CFRGXpZAxHGyaWqCFsRcNmWTJiiydzWF(cls, name, value):
        if hasattr(cls, name) and not isinstance(getattr(cls, name), property):
            set(cls, name, value)
        else:
            raise AttributeError("You cannot add class attributes to %s" % cls)
    return CFRGXpZAxHGyaWqCFsRcNmWTJiiydzWF
def wJeocrMNEcDfnfKYeSibBTBqooqTNnKi(metaclass):
    def uJemFhOTNKxbCUDaRKYikGWLadnPQZTA(cls):
        return metaclass(cls.__name__, cls.__bases__, cls.__dict__.copy())
    return uJemFhOTNKxbCUDaRKYikGWLadnPQZTA
class KbweKaPUSpEPsUmwKrAikHJGTIbUWfRp(type):
    __setattr__ = SfhrqtsWwyESBgfAfcMSseLKCyGoaOPy(type.__setattr__)
import weakref
hgqYeIPdwPzYHuSwSBOBMSWrtYfxVHjm = _thostmduserapi.hgqYeIPdwPzYHuSwSBOBMSWrtYfxVHjm
LUcNsCNmGdswmssapKVRXnkrCCetvFJr = _thostmduserapi.LUcNsCNmGdswmssapKVRXnkrCCetvFJr
FiGqHvIyhVYIyiZNxgnACTXHZlJvVjKQ = _thostmduserapi.FiGqHvIyhVYIyiZNxgnACTXHZlJvVjKQ
WRllTzVuYuZZwMDlWYWQHUjVdgVmviiV = _thostmduserapi.WRllTzVuYuZZwMDlWYWQHUjVdgVmviiV
r"""
    TFtdcExchangePropertyType是一个交易所属性类型
    正常
    TFtdcIdCardTypeType是一个证件类型类型
    组织机构代码
    TFtdcInvestorRangeType是一个投资者范围类型
    所有
    TFtdcDepartmentRangeType是一个投资者范围类型
    所有
    TFtdcDataSyncStatusType是一个数据同步状态类型
    未同步
    TFtdcBrokerDataSyncStatusType是一个经纪公司数据同步状态类型
    已同步
    TFtdcExchangeConnectStatusType是一个交易所连接状态类型
    没有任何连接
    TFtdcTraderConnectStatusType是一个交易所交易员连接状态类型
    没有任何连接
    TFtdcFunctionCodeType是一个功能代码类型
    数据异步化
    TFtdcBrokerFunctionCodeType是一个经纪公司功能代码类型
    强制用户登出
    TFtdcOrderActionStatusType是一个报单操作状态类型
    已经提交
    TFtdcOrderStatusType是一个报单状态类型
    全部成交
    TFtdcOrderSubmitStatusType是一个报单提交状态类型
    已经提交
    TFtdcPositionDateType是一个持仓日期类型
    今日持仓
    TFtdcPositionDateTypeType是一个持仓日期类型类型
    使用历史持仓
    TFtdcTradingRoleType是一个交易角色类型
    代理
    TFtdcProductClassType是一个产品类型类型
    期货
    TFtdcInstLifePhaseType是一个合约生命周期状态类型
    未上市
    TFtdcDirectionType是一个买卖方向类型
    买
    TFtdcPositionTypeType是一个持仓类型类型
    净持仓
    TFtdcPosiDirectionType是一个持仓多空方向类型
    净
    TFtdcSysSettlementStatusType是一个系统结算状态类型
    不活跃
    TFtdcRatioAttrType是一个费率属性类型
    交易费率
    TFtdcHedgeFlagType是一个投机套保标志类型
    投机
    TFtdcBillHedgeFlagType是一个投机套保标志类型
    投机
    TFtdcClientIDTypeType是一个交易编码类型类型
    投机
    TFtdcOrderPriceTypeType是一个报单价格条件类型
    任意价
    TFtdcOffsetFlagType是一个开平标志类型
    开仓
    TFtdcForceCloseReasonType是一个强平原因类型
    非强平
    TFtdcOrderTypeType是一个报单类型类型
    正常
    TFtdcInvestorProgrammingTypeType是一个投资者程序化标识类型
    未知
    TFtdcTimeConditionType是一个有效期类型类型
    立即完成，否则撤销
    TFtdcVolumeConditionType是一个成交量类型类型
    任何数量
    TFtdcContingentConditionType是一个触发条件类型
    立即
    TFtdcActionFlagType是一个操作标志类型
    删除
    TFtdcTradingRightType是一个交易权限类型
    可以交易
    TFtdcOrderSourceType是一个报单来源类型
    来自参与者
    TFtdcTradeTypeType是一个成交类型类型
    组合持仓拆分为单一持仓,初始化不应包含该类型的持仓
    TFtdcPriceSourceType是一个成交价来源类型
    前成交价
    TFtdcInstrumentStatusType是一个合约交易状态类型
    开盘前
    TFtdcInstStatusEnterReasonType是一个品种进入交易状态原因类型
    自动切换
    TFtdcBatchStatusType是一个处理状态类型
    未上传
    TFtdcReturnStyleType是一个按品种返还方式类型
    按所有品种
    TFtdcReturnPatternType是一个返还模式类型
    按成交手数
    TFtdcReturnLevelType是一个返还级别类型
    级别1
    TFtdcReturnStandardType是一个返还标准类型
    分阶段返还
    TFtdcMortgageTypeType是一个质押类型类型
    质出
    TFtdcInvestorSettlementParamIDType是一个投资者结算参数代码类型
    质押比例
    TFtdcExchangeSettlementParamIDType是一个交易所结算参数代码类型
    质押比例
    TFtdcSystemParamIDType是一个系统参数代码类型
    投资者代码最小长度
    TFtdcTradeParamIDType是一个交易系统参数代码类型
    系统加密算法
    TFtdcFileIDType是一个文件标识类型
    资金数据
    TFtdcFileTypeType是一个文件上传类型类型
    结算
    TFtdcFileFormatType是一个文件格式类型
    文本文件(.txt)
    TFtdcFileUploadStatusType是一个文件状态类型
    上传成功
    TFtdcTransferDirectionType是一个移仓方向类型
    移出
    TFtdcSpecialCreateRuleType是一个特殊的创建规则类型
    没有特殊创建规则
    TFtdcBasisPriceTypeType是一个挂牌基准价类型类型
    上一合约结算价
    TFtdcProductLifePhaseType是一个产品生命周期状态类型
    活跃
    TFtdcDeliveryModeType是一个交割方式类型
    现金交割
    TFtdcFundIOTypeType是一个出入金类型类型
    出入金
    TFtdcFundTypeType是一个资金类型类型
    银行存款
    TFtdcFundDirectionType是一个出入金方向类型
    入金
    TFtdcFundStatusType是一个资金状态类型
    已录入
    TFtdcPublishStatusType是一个发布状态类型
    未发布
    TFtdcSystemStatusType是一个系统状态类型
    不活跃
    TFtdcSettlementStatusType是一个结算状态类型
    初始
    TFtdcInvestorTypeType是一个投资者类型类型
    自然人
    TFtdcBrokerTypeType是一个经纪公司类型类型
    交易会员
    TFtdcRiskLevelType是一个风险等级类型
    低风险客户
    TFtdcFeeAcceptStyleType是一个手续费收取方式类型
    按交易收取
    TFtdcPasswordTypeType是一个密码类型类型
    交易密码
    TFtdcAlgorithmType是一个盈亏算法类型
    浮盈浮亏都计算
    TFtdcIncludeCloseProfitType是一个是否包含平仓盈利类型
    包含平仓盈利
    TFtdcAllWithoutTradeType是一个是否受可提比例限制类型
    无仓无成交不受可提比例限制
    TFtdcFuturePwdFlagType是一个资金密码核对标志类型
    不核对
    TFtdcTransferTypeType是一个银期转账类型类型
    银行转期货
    TFtdcTransferValidFlagType是一个转账有效标志类型
    无效或失败
    TFtdcBankChannelType是一个银行转账通道类型
    银期
    TFtdcReasonType是一个事由类型
    错单
    TFtdcSexType是一个性别类型
    未知
    TFtdcUserTypeType是一个用户类型类型
    投资者
    TFtdcRateTypeType是一个费率类型类型
    保证金率
    TFtdcNoteTypeType是一个通知类型类型
    交易结算单
    TFtdcSettlementStyleType是一个结算单方式类型
    逐日盯市
    TFtdcSettlementBillTypeType是一个结算单类型类型
    日报
    TFtdcUserRightTypeType是一个客户权限类型类型
    登录
    TFtdcMarginPriceTypeType是一个保证金价格类型类型
    昨结算价
    TFtdcBillGenStatusType是一个结算单生成状态类型
    未生成
    TFtdcAlgoTypeType是一个算法类型类型
    持仓处理算法
    TFtdcHandlePositionAlgoIDType是一个持仓处理算法编号类型
    基本
    TFtdcFindMarginRateAlgoIDType是一个寻找保证金率算法编号类型
    基本
    TFtdcHandleTradingAccountAlgoIDType是一个资金处理算法编号类型
    基本
    TFtdcPersonTypeType是一个联系人类型类型
    指定下单人
    TFtdcQueryInvestorRangeType是一个查询范围类型
    所有
    TFtdcInvestorRiskStatusType是一个投资者风险状态类型
    正常
    TFtdcUserEventTypeType是一个用户事件类型类型
    登录
    TFtdcCloseStyleType是一个平仓方式类型
    先开先平
    TFtdcStatModeType是一个统计方式类型
    ----
    TFtdcParkedOrderStatusType是一个预埋单状态类型
    未发送
    TFtdcVirDealStatusType是一个处理状态类型
    正在处理
    TFtdcOrgSystemIDType是一个原有系统代码类型
    综合交易平台
    TFtdcVirTradeStatusType是一个交易状态类型
    正常处理中
    TFtdcVirBankAccTypeType是一个银行帐户类型类型
    存折
    TFtdcVirementStatusType是一个银行帐户类型类型
    正常
    TFtdcVirementAvailAbilityType是一个有效标志类型
    未确认
    TFtdcAMLGenStatusType是一个Aml生成方式类型
    程序生成
    TFtdcCFMMCKeyKindType是一个动态密钥类别(保证金监管)类型
    主动请求更新
    TFtdcCertificationTypeType是一个证件类型类型
    身份证
    TFtdcFileBusinessCodeType是一个文件业务功能类型
    其他
    TFtdcCashExchangeCodeType是一个汇钞标志类型
    汇
    TFtdcYesNoIndicatorType是一个是或否标识类型
    是
    TFtdcBanlanceTypeType是一个余额类型类型
    当前余额
    TFtdcGenderType是一个性别类型
    未知状态
    TFtdcFeePayFlagType是一个费用支付标志类型
    由受益方支付费用
    TFtdcPassWordKeyTypeType是一个密钥类型类型
    交换密钥
    TFtdcFBTPassWordTypeType是一个密码类型类型
    查询
    TFtdcFBTEncryModeType是一个加密方式类型
    不加密
    TFtdcBankRepealFlagType是一个银行冲正标志类型
    银行无需自动冲正
    TFtdcBrokerRepealFlagType是一个期商冲正标志类型
    期商无需自动冲正
    TFtdcInstitutionTypeType是一个机构类别类型
    银行
    TFtdcLastFragmentType是一个最后分片标志类型
    是最后分片
    TFtdcBankAccStatusType是一个银行账户状态类型
    正常
    TFtdcMoneyAccountStatusType是一个资金账户状态类型
    正常
    TFtdcManageStatusType是一个存管状态类型
    指定存管
    TFtdcSystemTypeType是一个应用系统类型类型
    银期转帐
    TFtdcTxnEndFlagType是一个银期转帐划转结果标志类型
    正常处理中
    TFtdcProcessStatusType是一个银期转帐服务处理状态类型
    未处理
    TFtdcCustTypeType是一个客户类型类型
    自然人
    TFtdcFBTTransferDirectionType是一个银期转帐方向类型
    入金，银行转期货
    TFtdcOpenOrDestroyType是一个开销户类别类型
    开户
    TFtdcAvailabilityFlagType是一个有效标志类型
    未确认
    TFtdcOrganTypeType是一个机构类型类型
    银行代理
    TFtdcOrganLevelType是一个机构级别类型
    银行总行或期商总部
    TFtdcProtocalIDType是一个协议类型类型
    期商协议
    TFtdcConnectModeType是一个套接字连接方式类型
    短连接
    TFtdcSyncModeType是一个套接字通信方式类型
    异步
    TFtdcBankAccTypeType是一个银行帐号类型类型
    银行存折
    TFtdcFutureAccTypeType是一个期货公司帐号类型类型
    银行存折
    TFtdcOrganStatusType是一个接入机构状态类型
    启用
    TFtdcCCBFeeModeType是一个建行收费模式类型
    按金额扣收
    TFtdcCommApiTypeType是一个通讯API类型类型
    客户端
    TFtdcLinkStatusType是一个连接状态类型
    已经连接
    TFtdcPwdFlagType是一个密码核对标志类型
    不核对
    TFtdcSecuAccTypeType是一个期货帐号类型类型
    资金帐号
    TFtdcTransferStatusType是一个转账交易状态类型
    正常
    TFtdcSponsorTypeType是一个发起方类型
    期商
    TFtdcReqRspTypeType是一个请求响应类别类型
    请求
    TFtdcFBTUserEventTypeType是一个银期转帐用户事件类型类型
    签到
    TFtdcDBOperationType是一个记录操作类型类型
    插入
    TFtdcSyncFlagType是一个同步标记类型
    已同步
    TFtdcSyncTypeType是一个同步类型类型
    一次同步
    TFtdcExDirectionType是一个换汇方向类型
    结汇
    TFtdcFBEResultFlagType是一个换汇成功标志类型
    成功
    TFtdcFBEExchStatusType是一个换汇交易状态类型
    正常
    TFtdcFBEFileFlagType是一个换汇文件标志类型
    数据包
    TFtdcFBEAlreadyTradeType是一个换汇已交易标志类型
    未交易
    TFtdcFBEUserEventTypeType是一个银期换汇用户事件类型类型
    签到
    TFtdcFBEReqFlagType是一个换汇发送标志类型
    未处理
    TFtdcNotifyClassType是一个风险通知类型类型
    正常
    TFtdcForceCloseTypeType是一个强平单类型类型
    手工强平
    TFtdcRiskNotifyMethodType是一个风险通知途径类型
    系统通知
    TFtdcRiskNotifyStatusType是一个风险通知状态类型
    未生成
    TFtdcRiskUserEventType是一个风控用户操作事件类型
    导出数据
    TFtdcConditionalOrderSortTypeType是一个条件单索引条件类型
    使用最新价升序
    TFtdcSendTypeType是一个报送状态类型
    未发送
    TFtdcClientIDStatusType是一个交易编码状态类型
    未申请
    TFtdcQuestionTypeType是一个特有信息类型类型
    单选
    TFtdcBusinessTypeType是一个业务类型类型
    请求
    TFtdcCfmmcReturnCodeType是一个监控中心返回码类型
    成功
    TFtdcClientTypeType是一个客户类型类型
    所有
    TFtdcExchangeIDTypeType是一个交易所编号类型
    上海期货交易所
    TFtdcExClientIDTypeType是一个交易编码类型类型
    套保
    TFtdcUpdateFlagType是一个更新状态类型
    未更新
    TFtdcApplyOperateIDType是一个申请动作类型
    开户
    TFtdcApplyStatusIDType是一个申请状态类型
    未补全
    TFtdcSendMethodType是一个发送方式类型
    文件发送
    TFtdcEventModeType是一个操作方法类型
    增加
    TFtdcUOAAutoSendType是一个统一开户申请自动发送类型
    自动发送并接收
    TFtdcFlowIDType是一个流程ID类型
    投资者对应投资者组设置
    TFtdcCheckLevelType是一个复核级别类型
    零级复核
    TFtdcCheckStatusType是一个复核级别类型
    未复核
    TFtdcUsedStatusType是一个生效状态类型
    未生效
    TFtdcBankAcountOriginType是一个账户来源类型
    手工录入
    TFtdcMonthBillTradeSumType是一个结算单月报成交汇总方式类型
    同日同合约
    TFtdcOTPTypeType是一个动态令牌类型类型
    无动态令牌
    TFtdcOTPStatusType是一个动态令牌状态类型
    未使用
    TFtdcBrokerUserTypeType是一个经济公司用户类型类型
    投资者
    TFtdcFutureTypeType是一个期货类型类型
    商品期货
    TFtdcFundEventTypeType是一个资金管理操作类型类型
    转账限额
    TFtdcAccountSourceTypeType是一个资金账户来源类型
    银期同步
    TFtdcCodeSourceTypeType是一个交易编码来源类型
    统一开户(已规范)
    TFtdcUserRangeType是一个操作员范围类型
    所有
    TFtdcByGroupType是一个交易统计表按客户统计方式类型
    按投资者统计
    TFtdcTradeSumStatModeType是一个交易统计表按范围统计方式类型
    按合约统计
    TFtdcExprSetModeType是一个日期表达式设置类型类型
    相对已有规则设置
    TFtdcRateInvestorRangeType是一个投资者范围类型
    公司标准
    TFtdcSyncDataStatusType是一个主次用系统数据同步状态类型
    未同步
    TFtdcTradeSourceType是一个成交来源类型
    来自交易所普通回报
    TFtdcFlexStatModeType是一个产品合约统计方式类型
    产品统计
    TFtdcByInvestorRangeType是一个投资者范围统计方式类型
    属性统计
    TFtdcPropertyInvestorRangeType是一个投资者范围类型
    所有
    TFtdcFileStatusType是一个文件状态类型
    未生成
    TFtdcFileGenStyleType是一个文件生成方式类型
    下发
    TFtdcSysOperModeType是一个系统日志操作方法类型
    增加
    TFtdcSysOperTypeType是一个系统日志操作类型类型
    修改操作员密码
    TFtdcCSRCDataQueyTypeType是一个上报数据查询类型类型
    查询当前交易日报送的数据
    TFtdcFreezeStatusType是一个休眠状态类型
    活跃
    TFtdcStandardStatusType是一个规范状态类型
    已规范
    TFtdcRightParamTypeType是一个配置类型类型
    休眠户
    TFtdcDataStatusType是一个反洗钱审核表数据状态类型
    正常
    TFtdcAMLCheckStatusType是一个审核状态类型
    未复核
    TFtdcAmlDateTypeType是一个日期类型类型
    检查日期
    TFtdcAmlCheckLevelType是一个审核级别类型
    零级审核
    TFtdcExportFileTypeType是一个导出文件类型类型
    CSV
    TFtdcSettleManagerTypeType是一个结算配置类型类型
    结算前准备
    TFtdcSettleManagerLevelType是一个结算配置等级类型
    必要
    TFtdcSettleManagerGroupType是一个模块分组类型
    交易所核对
    TFtdcLimitUseTypeType是一个保值额度使用类型类型
    可重复使用
    TFtdcDataResourceType是一个数据来源类型
    本系统
    TFtdcMarginTypeType是一个保证金类型类型
    交易所保证金率
    TFtdcActiveTypeType是一个生效类型类型
    仅当日生效
    TFtdcMarginRateTypeType是一个冲突保证金率类型类型
    交易所保证金率
    TFtdcBackUpStatusType是一个备份数据状态类型
    未生成备份数据
    TFtdcInitSettlementType是一个结算初始化状态类型
    结算初始化未开始
    TFtdcReportStatusType是一个报表数据生成状态类型
    未生成报表数据
    TFtdcSaveStatusType是一个数据归档状态类型
    归档未完成
    TFtdcSettArchiveStatusType是一个结算确认数据归档状态类型
    未归档数据
    TFtdcCTPTypeType是一个CTP交易系统类型类型
    未知类型
    TFtdcCloseDealTypeType是一个平仓处理类型类型
    正常
    TFtdcMortgageFundUseRangeType是一个货币质押资金可用范围类型
    不能使用
    TFtdcSpecProductTypeType是一个特殊产品类型类型
    郑商所套保产品
    TFtdcFundMortgageTypeType是一个货币质押类型类型
    质押
    TFtdcAccountSettlementParamIDType是一个投资者账户结算参数代码类型
    基础保证金
    TFtdcFundMortDirectionType是一个货币质押方向类型
    货币质入
    TFtdcBusinessClassType是一个换汇类别类型
    盈利
    TFtdcSwapSourceTypeType是一个换汇数据来源类型
    手工
    TFtdcCurrExDirectionType是一个换汇类型类型
    结汇
    TFtdcCurrencySwapStatusType是一个申请状态类型
    已录入
    TFtdcReqFlagType是一个换汇发送标志类型
    未发送
    TFtdcResFlagType是一个换汇返回成功标志类型
    成功
    TFtdcExStatusType是一个修改状态类型
    修改前
    TFtdcClientRegionType是一个开户客户地域类型
    国内客户
    TFtdcHasBoardType是一个是否有董事会类型
    没有
    TFtdcStartModeType是一个启动模式类型
    正常
    TFtdcTemplateTypeType是一个模型类型类型
    全量
    TFtdcLoginModeType是一个登录模式类型
    交易
    TFtdcPromptTypeType是一个日历提示类型类型
    合约上下市
    TFtdcHasTrusteeType是一个是否有托管人类型
    有
    TFtdcAmTypeType是一个机构类型类型
    银行
    TFtdcCSRCFundIOTypeType是一个出入金类型类型
    出入金
    TFtdcCusAccountTypeType是一个结算账户类型类型
    期货结算账户
    TFtdcLanguageTypeType是一个通知语言类型类型
    中文
    TFtdcAssetmgrClientTypeType是一个资产管理客户类型类型
    个人资管客户
    TFtdcAssetmgrTypeType是一个投资类型类型
    期货类
    TFtdcCheckInstrTypeType是一个合约比较类型类型
    合约交易所不存在
    TFtdcDeliveryTypeType是一个交割类型类型
    手工交割
    TFtdcMaxMarginSideAlgorithmType是一个大额单边保证金算法类型
    不使用大额单边保证金算法
    TFtdcDAClientTypeType是一个资产管理客户类型类型
    自然人
    TFtdcUOAAssetmgrTypeType是一个投资类型类型
    期货类
    TFtdcDirectionEnType是一个买卖方向类型
    Buy
    TFtdcOffsetFlagEnType是一个开平标志类型
    Position Opening
    TFtdcHedgeFlagEnType是一个投机套保标志类型
    Speculation
    TFtdcFundIOTypeEnType是一个出入金类型类型
    Deposit/Withdrawal
    TFtdcFundTypeEnType是一个资金类型类型
    Bank Deposit
    TFtdcFundDirectionEnType是一个出入金方向类型
    Deposit
    TFtdcFundMortDirectionEnType是一个货币质押方向类型
    Pledge
    TFtdcOptionsTypeType是一个期权类型类型
    看涨
    TFtdcStrikeModeType是一个执行方式类型
    欧式
    TFtdcStrikeTypeType是一个执行类型类型
    自身对冲
    TFtdcApplyTypeType是一个中金所期权放弃执行申请类型类型
    不执行数量
    TFtdcGiveUpDataSourceType是一个放弃执行申请数据来源类型
    系统生成
    TFtdcExecResultType是一个执行结果类型
    没有执行
    TFtdcCombinationTypeType是一个组合类型类型
    期货组合
    TFtdcOptionRoyaltyPriceTypeType是一个期权权利金价格类型类型
    昨结算价
    TFtdcBalanceAlgorithmType是一个权益算法类型
    不计算期权市值盈亏
    TFtdcActionTypeType是一个执行类型类型
    执行
    TFtdcForQuoteStatusType是一个询价状态类型
    已经提交
    TFtdcValueMethodType是一个取值方式类型
    按绝对值
    TFtdcExecOrderPositionFlagType是一个期权行权后是否保留期货头寸的标记类型
    保留
    TFtdcExecOrderCloseFlagType是一个期权行权后生成的头寸是否自动平仓类型
    自动平仓
    TFtdcProductTypeType是一个产品类型类型
    期货
    TFtdcCZCEUploadFileNameType是一个郑商所结算文件名类型
    ^\d{8}_zz_\d{4}
    TFtdcDCEUploadFileNameType是一个大商所结算文件名类型
    ^\d{8}_dl_\d{3}
    TFtdcSHFEUploadFileNameType是一个上期所结算文件名类型
    ^\d{4}_\d{8}_\d{8}_DailyFundChg
    TFtdcCFFEXUploadFileNameType是一个中金所结算文件名类型
    ^\d{4}_SG\d{1}_\d{8}_\d{1}_Trade
    TFtdcCombDirectionType是一个组合指令方向类型
    申请组合
    TFtdcLockTypeType是一个锁定方向类型
    锁定
    TFtdcBizTypeType是一个业务类型类型
    期货
    TFtdcDesignateTypeType是一个指定类型类型
    指定登记
    TFtdcFreezeReasonTypeType是一个冻结原因类型
    初始化
    TFtdcFreezeTypeType是一个冻结类型类型
    冻结
    TFtdcTradeSystemTypeType是一个交易系统类型类型
    未知系统
    TFtdcStockDisposalTypeType是一个证券处置方向类型
    划入经纪公司账户
    TFtdcStockDisposalStatusType是一个证券处置状态类型
    已经提交
    TFtdcInstructionRightTypeType是一个指令权限类型类型
    限价单
    TFtdcLevelTypeType是一个投资者分级类型类型
    一级投资者
    TFtdcStrikeOffsetTypeType是一个行权偏移类型类型
    实值额
    TFtdcSmsCodeStatusType是一个行权偏移类型类型
    未发送
    TFtdcWeakPasswordSourceType是一个弱密码来源类型
    弱密码库
    TFtdcOptSelfCloseFlagType是一个期权行权的头寸是否自对冲类型
    自对冲期权仓位
    TFtdcAppTypeType是一个用户App类型类型
    直连的投资者
    TFtdcReserveOpenAccStasType是一个预指定开户状态类型
    等待处理中
    TFtdcSFInterestTypeType是一个结息类型类型
    未结息
    TFtdcInterestSuccessType是一个结息状态类型
    未处理
    TFtdcSFSponsorTypeType是一个发起方类型
    券商
    TFtdcSFFBTransferDirectionType是一个银证转帐方向类型
    入金，银行转期货
    TFtdcSFCashRemitFlagType是一个钞汇标示类型
    钞
    TFtdcSFStatusType是一个存管状态类型
    正常
    TFtdcSFBuySellFlagType是一个买卖差标志类型
    卖差
    TFtdcSFIdCardTypeType是一个证件类型类型
    身份证
    TFtdcSFMarketIDType是一个市场代码类型
    沪A
    TFtdcInternalFundDirectionType是一个资金内转方向类型
    期权入金，期货出金
    TFtdcSyncDepositStatusType是一个源系统或目标系统类型
    未发起
    TFtdcFundServerStatusType是一个fundserver连接状态类型
    没有任何连接
    TFtdcFundServerRedoFlagType是一个是否重演再次生成的流水,kernel会忽略相同的depoSeq类型
    非重演报文
    TFtdcInternalTransferStatusType是一个资金内转系统响应状态类型
    出金成功
    TFtdcLinearMarginTypeType是一个线性保证金类型类型
    基础保证金
        当客户端与交易后台通信连接断开时，该方法被调用。当发生这个情况后，API会自动重新连接，客户端可不做处理。
        :type nReason: int
        :param nReason: 错误原因
                    0x1001 网络读失败
                    0x1002 网络写失败
                    0x2001 接收心跳超时
                    0x2002 发送心跳失败
                    0x2003 收到错误报文
        心跳超时警告。当长时间未收到报文时，该方法被调用。
        :type nTimeLapse: int
        :param nTimeLapse: 距离上次接收报文的时间
        创建MdApi
        :type pszFlowPath: string, optional
        :param pszFlowPath: 存贮订阅信息文件的目录，默认为当前目录
        :rtype: :py:class:`CThostFtdcMdApi`
        :return: 创建出的UserApi
            modify for udp marketdata
        获取API的版本信息
        :rtype: string
        :return: 获取到的版本号
        删除接口对象本身
        Remarks: 不再使用本接口对象时,调用该函数删除接口对象
        初始化
        Remarks: 初始化运行环境,只有调用后,接口才开始工作
        等待接口线程结束运行
        :rtype: int
        :return: 线程退出代码
        获取当前交易日
        :rtype: string
        :return: 获取到的交易日
        Remarks: 只有登录成功后,才能得到正确的交易日
        注册前置机网络地址
        :param pszFrontAddress：前置机网络地址。:
        Remarks: 网络地址的格式为：“protocol://ipaddress:port”，如：”tcp://127.0.0.1:17001”。
        “tcp”代表传输协议，“127.0.0.1”代表服务器地址。”17001”代表服务器端口号。
        注册名字服务器网络地址
        :param pszNsAddress：名字服务器网络地址。:
        Remarks: 网络地址的格式为：“protocol://ipaddress:port”，如：”tcp://127.0.0.1:12001”。
        “tcp”代表传输协议，“127.0.0.1”代表服务器地址。”12001”代表服务器端口号。
        RegisterNameServer优先于RegisterFront
        注册名字服务器用户信息
        :param pFensUserInfo：用户信息。:
        注册回调接口
        :type pSpi: :py:class:`CThostFtdcMdSpi`
        :param pSpi: 派生自回调接口类的实例
        订阅行情。
        :type ppInstrumentID: string
        :param ppInstrumentID: 合约ID
        :type nCount: int
        :param nCount: 要订阅/退订行情的合约个数
        Remarks: 
        退订行情。
        :type ppInstrumentID: string
        :param ppInstrumentID: 合约ID
        :type nCount: int
        :param nCount: 要订阅/退订行情的合约个数
        Remarks: 
        订阅询价。
        :type ppInstrumentID: string
        :param ppInstrumentID: 合约ID
        :type nCount: int
        :param nCount: 要订阅/退订行情的合约个数
        Remarks: 
        退订询价。
        :type ppInstrumentID: string
        :param ppInstrumentID: 合约ID
        :type nCount: int
        :param nCount: 要订阅/退订行情的合约个数
        Remarks: 
