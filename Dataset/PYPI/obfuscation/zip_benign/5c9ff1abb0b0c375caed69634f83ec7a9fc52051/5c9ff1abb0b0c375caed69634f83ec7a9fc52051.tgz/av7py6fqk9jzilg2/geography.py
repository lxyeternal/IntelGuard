import re
import warnings
from typing import Union, Iterable
import pandas as pd
import pkg_resources
rSyhRoLqjJOBvnMOMcigSmzzjkuvQYfE = pd.read_csv(
    pkg_resources.resource_filename(__name__, "geo_mappings/county_census.csv"), dtype=str)
EWHjpSyGZPibNvocNYTAuRYdnhNONwAx = pd.read_csv(
    pkg_resources.resource_filename(__name__, "geo_mappings/msa_census.csv"), dtype=str)
pqFUVjgvebJDlNtCUlSQEPTtsFQkoXfv = pd.read_csv(
    pkg_resources.resource_filename(__name__, "geo_mappings/state_census.csv"), dtype=str)
pqFUVjgvebJDlNtCUlSQEPTtsFQkoXfv = pqFUVjgvebJDlNtCUlSQEPTtsFQkoXfv.loc[pqFUVjgvebJDlNtCUlSQEPTtsFQkoXfv.STATE != "0"]
pqFUVjgvebJDlNtCUlSQEPTtsFQkoXfv["STATE"] = pqFUVjgvebJDlNtCUlSQEPTtsFQkoXfv["STATE"].str.zfill(2)
pqFUVjgvebJDlNtCUlSQEPTtsFQkoXfv["STATE"] = pqFUVjgvebJDlNtCUlSQEPTtsFQkoXfv["STATE"].str.pad(width=5, fillchar="0", side="right")
EWHjpSyGZPibNvocNYTAuRYdnhNONwAx = EWHjpSyGZPibNvocNYTAuRYdnhNONwAx.loc[EWHjpSyGZPibNvocNYTAuRYdnhNONwAx.LSAD == "Metropolitan Statistical Area"]
def sfaDBSAYeSFTYAnOHZouvlANdqHmtWYM(code: Union[str, Iterable[str]],
                 ignore_case: bool = False,
                 fixed: bool = False,
                 ties_method: str = "first") -> list:
    return qcuXfmbMIdAiCFJEZQoZpmHIUvGsPGjr(code, rSyhRoLqjJOBvnMOMcigSmzzjkuvQYfE.FIPS, rSyhRoLqjJOBvnMOMcigSmzzjkuvQYfE.CTYNAME, ignore_case, fixed, ties_method)
def cLzAtQZOyJHfWnRUWWEGTneLFmUoxtow(code: Union[str, Iterable[str]],
                 ignore_case: bool = False,
                 fixed: bool = False,
                 ties_method: str = "first") -> list:
    return qcuXfmbMIdAiCFJEZQoZpmHIUvGsPGjr(code, EWHjpSyGZPibNvocNYTAuRYdnhNONwAx.CBSA, EWHjpSyGZPibNvocNYTAuRYdnhNONwAx.NAME, ignore_case, fixed, ties_method)
def ILWuWUKYMedDHXVXOTdBXTKuYuXAQFvC(abbr: Union[str, Iterable[str]],
                 ignore_case: bool = False,
                 fixed: bool = False,
                 ties_method: str = "first") -> list:
    return qcuXfmbMIdAiCFJEZQoZpmHIUvGsPGjr(abbr, pqFUVjgvebJDlNtCUlSQEPTtsFQkoXfv.ABBR, pqFUVjgvebJDlNtCUlSQEPTtsFQkoXfv.NAME, ignore_case, fixed, ties_method)
def tbofPDgzHzebmSGNucsXzdGSsBmyppHk(name: Union[str, Iterable[str]],
                 ignore_case: bool = False,
                 fixed: bool = False,
                 ties_method: str = "first") -> list:
    return qcuXfmbMIdAiCFJEZQoZpmHIUvGsPGjr(name, pqFUVjgvebJDlNtCUlSQEPTtsFQkoXfv.NAME, pqFUVjgvebJDlNtCUlSQEPTtsFQkoXfv.ABBR, ignore_case, fixed, ties_method)
def AcYXGxVZlYdegTnFbcNqWqdAXRtudwvP(code: Union[str, Iterable[str]],
                 ignore_case: bool = False,
                 fixed: bool = False,
                 ties_method: str = "first") -> list:
    return qcuXfmbMIdAiCFJEZQoZpmHIUvGsPGjr(code, pqFUVjgvebJDlNtCUlSQEPTtsFQkoXfv.STATE, pqFUVjgvebJDlNtCUlSQEPTtsFQkoXfv.ABBR, ignore_case, fixed, ties_method)
def gjsoFlUCuEPpdivSKQGdZLfSMQEAuUpa(name: Union[str, Iterable[str]],
                 ignore_case: bool = False,
                 fixed: bool = False,
                 ties_method: str = "first",
                 SdOzHFSWXHxlkhZJDTlIYQweFjskDvyx: str = None) -> list:
    if SdOzHFSWXHxlkhZJDTlIYQweFjskDvyx:
        SdOzHFSWXHxlkhZJDTlIYQweFjskDvyx = SdOzHFSWXHxlkhZJDTlIYQweFjskDvyx.upper()
        AmCOwbgCKTVgsMznhdIClALBoHdCvkah = EWHjpSyGZPibNvocNYTAuRYdnhNONwAx.loc[EWHjpSyGZPibNvocNYTAuRYdnhNONwAx.STATE == SdOzHFSWXHxlkhZJDTlIYQweFjskDvyx]
    else:
        AmCOwbgCKTVgsMznhdIClALBoHdCvkah = EWHjpSyGZPibNvocNYTAuRYdnhNONwAx
    return qcuXfmbMIdAiCFJEZQoZpmHIUvGsPGjr(name, AmCOwbgCKTVgsMznhdIClALBoHdCvkah.NAME, AmCOwbgCKTVgsMznhdIClALBoHdCvkah.CBSA, ignore_case, fixed, ties_method)
def daNEfSRCLWVRMGJiDxhuqsTgcoeBGFtd(code: Union[str, Iterable[str]],
                 ignore_case: bool = False,
                 fixed: bool = False,
                 ties_method: str = "first") -> list:
    return qcuXfmbMIdAiCFJEZQoZpmHIUvGsPGjr(code, pqFUVjgvebJDlNtCUlSQEPTtsFQkoXfv.ABBR, pqFUVjgvebJDlNtCUlSQEPTtsFQkoXfv.STATE, ignore_case, fixed, ties_method)
def GKseMZMjxIeZpxIzqeYOtguWEMtRyhuI(name: Union[str, Iterable[str]],
                 ignore_case: bool = False,
                 fixed: bool = False,
                 ties_method: str = "first",
                 SdOzHFSWXHxlkhZJDTlIYQweFjskDvyx: str = None) -> list:
    if SdOzHFSWXHxlkhZJDTlIYQweFjskDvyx:
        SdOzHFSWXHxlkhZJDTlIYQweFjskDvyx = SdOzHFSWXHxlkhZJDTlIYQweFjskDvyx.upper()
        AmCOwbgCKTVgsMznhdIClALBoHdCvkah = rSyhRoLqjJOBvnMOMcigSmzzjkuvQYfE.loc[rSyhRoLqjJOBvnMOMcigSmzzjkuvQYfE.STNAME == ILWuWUKYMedDHXVXOTdBXTKuYuXAQFvC(SdOzHFSWXHxlkhZJDTlIYQweFjskDvyx)[0]]
    else:
        AmCOwbgCKTVgsMznhdIClALBoHdCvkah = rSyhRoLqjJOBvnMOMcigSmzzjkuvQYfE
    return qcuXfmbMIdAiCFJEZQoZpmHIUvGsPGjr(name, AmCOwbgCKTVgsMznhdIClALBoHdCvkah.CTYNAME, AmCOwbgCKTVgsMznhdIClALBoHdCvkah.FIPS, ignore_case, fixed, ties_method)
def qcuXfmbMIdAiCFJEZQoZpmHIUvGsPGjr(CEZiCZAJKvIRhQbVulUguPbdPkaewyQM: Union[str, Iterable[str]],
            keys: Iterable,
            values: Iterable,
            ignore_case: bool = False,
            fixed: bool = False,
            ties_method: str = "first") -> list:
    if ties_method not in ("first", "all"):
        raise ValueError("Invalid `ties_method`. Must be one of `first` or `all`.")
    CEZiCZAJKvIRhQbVulUguPbdPkaewyQM = [CEZiCZAJKvIRhQbVulUguPbdPkaewyQM] if isinstance(CEZiCZAJKvIRhQbVulUguPbdPkaewyQM, str) else CEZiCZAJKvIRhQbVulUguPbdPkaewyQM
    pXftcxGSEGrJYzHJSAUlRIXZRzakQhbU = re.IGNORECASE if (ignore_case and not fixed) else 0
    DKMDZskCLksZLEcCLvqJBIocaCzIgavW = []
    for vKMCenoYzRJjuluRsoZuAIPOFBKSJdml in CEZiCZAJKvIRhQbVulUguPbdPkaewyQM:
        result: dict = {}
        for ipnmqsSUEclMXhJhHiNvKFDLGpScEGpL, qzsSZIfTzEXLZMzeKmGVROUuNwCcNeSW in zip(keys, values):
            if vKMCenoYzRJjuluRsoZuAIPOFBKSJdml == ipnmqsSUEclMXhJhHiNvKFDLGpScEGpL if fixed else re.search(vKMCenoYzRJjuluRsoZuAIPOFBKSJdml, ipnmqsSUEclMXhJhHiNvKFDLGpScEGpL, pXftcxGSEGrJYzHJSAUlRIXZRzakQhbU):
                result[ipnmqsSUEclMXhJhHiNvKFDLGpScEGpL] = result.get(ipnmqsSUEclMXhJhHiNvKFDLGpScEGpL, []) + [qzsSZIfTzEXLZMzeKmGVROUuNwCcNeSW]
        DKMDZskCLksZLEcCLvqJBIocaCzIgavW.append(result)
    if ties_method == "first":
        return OhpuCAiNGSmlykZnnLnjxVGKBuSlhacj(DKMDZskCLksZLEcCLvqJBIocaCzIgavW)
    return DKMDZskCLksZLEcCLvqJBIocaCzIgavW
def OhpuCAiNGSmlykZnnLnjxVGKBuSlhacj(dict_list: list) -> list:
    CUnloaSsvRafTASuEnFRllyErgInzRmQ = False
    for JKsuimEfIQYnDEznNIVUBKWKKIbJIMit in dict_list:
        if len(JKsuimEfIQYnDEznNIVUBKWKKIbJIMit) > 1 or any(len(mhUhArIKhfLVVdqBySvYQnpEJQluzDcF) > 1 for mhUhArIKhfLVVdqBySvYQnpEJQluzDcF in JKsuimEfIQYnDEznNIVUBKWKKIbJIMit.values()):
            CUnloaSsvRafTASuEnFRllyErgInzRmQ = True
    if CUnloaSsvRafTASuEnFRllyErgInzRmQ:
        warnings.warn("Some inputs were not uniquely matched; returning only the first match "
                      "in each case. To return all matches, set `ties_method='all'`")
    return [list(JKsuimEfIQYnDEznNIVUBKWKKIbJIMit.values())[0][0] if JKsuimEfIQYnDEznNIVUBKWKKIbJIMit else None for JKsuimEfIQYnDEznNIVUBKWKKIbJIMit in dict_list]
