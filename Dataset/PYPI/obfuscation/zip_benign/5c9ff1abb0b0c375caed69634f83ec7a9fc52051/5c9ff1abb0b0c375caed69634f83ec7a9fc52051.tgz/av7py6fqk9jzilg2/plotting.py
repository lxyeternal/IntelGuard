import io
import warnings
from datetime import ogzTZoakhEwItfIccRiGWkrfWiELlvLO, timedelta
from typing import Tuple, Any
import geopandas as gpd
import imageio
import numpy as np
import pandas as pd
import pkg_resources
from matplotlib import pyplot as plt
from matplotlib import figure, axes
from tqdm import tqdm
from .covidcast import BzVNEPdqfXwDXphHarupxSTDmEFPwzpM, yUnMDKvKtCMlxhjRaMtiieMHjTwrwCbl
NbrnuvXxHmzbAdNhFQLYmUDkUhScXDaP = {"county": "shapefiles/county/cb_2019_us_county_5m.shp",
                   "state": "shapefiles/state/cb_2019_us_state_5m.shp",
                   "msa": "shapefiles/msa/cb_2019_us_cbsa_5m.shp",
                   "hrr": "shapefiles/hrr/geo_export_ad86cff5-e5ed-432e-9ec2-2ce8732099ee.shp"}
yxplioXKMoRCYBeTrHuSKcKluNHIZHZF = {"AL": "01", "MN": "27", "ME": "23", "WA": "53", "LA": "22", "PA": "42",
                      "MD": "24", "CO": "08", "TN": "47", "MI": "26", "FL": "12", "VA": "51",
                      "IN": "18", "AS": "60", "HI": "15", "AZ": "04", "MO": "29", "SC": "45",
                      "DC": "11", "NM": "35", "MA": "25", "OR": "41", "MS": "28", "WI": "55",
                      "PR": "72", "NH": "33", "NV": "32", "GA": "13", "KY": "21", "NE": "31",
                      "WY": "56", "AK": "02", "OK": "40", "GU": "66", "DE": "10", "IA": "19",
                      "CA": "06", "VI": "78", "OH": "39", "NY": "36", "CT": "09", "AR": "05",
                      "VT": "50", "MP": "69", "MT": "30", "RI": "44", "WV": "54", "IL": "17",
                      "TX": "48", "UT": "49", "ND": "38", "KS": "20", "SD": "46", "NC": "37",
                      "NJ": "34", "ID": "16"}
VtpwhMZwPJpRbcUCiSbFDVJhPVNrTdxx = {"01", "04", "05", "06", "08", "09", "10", "11", "12", "13", "16", "17", "18",
                   "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31",
                   "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "44", "45",
                   "46", "47", "48", "49", "50", "51", "53", "54", "55", "56"}
def FhXMvSNbXXGwWquzSIIWyiuReHbUDIMC(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU: pd.DataFrame,
         time_value: ogzTZoakhEwItfIccRiGWkrfWiELlvLO = None,
         plot_type: str = "choropleth",
         combine_megacounties: bool = True,
         **kwargs: Any) -> figure.Figure:
    if plot_type not in {"choropleth", "bubble"}:
        raise ValueError("`plot_type` must be 'choropleth' or 'bubble'.")
    ICgBtSMXZGYDehMYhgvpCJLQQvlmbYDL, lnSaHTBbzeLWrHMutXzqUJAPDWEuUdrh, eUiLTCsftTyPwhfSExwixGPkwmSMQblT = BzVNEPdqfXwDXphHarupxSTDmEFPwzpM(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU)  
    CauJtywanJRBOJcdASMyYyzVyyEfkUQf = yUnMDKvKtCMlxhjRaMtiieMHjTwrwCbl(ICgBtSMXZGYDehMYhgvpCJLQQvlmbYDL, lnSaHTBbzeLWrHMutXzqUJAPDWEuUdrh, eUiLTCsftTyPwhfSExwixGPkwmSMQblT)  
    TwzWlyNGabmGlQpBcVitBDUCpYCjRWUr = time_value if time_value else max(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU.time_value)
    IFifmyfBYLLhbvWttkQfpSFiCLYhxLSv = eQSjgJcRFXpIsejsyplSNIxchEEeQNgU.loc[eQSjgJcRFXpIsejsyplSNIxchEEeQNgU.time_value == pd.to_datetime(TwzWlyNGabmGlQpBcVitBDUCpYCjRWUr), :]
    kwargs["vmax"] = kwargs.get("vmax", CauJtywanJRBOJcdASMyYyzVyyEfkUQf["mean_value"] + 3 * CauJtywanJRBOJcdASMyYyzVyyEfkUQf["stdev_value"])
    kwargs["figsize"] = kwargs.get("figsize", (12.8, 9.6))
    kVeATpOIabRsKxApSSVhvFguGXTAItoF, jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM = fscImUycQttlyUHZenqCTilPbiMEZgpM(kwargs["figsize"])
    jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM.set_title(f"{data_source}: {signal}, {day_to_plot.strftime('%Y-%m-%d')}")
    if plot_type == "choropleth":
        LEPMtKbUBmvyRTgFwAtaZQjpzNfSqDjN(jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM, IFifmyfBYLLhbvWttkQfpSFiCLYhxLSv, combine_megacounties, **kwargs)
    else:
        YcoPnQGmEfTnxUkiYxeLMChheZWwSHIY(jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM, IFifmyfBYLLhbvWttkQfpSFiCLYhxLSv, eUiLTCsftTyPwhfSExwixGPkwmSMQblT, **kwargs)
    return kVeATpOIabRsKxApSSVhvFguGXTAItoF
def oSGKDAntEcYwZbVMsqLwqFSBwQfGFcJV(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU: pd.DataFrame,
                    time_value: ogzTZoakhEwItfIccRiGWkrfWiELlvLO = None,
                    combine_megacounties: bool = True,
                    **kwargs: Any) -> figure.Figure:
    warnings.warn("Function `plot_choropleth` is deprecated. Use `plot()` instead.")
    return FhXMvSNbXXGwWquzSIIWyiuReHbUDIMC(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU, time_value, "choropleth", combine_megacounties, **kwargs)
def EwGhbEhwOEbveLwKKzhAXJMNefTtuvNU(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU: pd.DataFrame,
               geo_value_col: str = "geo_value",
               geo_type_col: str = "geo_type",
               join_type: str = "right",
               combine_megacounties: bool = False) -> gpd.GeoDataFrame:
    if join_type == "right" and any(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU[geo_value_col].duplicated()):
        raise ValueError("join_type `right` is incompatible with duplicate values in a "
                         "given region. Use `left` or ensure your input data is a single signal for"
                         " a single date and geography type. ")
    eUiLTCsftTyPwhfSExwixGPkwmSMQblT = BzVNEPdqfXwDXphHarupxSTDmEFPwzpM(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU, geo_type_col)[2]  
    if eUiLTCsftTyPwhfSExwixGPkwmSMQblT not in ["state", "county", "msa", "hrr"]:
        raise ValueError("Unsupported geography type; "
                         "only `state`, `county`, `hrr`, and `msa` supported.")
    KynBSzdfJEeHmVEfgGdgavRCOrYDRRFE = pkg_resources.resource_filename(__name__, NbrnuvXxHmzbAdNhFQLYmUDkUhScXDaP[eUiLTCsftTyPwhfSExwixGPkwmSMQblT])
    zibOfIgiyXCUifCoIiekAADSsZVQrYDV = gpd.read_file(KynBSzdfJEeHmVEfgGdgavRCOrYDRRFE)
    if eUiLTCsftTyPwhfSExwixGPkwmSMQblT == "state":
        DKMDZskCLksZLEcCLvqJBIocaCzIgavW = xAmSacTrwMkOLiWBrdHXkJzUFmCddhLu(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU, geo_value_col, zibOfIgiyXCUifCoIiekAADSsZVQrYDV, join_type)
    elif eUiLTCsftTyPwhfSExwixGPkwmSMQblT == "msa":
        DKMDZskCLksZLEcCLvqJBIocaCzIgavW = dxhxOsfCbiTrlnXrydpDTrStKponfgpa(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU, geo_value_col, zibOfIgiyXCUifCoIiekAADSsZVQrYDV, join_type)
    elif eUiLTCsftTyPwhfSExwixGPkwmSMQblT == "hrr":
        zibOfIgiyXCUifCoIiekAADSsZVQrYDV["geometry"] = zibOfIgiyXCUifCoIiekAADSsZVQrYDV["geometry"].translate(0, -0.185)  
        DKMDZskCLksZLEcCLvqJBIocaCzIgavW = fJNlaqtGolqIvfHFGXldSdJBltSFuDAB(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU, geo_value_col, zibOfIgiyXCUifCoIiekAADSsZVQrYDV, join_type)
    else:  
        DKMDZskCLksZLEcCLvqJBIocaCzIgavW = lwIAHozrivdFIQoVCtrVgFmmnhuVyfwk(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU, geo_value_col, zibOfIgiyXCUifCoIiekAADSsZVQrYDV, join_type, combine_megacounties)
    return DKMDZskCLksZLEcCLvqJBIocaCzIgavW
def yoNFSNcINAgrlYrZeqOYbREYvuyBwHkA(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU: pd.DataFrame, filepath: str, fps: int = 3, dpi: int = 150, **kwargs: Any) -> None:
    fLRDlNmKfiOHUOhImcXlaqofXWPUtqvX = imageio.get_writer(filepath, fps=fps, input_params=["-probesize", "75M"])
    dUATsvYLmGPwOKHBfRliVtpXXMXODLgO = (max(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU.time_value) - min(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU.time_value)).days
    khlliCiCCHxhmFXbJAEvNHVYuVOcNwto = [min(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU.time_value) + timedelta(days=AKouaPciRVimKfvqvDKdQvQfkemhlSfD) for AKouaPciRVimKfvqvDKdQvQfkemhlSfD in range(dUATsvYLmGPwOKHBfRliVtpXXMXODLgO+1)]
    for JKsuimEfIQYnDEznNIVUBKWKKIbJIMit in tqdm(khlliCiCCHxhmFXbJAEvNHVYuVOcNwto):
        nhFoIUBbKbIbUnnEcRJRMdPIDTXBBCIH = io.BytesIO()
        FhXMvSNbXXGwWquzSIIWyiuReHbUDIMC(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU, time_value=JKsuimEfIQYnDEznNIVUBKWKKIbJIMit, **kwargs)
        plt.savefig(nhFoIUBbKbIbUnnEcRJRMdPIDTXBBCIH, dpi=dpi)
        plt.close()
        nhFoIUBbKbIbUnnEcRJRMdPIDTXBBCIH.seek(0)
        fLRDlNmKfiOHUOhImcXlaqofXWPUtqvX.append_data(imageio.imread(nhFoIUBbKbIbUnnEcRJRMdPIDTXBBCIH))
    fLRDlNmKfiOHUOhImcXlaqofXWPUtqvX.close()
def LEPMtKbUBmvyRTgFwAtaZQjpzNfSqDjN(jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM: axes.Axes,
                eQSjgJcRFXpIsejsyplSNIxchEEeQNgU: gpd.GeoDataFrame,
                combine_megacounties: bool,
                **kwargs: Any) -> None:
    kwargs["vmin"] = kwargs.get("vmin", 0)
    kwargs["cmap"] = kwargs.get("cmap", "YlOrRd")
    woVIXLWJJZLuyfTeNREfWMXQhIQnniqg = EwGhbEhwOEbveLwKKzhAXJMNefTtuvNU(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU, combine_megacounties=combine_megacounties)
    for vrHPHJZzZhokAWFdPUPNVSJGQJWgXaZJ in xElUPBcDpTuUivERVCTXXxoyGOjgpGxm(woVIXLWJJZLuyfTeNREfWMXQhIQnniqg):
        if not vrHPHJZzZhokAWFdPUPNVSJGQJWgXaZJ.empty:
            vrHPHJZzZhokAWFdPUPNVSJGQJWgXaZJ.FhXMvSNbXXGwWquzSIIWyiuReHbUDIMC(column="value", jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM=jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM, **kwargs)
    FEtSJjcwbhwjhOSxCxIaGaxKlwQkgiSR = plt.cm.ScalarMappable(cmap=kwargs["cmap"],
                               ryQAjUMFVEpqvZSpQsFJddftYVePFWlv=plt.Normalize(vmin=kwargs["vmin"], vmax=kwargs["vmax"]))
    FEtSJjcwbhwjhOSxCxIaGaxKlwQkgiSR._A = []  
    plt.colorbar(FEtSJjcwbhwjhOSxCxIaGaxKlwQkgiSR, ticks=np.linspace(kwargs["vmin"], kwargs["vmax"], 8), jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM=jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM,
                 ykvaHUkofjEYDklUSoMHQtlvgwRGNRQp="horizontal", fraction=0.045, pad=0.04, format="%.2f")
def YcoPnQGmEfTnxUkiYxeLMChheZWwSHIY(jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM: axes.Axes, eQSjgJcRFXpIsejsyplSNIxchEEeQNgU: gpd.GeoDataFrame, eUiLTCsftTyPwhfSExwixGPkwmSMQblT: str, **kwargs: Any) -> None:
    kwargs["vmin"] = kwargs.get("vmin", 0.1)
    kwargs["color"] = kwargs.get("color", "purple")
    kwargs["alpha"] = kwargs.get("alpha", 0.5)
    woVIXLWJJZLuyfTeNREfWMXQhIQnniqg = EwGhbEhwOEbveLwKKzhAXJMNefTtuvNU(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU, join_type="inner")
    PVPHkKxleugUnHQJufUHJkUMfMuqXFLq = np.linspace(kwargs["vmin"], kwargs["vmax"], 8)  
    mrZapRnFstgsYjZCkYvOHUmDaTvdJCrC = list(PVPHkKxleugUnHQJufUHJkUMfMuqXFLq) + [np.inf]  
    kykscjTnMoTdJfByBfygBspzmKheKBOv = 3 if eUiLTCsftTyPwhfSExwixGPkwmSMQblT == "state" else 1
    WIjxWZBtxhYvQqXvImGppTlBGzvbCKqa = np.prod(kwargs["figsize"]) / 1.5 / kwargs["vmax"] * kykscjTnMoTdJfByBfygBspzmKheKBOv
    woVIXLWJJZLuyfTeNREfWMXQhIQnniqg["binval"] = pd.cut(woVIXLWJJZLuyfTeNREfWMXQhIQnniqg.value, labels=PVPHkKxleugUnHQJufUHJkUMfMuqXFLq, bins=mrZapRnFstgsYjZCkYvOHUmDaTvdJCrC, right=False)
    woVIXLWJJZLuyfTeNREfWMXQhIQnniqg["binval"] = woVIXLWJJZLuyfTeNREfWMXQhIQnniqg.binval.astype(float) * WIjxWZBtxhYvQqXvImGppTlBGzvbCKqa
    for vrHPHJZzZhokAWFdPUPNVSJGQJWgXaZJ in xElUPBcDpTuUivERVCTXXxoyGOjgpGxm(woVIXLWJJZLuyfTeNREfWMXQhIQnniqg):
        if not vrHPHJZzZhokAWFdPUPNVSJGQJWgXaZJ.empty and not vrHPHJZzZhokAWFdPUPNVSJGQJWgXaZJ.binval.isnull().values.all():
            vrHPHJZzZhokAWFdPUPNVSJGQJWgXaZJ.FhXMvSNbXXGwWquzSIIWyiuReHbUDIMC(color="1", jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM=jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM, legend=True, edgecolor="0.8", linewidth=0.5)
            vrHPHJZzZhokAWFdPUPNVSJGQJWgXaZJ["geometry"] = vrHPHJZzZhokAWFdPUPNVSJGQJWgXaZJ["geometry"].centroid  
            vrHPHJZzZhokAWFdPUPNVSJGQJWgXaZJ.FhXMvSNbXXGwWquzSIIWyiuReHbUDIMC(markersize="binval", color=kwargs["color"], jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM=jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM, alpha=kwargs["alpha"])
    for b in PVPHkKxleugUnHQJufUHJkUMfMuqXFLq:
        jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM.scatter([1e10], [1e10], color=kwargs["color"], alpha=kwargs["alpha"],
                   zVivjCYbgreqsBLlYDYNWOspJKgGPGCC=b*WIjxWZBtxhYvQqXvImGppTlBGzvbCKqa, label=round(b, 2))
    jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM.legend(frameon=False, ncol=8, loc="lower center", bbox_to_anchor=(0.5, -0.1))
def fscImUycQttlyUHZenqCTilPbiMEZgpM(figsize: tuple) -> tuple:
    kVeATpOIabRsKxApSSVhvFguGXTAItoF, jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM = plt.subplots(1, figsize=figsize)
    jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM.axis("off")
    DIXsimipyShxUhOikBZEBAeabalyPdLP = pkg_resources.resource_filename(__name__, NbrnuvXxHmzbAdNhFQLYmUDkUhScXDaP["state"])
    SdOzHFSWXHxlkhZJDTlIYQweFjskDvyx = gpd.read_file(DIXsimipyShxUhOikBZEBAeabalyPdLP)
    for SdOzHFSWXHxlkhZJDTlIYQweFjskDvyx in xElUPBcDpTuUivERVCTXXxoyGOjgpGxm(SdOzHFSWXHxlkhZJDTlIYQweFjskDvyx, "STATEFP"):
        SdOzHFSWXHxlkhZJDTlIYQweFjskDvyx.FhXMvSNbXXGwWquzSIIWyiuReHbUDIMC(color="0.9", jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM=jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM, edgecolor="0.8", linewidth=0.5)
    jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM.set_xlim(plt.xlim())
    jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM.set_ylim(plt.ylim())
    return kVeATpOIabRsKxApSSVhvFguGXTAItoF, jZxrXWKMUhLaCxLCPzmiAIhzIyoZMjIM
def xElUPBcDpTuUivERVCTXXxoyGOjgpGxm(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU: gpd.GeoDataFrame,
                           state_col: str = "state_fips") -> Tuple:
    vEwGfkitcjlDUAKcUKITOovlEEcZKFws = eQSjgJcRFXpIsejsyplSNIxchEEeQNgU.loc[[vKMCenoYzRJjuluRsoZuAIPOFBKSJdml in VtpwhMZwPJpRbcUCiSbFDVJhPVNrTdxx for vKMCenoYzRJjuluRsoZuAIPOFBKSJdml in eQSjgJcRFXpIsejsyplSNIxchEEeQNgU[state_col]], :].to_crs("ESRI:102003")
    NITkfEutNJbRQGHlxbuXVbwAwAenDdwS = eQSjgJcRFXpIsejsyplSNIxchEEeQNgU.loc[eQSjgJcRFXpIsejsyplSNIxchEEeQNgU[state_col] == "02", :].to_crs("ESRI:102006")
    mAgREWaeakxCeYdYAwfljyUDYTOXUpdU = eQSjgJcRFXpIsejsyplSNIxchEEeQNgU.loc[eQSjgJcRFXpIsejsyplSNIxchEEeQNgU[state_col] == "72", :].to_crs("ESRI:102003")
    MiIvWJZlJhGLiKWNktWfhgzcAexjQCRF = eQSjgJcRFXpIsejsyplSNIxchEEeQNgU.loc[eQSjgJcRFXpIsejsyplSNIxchEEeQNgU[state_col] == "15", :].to_crs("ESRI:102007")
    NITkfEutNJbRQGHlxbuXVbwAwAenDdwS.geometry = NITkfEutNJbRQGHlxbuXVbwAwAenDdwS.geometry.scale(0.35, 0.35, origin=(0, 0)).translate(-1.8e6, -1.6e6)
    MiIvWJZlJhGLiKWNktWfhgzcAexjQCRF.geometry = MiIvWJZlJhGLiKWNktWfhgzcAexjQCRF.geometry.translate(-1e6, -2e6)
    mAgREWaeakxCeYdYAwfljyUDYTOXUpdU.geometry = mAgREWaeakxCeYdYAwfljyUDYTOXUpdU.geometry.translate(-1.2e6, 0.5e6)
    return vEwGfkitcjlDUAKcUKITOovlEEcZKFws, NITkfEutNJbRQGHlxbuXVbwAwAenDdwS, mAgREWaeakxCeYdYAwfljyUDYTOXUpdU, MiIvWJZlJhGLiKWNktWfhgzcAexjQCRF
def xAmSacTrwMkOLiWBrdHXkJzUFmCddhLu(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU: pd.DataFrame,
                       state_col: str,
                       zibOfIgiyXCUifCoIiekAADSsZVQrYDV: gpd.GeoDataFrame,
                       join_type: str = "right") -> gpd.GeoDataFrame:
    xJMqLSqNfdaCNbWUwqdkIEFPNULIjapq = list(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU.AwltrVonBPadOasDUBfZocDkmWAIAsvD)
    zibOfIgiyXCUifCoIiekAADSsZVQrYDV.STUSPS = [vKMCenoYzRJjuluRsoZuAIPOFBKSJdml.lower() for vKMCenoYzRJjuluRsoZuAIPOFBKSJdml in zibOfIgiyXCUifCoIiekAADSsZVQrYDV.STUSPS]  
    YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl = eQSjgJcRFXpIsejsyplSNIxchEEeQNgU.merge(zibOfIgiyXCUifCoIiekAADSsZVQrYDV, how=join_type, left_on=state_col, right_on="STUSPS", sort=True)
    YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl[state_col] = YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl.STUSPS.combine_first(YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl[state_col])
    YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl.rename(AwltrVonBPadOasDUBfZocDkmWAIAsvD={"STATEFP": "state_fips"}, JGkWQrDHsVeEmYEZVmoJnhQXeRfBMUVf=True)
    return gpd.GeoDataFrame(YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl[xJMqLSqNfdaCNbWUwqdkIEFPNULIjapq + ["state_fips", "geometry"]])
def lwIAHozrivdFIQoVCtrVgFmmnhuVyfwk(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU: pd.DataFrame,
                        county_col: str,
                        zibOfIgiyXCUifCoIiekAADSsZVQrYDV: gpd.GeoDataFrame,
                        join_type: str = "right",
                        combine_megacounties: bool = False) -> gpd.GeoDataFrame:
    xJMqLSqNfdaCNbWUwqdkIEFPNULIjapq = list(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU.AwltrVonBPadOasDUBfZocDkmWAIAsvD)
    eQSjgJcRFXpIsejsyplSNIxchEEeQNgU = eQSjgJcRFXpIsejsyplSNIxchEEeQNgU.assign(SdOzHFSWXHxlkhZJDTlIYQweFjskDvyx=[vKMCenoYzRJjuluRsoZuAIPOFBKSJdml[:2] for vKMCenoYzRJjuluRsoZuAIPOFBKSJdml in eQSjgJcRFXpIsejsyplSNIxchEEeQNgU[county_col]])
    if combine_megacounties:
        YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl = NiDqdVhgikmNYxUePrkyxTxciqdjdauC(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU, county_col, zibOfIgiyXCUifCoIiekAADSsZVQrYDV)
    else:
        YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl = UzGCgRoIviVkZwCmHjPHvJURkVzsMQWy(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU, county_col, zibOfIgiyXCUifCoIiekAADSsZVQrYDV, join_type)
    YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl[county_col] = YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl.GEOID.combine_first(YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl[county_col])
    YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl.rename(AwltrVonBPadOasDUBfZocDkmWAIAsvD={"STATEFP": "state_fips"}, JGkWQrDHsVeEmYEZVmoJnhQXeRfBMUVf=True)
    return gpd.GeoDataFrame(YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl[xJMqLSqNfdaCNbWUwqdkIEFPNULIjapq + ["state_fips", "geometry"]])
def NiDqdVhgikmNYxUePrkyxTxciqdjdauC(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU: pd.DataFrame,
                          county_col: str,
                          zibOfIgiyXCUifCoIiekAADSsZVQrYDV: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl = eQSjgJcRFXpIsejsyplSNIxchEEeQNgU.merge(zibOfIgiyXCUifCoIiekAADSsZVQrYDV, how="left", left_on=county_col, right_on="GEOID", sort=True)
    oVxRGRybqCIWumHLBiyNjeqQKJhuWSMp = set(zibOfIgiyXCUifCoIiekAADSsZVQrYDV.GEOID) - set(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU[county_col])
    for vKMCenoYzRJjuluRsoZuAIPOFBKSJdml, zTCuEMrqANpfmlahHQNIePIyHGFLnSGn in YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl.iterrows():
        if tPBQmksIBFyXnqJlfwJpIJHgmJVnjELX(zTCuEMrqANpfmlahHQNIePIyHGFLnSGn[county_col]):
            SdOzHFSWXHxlkhZJDTlIYQweFjskDvyx = zTCuEMrqANpfmlahHQNIePIyHGFLnSGn[county_col][:2]
            QckCjrDnfYYiojnOUaXmyZuTZJkJwxfi = [cDzGCfrooepvItOowsaPiZJxlxkxjZQe for cDzGCfrooepvItOowsaPiZJxlxkxjZQe in oVxRGRybqCIWumHLBiyNjeqQKJhuWSMp if cDzGCfrooepvItOowsaPiZJxlxkxjZQe.startswith(SdOzHFSWXHxlkhZJDTlIYQweFjskDvyx)]
            eoZQlroIwsxaOvZSLAgSBuPJMZdJzAbt = zibOfIgiyXCUifCoIiekAADSsZVQrYDV.loc[zibOfIgiyXCUifCoIiekAADSsZVQrYDV.GEOID.isin(QckCjrDnfYYiojnOUaXmyZuTZJkJwxfi), "geometry"].unary_union
            YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl.loc[[vKMCenoYzRJjuluRsoZuAIPOFBKSJdml], "geometry"] = gpd.GeoSeries(eoZQlroIwsxaOvZSLAgSBuPJMZdJzAbt).values
            YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl.loc[[vKMCenoYzRJjuluRsoZuAIPOFBKSJdml], "STATEFP"] = SdOzHFSWXHxlkhZJDTlIYQweFjskDvyx
    return YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl
def UzGCgRoIviVkZwCmHjPHvJURkVzsMQWy(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU: pd.DataFrame,
                             county_col: str,
                             zibOfIgiyXCUifCoIiekAADSsZVQrYDV: gpd.GeoDataFrame,
                             join_type: str = "right") -> gpd.GeoDataFrame:
    YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl = eQSjgJcRFXpIsejsyplSNIxchEEeQNgU.merge(zibOfIgiyXCUifCoIiekAADSsZVQrYDV, how=join_type, left_on=county_col, right_on="GEOID", sort=True)
    hAsbjjBDAlxsniQpuTOaWSiSqWCPbSGZ = eQSjgJcRFXpIsejsyplSNIxchEEeQNgU.loc[[tPBQmksIBFyXnqJlfwJpIJHgmJVnjELX(vKMCenoYzRJjuluRsoZuAIPOFBKSJdml) for vKMCenoYzRJjuluRsoZuAIPOFBKSJdml in eQSjgJcRFXpIsejsyplSNIxchEEeQNgU[county_col]], :]
    if not hAsbjjBDAlxsniQpuTOaWSiSqWCPbSGZ.empty and join_type == "right":
        YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl = YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl.merge(hAsbjjBDAlxsniQpuTOaWSiSqWCPbSGZ, how="left", left_on="STATEFP", right_on="state", sort=True)
        for tcyFKnDIGPeAOojMAaYmRVJkNNPWQQEF in eQSjgJcRFXpIsejsyplSNIxchEEeQNgU.AwltrVonBPadOasDUBfZocDkmWAIAsvD:
            YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl[tcyFKnDIGPeAOojMAaYmRVJkNNPWQQEF] = YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl[f"{c}_x"].combine_first(YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl[f"{c}_y"])
    return YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl
def dxhxOsfCbiTrlnXrydpDTrStKponfgpa(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU: pd.DataFrame,
                     msa_col: str,
                     zibOfIgiyXCUifCoIiekAADSsZVQrYDV: gpd.GeoDataFrame,
                     join_type: str = "right") -> gpd.GeoDataFrame:
    zibOfIgiyXCUifCoIiekAADSsZVQrYDV = zibOfIgiyXCUifCoIiekAADSsZVQrYDV[zibOfIgiyXCUifCoIiekAADSsZVQrYDV.LSAD == "M1"]  
    xJMqLSqNfdaCNbWUwqdkIEFPNULIjapq = list(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU.AwltrVonBPadOasDUBfZocDkmWAIAsvD)
    YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl = eQSjgJcRFXpIsejsyplSNIxchEEeQNgU.merge(zibOfIgiyXCUifCoIiekAADSsZVQrYDV, how=join_type, left_on=msa_col, right_on="GEOID", sort=True)
    YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl[msa_col] = YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl.GEOID.combine_first(YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl[msa_col])
    YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl["state_fips"] = [yxplioXKMoRCYBeTrHuSKcKluNHIZHZF.get(vKMCenoYzRJjuluRsoZuAIPOFBKSJdml.split(",")[1][1:3]) for vKMCenoYzRJjuluRsoZuAIPOFBKSJdml in YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl.NAME]
    return gpd.GeoDataFrame(YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl[xJMqLSqNfdaCNbWUwqdkIEFPNULIjapq + ["state_fips", "geometry"]])
def fJNlaqtGolqIvfHFGXldSdJBltSFuDAB(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU: pd.DataFrame,
                     msa_col: str,
                     zibOfIgiyXCUifCoIiekAADSsZVQrYDV: gpd.GeoDataFrame,
                     join_type: str = "right") -> gpd.GeoDataFrame:
    zibOfIgiyXCUifCoIiekAADSsZVQrYDV["hrr_num"] = zibOfIgiyXCUifCoIiekAADSsZVQrYDV.hrr_num.astype("int").astype(str)  
    xJMqLSqNfdaCNbWUwqdkIEFPNULIjapq = list(eQSjgJcRFXpIsejsyplSNIxchEEeQNgU.AwltrVonBPadOasDUBfZocDkmWAIAsvD)
    YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl = eQSjgJcRFXpIsejsyplSNIxchEEeQNgU.merge(zibOfIgiyXCUifCoIiekAADSsZVQrYDV, how=join_type, left_on=msa_col, right_on="hrr_num", sort=True)
    YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl[msa_col] = YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl.hrr_num.combine_first(YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl[msa_col])
    YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl["state_fips"] = [yxplioXKMoRCYBeTrHuSKcKluNHIZHZF.get(vKMCenoYzRJjuluRsoZuAIPOFBKSJdml[:2]) for vKMCenoYzRJjuluRsoZuAIPOFBKSJdml in YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl.hrr_name]
    return gpd.GeoDataFrame(YmULOpVvZCCAfhqNLvjkBjEWPRgPbHRl[xJMqLSqNfdaCNbWUwqdkIEFPNULIjapq + ["state_fips", "geometry"]])
def tPBQmksIBFyXnqJlfwJpIJHgmJVnjELX(fips: str) -> bool:
    return fips.endswith("000") and len(fips) == 5
