class lzrMIDeLYXkwxWaCeOKfKYQHKQUrClsA(Warning):
    QkTSViidnkUaLtirfdxsJDoNmzRLZccx = 'JJIIMsrbvAKqaEgtoKwdYmLFzTukJYcd'
