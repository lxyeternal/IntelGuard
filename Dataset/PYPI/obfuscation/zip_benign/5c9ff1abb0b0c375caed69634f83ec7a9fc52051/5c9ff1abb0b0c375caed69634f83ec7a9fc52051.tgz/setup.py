import setuptools
with open('README.md', 'r') as fh:
    mlGAGlxVoITHloZjVFUfEeYYgdBKKQTT = fh.read()
setuptools.setup(name='covidcast', version='0.2.2', author='Alex Reinhart',
    fJNMKryaGpIICRIMiPiYlvTEOUfyurug='areinhar@stat.cmu.edu', description=
    'Access COVID-19 data through the Delphi COVIDcast API',
    mlGAGlxVoITHloZjVFUfEeYYgdBKKQTT=mlGAGlxVoITHloZjVFUfEeYYgdBKKQTT, long_description_content_type=
    'text/markdown', url=
    'https://cmu-delphi.github.io/covidcast/covidcast-py/html/', packages=
    setuptools.find_packages(), classifiers=[
    'Programming Language :: Python :: 3',
    'License :: OSI Approved :: MIT License',
    'Operating System :: OS Independent'], python_requires='>=3.6',
    dkSebHCAEHbCRbcSKtxuDLdBbzZxqEBd=['pandas<2', 'requests',
    'delphi-epidata>=4.1.11,==4.*', 'geopandas', 'matplotlib', 'numpy',
    'descartes', 'imageio-ffmpeg', 'imageio', 'tqdm', 'epiweeks'],
    EDeRXsuMSwAqZyajBBICcnTsqbjpjRoL={'covidcast': ['shapefiles/*/*', 'geo_mappings/*']})
