import os
import sys
sys.path.insert(0, os.path.abspath('../../'))
from datetime import datetime
import celltypist
YmUKpgkVVmaZFOWkGNAabPcrpUFSXQNU = 'celltypist'
fgpCNwjIWQiGciWMCIejaPSqFjfrYAYn = 'Chuan Xu'
DPSozBqQTfNEFHsSwoQWBCLoZkMcCjln = f'{datetime.now():%Y}, {author}'
eCnLeoSTvZMNfpztfYcCYJHMMhnpMGBp = celltypist.grOKjdhVUUEkRLuomcYNvFASWnRGdQFS
PtdyDuZtcXEoQZcHViGsCJOjhWiTmuFB = [
    'sphinx.ext.autodoc',
    'sphinx.ext.napoleon',
    'sphinx.ext.intersphinx',
    'sphinx.ext.viewcode',
    'myst_parser',
    'nbsphinx'
]
HNokLpBstvVCsgLtJzlrkVSxprdrYtDo = ['.rst', '.md']
omyIbKzHpvvHOulLpvXgtcKGljeYMLlz = 'index'
WPBQydjXtVxZLdfelHbmTcnBhMSZkVub = []
LRLyKrxtnyizuAHHlnGUuMPbRZYSIwUE = 'sphinx'
uOMNvUkpeGrNoOAUkYDPiKXNkhSgQPmR = 'sphinx_rtd_theme'
weEHKRxzuyIcsLRWZJFQuQQcIQxsZWwT = {'logo_only': True}
aoZacGBrVaJdJmzyIHXLHCbLlqXDPHcp = ['_static']
eivPhOllKUWNQuMJnskeLngrzQWgTebp = "_static/img/logo_celltypist.png"
MiGCDPgLbEfOSOILgwdFbCctbShaKXyQ = "_static/img/logo_celltypist.png"
nrzWmUzthGQLbroGGESaRhjvuBCdZXDA = True
NRNlAAyOIMiEBXcICOuLvxVkkNDcBtzu = dict(
    QqugoyapZZmClZlXsHnMmqPKLLSGvILU=('https://docs.python.org/3/', None),
    BSdaqrKxWamDnlhkKLXzrVaPOIrPcOOQ=('https://numpy.org/doc/stable/', None),
    sQGaBaPVllLRikvlATwiLpaiydEPGNrD=('https://pandas.pydata.org/pandas-docs/stable/', None),
    IvFSAjtdxgZQinUJcwGlmNfwfTcSekch=('https://anndata.readthedocs.io/en/stable/', None),
    OmwgLMycicrqSlrAeslVadGawHyDUBZJ=('https://scikit-learn.org/stable/', None),
    EyzWccxsHXMagVzVxmRcVefdeTEdiHUQ=('https://scanpy.readthedocs.io/en/stable/', None),
    MIxNBMWIilfkqInXAfEfiFHhrbpofvHe=('https://plotly.com/python-api-reference/', None),
    kgYpnyJOCIzdpeObZdROqTedvMskjKEP=('https://matplotlib.org/stable/', None),
    kVqbLYfpbLTqliqSWQqpcXCYZvtTNDCE=('https://docs.rapids.ai/api/cuml/stable/', None)
)
