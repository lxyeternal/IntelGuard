import os
import sys
from typing import Optional, Union
import scanpy as sc
from anndata import AnnData
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from .models import BnzGOEgqTnYensxoqtWNlisVwRaeXKPk
from . import QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=UserWarning)
warnings.simplefilter(action='ignore', category=RuntimeWarning)
try:
    import rapids_singlecell as rsc
except ImportError:
    pass
class VclreaWVGpuavOABclRCviWPgTIttoyx():
    def __init__(self, IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS: pd.DataFrame, vhUktzNubGxzfQrRlkfcWeREGZqHLJci: pd.DataFrame, DGMPOogwUSSMBSAdmMJFemmxRQKINLFo: pd.DataFrame, gIFkEFyIHtxZygbuxtLtLZOexWSLUYca: AnnData):
        self.predicted_labels = IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS
        self.decision_matrix = vhUktzNubGxzfQrRlkfcWeREGZqHLJci
        self.probability_matrix = DGMPOogwUSSMBSAdmMJFemmxRQKINLFo
        self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca = gIFkEFyIHtxZygbuxtLtLZOexWSLUYca
        self.cell_count = IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS.shape[0]
    def NKDAbIPXXmLSyVxMUaRgNdDNlewfgJJW(self, by: str = 'predicted_labels') -> pd.DataFrame:
        cNOItjkXBKNYniYhwbTjsJpKxHZqsbNY, VpUteGhrgUpienzBUjjCzgaWPjwXHOUn = np.cNOItjkXBKNYniYhwbTjsJpKxHZqsbNY(self.predicted_labels[by], return_counts=True)
        thyejXvDQZxsyrZrKHzlhRLoSNFxcIpA = pd.DataFrame(list(zip(cNOItjkXBKNYniYhwbTjsJpKxHZqsbNY, VpUteGhrgUpienzBUjjCzgaWPjwXHOUn)), columns=["celltype", "counts"])
        thyejXvDQZxsyrZrKHzlhRLoSNFxcIpA.sort_values(['counts'], ascending=False, inplace=True)
        return thyejXvDQZxsyrZrKHzlhRLoSNFxcIpA
    def LDgXMBvgdyrcaRGGNIrCEuxfZblPkEGd(self, insert_labels: bool = True, insert_conf: bool = True, insert_conf_by: str = 'predicted_labels', insert_decision: bool = False, insert_prob: bool = False, prefix: str = '') -> AnnData:
        if insert_labels:
            self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obs[[f"{prefix}{x}" for snCjAGJxAvKdIqJWNtlyHcUEofNVEYrH in self.predicted_labels.columns]] = self.predicted_labels
        if insert_conf:
            if insert_conf_by == 'predicted_labels':
                self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obs[f"{prefix}conf_score"] = self.probability_matrix.max(axis=1).values
            elif insert_conf_by == 'majority_voting':
                if insert_conf_by not in self.predicted_labels:
                    raise KeyError(
                            f"🛑 Did not find the column `majority_voting` in the `AnnotationResult.predicted_labels`, perform majority voting beforehand or use `insert_conf_by = 'predicted_labels'` instead")
                self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obs[f"{prefix}conf_score"] = [hlVYcwhTwObNWTFbPRxjLJfzOTIhdBlS[self.predicted_labels.EfrkPJJBjZqrczfFKgPscIzvhhUVhEFi[index]] if self.predicted_labels.EfrkPJJBjZqrczfFKgPscIzvhhUVhEFi[index] in hlVYcwhTwObNWTFbPRxjLJfzOTIhdBlS.index else hlVYcwhTwObNWTFbPRxjLJfzOTIhdBlS.max() for index, hlVYcwhTwObNWTFbPRxjLJfzOTIhdBlS in self.probability_matrix.iterrows()]
            else:
                raise KeyError(
                        f"🛑 Unrecognized `insert_conf_by` value ('{insert_conf_by}'), should be one of `'predicted_labels'` or `'majority_voting'`")
        if insert_prob:
            self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obs[[f"{prefix}{x}" for snCjAGJxAvKdIqJWNtlyHcUEofNVEYrH in self.probability_matrix.columns]] = self.probability_matrix
        elif insert_decision:
            self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obs[[f"{prefix}{x}" for snCjAGJxAvKdIqJWNtlyHcUEofNVEYrH in self.decision_matrix.columns]] = self.decision_matrix
        return self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca
    def yXOkcxuiRXktTvZvihEZOVOQeOJkgEpO(self, folder: str, plot_probability: bool = False, format: str = 'pdf', prefix: str = '') -> None:
        if not os.path.isdir(folder):
            raise FileNotFoundError(
                    f"🛑 Output folder {folder} does not exist. Please provide a valid folder")
        if 'X_umap' in self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obsm:
            QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv("👀 Detected existing UMAP coordinates, will plot the results accordingly")
        elif 'connectivities' in self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obsp:
            QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv("🧙 Generating UMAP coordinates based on the neighborhood graph")
            sc.tl.umap(self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca)
        else:
            QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv("🧙 Constructing the neighborhood graph and generating UMAP coordinates")
            gIFkEFyIHtxZygbuxtLtLZOexWSLUYca = self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.copy()
            self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obsm['X_pca'], self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obsp['connectivities'], self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obsp['distances'], self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.uns['neighbors'] = ktiKeRPdqBWEcuNCVwBwyrjRKymMZbkf.wNiUAUowQewSKjBdRwxpYjlAkDPbXdOj(gIFkEFyIHtxZygbuxtLtLZOexWSLUYca)
            sc.tl.umap(self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca)
        QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv("📈 Plotting the results")
        sc.settings.set_figure_params(figsize=[6.4, 6.4], format=format)
        self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obs[self.predicted_labels.columns] = self.predicted_labels
        for EGOZTsjYaFEJCqaVuJxRIKLuuORMPCDu in self.predicted_labels:
            sc.pl.umap(self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca, color = EGOZTsjYaFEJCqaVuJxRIKLuuORMPCDu, legend_loc = 'on data', qSrBGFEWqqHNUyTcIFIPSCyOHPtdrUCx = False, legend_fontweight = 'normal', title = EGOZTsjYaFEJCqaVuJxRIKLuuORMPCDu.replace('_', ' '))
            plt.savefig(os.path.join(folder, prefix + EGOZTsjYaFEJCqaVuJxRIKLuuORMPCDu + '.' + format))
            plt.close()
        if plot_probability:
            for EGOZTsjYaFEJCqaVuJxRIKLuuORMPCDu in self.probability_matrix:
                self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obs['decision score'] = self.decision_matrix[EGOZTsjYaFEJCqaVuJxRIKLuuORMPCDu]
                self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obs['probability'] = self.probability_matrix[EGOZTsjYaFEJCqaVuJxRIKLuuORMPCDu]
                sc.pl.umap(self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca, color = ['decision score', 'probability'], qSrBGFEWqqHNUyTcIFIPSCyOHPtdrUCx = False)
                plt.savefig(os.path.join(folder, prefix + EGOZTsjYaFEJCqaVuJxRIKLuuORMPCDu.replace('/','_') + '.' + format))
                plt.close()
            self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obs.drop(columns=['decision score', 'probability'], inplace=True)
    def yhQETExwIKaeemmkzSMDCoFNQEJNJkoO(self, folder: str, prefix: str = '', xlsx: bool = False) -> None:
        if not os.path.isdir(folder):
            raise FileNotFoundError(
                    f"🛑 Output folder {folder} does not exist. Please provide a valid folder")
        if not xlsx:
            self.predicted_labels.to_csv(os.path.join(folder, f"{prefix}predicted_labels.csv"))
            self.decision_matrix.to_csv(os.path.join(folder, f"{prefix}decision_matrix.csv"))
            self.probability_matrix.to_csv(os.path.join(folder, f"{prefix}probability_matrix.csv"))
        else:
            with pd.ExcelWriter(os.path.join(folder, f"{prefix}annotation_result.xlsx")) as writer:
                self.predicted_labels.to_excel(writer, sheet_name="Predicted Labels")
                self.decision_matrix.to_excel(writer, sheet_name="Decision Matrix")
                self.probability_matrix.to_excel(writer, sheet_name="Probability Matrix")
    def __repr__(self):
        MvKrDDmpJAharVxbfJigljiECBXjuyRg = f"CellTypist prediction result for {self.cell_count} query cells"
        MvKrDDmpJAharVxbfJigljiECBXjuyRg += f"\n    predicted_labels: data frame with {self.predicted_labels.shape[1]} {'columns' if self.predicted_labels.shape[1] > 1 else 'column'} ({str(list(self.predicted_labels.columns))[1:-1]})"
        MvKrDDmpJAharVxbfJigljiECBXjuyRg += f"\n    decision_matrix: data frame with {self.cell_count} query cells and {self.decision_matrix.shape[1]} cell types"
        MvKrDDmpJAharVxbfJigljiECBXjuyRg += f"\n    probability_matrix: data frame with {self.cell_count} query cells and {self.probability_matrix.shape[1]} cell types"
        MvKrDDmpJAharVxbfJigljiECBXjuyRg += f"\n    adata: AnnData object referred"
        return MvKrDDmpJAharVxbfJigljiECBXjuyRg
class ktiKeRPdqBWEcuNCVwBwyrjRKymMZbkf():
    def __init__(self, qjWsTlbTLNDLdTBvMHHSOzvRuXapYPOx: Union[AnnData,str] = "", tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP: Union[BnzGOEgqTnYensxoqtWNlisVwRaeXKPk,str] = "", transpose: bool = False, mDoktnNgmjTLAVkmkKokOHavIYwmeRCx: Optional[str] = None, HPdelTJhlbuzReKhVEodDsecYLKXVfsl: Optional[str] = None):
        if isinstance(tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP, str):
            tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP = BnzGOEgqTnYensxoqtWNlisVwRaeXKPk.THzQBFPCnBuADUGPJMLmpMcQUtnMpFMu(tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP)
        self.tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP = tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP
        if not qjWsTlbTLNDLdTBvMHHSOzvRuXapYPOx:
            QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.cqOkzJCPuYbFNHPhlrlXPGSWXTLNKTnx(f"📭 No input file provided to the classifier")
            return
        if isinstance(qjWsTlbTLNDLdTBvMHHSOzvRuXapYPOx, str):
            self.qjWsTlbTLNDLdTBvMHHSOzvRuXapYPOx = qjWsTlbTLNDLdTBvMHHSOzvRuXapYPOx
            QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv(f"📁 Input file is '{self.qjWsTlbTLNDLdTBvMHHSOzvRuXapYPOx}'")
            QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv(f"⏳ Loading data")
        if isinstance(qjWsTlbTLNDLdTBvMHHSOzvRuXapYPOx, str) and qjWsTlbTLNDLdTBvMHHSOzvRuXapYPOx.endswith(('.csv', '.txt', '.tsv', '.tab', '.mtx', '.mtx.gz')):
            self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca = sc.read(self.qjWsTlbTLNDLdTBvMHHSOzvRuXapYPOx)
            if transpose:
                self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca = self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.transpose()
            if self.qjWsTlbTLNDLdTBvMHHSOzvRuXapYPOx.endswith(('.mtx', '.mtx.gz')):
                if (mDoktnNgmjTLAVkmkKokOHavIYwmeRCx is None) or (HPdelTJhlbuzReKhVEodDsecYLKXVfsl is None):
                    raise FileNotFoundError(
                            "🛑 Missing `gene_file` and/or `cell_file`. Please provide both arguments together with the input mtx file")
                RyjLbcdfjhXfcqdWqPNLNhFdYYLSrjIs = pd.read_csv(mDoktnNgmjTLAVkmkKokOHavIYwmeRCx, header=None)[0].values
                tOdPQiqYWDjeuIhjVeBsYTYGDFZxEYHk = pd.read_csv(HPdelTJhlbuzReKhVEodDsecYLKXVfsl, header=None)[0].values
                if len(RyjLbcdfjhXfcqdWqPNLNhFdYYLSrjIs) != self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.n_vars:
                    raise ValueError(
                            f"🛑 The number of genes in {gene_file} does not match the number of genes in {self.filename}")
                if len(tOdPQiqYWDjeuIhjVeBsYTYGDFZxEYHk) != self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.n_obs:
                    raise ValueError(
                            f"🛑 The number of cells in {cell_file} does not match the number of cells in {self.filename}")
                self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.var_names = RyjLbcdfjhXfcqdWqPNLNhFdYYLSrjIs
                self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obs_names = tOdPQiqYWDjeuIhjVeBsYTYGDFZxEYHk
            if not float(self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.X[:1000].max()).is_integer():
                QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.cqOkzJCPuYbFNHPhlrlXPGSWXTLNKTnx(f"⚠️ Warning: the input file seems not a raw count matrix. The prediction result may not be accurate")
            if (self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.n_vars >= 100000) or (len(self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.var_names[0]) >= 30) or (len(self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obs_names.intersection(['GAPDH', 'ACTB', 'CALM1', 'PTPRC', 'MALAT1'])) >= 1):
                QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.cqOkzJCPuYbFNHPhlrlXPGSWXTLNKTnx(f"⚠️ The input matrix is detected to be a gene-by-cell matrix, will transpose it")
                self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca = self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.transpose()
            self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.var_names_make_unique()
            sc.pp.normalize_total(self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca, target_sum=1e4)
            sc.pp.log1p(self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca)
            self.WfNwDmJAjhHXNonldtmSHteAZkNbgRun = self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.X
            self.indata_genes = self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.var_names
            self.indata_names = self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obs_names
        elif isinstance(qjWsTlbTLNDLdTBvMHHSOzvRuXapYPOx, AnnData) or (isinstance(qjWsTlbTLNDLdTBvMHHSOzvRuXapYPOx, str) and qjWsTlbTLNDLdTBvMHHSOzvRuXapYPOx.endswith('.h5ad')):
            self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca = sc.read(qjWsTlbTLNDLdTBvMHHSOzvRuXapYPOx) if isinstance(qjWsTlbTLNDLdTBvMHHSOzvRuXapYPOx, str) else qjWsTlbTLNDLdTBvMHHSOzvRuXapYPOx
            self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.var_names_make_unique()
            if (self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.X[:1000].min() < 0) or (self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.X[:1000].max() > 9.22):
                if not self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.raw:
                    raise ValueError(
                            "🛑 Invalid expression matrix in `.X`, expect log1p normalized expression to 10000 counts per cell")
                elif (self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.raw.X[:1000].min() < 0) or (self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.raw.X[:1000].max() > 9.22):
                    raise ValueError(
                            "🛑 Invalid expression matrix in both `.X` and `.raw.X`, expect log1p normalized expression to 10000 counts per cell")
                else:
                    QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv("👀 Invalid expression matrix in `.X`, expect log1p normalized expression to 10000 counts per cell; will use `.raw.X` instead")
                    self.WfNwDmJAjhHXNonldtmSHteAZkNbgRun = self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.raw.X
                    self.indata_genes = self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.raw.var_names
                    self.indata_names = self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.raw.obs_names
            else:
                self.WfNwDmJAjhHXNonldtmSHteAZkNbgRun = self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.X
                self.indata_genes = self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.var_names
                self.indata_names = self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obs_names
            if np.abs(np.expm1(self.WfNwDmJAjhHXNonldtmSHteAZkNbgRun[0]).sum()-10000) > 1:
                QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.cqOkzJCPuYbFNHPhlrlXPGSWXTLNKTnx(f"⚠️ Warning: invalid expression matrix, expect ALL genes and log1p normalized expression to 10000 counts per cell. The prediction result may not be accurate")
        else:
            raise ValueError(
                    "🛑 Invalid input. Supported types: .csv, .txt, .tsv, .tab, .mtx, .mtx.gz and .h5ad, or AnnData loaded in memory")
        QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv(f"🔬 Input data has {self.indata.shape[0]} cells and {len(self.indata_genes)} genes")
    def FZOJnQPYltlJHFAuFIjGiSmaFTTtJpAZ(self, KHvvGDKFlaashZlaSeTgRMPwCUHsJUFS: str = 'best match', wokykibVYkkZatVyEboULMQUJdFfMvwv: float = 0.5) -> VclreaWVGpuavOABclRCviWPgTIttoyx:
        QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv(f"🔗 Matching reference genes in the model")
        uGJEliGUeMbKkVgFYUVNolvifeIPLnSg = np.isin(self.indata_genes, self.tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP.pNXJRhNezfTHMFOReigergVLwmwiNrft.plOSBmvdKJMFNMONmLAhLoGoJtKOuVvK)
        if uGJEliGUeMbKkVgFYUVNolvifeIPLnSg.sum() == 0:
            raise ValueError(
                    f"🛑 No features overlap with the model. Please provide gene symbols")
        else:
            QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv(f"🧬 {k_x.sum()} features used for prediction")
        lvjyEkIEDcopTkappuYGnlxYiaMcIIfX = np.where(uGJEliGUeMbKkVgFYUVNolvifeIPLnSg)[0]
        self.indata_genes = self.indata_genes[lvjyEkIEDcopTkappuYGnlxYiaMcIIfX]
        emSZyWcuLnafXNoOlREehloZKsIHEXsN = pd.DataFrame(self.tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP.pNXJRhNezfTHMFOReigergVLwmwiNrft.plOSBmvdKJMFNMONmLAhLoGoJtKOuVvK, columns=['features']).reset_index().set_index('features').loc[self.indata_genes, 'index'].values
        QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv(f"⚖️ Scaling input data")
        BtQbtyLOPhuqdOamzZTHMPBAJClsmtkR = self.tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP.aNsgKPdVZwfdNSQQxlnnomJSMfdyNtda.mean_[emSZyWcuLnafXNoOlREehloZKsIHEXsN] if self.tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP.aNsgKPdVZwfdNSQQxlnnomJSMfdyNtda.with_mean else 0
        pzPUXlpuHGDwnXKFSAxBecYjgVzhlyPF = self.tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP.aNsgKPdVZwfdNSQQxlnnomJSMfdyNtda.scale_[emSZyWcuLnafXNoOlREehloZKsIHEXsN]
        self.WfNwDmJAjhHXNonldtmSHteAZkNbgRun = (self.WfNwDmJAjhHXNonldtmSHteAZkNbgRun[:, lvjyEkIEDcopTkappuYGnlxYiaMcIIfX] - BtQbtyLOPhuqdOamzZTHMPBAJClsmtkR) / pzPUXlpuHGDwnXKFSAxBecYjgVzhlyPF
        self.WfNwDmJAjhHXNonldtmSHteAZkNbgRun[self.WfNwDmJAjhHXNonldtmSHteAZkNbgRun > 10] = 10
        lwuDTjnMugurTXtpMDLhySeZxoEKLQbz, vWqxZFOCuQasjzkEuvWINefnzQqgmheX, FAPxlVSBxfGXRRutoCvXcZSrRkOknhwt = self.tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP.pNXJRhNezfTHMFOReigergVLwmwiNrft.n_features_in_, self.tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP.pNXJRhNezfTHMFOReigergVLwmwiNrft.plOSBmvdKJMFNMONmLAhLoGoJtKOuVvK, self.tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP.pNXJRhNezfTHMFOReigergVLwmwiNrft.coef_
        self.tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP.pNXJRhNezfTHMFOReigergVLwmwiNrft.n_features_in_ = emSZyWcuLnafXNoOlREehloZKsIHEXsN.size
        self.tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP.pNXJRhNezfTHMFOReigergVLwmwiNrft.plOSBmvdKJMFNMONmLAhLoGoJtKOuVvK = self.tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP.pNXJRhNezfTHMFOReigergVLwmwiNrft.plOSBmvdKJMFNMONmLAhLoGoJtKOuVvK[emSZyWcuLnafXNoOlREehloZKsIHEXsN]
        self.tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP.pNXJRhNezfTHMFOReigergVLwmwiNrft.coef_ = self.tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP.pNXJRhNezfTHMFOReigergVLwmwiNrft.coef_[:, emSZyWcuLnafXNoOlREehloZKsIHEXsN]
        QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv("🖋️ Predicting labels")
        vhUktzNubGxzfQrRlkfcWeREGZqHLJci, DGMPOogwUSSMBSAdmMJFemmxRQKINLFo, GpvuUhbHDWQlCwHjimJBpIrbFKmgHUHO = self.tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP.RQnnAEbNsTzKCEEbtnQaSxMsWOtEApAH(self.WfNwDmJAjhHXNonldtmSHteAZkNbgRun, KHvvGDKFlaashZlaSeTgRMPwCUHsJUFS = KHvvGDKFlaashZlaSeTgRMPwCUHsJUFS, wokykibVYkkZatVyEboULMQUJdFfMvwv = wokykibVYkkZatVyEboULMQUJdFfMvwv)
        QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv("✅ Prediction done!")
        self.tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP.pNXJRhNezfTHMFOReigergVLwmwiNrft.n_features_in_, self.tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP.pNXJRhNezfTHMFOReigergVLwmwiNrft.plOSBmvdKJMFNMONmLAhLoGoJtKOuVvK, self.tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP.pNXJRhNezfTHMFOReigergVLwmwiNrft.coef_ = lwuDTjnMugurTXtpMDLhySeZxoEKLQbz, vWqxZFOCuQasjzkEuvWINefnzQqgmheX, FAPxlVSBxfGXRRutoCvXcZSrRkOknhwt
        seALLtFsfOFrdWBbckiaBhOPZimFUWrb = self.indata_names
        return VclreaWVGpuavOABclRCviWPgTIttoyx(pd.DataFrame(GpvuUhbHDWQlCwHjimJBpIrbFKmgHUHO, columns=['predicted_labels'], index=seALLtFsfOFrdWBbckiaBhOPZimFUWrb, dtype='category'), pd.DataFrame(vhUktzNubGxzfQrRlkfcWeREGZqHLJci, columns=self.tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP.pNXJRhNezfTHMFOReigergVLwmwiNrft.classes_, index=seALLtFsfOFrdWBbckiaBhOPZimFUWrb), pd.DataFrame(DGMPOogwUSSMBSAdmMJFemmxRQKINLFo, columns=self.tVscCtTvxtUiQwImcjtmXIPwHNOsmPXP.pNXJRhNezfTHMFOReigergVLwmwiNrft.classes_, index=seALLtFsfOFrdWBbckiaBhOPZimFUWrb), self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca)
    @staticmethod
    def wNiUAUowQewSKjBdRwxpYjlAkDPbXdOj(gIFkEFyIHtxZygbuxtLtLZOexWSLUYca: AnnData, fUSsgEPmNHPZRkIuPEHPtCETMTwCrYdT: bool = False) -> tuple:
        YLTiPdJcClaZHuUipzvzynIlhHalNHVo = rsc if fUSsgEPmNHPZRkIuPEHPtCETMTwCrYdT else sc
        if 'log1p' in gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.uns.keys():
            if isinstance(gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.uns['log1p'], dict) and 'base' not in gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.uns['log1p'].keys():
                gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.uns['log1p']['base'] = None
        if 'X_pca' not in gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obsm.keys():
            if gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.X[:1000].min() < 0:
                gIFkEFyIHtxZygbuxtLtLZOexWSLUYca = gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.raw.LDgXMBvgdyrcaRGGNIrCEuxfZblPkEGd()
            if fUSsgEPmNHPZRkIuPEHPtCETMTwCrYdT:
                YLTiPdJcClaZHuUipzvzynIlhHalNHVo.get.anndata_to_GPU(gIFkEFyIHtxZygbuxtLtLZOexWSLUYca)
            if 'highly_variable' not in gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.var:
                sc.pp.filter_genes(gIFkEFyIHtxZygbuxtLtLZOexWSLUYca, min_cells=5)
                YLTiPdJcClaZHuUipzvzynIlhHalNHVo.pp.highly_variable_genes(gIFkEFyIHtxZygbuxtLtLZOexWSLUYca, n_top_genes = min([2500, gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.n_vars]))
            gIFkEFyIHtxZygbuxtLtLZOexWSLUYca = gIFkEFyIHtxZygbuxtLtLZOexWSLUYca[:, gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.var.highly_variable]
            YLTiPdJcClaZHuUipzvzynIlhHalNHVo.pp.scale(gIFkEFyIHtxZygbuxtLtLZOexWSLUYca, max_value=10)
            YLTiPdJcClaZHuUipzvzynIlhHalNHVo.pp.pca(gIFkEFyIHtxZygbuxtLtLZOexWSLUYca, n_comps=50)
        YLTiPdJcClaZHuUipzvzynIlhHalNHVo.pp.neighbors(gIFkEFyIHtxZygbuxtLtLZOexWSLUYca, n_neighbors=10, n_pcs=50)
        return gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obsm['X_pca'], gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obsp['connectivities'], gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obsp['distances'], gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.uns['neighbors']
    def kGiWQsFBIIiFoeyDTUNVgQPCmNZVgczE(self, sxnqobVviXYvLqdmdWUrJelYNQkVjZXV: Optional[float] = None, fUSsgEPmNHPZRkIuPEHPtCETMTwCrYdT: bool = False) -> pd.Series:
        if fUSsgEPmNHPZRkIuPEHPtCETMTwCrYdT and 'rapids_singlecell' not in sys.modules:
            QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.cqOkzJCPuYbFNHPhlrlXPGSWXTLNKTnx("⚠️ Warning: rapids_singlecell is not installed but required for GPU running, will switch back to CPU")
            fUSsgEPmNHPZRkIuPEHPtCETMTwCrYdT = False
        if 'connectivities' not in self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obsp:
            QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv("👀 Can not detect a neighborhood graph, will construct one before the over-clustering")
            gIFkEFyIHtxZygbuxtLtLZOexWSLUYca = self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.copy()
            self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obsm['X_pca'], self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obsp['connectivities'], self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obsp['distances'], self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.uns['neighbors'] = ktiKeRPdqBWEcuNCVwBwyrjRKymMZbkf.wNiUAUowQewSKjBdRwxpYjlAkDPbXdOj(gIFkEFyIHtxZygbuxtLtLZOexWSLUYca, fUSsgEPmNHPZRkIuPEHPtCETMTwCrYdT)
        else:
            QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv("👀 Detected a neighborhood graph in the input object, will run over-clustering on the basis of it")
        if sxnqobVviXYvLqdmdWUrJelYNQkVjZXV is None:
            if self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.n_obs < 5000:
                sxnqobVviXYvLqdmdWUrJelYNQkVjZXV = 5
            elif self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.n_obs < 20000:
                sxnqobVviXYvLqdmdWUrJelYNQkVjZXV = 10
            elif self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.n_obs < 40000:
                sxnqobVviXYvLqdmdWUrJelYNQkVjZXV = 15
            elif self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.n_obs < 100000:
                sxnqobVviXYvLqdmdWUrJelYNQkVjZXV = 20
            elif self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.n_obs < 200000:
                sxnqobVviXYvLqdmdWUrJelYNQkVjZXV = 25
            else:
                sxnqobVviXYvLqdmdWUrJelYNQkVjZXV = 30
        QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv(f"⛓️ Over-clustering input data with resolution set to {resolution}")
        if fUSsgEPmNHPZRkIuPEHPtCETMTwCrYdT:
            rsc.tl.leiden(self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca, sxnqobVviXYvLqdmdWUrJelYNQkVjZXV=sxnqobVviXYvLqdmdWUrJelYNQkVjZXV, key_added='over_clustering')
        else:
            sc.tl.leiden(self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca, sxnqobVviXYvLqdmdWUrJelYNQkVjZXV=sxnqobVviXYvLqdmdWUrJelYNQkVjZXV, key_added='over_clustering')
        return self.gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obs.pop('over_clustering')
    @staticmethod
    def DsqCqADMFrCwlqzrGDqDGJtrVxHDseWX(NpTsfIWZDYUyKPtbESSBpFAzvCNxKLyK: VclreaWVGpuavOABclRCviWPgTIttoyx, NmCQrkDqSXIofdSuRnDfLUXfefMRoTWZ: Union[list, tuple, np.ndarray, pd.Series, pd.Index], qVnrukvHtFgywPYrxjeFECqKCNUjGKOP: float = 0) -> VclreaWVGpuavOABclRCviWPgTIttoyx:
        if isinstance(NmCQrkDqSXIofdSuRnDfLUXfefMRoTWZ, (list, tuple)):
            NmCQrkDqSXIofdSuRnDfLUXfefMRoTWZ = np.array(NmCQrkDqSXIofdSuRnDfLUXfefMRoTWZ)
        QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv("🗳️ Majority voting the predictions")
        PITwWknSqYlkkuCKMbgIhuyeCzQKwipF = pd.crosstab(NpTsfIWZDYUyKPtbESSBpFAzvCNxKLyK.predicted_labels['predicted_labels'], NmCQrkDqSXIofdSuRnDfLUXfefMRoTWZ)
        JQrWXQISeqeYSOlKuGPUziylmljjNgWV = PITwWknSqYlkkuCKMbgIhuyeCzQKwipF.idxmax(axis=0).astype(str)
        qydwKVddCwDcaKPWMZSIOKZBLUebuJvy = (PITwWknSqYlkkuCKMbgIhuyeCzQKwipF / PITwWknSqYlkkuCKMbgIhuyeCzQKwipF.sum(axis=0).values).max(axis=0)
        JQrWXQISeqeYSOlKuGPUziylmljjNgWV[qydwKVddCwDcaKPWMZSIOKZBLUebuJvy < qVnrukvHtFgywPYrxjeFECqKCNUjGKOP] = 'Heterogeneous'
        JQrWXQISeqeYSOlKuGPUziylmljjNgWV = JQrWXQISeqeYSOlKuGPUziylmljjNgWV[NmCQrkDqSXIofdSuRnDfLUXfefMRoTWZ].reset_index()
        JQrWXQISeqeYSOlKuGPUziylmljjNgWV.index = NpTsfIWZDYUyKPtbESSBpFAzvCNxKLyK.predicted_labels.index
        JQrWXQISeqeYSOlKuGPUziylmljjNgWV.columns = ['over_clustering', 'majority_voting']
        JQrWXQISeqeYSOlKuGPUziylmljjNgWV['majority_voting'] = JQrWXQISeqeYSOlKuGPUziylmljjNgWV['majority_voting'].astype('category')
        NpTsfIWZDYUyKPtbESSBpFAzvCNxKLyK.predicted_labels = NpTsfIWZDYUyKPtbESSBpFAzvCNxKLyK.predicted_labels.join(JQrWXQISeqeYSOlKuGPUziylmljjNgWV)
        QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv("✅ Majority voting done!")
        return NpTsfIWZDYUyKPtbESSBpFAzvCNxKLyK
