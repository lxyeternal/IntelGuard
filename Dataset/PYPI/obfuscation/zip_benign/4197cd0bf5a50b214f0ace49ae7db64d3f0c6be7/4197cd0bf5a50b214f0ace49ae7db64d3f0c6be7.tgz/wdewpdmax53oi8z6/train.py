import numpy as np
import pandas as pd
import scanpy as sc
from anndata import AnnData
from sklearn.preprocessing import StandardScaler,LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import SGDClassifier
from sklearn import grOKjdhVUUEkRLuomcYNvFASWnRGdQFS as skv
from typing import Optional, Union
from .models import BnzGOEgqTnYensxoqtWNlisVwRaeXKPk
from . import QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu
from scipy.sparse import spmatrix
from datetime import datetime
import sys
try:
    from cuml import LogisticRegression as cuLogisticRegression
except ImportError:
    pass
def OZKfeucezfHlKVQtNhIgRWdJwoQVwFzx(_vector_or_file):
    if isinstance(_vector_or_file, str):
        try:
            return pd.read_csv(_vector_or_file, header=None)[0].values
        except Exception as wEuqXZMuNefZAtKqLAafUblfDrhgiYSr:
            raise Exception(
                    f"🛑 {e}")
    else:
        return _vector_or_file
def WcYfupuXtTNMLLlpJRGDknjozkRwOZif(_array_like) -> np.ndarray:
    if isinstance(_array_like, pd.DataFrame):
        return _array_like.values
    elif isinstance(_array_like, spmatrix):
        return _array_like.toarray()
    elif isinstance(_array_like, np.matrix):
        return np.array(_array_like)
    elif isinstance(_array_like, np.ndarray):
        return _array_like
    else:
        raise TypeError(
                f"🛑 Please provide a valid array-like object as input")
def lUnpcjTujAidSKxRgkjgRjtPCOziIiJs(X, IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS, CVmtDIyHCRyGslrApDcuSflgxNKWznEX, transpose) -> tuple:
    if (X is None) or (IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS is None):
        raise Exception(
                "🛑 Missing training data and/or training labels. Please provide both arguments")
    if isinstance(X, AnnData) or (isinstance(X, str) and X.endswith('.h5ad')):
        gIFkEFyIHtxZygbuxtLtLZOexWSLUYca = sc.read(X) if isinstance(X, str) else X
        gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.var_names_make_unique()
        if gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.X[:1000].min() < 0:
            QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv("👀 Detected scaled expression in the input data, will try the .raw attribute")
            try:
                WfNwDmJAjhHXNonldtmSHteAZkNbgRun = gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.raw.X
                CVmtDIyHCRyGslrApDcuSflgxNKWznEX = gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.raw.var_names
            except Exception as wEuqXZMuNefZAtKqLAafUblfDrhgiYSr:
                raise Exception(
                        f"🛑 Fail to use the .raw attribute in the input object. {e}")
        else:
            WfNwDmJAjhHXNonldtmSHteAZkNbgRun = gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.X
            CVmtDIyHCRyGslrApDcuSflgxNKWznEX = gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.var_names
        if isinstance(IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS, str) and (IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS in gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obs):
            IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS = gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.obs[IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS]
        else:
            IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS = OZKfeucezfHlKVQtNhIgRWdJwoQVwFzx(IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS)
    elif isinstance(X, str) and X.endswith(('.csv', '.txt', '.tsv', '.tab', '.mtx', '.mtx.gz')):
        gIFkEFyIHtxZygbuxtLtLZOexWSLUYca = sc.read(X)
        if transpose:
            gIFkEFyIHtxZygbuxtLtLZOexWSLUYca = gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.transpose()
        if X.endswith(('.mtx', '.mtx.gz')):
            if CVmtDIyHCRyGslrApDcuSflgxNKWznEX is None:
                raise Exception(
                        "🛑 Missing `genes`. Please provide this argument together with the input mtx file")
            CVmtDIyHCRyGslrApDcuSflgxNKWznEX = OZKfeucezfHlKVQtNhIgRWdJwoQVwFzx(CVmtDIyHCRyGslrApDcuSflgxNKWznEX)
            if len(CVmtDIyHCRyGslrApDcuSflgxNKWznEX) != gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.n_vars:
                raise ValueError(
                        f"🛑 The number of genes provided does not match the number of genes in {X}")
            gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.var_names = np.array(CVmtDIyHCRyGslrApDcuSflgxNKWznEX)
        gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.var_names_make_unique()
        if not float(gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.X[:1000].max()).is_integer():
            QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.cqOkzJCPuYbFNHPhlrlXPGSWXTLNKTnx(f"⚠️ Warning: the input file seems not a raw count matrix. The trained model may be biased")
        sc.pp.normalize_total(gIFkEFyIHtxZygbuxtLtLZOexWSLUYca, target_sum=1e4)
        sc.pp.log1p(gIFkEFyIHtxZygbuxtLtLZOexWSLUYca)
        WfNwDmJAjhHXNonldtmSHteAZkNbgRun = gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.X
        CVmtDIyHCRyGslrApDcuSflgxNKWznEX = gIFkEFyIHtxZygbuxtLtLZOexWSLUYca.var_names
        IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS = OZKfeucezfHlKVQtNhIgRWdJwoQVwFzx(IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS)
    elif isinstance(X, str):
        raise ValueError(
                "🛑 Invalid input. Supported types: .csv, .txt, .tsv, .tab, .mtx, .mtx.gz and .h5ad")
    else:
        QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv("👀 The input training data is processed as an array-like object")
        WfNwDmJAjhHXNonldtmSHteAZkNbgRun = X
        if transpose:
            WfNwDmJAjhHXNonldtmSHteAZkNbgRun = WfNwDmJAjhHXNonldtmSHteAZkNbgRun.transpose()
        if isinstance(WfNwDmJAjhHXNonldtmSHteAZkNbgRun, pd.DataFrame):
            CVmtDIyHCRyGslrApDcuSflgxNKWznEX = WfNwDmJAjhHXNonldtmSHteAZkNbgRun.columns
        else:
            if CVmtDIyHCRyGslrApDcuSflgxNKWznEX is None:
                raise Exception(
                        "🛑 Missing `genes`. Please provide this argument together with the input training data")
            CVmtDIyHCRyGslrApDcuSflgxNKWznEX = OZKfeucezfHlKVQtNhIgRWdJwoQVwFzx(CVmtDIyHCRyGslrApDcuSflgxNKWznEX)
        IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS = OZKfeucezfHlKVQtNhIgRWdJwoQVwFzx(IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS)
    return WfNwDmJAjhHXNonldtmSHteAZkNbgRun, IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS, CVmtDIyHCRyGslrApDcuSflgxNKWznEX
def EXEtmNRMjysOrbwQpRycsulTteThfZvg(WfNwDmJAjhHXNonldtmSHteAZkNbgRun, IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS, C, rxRvRNwNiSiguCXPFDfQklamxVIBmtMu, rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd, n_jobs, **kwargs) -> LogisticRegression:
    mXwtmKaoXWFPcXNVcddCwORyGuQVlGka = len(IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS)
    if rxRvRNwNiSiguCXPFDfQklamxVIBmtMu is None:
        rxRvRNwNiSiguCXPFDfQklamxVIBmtMu = 'sag' if no_cells>50000 else 'lbfgs'
    elif rxRvRNwNiSiguCXPFDfQklamxVIBmtMu not in ('liblinear', 'lbfgs', 'newton-cg', 'sag', 'saga'):
        raise ValueError(
                f"🛑 Invalid `solver`, should be one of `'liblinear'`, `'lbfgs'`, `'newton-cg'`, `'sag'`, and `'saga'`")
    QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv(f"🏋️ Training data using logistic regression")
    if (mXwtmKaoXWFPcXNVcddCwORyGuQVlGka > 100000) and (WfNwDmJAjhHXNonldtmSHteAZkNbgRun.shape[1] > 10000):
        QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.cqOkzJCPuYbFNHPhlrlXPGSWXTLNKTnx(f"⚠️ Warning: it may take a long time to train this dataset with {no_cells} cells and {indata.shape[1]} genes, try to downsample cells and/or restrict genes to a subset (e.g., hvgs)")
    pNXJRhNezfTHMFOReigergVLwmwiNrft = LogisticRegression(C = C, rxRvRNwNiSiguCXPFDfQklamxVIBmtMu = rxRvRNwNiSiguCXPFDfQklamxVIBmtMu, rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd = rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd, multi_class = 'ovr', n_jobs = n_jobs, **kwargs)
    pNXJRhNezfTHMFOReigergVLwmwiNrft.fit(WfNwDmJAjhHXNonldtmSHteAZkNbgRun, IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS)
    return pNXJRhNezfTHMFOReigergVLwmwiNrft
def FbhDyhTwPWzhiiOCMejXCKEdMeYCuqec(WfNwDmJAjhHXNonldtmSHteAZkNbgRun, IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS, C, rxRvRNwNiSiguCXPFDfQklamxVIBmtMu, rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd, **kwargs) -> LogisticRegression:
    rxRvRNwNiSiguCXPFDfQklamxVIBmtMu = 'qn' if rxRvRNwNiSiguCXPFDfQklamxVIBmtMu is None else rxRvRNwNiSiguCXPFDfQklamxVIBmtMu
    if rxRvRNwNiSiguCXPFDfQklamxVIBmtMu != 'qn':
        raise ValueError(
                f"🛑 Invalid `solver`, should be `'qn'` to run on GPU")
    DRpxoQQXBFvLpBrILbriIWsIoDKxGpLa = LabelEncoder()
    aZeoBuoimxKemKdYDtpVSsntuVclTojR = DRpxoQQXBFvLpBrILbriIWsIoDKxGpLa.fit_transform(IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS)
    QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv(f"🏋️ Training data using logistic regression on GPU")
    mXwtmKaoXWFPcXNVcddCwORyGuQVlGka = len(IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS)
    if (mXwtmKaoXWFPcXNVcddCwORyGuQVlGka > 100000) and (WfNwDmJAjhHXNonldtmSHteAZkNbgRun.shape[1] > 10000):
        QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.cqOkzJCPuYbFNHPhlrlXPGSWXTLNKTnx(f"⚠️ Warning: it may take a long time to train this dataset with {no_cells} cells and {indata.shape[1]} genes, try to downsample cells and/or restrict genes to a subset (e.g., hvgs)")
    CGbLKRbAArgGKktrzQAHoKcsPPzVDeZu = cuLogisticRegression(C = C, rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd = rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd, rxRvRNwNiSiguCXPFDfQklamxVIBmtMu = rxRvRNwNiSiguCXPFDfQklamxVIBmtMu, **kwargs)
    CGbLKRbAArgGKktrzQAHoKcsPPzVDeZu.fit(WfNwDmJAjhHXNonldtmSHteAZkNbgRun, aZeoBuoimxKemKdYDtpVSsntuVclTojR)
    pNXJRhNezfTHMFOReigergVLwmwiNrft = LogisticRegression(multi_class = 'ovr')
    for GvuloJBQrvEiPYzEBPbJcbOugAEdNjgK in ['C', 'class_weight', 'fit_intercept', 'l1_ratio', 'max_iter', 'penalty', 'tol', 'solver', 'coef_', 'intercept_', 'verbose']:
        setattr(pNXJRhNezfTHMFOReigergVLwmwiNrft, GvuloJBQrvEiPYzEBPbJcbOugAEdNjgK, getattr(CGbLKRbAArgGKktrzQAHoKcsPPzVDeZu, GvuloJBQrvEiPYzEBPbJcbOugAEdNjgK))
    pNXJRhNezfTHMFOReigergVLwmwiNrft.classes_ = DRpxoQQXBFvLpBrILbriIWsIoDKxGpLa.inverse_transform(CGbLKRbAArgGKktrzQAHoKcsPPzVDeZu.classes_)
    return pNXJRhNezfTHMFOReigergVLwmwiNrft
def VUDBdGVXhxPlDEloxHeIOSvpdIzDpaGI(WfNwDmJAjhHXNonldtmSHteAZkNbgRun, IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS,
                   alpha, rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd, n_jobs,
                   mini_batch, batch_number, batch_size, epochs, balance_cell_type, **kwargs) -> SGDClassifier:
    zONPqHYZGUbgjUcZGiuzlHgYAiAaQxQR = 'log_loss' if float(skv[:3]) >= 1.1 else 'log'
    pNXJRhNezfTHMFOReigergVLwmwiNrft = SGDClassifier(loss = zONPqHYZGUbgjUcZGiuzlHgYAiAaQxQR, alpha = alpha, rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd = rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd, n_jobs = n_jobs, **kwargs)
    if not mini_batch:
        QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv(f"🏋️ Training data using SGD logistic regression")
        if (len(IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS) > 100000) and (WfNwDmJAjhHXNonldtmSHteAZkNbgRun.shape[1] > 10000):
            QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.cqOkzJCPuYbFNHPhlrlXPGSWXTLNKTnx(f"⚠️ Warning: it may take a long time to train this dataset with {len(labels)} cells and {indata.shape[1]} genes, try to downsample cells and/or restrict genes to a subset (e.g., hvgs)")
        pNXJRhNezfTHMFOReigergVLwmwiNrft.fit(WfNwDmJAjhHXNonldtmSHteAZkNbgRun, IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS)
    else:
        QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv(f"🏋️ Training data using mini-batch SGD logistic regression")
        mXwtmKaoXWFPcXNVcddCwORyGuQVlGka = len(IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS)
        if mXwtmKaoXWFPcXNVcddCwORyGuQVlGka < 10000:
            QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.cqOkzJCPuYbFNHPhlrlXPGSWXTLNKTnx(f"⚠️ Warning: the number of cells ({no_cells}) is not big enough to conduct a proper mini-batch training. You may consider using traditional SGD classifier (mini_batch = False)")
        if mXwtmKaoXWFPcXNVcddCwORyGuQVlGka <= batch_size:
            raise ValueError(
                    f"🛑 Number of cells ({no_cells}) is fewer than the batch size ({batch_size}). Decrease `batch_size`, or use SGD directly (mini_batch = False)")
        sEESVExjOIWAABKJKQjvltIyTfvCKYWY = min([batch_number*batch_size, mXwtmKaoXWFPcXNVcddCwORyGuQVlGka])
        EsHRWyHdgvaLpmmMxucRLDNUWTXlTKXm = np.arange(0, sEESVExjOIWAABKJKQjvltIyTfvCKYWY, batch_size)
        if balance_cell_type:
            lFNfdyjLFmjonTdPHsjkJopSLGeIWXHR = np.cNOItjkXBKNYniYhwbTjsJpKxHZqsbNY(IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS, return_counts = True)
            DaWzlJgcJFlPKvVefQGEnaTTWScXQYLF = len(lFNfdyjLFmjonTdPHsjkJopSLGeIWXHR[0])
            NLPtRkIOVYcrlgBqaQlOQDLUDAMJMJfB = pd.Series(1 / (lFNfdyjLFmjonTdPHsjkJopSLGeIWXHR[1]*DaWzlJgcJFlPKvVefQGEnaTTWScXQYLF), index = lFNfdyjLFmjonTdPHsjkJopSLGeIWXHR[0])
            uMzdGlhtbWGzzRjRROQCyxSUWEFQFCgT = NLPtRkIOVYcrlgBqaQlOQDLUDAMJMJfB[IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS].values
        for DJgyQrFfREsdZCVTfWXbIbIoVMOufTVg in range(1, (epochs+1)):
            QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv(f"⏳ Epochs: [{epoch}/{epochs}]")
            if not balance_cell_type:
                tusIBpxxlsSmeDCCOdJrryeEhXqkWxQH = np.random.choice(mXwtmKaoXWFPcXNVcddCwORyGuQVlGka, sEESVExjOIWAABKJKQjvltIyTfvCKYWY, replace = False)
            else:
                tusIBpxxlsSmeDCCOdJrryeEhXqkWxQH = np.random.choice(mXwtmKaoXWFPcXNVcddCwORyGuQVlGka, sEESVExjOIWAABKJKQjvltIyTfvCKYWY, replace = False, uMzdGlhtbWGzzRjRROQCyxSUWEFQFCgT = uMzdGlhtbWGzzRjRROQCyxSUWEFQFCgT)
            for iiNNMdQtDECwydLlsoKvNRwCTTFOOpVx in EsHRWyHdgvaLpmmMxucRLDNUWTXlTKXm:
                pNXJRhNezfTHMFOReigergVLwmwiNrft.partial_fit(WfNwDmJAjhHXNonldtmSHteAZkNbgRun[tusIBpxxlsSmeDCCOdJrryeEhXqkWxQH[iiNNMdQtDECwydLlsoKvNRwCTTFOOpVx:iiNNMdQtDECwydLlsoKvNRwCTTFOOpVx+batch_size]], IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS[tusIBpxxlsSmeDCCOdJrryeEhXqkWxQH[iiNNMdQtDECwydLlsoKvNRwCTTFOOpVx:iiNNMdQtDECwydLlsoKvNRwCTTFOOpVx+batch_size]], classes = np.cNOItjkXBKNYniYhwbTjsJpKxHZqsbNY(IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS))
    return pNXJRhNezfTHMFOReigergVLwmwiNrft
def CmIIlcxIadyrkuHfjdsxuZdHgbaXylyq(X = None,
          IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS: Optional[Union[str, list, tuple, np.ndarray, pd.Series, pd.Index]] = None,
          CVmtDIyHCRyGslrApDcuSflgxNKWznEX: Optional[Union[str, list, tuple, np.ndarray, pd.Series, pd.Index]] = None,
          SjWEVxdksbbUrknjgqdfnTvRpgHHBjql: bool = False,
          with_mean: bool = True,
          check_expression: bool = True,
          C: float = 1.0, rxRvRNwNiSiguCXPFDfQklamxVIBmtMu: Optional[str] = None, rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd: Optional[int] = None, n_jobs: Optional[int] = None,
          use_SGD: bool = False, alpha: float = 0.0001,
          fUSsgEPmNHPZRkIuPEHPtCETMTwCrYdT: bool = False,
          mini_batch: bool = False, batch_number: int = 100, batch_size: int = 1000, epochs: int = 10, balance_cell_type: bool = False,
          feature_selection: bool = False, top_genes: int = 300,
          wxNXudITNyHnAhXAxvoweXnSOyMsEIOA: str = '', details: str = '', NIzIFfEdrXvIPqCLojguaftpLUvWGlnH: str = '', source: str = '', version: str = '',
          **kwargs
         ) -> BnzGOEgqTnYensxoqtWNlisVwRaeXKPk:
    if not use_SGD and fUSsgEPmNHPZRkIuPEHPtCETMTwCrYdT and 'cuml' not in sys.modules:
        QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.cqOkzJCPuYbFNHPhlrlXPGSWXTLNKTnx(f"⚠️ Warning: to run logistic regression on GPU, please first install cuml")
        return
    QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv("🍳 Preparing data before training")
    WfNwDmJAjhHXNonldtmSHteAZkNbgRun, IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS, CVmtDIyHCRyGslrApDcuSflgxNKWznEX = lUnpcjTujAidSKxRgkjgRjtPCOziIiJs(X, IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS, CVmtDIyHCRyGslrApDcuSflgxNKWznEX, SjWEVxdksbbUrknjgqdfnTvRpgHHBjql)
    if isinstance(WfNwDmJAjhHXNonldtmSHteAZkNbgRun, pd.DataFrame):
        WfNwDmJAjhHXNonldtmSHteAZkNbgRun = WfNwDmJAjhHXNonldtmSHteAZkNbgRun.values
    elif with_mean and isinstance(WfNwDmJAjhHXNonldtmSHteAZkNbgRun, spmatrix):
        WfNwDmJAjhHXNonldtmSHteAZkNbgRun = WfNwDmJAjhHXNonldtmSHteAZkNbgRun.toarray()
    IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS = np.array(IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS)
    CVmtDIyHCRyGslrApDcuSflgxNKWznEX = np.array(CVmtDIyHCRyGslrApDcuSflgxNKWznEX)
    if check_expression and (np.abs(np.expm1(WfNwDmJAjhHXNonldtmSHteAZkNbgRun[0]).sum()-10000) > 1):
        raise ValueError(
                "🛑 Invalid expression matrix, expect log1p normalized expression to 10000 counts per cell")
    if len(IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS) != WfNwDmJAjhHXNonldtmSHteAZkNbgRun.shape[0]:
        raise ValueError(
                f"🛑 Length of training labels ({len(labels)}) does not match the number of input cells ({indata.shape[0]})")
    if len(CVmtDIyHCRyGslrApDcuSflgxNKWznEX) != WfNwDmJAjhHXNonldtmSHteAZkNbgRun.shape[1]:
        raise ValueError(
                f"🛑 The number of genes ({len(genes)}) provided does not match the number of genes in the training data ({indata.shape[1]})")
    nmFPCawNxncOKLLNRWPtGsONouRNXAyQ = WfNwDmJAjhHXNonldtmSHteAZkNbgRun.sum(axis = 0) == 0
    if isinstance(nmFPCawNxncOKLLNRWPtGsONouRNXAyQ, np.matrix):
        nmFPCawNxncOKLLNRWPtGsONouRNXAyQ = nmFPCawNxncOKLLNRWPtGsONouRNXAyQ.A1
    if nmFPCawNxncOKLLNRWPtGsONouRNXAyQ.sum() > 0:
        QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv(f"✂️ {flag.sum()} non-expressed genes are filtered out")
        CVmtDIyHCRyGslrApDcuSflgxNKWznEX = CVmtDIyHCRyGslrApDcuSflgxNKWznEX[~nmFPCawNxncOKLLNRWPtGsONouRNXAyQ]
    QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv(f"🔬 Input data has {indata.shape[0]} cells and {(~flag).sum()} genes")
    QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv(f"⚖️ Scaling input data")
    aNsgKPdVZwfdNSQQxlnnomJSMfdyNtda = StandardScaler(with_mean = with_mean)
    WfNwDmJAjhHXNonldtmSHteAZkNbgRun = aNsgKPdVZwfdNSQQxlnnomJSMfdyNtda.fit_transform(WfNwDmJAjhHXNonldtmSHteAZkNbgRun[:, ~nmFPCawNxncOKLLNRWPtGsONouRNXAyQ] if nmFPCawNxncOKLLNRWPtGsONouRNXAyQ.sum() > 0 else WfNwDmJAjhHXNonldtmSHteAZkNbgRun)
    WfNwDmJAjhHXNonldtmSHteAZkNbgRun[WfNwDmJAjhHXNonldtmSHteAZkNbgRun > 10] = 10
    if isinstance(WfNwDmJAjhHXNonldtmSHteAZkNbgRun, spmatrix) and ((WfNwDmJAjhHXNonldtmSHteAZkNbgRun.indices.dtype == 'int64') or (WfNwDmJAjhHXNonldtmSHteAZkNbgRun.indptr.dtype == 'int64')):
        WfNwDmJAjhHXNonldtmSHteAZkNbgRun = WfNwDmJAjhHXNonldtmSHteAZkNbgRun.toarray()
    if rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd is None:
        if WfNwDmJAjhHXNonldtmSHteAZkNbgRun.shape[0] < 50000:
            rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd = 1000
        elif WfNwDmJAjhHXNonldtmSHteAZkNbgRun.shape[0] < 500000:
            rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd = 500
        else:
            rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd = 200
    if use_SGD or feature_selection:
        pNXJRhNezfTHMFOReigergVLwmwiNrft = VUDBdGVXhxPlDEloxHeIOSvpdIzDpaGI(WfNwDmJAjhHXNonldtmSHteAZkNbgRun = WfNwDmJAjhHXNonldtmSHteAZkNbgRun, IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS = IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS, alpha = alpha, rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd = rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd, n_jobs = n_jobs, mini_batch = mini_batch, batch_number = batch_number, batch_size = batch_size, epochs = epochs, balance_cell_type = balance_cell_type, **kwargs)
    elif fUSsgEPmNHPZRkIuPEHPtCETMTwCrYdT:
        pNXJRhNezfTHMFOReigergVLwmwiNrft = FbhDyhTwPWzhiiOCMejXCKEdMeYCuqec(WfNwDmJAjhHXNonldtmSHteAZkNbgRun = WfNwDmJAjhHXNonldtmSHteAZkNbgRun, IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS = IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS, C = C, rxRvRNwNiSiguCXPFDfQklamxVIBmtMu = rxRvRNwNiSiguCXPFDfQklamxVIBmtMu, rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd = rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd, **kwargs)
    else:
        pNXJRhNezfTHMFOReigergVLwmwiNrft = EXEtmNRMjysOrbwQpRycsulTteThfZvg(WfNwDmJAjhHXNonldtmSHteAZkNbgRun = WfNwDmJAjhHXNonldtmSHteAZkNbgRun, IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS = IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS, C = C, rxRvRNwNiSiguCXPFDfQklamxVIBmtMu = rxRvRNwNiSiguCXPFDfQklamxVIBmtMu, rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd = rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd, n_jobs = n_jobs, **kwargs)
    if feature_selection:
        QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv(f"🔎 Selecting features")
        if len(CVmtDIyHCRyGslrApDcuSflgxNKWznEX) <= top_genes:
            raise ValueError(
                    f"🛑 The number of genes ({len(genes)}) is fewer than the `top_genes` ({top_genes}). Unable to perform feature selection")
        NAWRaHAWQMjdLsgPDNrIshsiZLkQdxtE = np.argpartition(np.abs(pNXJRhNezfTHMFOReigergVLwmwiNrft.coef_), -top_genes, axis = 1)[:, -top_genes:]
        NAWRaHAWQMjdLsgPDNrIshsiZLkQdxtE = np.cNOItjkXBKNYniYhwbTjsJpKxHZqsbNY(NAWRaHAWQMjdLsgPDNrIshsiZLkQdxtE)
        QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv(f"🧬 {len(gene_index)} features are selected")
        CVmtDIyHCRyGslrApDcuSflgxNKWznEX = CVmtDIyHCRyGslrApDcuSflgxNKWznEX[NAWRaHAWQMjdLsgPDNrIshsiZLkQdxtE]
        QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv(f"🏋️ Starting the second round of training")
        if use_SGD:
            pNXJRhNezfTHMFOReigergVLwmwiNrft = VUDBdGVXhxPlDEloxHeIOSvpdIzDpaGI(WfNwDmJAjhHXNonldtmSHteAZkNbgRun = WfNwDmJAjhHXNonldtmSHteAZkNbgRun[:, NAWRaHAWQMjdLsgPDNrIshsiZLkQdxtE], IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS = IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS, alpha = alpha, rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd = rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd, n_jobs = n_jobs, mini_batch = mini_batch, batch_number = batch_number, batch_size = batch_size, epochs = epochs, balance_cell_type = balance_cell_type, **kwargs)
        elif fUSsgEPmNHPZRkIuPEHPtCETMTwCrYdT:
            pNXJRhNezfTHMFOReigergVLwmwiNrft = FbhDyhTwPWzhiiOCMejXCKEdMeYCuqec(WfNwDmJAjhHXNonldtmSHteAZkNbgRun = WfNwDmJAjhHXNonldtmSHteAZkNbgRun[:, NAWRaHAWQMjdLsgPDNrIshsiZLkQdxtE], IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS = IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS, C = C, rxRvRNwNiSiguCXPFDfQklamxVIBmtMu = rxRvRNwNiSiguCXPFDfQklamxVIBmtMu, rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd = rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd, **kwargs)
        else:
            pNXJRhNezfTHMFOReigergVLwmwiNrft = EXEtmNRMjysOrbwQpRycsulTteThfZvg(WfNwDmJAjhHXNonldtmSHteAZkNbgRun = WfNwDmJAjhHXNonldtmSHteAZkNbgRun[:, NAWRaHAWQMjdLsgPDNrIshsiZLkQdxtE], IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS = IqJQtMnKeIPPInOSlkBOHRSpYvNXcuHS, C = C, rxRvRNwNiSiguCXPFDfQklamxVIBmtMu = rxRvRNwNiSiguCXPFDfQklamxVIBmtMu, rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd = rGtrbqIDSZaRvAoEXkeUjTyCVFqzLpCd, n_jobs = n_jobs, **kwargs)
        aNsgKPdVZwfdNSQQxlnnomJSMfdyNtda.mean_ = aNsgKPdVZwfdNSQQxlnnomJSMfdyNtda.mean_[NAWRaHAWQMjdLsgPDNrIshsiZLkQdxtE]
        aNsgKPdVZwfdNSQQxlnnomJSMfdyNtda.var_ = aNsgKPdVZwfdNSQQxlnnomJSMfdyNtda.var_[NAWRaHAWQMjdLsgPDNrIshsiZLkQdxtE]
        aNsgKPdVZwfdNSQQxlnnomJSMfdyNtda.scale_ = aNsgKPdVZwfdNSQQxlnnomJSMfdyNtda.scale_[NAWRaHAWQMjdLsgPDNrIshsiZLkQdxtE]
        aNsgKPdVZwfdNSQQxlnnomJSMfdyNtda.n_features_in_ = len(NAWRaHAWQMjdLsgPDNrIshsiZLkQdxtE)
    pNXJRhNezfTHMFOReigergVLwmwiNrft.plOSBmvdKJMFNMONmLAhLoGoJtKOuVvK = CVmtDIyHCRyGslrApDcuSflgxNKWznEX
    pNXJRhNezfTHMFOReigergVLwmwiNrft.n_features_in_ = len(CVmtDIyHCRyGslrApDcuSflgxNKWznEX)
    if not wxNXudITNyHnAhXAxvoweXnSOyMsEIOA:
        wxNXudITNyHnAhXAxvoweXnSOyMsEIOA = str(datetime.now())
    hneFwAFcmgvNGPzBStSOlUWGDilILeyN = {'date': wxNXudITNyHnAhXAxvoweXnSOyMsEIOA, 'details': details, 'url': NIzIFfEdrXvIPqCLojguaftpLUvWGlnH, 'source': source, 'version': version, 'number_celltypes': len(pNXJRhNezfTHMFOReigergVLwmwiNrft.classes_)}
    QozjWWyqoGpsZnPwkjRFLgcspbfNrrHu.RKhpfFAYzFsOigJiwgdiCOIGVZNGLQkv(f"✅ Model training done!")
    return BnzGOEgqTnYensxoqtWNlisVwRaeXKPk(pNXJRhNezfTHMFOReigergVLwmwiNrft, aNsgKPdVZwfdNSQQxlnnomJSMfdyNtda, hneFwAFcmgvNGPzBStSOlUWGDilILeyN)
