from __future__ import absolute_import
from .server import tuVfMcXtXRqwhVqjNXFfUHuZKZqTXUlF
CLzIqVHGcbqEyjNVCJTBUJOndyLKxeSW = None
def XbLBsbyVSyFHtvNdXanGoDgfYAWjFlcb(debug, mask_log):
    global CLzIqVHGcbqEyjNVCJTBUJOndyLKxeSW
    if CLzIqVHGcbqEyjNVCJTBUJOndyLKxeSW:
        return CLzIqVHGcbqEyjNVCJTBUJOndyLKxeSW
    CLzIqVHGcbqEyjNVCJTBUJOndyLKxeSW = tuVfMcXtXRqwhVqjNXFfUHuZKZqTXUlF(debug, mask_log)
    return CLzIqVHGcbqEyjNVCJTBUJOndyLKxeSW
