from __future__ import absolute_import
import os
def ssGavQOjltmCpAPOiYplhplQMTmioXFC(package_name):
    try:  
        from importlib.metadata import version
        return version(package_name)
    except ImportError:  
        from pkg_resources import get_distribution
        return get_distribution(package_name).version
OQvbUuHTloUjlgifXWJGpXErRIITTwfC = ssGavQOjltmCpAPOiYplhplQMTmioXFC("core-universal4")
def QYqhRikoJoslJkmJodegpnwQVsIYqmwk(v):
    return None if v is None else v.lower() in ("yes", "true", "t", "1")
qjVyGwnjCpNrZdhtIEivYgvUiogBniNj = QYqhRikoJoslJkmJodegpnwQVsIYqmwk(os.getenv("APPLITOOLS_UNIVERSAL_DEBUG", None))
def XApgMTFSCPKMsvbfSUxrbhYvSLXVSyAo(mask_log=None):
    from . import instance
    return instance.XbLBsbyVSyFHtvNdXanGoDgfYAWjFlcb(debug=qjVyGwnjCpNrZdhtIEivYgvUiogBniNj, mask_log=mask_log)
__all__ = ("get_instance",)
