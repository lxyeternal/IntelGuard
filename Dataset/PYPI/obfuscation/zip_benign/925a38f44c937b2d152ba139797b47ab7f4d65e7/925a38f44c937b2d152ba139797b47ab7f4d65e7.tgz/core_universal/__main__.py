from __future__ import absolute_import
import subprocess
import sys
from .server import hOXaGGNcQBzesjozpqmOnYTURmHvxDQU
try:
    exit(subprocess.call([hOXaGGNcQBzesjozpqmOnYTURmHvxDQU] + sys.argv[1:]))
except KeyboardInterrupt:
    exit(1)
