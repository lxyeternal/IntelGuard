import atexit
import contextlib
import sys
from logging import getLogger
from subprocess import PIPE, Popen  
try:
    from importlib.resources import as_file, files
    def yZvkqggpSYcPATIIAPCidVfuujYNhFtz(package, file_name):
        UzAQUpXIimKCBRLJEJDZjJwUehApxOcG = contextlib.ExitStack()
        hBLFvqbTDmJJgTThsLUCrtofaLmspUcX = files(package) / file_name
        fNTRcNVWMkrmxXYwGIcUdjQmOuSCHQof = UzAQUpXIimKCBRLJEJDZjJwUehApxOcG.enter_context(as_file(hBLFvqbTDmJJgTThsLUCrtofaLmspUcX))
        atexit.register(UzAQUpXIimKCBRLJEJDZjJwUehApxOcG.close)
        return fNTRcNVWMkrmxXYwGIcUdjQmOuSCHQof
except ImportError:
    from pkg_resources import yZvkqggpSYcPATIIAPCidVfuujYNhFtz
NsrrxNWFIgUsRFnNjOATWNwGcebWocyh = getLogger(__name__)
fbvDZmfIulxQtyxKwurrpDnRDEuqjAqw = "core.exe" if sys.platform == "win32" else "core"
hOXaGGNcQBzesjozpqmOnYTURmHvxDQU = yZvkqggpSYcPATIIAPCidVfuujYNhFtz("applitools.core_universal", "bin/" + fbvDZmfIulxQtyxKwurrpDnRDEuqjAqw)
class tuVfMcXtXRqwhVqjNXFfUHuZKZqTXUlF(object):
    def __init__(self, debug=None, mask_log=None):
        eZXDKLYUvkhxuvXdmOJxThuHcwjfWbng = [
            hOXaGGNcQBzesjozpqmOnYTURmHvxDQU,
            "universal",
            "--no-singleton",
            "--shutdown-mode",
            "stdin",
        ]
        if debug:
            eZXDKLYUvkhxuvXdmOJxThuHcwjfWbng.append("--debug")
        if mask_log:
            eZXDKLYUvkhxuvXdmOJxThuHcwjfWbng.append("--maskLog")
        self._usdk_subprocess = Popen(eZXDKLYUvkhxuvXdmOJxThuHcwjfWbng, stdin=PIPE, stdout=PIPE)  
        self.port = int(self._usdk_subprocess.stdout.readline())
        NsrrxNWFIgUsRFnNjOATWNwGcebWocyh.info("Started Universal SDK server at %s", self.port)
    def __repr__(self):
        return "SDKServer(port={})".format(self.port)
