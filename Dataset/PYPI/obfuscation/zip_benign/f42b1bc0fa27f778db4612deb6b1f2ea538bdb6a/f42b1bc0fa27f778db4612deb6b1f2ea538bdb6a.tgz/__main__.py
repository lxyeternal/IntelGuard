import os
import signal
import subprocess  
import sys
class hoCtmvJtUbABgABvETlfPmpydejjfWbG:
    def __init__(self, MPYWAuXdnyXKsefXTqjRzoBIZTcosHqm: list[str]) -> None:
        self.MPYWAuXdnyXKsefXTqjRzoBIZTcosHqm = MPYWAuXdnyXKsefXTqjRzoBIZTcosHqm
        self.child_process = None
    def XNuVyccPEMsmRRaeeRcgqzKHXYyZjivf(self, signum: int, frame: int) -> None:
        if self.child_process is not None:
            os.kill(self.child_process.pid, signum)
    def pcGQFSTiYMfLumxEphugzzBvivzzbbNe(self) -> int:
        signal.signal(signal.SIGINT, self.XNuVyccPEMsmRRaeeRcgqzKHXYyZjivf)
        signal.signal(signal.SIGTERM, self.XNuVyccPEMsmRRaeeRcgqzKHXYyZjivf)
        self.child_process = subprocess.Popen(self.MPYWAuXdnyXKsefXTqjRzoBIZTcosHqm)  
        return self.child_process.wait()
def pcGQFSTiYMfLumxEphugzzBvivzzbbNe() -> None:
    MPYWAuXdnyXKsefXTqjRzoBIZTcosHqm = [
        os.path.join(os.path.dirname(__file__), 'bauplan-cli'),
        *sys.argv[1:],
    ]
    TDcdmJpHCZXqbAKMAkiwqnijPtPFRDmC = hoCtmvJtUbABgABvETlfPmpydejjfWbG(MPYWAuXdnyXKsefXTqjRzoBIZTcosHqm)
    sys.exit(TDcdmJpHCZXqbAKMAkiwqnijPtPFRDmC.pcGQFSTiYMfLumxEphugzzBvivzzbbNe())
if __name__ == '__main__':
    pcGQFSTiYMfLumxEphugzzBvivzzbbNe()
