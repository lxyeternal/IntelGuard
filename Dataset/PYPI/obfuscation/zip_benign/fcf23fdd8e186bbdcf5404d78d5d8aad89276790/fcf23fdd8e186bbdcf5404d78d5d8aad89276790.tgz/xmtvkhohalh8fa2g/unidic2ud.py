#! /usr/bin/python -tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe
import os
aipUPwpioroSMFoKiCtXfdHtywBjkTKw=os.path.abspath(os.path.dirname(__file__))
KVHfBWxvtsZcePaikyCcTlpLrgOLDVqA=os.path.join(aipUPwpioroSMFoKiCtXfdHtywBjkTKw,"download")
import time
GmGJQgtzOojCatMmtKdtbnXQhNPDUEQT=time.time()
ITbdvcxLWdFwQSMrbpnlmiMgmhcgiqME="https://clrd.ninjal.ac.jp/unidic_archive/"
SYNTxbhdQRxjWEJFewPONEObMlynZoIG={
  "gendai":ITbdvcxLWdFwQSMrbpnlmiMgmhcgiqME+"2302/unidic-cwj-202302.zip",
  "spoken":ITbdvcxLWdFwQSMrbpnlmiMgmhcgiqME+"2302/unidic-csj-202302.zip",
  "novel":ITbdvcxLWdFwQSMrbpnlmiMgmhcgiqME+"2203/UniDic-202203_65_novel.zip",
  "qkana":ITbdvcxLWdFwQSMrbpnlmiMgmhcgiqME+"2203/UniDic-202203_60b_qkana.zip",
  "kindai":ITbdvcxLWdFwQSMrbpnlmiMgmhcgiqME+"2203/UniDic-202203_60a_kindai-bungo.zip",
  "kinsei":ITbdvcxLWdFwQSMrbpnlmiMgmhcgiqME+"2203/UniDic-202203_50c_kinsei-edo.zip",
  "kyogen":ITbdvcxLWdFwQSMrbpnlmiMgmhcgiqME+"2203/UniDic-202203_40_chusei-kougo.zip",
  "wakan":ITbdvcxLWdFwQSMrbpnlmiMgmhcgiqME+"2203/UniDic-202203_30_chusei-bungo.zip",
  "wabun":ITbdvcxLWdFwQSMrbpnlmiMgmhcgiqME+"2203/UniDic-202203_20_chuko.zip",
  "manyo":ITbdvcxLWdFwQSMrbpnlmiMgmhcgiqME+"2203/UniDic-202203_10_jodai.zip"
}
CkYIEFpfPLGeETjsIZjwJQqIxtEHCQET="https://lindat.mff.cuni.cz/repository/xmlui/bitstream/handle/11234/1-3131/"
pnMfbzatKDWtPWxOiqCNkqpTRndiHxSV="ud-2.5-191206"
import ssl
ssl._create_default_https_context=ssl._create_unverified_context
import sys
def NpxNjxxvrfoHHWyoAgWhcaQOoinMTnuq(block_count,block_size,total_size):
  KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR=time.time()
  UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt=100.0*block_count*block_size/total_size
  if p<1:
    KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR=-1
  elif p>=100:
    UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt=100
    KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR-=GmGJQgtzOojCatMmtKdtbnXQhNPDUEQT
  else:
    KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR=(KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR-GmGJQgtzOojCatMmtKdtbnXQhNPDUEQT)*(100-UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt)/UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt
  b=int(UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt/2)
  if b==50:
    UwPPiaBKixQDGBBvxHkNjWNtugAMEtye="="*50
  else:
    UwPPiaBKixQDGBBvxHkNjWNtugAMEtye=("="*b)+">"+(" "*(49-b))
  if t<0:
    u="   "
  elif t<3600:
    u=time.strftime("%M:%S   ",time.gmtime(KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR))
  elif t<86400:
    u=time.strftime("%H:%M:%S   ",time.gmtime(KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR))
  else:
    u=time.strftime("%d+%H:%M:%S   ",time.gmtime(KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR))
  print("\r ["+UwPPiaBKixQDGBBvxHkNjWNtugAMEtye+"] "+str(int(UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt))+"% "+u,end="",file=sys.stderr)
def oDkeNAyzRVMwSLiPRgTJqKzDwTOPwAwO(model,option=None):
  global GmGJQgtzOojCatMmtKdtbnXQhNPDUEQT
  os.makedirs(KVHfBWxvtsZcePaikyCcTlpLrgOLDVqA,exist_ok=True)
  if option=="unidic":
    u=SYNTxbhdQRxjWEJFewPONEObMlynZoIG[model]
  elif option=="udpipe":
    u=False
  else:
    try:
      u=SYNTxbhdQRxjWEJFewPONEObMlynZoIG[model]
    except:
      u=False
  GmGJQgtzOojCatMmtKdtbnXQhNPDUEQT=time.time()
  if u:
    import urllib.request,zipfile,glob,shutil
    f,IauKiVeAXdYjPpdDebxzFLcCYFdtVNQv=urllib.request.urlretrieve(u,reporthook=NpxNjxxvrfoHHWyoAgWhcaQOoinMTnuq)
    UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt=os.path.join(KVHfBWxvtsZcePaikyCcTlpLrgOLDVqA,".temporary")
    with zipfile.ZipFile(f) as dbBANPZxQfFEUunoLhlMXdJgIKRaiqHs:
      dbBANPZxQfFEUunoLhlMXdJgIKRaiqHs.extractall(UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt)
    zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe=os.path.join(KVHfBWxvtsZcePaikyCcTlpLrgOLDVqA,model)
    if os.path.exists(zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe):
      shutil.rmtree(zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe)
    RHfqanFkvSEUDPFCURlpTiBqyDczFUEb=glob.glob(os.path.join(UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt,"*"))
    if len(RHfqanFkvSEUDPFCURlpTiBqyDczFUEb)==1:
      os.rename(RHfqanFkvSEUDPFCURlpTiBqyDczFUEb[0],zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe)
      os.rmdir(UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt)
    else:
      os.rename(UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt,zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe)
    f=os.path.join(zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe,"dicrc")
    if not os.path.isfile(f):
      shutil.copy(os.path.join(zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe,".dicrc"),f)
  else:
    import urllib.request
    f,IauKiVeAXdYjPpdDebxzFLcCYFdtVNQv=urllib.request.urlretrieve(CkYIEFpfPLGeETjsIZjwJQqIxtEHCQET+model+"-"+pnMfbzatKDWtPWxOiqCNkqpTRndiHxSV+".udpipe",filename=os.path.join(KVHfBWxvtsZcePaikyCcTlpLrgOLDVqA,model+".udpipe"),reporthook=NpxNjxxvrfoHHWyoAgWhcaQOoinMTnuq)
  print("",flush=True,file=sys.stderr)
def xbJLNJlOhzbNcDdYQSFlUUhVqkYXlpZP():
  os.makedirs(KVHfBWxvtsZcePaikyCcTlpLrgOLDVqA,exist_ok=True)
  try:
    import subprocess
    zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe=subprocess.check_output(["/bin/ls","-1tr",KVHfBWxvtsZcePaikyCcTlpLrgOLDVqA]).decode("utf-8")
  except:
    import glob
    zhMTQUOObtMONfCwxbyBvVUaCmLEuytF=os.getcwd()
    os.chdir(KVHfBWxvtsZcePaikyCcTlpLrgOLDVqA)
    zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe="\n".join(glob.glob("*"))+"\n"
    os.chdir(zhMTQUOObtMONfCwxbyBvVUaCmLEuytF)
  return zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe
class NursDaahDHWeifFiRnFzGDRRJOUzUakq(object):
  def __init__(self,cpryiJhFpOzrnstfFiDqLhBEDLiUcxpI):
    if "\n" in cpryiJhFpOzrnstfFiDqLhBEDLiUcxpI:
      KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR=[NursDaahDHWeifFiRnFzGDRRJOUzUakq("0\t_\t_\t_\t_\t_\t0\t_\t_\t_")]
      for r in cpryiJhFpOzrnstfFiDqLhBEDLiUcxpI.split("\n"):
        peRZKciRbOWeRRHXWWSgducMSzIWuRrB=NursDaahDHWeifFiRnFzGDRRJOUzUakq(r)
        if peRZKciRbOWeRRHXWWSgducMSzIWuRrB.id>0:
          KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR.append(peRZKciRbOWeRRHXWWSgducMSzIWuRrB)
      self._tokens=KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR
      for peRZKciRbOWeRRHXWWSgducMSzIWuRrB in KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR:
        peRZKciRbOWeRRHXWWSgducMSzIWuRrB._parent=self
        peRZKciRbOWeRRHXWWSgducMSzIWuRrB.QpticPwshsLBghshfYvuYDcHKJLzokCQ=peRZKciRbOWeRRHXWWSgducMSzIWuRrB._head
      self._result=cpryiJhFpOzrnstfFiDqLhBEDLiUcxpI
    else:
      peRZKciRbOWeRRHXWWSgducMSzIWuRrB=cpryiJhFpOzrnstfFiDqLhBEDLiUcxpI.split("\t")
      try:
        peRZKciRbOWeRRHXWWSgducMSzIWuRrB[0],peRZKciRbOWeRRHXWWSgducMSzIWuRrB[6]=int(peRZKciRbOWeRRHXWWSgducMSzIWuRrB[0]),int(peRZKciRbOWeRRHXWWSgducMSzIWuRrB[6])
      except:
        peRZKciRbOWeRRHXWWSgducMSzIWuRrB=[0]*10
      self.id,self.SUIkmCGlhwlHKovaIPUvdIqEsYipNDSF,self.IAxSwhoIhOaxTzWwkcEHjQRdUnQPDuib,self.lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS,self.oEwGufqOIJjxdaGKsdIMCFVbgUIfoMJd,self.wptVguPghfXGZPIXSjIdZkLAXRkwjxDg,self._head,self.zSGiFziCrxBmkbkTdGUuzkpipfMLOkEi,self.fcnSdNYRtRAfbnVQDKRpWYMyKHutAXSm,self.oMCQDdKGDXNwGIwXjvYVQyHRtpwGcWVb=peRZKciRbOWeRRHXWWSgducMSzIWuRrB if len(peRZKciRbOWeRRHXWWSgducMSzIWuRrB)==10 else [0]*10
      self._result=""
  def __setattr__(self,name,value):
    awHJWzHObTHWDsWMSQodQjAATPwYVCLi=value
    if name=="head":
      KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR=self._parent._tokens
      tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe=KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR.index(self)
      awHJWzHObTHWDsWMSQodQjAATPwYVCLi=self if awHJWzHObTHWDsWMSQodQjAATPwYVCLi==0 else KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe+awHJWzHObTHWDsWMSQodQjAATPwYVCLi-self.id]
    if hasattr(self,name):
      if getattr(self,name)!=awHJWzHObTHWDsWMSQodQjAATPwYVCLi:
        super(NursDaahDHWeifFiRnFzGDRRJOUzUakq,self._parent).__setattr__("_result","")
        if name=="id":
          KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR=self._parent._tokens
          tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe=KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR.index(self)
          GPuPzBsbrAtoFChYzHFHVecNaINEoEOc=tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe+awHJWzHObTHWDsWMSQodQjAATPwYVCLi-self.id
          super(NursDaahDHWeifFiRnFzGDRRJOUzUakq,KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR[GPuPzBsbrAtoFChYzHFHVecNaINEoEOc]).__setattr__("id",KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].id)
          KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe],KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR[GPuPzBsbrAtoFChYzHFHVecNaINEoEOc]=KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR[GPuPzBsbrAtoFChYzHFHVecNaINEoEOc],KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]
    super(NursDaahDHWeifFiRnFzGDRRJOUzUakq,self).__setattr__(name,awHJWzHObTHWDsWMSQodQjAATPwYVCLi)
  def __repr__(self):
    if self._result!="":
      r=self._result
    elif hasattr(self,"_tokens"):
      r="".join(str(KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR)+"\n" for KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR in self._tokens[1:]).replace("\n1\t","\n\n1\t")
    else:
      r="\t".join([str(self.id),self.SUIkmCGlhwlHKovaIPUvdIqEsYipNDSF,self.IAxSwhoIhOaxTzWwkcEHjQRdUnQPDuib,self.lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS,self.oEwGufqOIJjxdaGKsdIMCFVbgUIfoMJd,self.wptVguPghfXGZPIXSjIdZkLAXRkwjxDg,str(0 if self.QpticPwshsLBghshfYvuYDcHKJLzokCQ is self else self.QpticPwshsLBghshfYvuYDcHKJLzokCQ.id),self.zSGiFziCrxBmkbkTdGUuzkpipfMLOkEi,self.fcnSdNYRtRAfbnVQDKRpWYMyKHutAXSm,self.oMCQDdKGDXNwGIwXjvYVQyHRtpwGcWVb])
    return r if type(r) is str else r.encode("utf-8")
  def __getitem__(self,item):
    return self._tokens[item]
  def __len__(self):
    return len(self._tokens)
  def index(self,item):
    return self._tokens.index(item)
  def duKmUQvmemXWsFbprxCApHlrZCYcOcoP(self,item=0):
    import deplacy
    if not hasattr(self,"_tokens"):
      return self._parent.duKmUQvmemXWsFbprxCApHlrZCYcOcoP(self._parent.index(self))
    UwPPiaBKixQDGBBvxHkNjWNtugAMEtye='<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"  width="100%" height="100%" onload="conllusvg.view(this,+conllu+)" onresize="conllusvg.rewrite(+conllu+)">\n'.replace("+","'")
    UwPPiaBKixQDGBBvxHkNjWNtugAMEtye+='<text id="conllu" fill="none" visibility="hidden">\n'
    if item==0:
      UwPPiaBKixQDGBBvxHkNjWNtugAMEtye+=str(self)
    else:
      from itertools import takewhile
      tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe=item-self[item].id
      for GPuPzBsbrAtoFChYzHFHVecNaINEoEOc in takewhile(lambda GPuPzBsbrAtoFChYzHFHVecNaINEoEOc:GPuPzBsbrAtoFChYzHFHVecNaINEoEOc-self[GPuPzBsbrAtoFChYzHFHVecNaINEoEOc].id==tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe,range(tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe+1,len(self))):
        UwPPiaBKixQDGBBvxHkNjWNtugAMEtye+=str(self[GPuPzBsbrAtoFChYzHFHVecNaINEoEOc])+'\n'
    UwPPiaBKixQDGBBvxHkNjWNtugAMEtye+='</text>\n<script type="text/javascript"><![CDATA[\n'
    f=open(os.path.join(deplacy.aipUPwpioroSMFoKiCtXfdHtywBjkTKw,"conllusvgview.js"),"r",encoding="utf-8")
    UwPPiaBKixQDGBBvxHkNjWNtugAMEtye+=f.read()
    f.close()
    UwPPiaBKixQDGBBvxHkNjWNtugAMEtye+=']]></script>\n</svg>\n'
    return UwPPiaBKixQDGBBvxHkNjWNtugAMEtye
class DALMifTZBtspLFVNXVHrGMhovDiSFnHq(NursDaahDHWeifFiRnFzGDRRJOUzUakq):
  def DcQHfhSdsuUhhopxhzVHteInRjUdTJBq(self,BoxDrawingWidth=1,Japanese=True,CatenaAnalysis=True):
    import deplacy
    if not hasattr(self,"_tokens"):
      return None
    UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt=deplacy.renderMatrix(self,CatenaAnalysis)
    u=[" ","\u2578","\u257A","\u2550","\u2579","\u255D","\u255A","\u2569","\u257B","\u2557","\u2554","\u2566","\u2551","\u2563","\u2560","\u256C","<"]
    if CatenaAnalysis:
      u[7]=u[5]
      u[11]=u[9]
      u[15]=u[12]
    awHJWzHObTHWDsWMSQodQjAATPwYVCLi=[KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR.SUIkmCGlhwlHKovaIPUvdIqEsYipNDSF for KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR in self]
    DXQSJgyqFLyzyvzxlCPHbMNMktxpFZKr=[]
    for peRZKciRbOWeRRHXWWSgducMSzIWuRrB in awHJWzHObTHWDsWMSQodQjAATPwYVCLi:
      DXQSJgyqFLyzyvzxlCPHbMNMktxpFZKr.append(len(peRZKciRbOWeRRHXWWSgducMSzIWuRrB)+len([GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP for GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP in peRZKciRbOWeRRHXWWSgducMSzIWuRrB if ord(GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP)>12287]))
    BAkXoxPcTQqyaxxiaJuJVbTqFFmDTqLS=max(DXQSJgyqFLyzyvzxlCPHbMNMktxpFZKr)
    if Japanese:
      import deplacy.deprelja
      r=deplacy.deprelja.deprelja
    else:
      r={}
    UwPPiaBKixQDGBBvxHkNjWNtugAMEtye=""
    for tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe in range(1,len(self)):
      KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR="".join(u[GPuPzBsbrAtoFChYzHFHVecNaINEoEOc] for GPuPzBsbrAtoFChYzHFHVecNaINEoEOc in UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe-1])
      if BoxDrawingWidth>1:
        KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR=KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR.replace(" "," "*BoxDrawingWidth).replace("<"," "*(BoxDrawingWidth-1)+"<")
      if self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].zSGiFziCrxBmkbkTdGUuzkpipfMLOkEi in r:
        UwPPiaBKixQDGBBvxHkNjWNtugAMEtye+=" "*(BAkXoxPcTQqyaxxiaJuJVbTqFFmDTqLS-DXQSJgyqFLyzyvzxlCPHbMNMktxpFZKr[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe])+awHJWzHObTHWDsWMSQodQjAATPwYVCLi[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]+" "+KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR+" "+self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].zSGiFziCrxBmkbkTdGUuzkpipfMLOkEi+"("+r[self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].zSGiFziCrxBmkbkTdGUuzkpipfMLOkEi]+")\n"
      elif self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].zSGiFziCrxBmkbkTdGUuzkpipfMLOkEi.find(":")>0:
        GPuPzBsbrAtoFChYzHFHVecNaINEoEOc=self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].zSGiFziCrxBmkbkTdGUuzkpipfMLOkEi.split(":")
        if GPuPzBsbrAtoFChYzHFHVecNaINEoEOc[0] in r:
          UwPPiaBKixQDGBBvxHkNjWNtugAMEtye+=" "*(BAkXoxPcTQqyaxxiaJuJVbTqFFmDTqLS-DXQSJgyqFLyzyvzxlCPHbMNMktxpFZKr[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe])+awHJWzHObTHWDsWMSQodQjAATPwYVCLi[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]+" "+KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR+" "+self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].zSGiFziCrxBmkbkTdGUuzkpipfMLOkEi+"("+r[GPuPzBsbrAtoFChYzHFHVecNaINEoEOc[0]]+"["+GPuPzBsbrAtoFChYzHFHVecNaINEoEOc[1]+"])\n"
        else:
          UwPPiaBKixQDGBBvxHkNjWNtugAMEtye+=" "*(BAkXoxPcTQqyaxxiaJuJVbTqFFmDTqLS-DXQSJgyqFLyzyvzxlCPHbMNMktxpFZKr[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe])+awHJWzHObTHWDsWMSQodQjAATPwYVCLi[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]+" "+KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR+" "+self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].zSGiFziCrxBmkbkTdGUuzkpipfMLOkEi+"\n"
      else:
        UwPPiaBKixQDGBBvxHkNjWNtugAMEtye+=" "*(BAkXoxPcTQqyaxxiaJuJVbTqFFmDTqLS-DXQSJgyqFLyzyvzxlCPHbMNMktxpFZKr[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe])+awHJWzHObTHWDsWMSQodQjAATPwYVCLi[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]+" "+KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR+" "+self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].zSGiFziCrxBmkbkTdGUuzkpipfMLOkEi+"\n"
    return UwPPiaBKixQDGBBvxHkNjWNtugAMEtye
class mRxjzrLQByKfHwSQrAFdqEsMtYzFEGPK(object):
  def __init__(self,jobEtvhVQburTHZejUvpnhBTgQnarPfi,UDPipe):
    self.jobEtvhVQburTHZejUvpnhBTgQnarPfi=jobEtvhVQburTHZejUvpnhBTgQnarPfi
    if UniDic!=None:
      zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe=os.path.join(KVHfBWxvtsZcePaikyCcTlpLrgOLDVqA,jobEtvhVQburTHZejUvpnhBTgQnarPfi)
      r=os.path.join(aipUPwpioroSMFoKiCtXfdHtywBjkTKw,"mecabrc")
      if os.path.isdir(zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe):
        try:
          from MeCab import Tagger
        except:
          from fugashi import GenericTagger as Tagger
        self.mecab=Tagger("-r "+r.replace("\\","\\\\")+" -d "+zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe.replace("\\","\\\\")).AEJmffENNPFRriparsTHobsttCRfAMNQ
      elif jobEtvhVQburTHZejUvpnhBTgQnarPfi=="unidic-lite":
        try:
          from MeCab import Tagger
        except:
          from fugashi import GenericTagger as Tagger
        import unidic_lite
        self.mecab=Tagger("-r "+r.replace("\\","\\\\")+" -d "+unidic_lite.DICDIR.replace("\\","\\\\")).AEJmffENNPFRriparsTHobsttCRfAMNQ
      elif jobEtvhVQburTHZejUvpnhBTgQnarPfi=="ipadic":
        try:
          from MeCab import Tagger
        except:
          from fugashi import GenericTagger as Tagger
        try:
          import ipadic
          self.mecab=Tagger(ipadic.MECAB_ARGS).AEJmffENNPFRriparsTHobsttCRfAMNQ
        except:
          self.mecab=Tagger().AEJmffENNPFRriparsTHobsttCRfAMNQ
      else:
        zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe={ "gendai":"dic1", "spoken":"dic2", "novel":"dic11", "qkana":"dic3", "kindai":"dic4", "kinsei":"dic5", "kyogen":"dic6", "wakan":"dic7", "wabun":"dic8", "manyo":"dic9" }
        self.dictkey=zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe[jobEtvhVQburTHZejUvpnhBTgQnarPfi]
        zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe={ "spoken":"unidic-spoken", "novel":"65_novel", "qkana":"60b_qkana", "kindai":"60a_kindai-bungo", "kinsei":"50c_kinsei-edo", "kyogen":"40_chusei-kougo", "wakan":"30_chusei-bungo", "wabun":"20_chuko", "manyo":"10_jodai" }
        self.dictvalue=zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe[jobEtvhVQburTHZejUvpnhBTgQnarPfi] if jobEtvhVQburTHZejUvpnhBTgQnarPfi in zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe else jobEtvhVQburTHZejUvpnhBTgQnarPfi
        self.mecab=self.tixPuAWjhJHDPEThtUbEQfgFyFrvOsYq
    self.udpipe=self.pxQslauffUHBGKErxAVFGEDudCZEltuK
    if UDPipe==None:
      self.model="japanese-gsd"
    else:
      self.model=UDPipe
      BAkXoxPcTQqyaxxiaJuJVbTqFFmDTqLS=os.path.join(KVHfBWxvtsZcePaikyCcTlpLrgOLDVqA,self.model+".udpipe")
      if os.path.isfile(BAkXoxPcTQqyaxxiaJuJVbTqFFmDTqLS):
        import ufal.udpipe
        self.model=ufal.udpipe.Model.pIyFUfcMyZnxKdBFPwVjZesSYTTJVXms(BAkXoxPcTQqyaxxiaJuJVbTqFFmDTqLS)
        if jobEtvhVQburTHZejUvpnhBTgQnarPfi==None:
          self.udpipe=ufal.udpipe.Pipeline(self.model,"tokenizer=presegmented","","","").process
        else:
          self.udpipe=ufal.udpipe.Pipeline(self.model,"conllu","none","","").process
      elif self.model.startswith("stanza_"):
        import stanza
        if jobEtvhVQburTHZejUvpnhBTgQnarPfi==None:
          self.model=stanza.Pipeline(self.model[7:],verbose=False)
          from stanza.utils.conll import CoNLL
          self.udpipe=lambda text:CoNLL.conll_as_string(CoNLL.convert_dict(self.model(text).to_dict()))
        else:
          self.model=stanza.Pipeline(self.model[7:],processors="depparse",depparse_pretagged=True,verbose=False)
          self.udpipe=self.ltsADApOtOTIVZfWWVNIEZOCJmLpfnbX
  def __call__(self,SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF,raw=False):
    eCXmDczOBaNEYvpOiHHhmuoWkgPMyqGt=SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF
    tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe=eCXmDczOBaNEYvpOiHHhmuoWkgPMyqGt.find("\u3099")
    while i>0:
      f={"う":"ゔ","ウ":"ヴ","ワ":"ヷ","ヰ":"ヸ","ヱ":"ヹ","ヲ":"ヺ"}
      if eCXmDczOBaNEYvpOiHHhmuoWkgPMyqGt[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe-1] in f:
        GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP=f[eCXmDczOBaNEYvpOiHHhmuoWkgPMyqGt[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe-1]]
      else:
        GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP=chr(ord(eCXmDczOBaNEYvpOiHHhmuoWkgPMyqGt[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe-1])+1)
      eCXmDczOBaNEYvpOiHHhmuoWkgPMyqGt=eCXmDczOBaNEYvpOiHHhmuoWkgPMyqGt[0:tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe-1]+GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP+eCXmDczOBaNEYvpOiHHhmuoWkgPMyqGt[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe+1:]
      tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe=eCXmDczOBaNEYvpOiHHhmuoWkgPMyqGt.find("\u3099")
    tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe=eCXmDczOBaNEYvpOiHHhmuoWkgPMyqGt.find("\u309A")
    while i>0:
      eCXmDczOBaNEYvpOiHHhmuoWkgPMyqGt=eCXmDczOBaNEYvpOiHHhmuoWkgPMyqGt[0:tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe-1]+chr(ord(eCXmDczOBaNEYvpOiHHhmuoWkgPMyqGt[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe-1])+2)+eCXmDczOBaNEYvpOiHHhmuoWkgPMyqGt[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe+1:]
      tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe=eCXmDczOBaNEYvpOiHHhmuoWkgPMyqGt.find("\u309A")
    if self.jobEtvhVQburTHZejUvpnhBTgQnarPfi==None:
      u=self.udpipe(eCXmDczOBaNEYvpOiHHhmuoWkgPMyqGt).replace("# newdoc\n# newpar\n","")
      if raw:
        return u
      return DALMifTZBtspLFVNXVHrGMhovDiSFnHq(u)
    f={ "接頭辞":"NOUN", "接頭詞":"NOUN", "代名詞":"PRON", "連体詞":"DET", "副詞":"ADV", "感動詞":"INTJ", "フィラー":"INTJ", "接続詞":"CCONJ", "補助記号":"PUNCT" }
    u=""
    for KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR in eCXmDczOBaNEYvpOiHHhmuoWkgPMyqGt.split("\n"):
      u+="# text = "+KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR+"\n"
      awHJWzHObTHWDsWMSQodQjAATPwYVCLi=KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR
      oMCQDdKGDXNwGIwXjvYVQyHRtpwGcWVb=emAnIsoCzSnlPaHLAFzqOlSfXvyKleTS=""
      id=0
      for UwPPiaBKixQDGBBvxHkNjWNtugAMEtye in self.mecab(KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR).split("\n"):
        tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe=UwPPiaBKixQDGBBvxHkNjWNtugAMEtye.find("\t")
        if i>0:
          if self.jobEtvhVQburTHZejUvpnhBTgQnarPfi=="unidic-lite":
            HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd=UwPPiaBKixQDGBBvxHkNjWNtugAMEtye.split("\t")
            SUIkmCGlhwlHKovaIPUvdIqEsYipNDSF=HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[0]
            oEwGufqOIJjxdaGKsdIMCFVbgUIfoMJd=HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[4]
            IAxSwhoIhOaxTzWwkcEHjQRdUnQPDuib=HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[3]
            ndfbTccBPpHcgSTNDGVjvQTLnHnBVPqR=HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[1]
          else:
            SUIkmCGlhwlHKovaIPUvdIqEsYipNDSF=UwPPiaBKixQDGBBvxHkNjWNtugAMEtye[0:tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]
            HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd=UwPPiaBKixQDGBBvxHkNjWNtugAMEtye[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe+1:].split(",")
            oEwGufqOIJjxdaGKsdIMCFVbgUIfoMJd=HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[0]
            for KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR in HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[1:4]:
              if t!="*" and t!="　" and t!="":
                oEwGufqOIJjxdaGKsdIMCFVbgUIfoMJd+="-"+KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR
            if self.jobEtvhVQburTHZejUvpnhBTgQnarPfi=="ipadic":
              if len(HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd)>7:
                IAxSwhoIhOaxTzWwkcEHjQRdUnQPDuib=HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[6]
                ndfbTccBPpHcgSTNDGVjvQTLnHnBVPqR=HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[7]
              else:
                IAxSwhoIhOaxTzWwkcEHjQRdUnQPDuib=ndfbTccBPpHcgSTNDGVjvQTLnHnBVPqR=""
            elif len(HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd)<11:
              IAxSwhoIhOaxTzWwkcEHjQRdUnQPDuib=ndfbTccBPpHcgSTNDGVjvQTLnHnBVPqR=""
            else:
              IAxSwhoIhOaxTzWwkcEHjQRdUnQPDuib=HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[7]
              ndfbTccBPpHcgSTNDGVjvQTLnHnBVPqR=HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[10]
              if self.jobEtvhVQburTHZejUvpnhBTgQnarPfi in {"gendai","spoken"}:
                if len(HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd)>20:
                  ndfbTccBPpHcgSTNDGVjvQTLnHnBVPqR=HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[20]
                else:
                  ndfbTccBPpHcgSTNDGVjvQTLnHnBVPqR=HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[9]
          id+=1
        else:
          HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd=UwPPiaBKixQDGBBvxHkNjWNtugAMEtye.split(",")
          if len(HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd)<6:
            continue
          if HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[1]=="B":
            id=1
          elif HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[1]=="I":
            id+=1
          else:
            continue
          SUIkmCGlhwlHKovaIPUvdIqEsYipNDSF=HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[2]
          IAxSwhoIhOaxTzWwkcEHjQRdUnQPDuib=HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[3]
          oEwGufqOIJjxdaGKsdIMCFVbgUIfoMJd=HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[4]
          ndfbTccBPpHcgSTNDGVjvQTLnHnBVPqR=HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[5].replace("　","")
        if oEwGufqOIJjxdaGKsdIMCFVbgUIfoMJd=="空白" or oEwGufqOIJjxdaGKsdIMCFVbgUIfoMJd=="記号-空白":
          id-=1
          continue
        if awHJWzHObTHWDsWMSQodQjAATPwYVCLi.startswith(SUIkmCGlhwlHKovaIPUvdIqEsYipNDSF):
          awHJWzHObTHWDsWMSQodQjAATPwYVCLi=awHJWzHObTHWDsWMSQodQjAATPwYVCLi[len(SUIkmCGlhwlHKovaIPUvdIqEsYipNDSF):]
        else:
          awHJWzHObTHWDsWMSQodQjAATPwYVCLi=awHJWzHObTHWDsWMSQodQjAATPwYVCLi[awHJWzHObTHWDsWMSQodQjAATPwYVCLi.find(SUIkmCGlhwlHKovaIPUvdIqEsYipNDSF)+len(SUIkmCGlhwlHKovaIPUvdIqEsYipNDSF):]
          if oMCQDdKGDXNwGIwXjvYVQyHRtpwGcWVb=="SpaceAfter=No":
            u=u.rstrip("\t"+oMCQDdKGDXNwGIwXjvYVQyHRtpwGcWVb+"\n")+"\t_\n"
          elif "SpaceAfter=No|" in oMCQDdKGDXNwGIwXjvYVQyHRtpwGcWVb:
            u=u.rstrip(oMCQDdKGDXNwGIwXjvYVQyHRtpwGcWVb+"\n")+oMCQDdKGDXNwGIwXjvYVQyHRtpwGcWVb.replace("SpaceAfter=No|","")+"\n"
        IAxSwhoIhOaxTzWwkcEHjQRdUnQPDuib=IAxSwhoIhOaxTzWwkcEHjQRdUnQPDuib.replace("*","")
        tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe=IAxSwhoIhOaxTzWwkcEHjQRdUnQPDuib.find("-")
        if i>0:
          IAxSwhoIhOaxTzWwkcEHjQRdUnQPDuib=IAxSwhoIhOaxTzWwkcEHjQRdUnQPDuib[0:tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]
        if IAxSwhoIhOaxTzWwkcEHjQRdUnQPDuib=="":
          IAxSwhoIhOaxTzWwkcEHjQRdUnQPDuib=SUIkmCGlhwlHKovaIPUvdIqEsYipNDSF
        ndfbTccBPpHcgSTNDGVjvQTLnHnBVPqR=ndfbTccBPpHcgSTNDGVjvQTLnHnBVPqR.replace("*","")
        if ndfbTccBPpHcgSTNDGVjvQTLnHnBVPqR==SUIkmCGlhwlHKovaIPUvdIqEsYipNDSF:
          ndfbTccBPpHcgSTNDGVjvQTLnHnBVPqR=""
        lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS="X"
        ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw=(oEwGufqOIJjxdaGKsdIMCFVbgUIfoMJd+"-").replace("　","").split("-")
        if ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[0]=="名詞":
          lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS="NOUN"
          if ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[1]=="固有名詞":
            lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS="PROPN"
          elif ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[1]=="数詞" or ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[1]=="数":
            lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS="NUM"
          elif ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[1]=="代名詞":
            lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS="PRON"
          elif ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[1]=="助動詞語幹":
            lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS="AUX"
        elif ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[0]=="動詞":
          lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS="VERB"
          if ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[1]=="非自立可能":
            if emAnIsoCzSnlPaHLAFzqOlSfXvyKleTS.endswith("-サ変可能") or emAnIsoCzSnlPaHLAFzqOlSfXvyKleTS.endswith("-サ変形状詞可能"):
              KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR="\tNOUN\t"+emAnIsoCzSnlPaHLAFzqOlSfXvyKleTS+"\t_\t_\t_\t_\t"+oMCQDdKGDXNwGIwXjvYVQyHRtpwGcWVb+"\n"
              if u.endswith(KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR):
                u=u[0:-len(KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR)]+"\tVERB\t"+u[6-len(KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR):]
                lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS="AUX"
            elif emAnIsoCzSnlPaHLAFzqOlSfXvyKleTS.startswith("動詞") or emAnIsoCzSnlPaHLAFzqOlSfXvyKleTS=="助動詞" or emAnIsoCzSnlPaHLAFzqOlSfXvyKleTS.startswith("形容詞") or emAnIsoCzSnlPaHLAFzqOlSfXvyKleTS=="助詞-接続助詞":
              lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS="AUX"
        elif ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[0]=="形容詞":
          lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS="ADJ"
          if ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[1]=="非自立可能":
            if emAnIsoCzSnlPaHLAFzqOlSfXvyKleTS.startswith("動詞") or emAnIsoCzSnlPaHLAFzqOlSfXvyKleTS=="助動詞" or emAnIsoCzSnlPaHLAFzqOlSfXvyKleTS.startswith("形容詞"):
              lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS="AUX"
        elif ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[0]=="形状詞":
          lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS="ADJ"
          if ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[1]=="助動詞語幹":
            if emAnIsoCzSnlPaHLAFzqOlSfXvyKleTS.startswith("動詞") or emAnIsoCzSnlPaHLAFzqOlSfXvyKleTS=="助動詞" or emAnIsoCzSnlPaHLAFzqOlSfXvyKleTS.startswith("形容詞"):
              lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS="AUX"
        elif ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[0]=="助動詞":
          lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS="AUX"
          if emAnIsoCzSnlPaHLAFzqOlSfXvyKleTS.endswith("形状詞可能"):
            KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR="\tNOUN\t"+emAnIsoCzSnlPaHLAFzqOlSfXvyKleTS+"\t_\t_\t_\t_\t"+oMCQDdKGDXNwGIwXjvYVQyHRtpwGcWVb+"\n"
            if u.endswith(KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR):
              u=u[0:-len(KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR)]+"\tADJ\t"+u[6-len(KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR):]
        elif ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[0]=="助詞":
          lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS="ADP"
          if ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[1]=="接続助詞":
            lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS="SCONJ" if IAxSwhoIhOaxTzWwkcEHjQRdUnQPDuib=="て" else "CCONJ"
          elif ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[1]=="終助詞":
            lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS="PART"
        elif ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[0]=="接尾辞":
          lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS="NOUN" if ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[1]=="名詞的" else "PART"
        elif ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[0]=="記号":
          lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS="PUNCT" if ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[1] in {"句点","読点","括弧開","括弧閉"} else "SYM"
        elif ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[0] in f:
          lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS=f[ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[0]]
        oMCQDdKGDXNwGIwXjvYVQyHRtpwGcWVb="SpaceAfter=No" if ndfbTccBPpHcgSTNDGVjvQTLnHnBVPqR=="" else "SpaceAfter=No|Translit="+ndfbTccBPpHcgSTNDGVjvQTLnHnBVPqR
        u+="\t".join([str(id),SUIkmCGlhwlHKovaIPUvdIqEsYipNDSF,IAxSwhoIhOaxTzWwkcEHjQRdUnQPDuib,lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS,oEwGufqOIJjxdaGKsdIMCFVbgUIfoMJd,"_","_","_","_",oMCQDdKGDXNwGIwXjvYVQyHRtpwGcWVb])+"\n"
        emAnIsoCzSnlPaHLAFzqOlSfXvyKleTS=oEwGufqOIJjxdaGKsdIMCFVbgUIfoMJd
      u+="\n"
    if raw:
      return self.udpipe(u)
    return DALMifTZBtspLFVNXVHrGMhovDiSFnHq(self.udpipe(u))
  def tixPuAWjhJHDPEThtUbEQfgFyFrvOsYq(self,SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF):
    import random,urllib.request,json
    f={ self.dictkey:self.dictvalue, "st":SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF+"\n", "f1":"1", "f3":"1", "f10":"1", "out-e":"csv", "c-code":"utf-8" }
    b="".join(random.choice("abcdefghijklmnopqrstuvwxyz0123456789") for tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe in range(10))
    zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe="\n".join("--"+b+"\nContent-Disposition:form-data;name="+lnNYckBjoYMooooEDQqPrAOAkgKYAGHo+"\n\n"+awHJWzHObTHWDsWMSQodQjAATPwYVCLi for lnNYckBjoYMooooEDQqPrAOAkgKYAGHo,awHJWzHObTHWDsWMSQodQjAATPwYVCLi in f.items())+"\n--"+b+"--\n"
    IauKiVeAXdYjPpdDebxzFLcCYFdtVNQv={ "Content-Type":"multipart/form-data;charset=utf-8;boundary="+b }
    u=urllib.request.Request("https://chamame.ninjal.ac.jp/chamamebin/webchamame.php",zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe.encode(),IauKiVeAXdYjPpdDebxzFLcCYFdtVNQv)
    with urllib.request.urlopen(u) as r:
      VXAbdgQuhVifwRLxMFDJCwXnWRjYULCt=r.read()
    return VXAbdgQuhVifwRLxMFDJCwXnWRjYULCt.decode("utf-8").replace("\r","")
  def pxQslauffUHBGKErxAVFGEDudCZEltuK(self,SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF):
    import urllib.request,urllib.parse,json
    GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP="http://lindat.mff.cuni.cz/services/udpipe/api/process?model="+self.model
    u=urllib.AEJmffENNPFRriparsTHobsttCRfAMNQ.quote(SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF)
    if self.jobEtvhVQburTHZejUvpnhBTgQnarPfi==None:
      cdazJyeyMAWpjXejxpUJxNErHzPxsgwf="\n"
      yoLuIBLPvpGVANCOhMZWfbPgaoHBqUlW="&tokenizer=presegmented&tagger&parser"
    else:
      cdazJyeyMAWpjXejxpUJxNErHzPxsgwf="\n\n"
      yoLuIBLPvpGVANCOhMZWfbPgaoHBqUlW="&parser"
    if len(u)<8000:
      with urllib.request.urlopen(GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP+yoLuIBLPvpGVANCOhMZWfbPgaoHBqUlW+"&data="+u) as r:
        VXAbdgQuhVifwRLxMFDJCwXnWRjYULCt=r.read()
      return json.loads(VXAbdgQuhVifwRLxMFDJCwXnWRjYULCt)["result"]
    u=""
    for KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR in SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF.split(cdazJyeyMAWpjXejxpUJxNErHzPxsgwf):
      if KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR=="":
        continue
      with urllib.request.urlopen(GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP+yoLuIBLPvpGVANCOhMZWfbPgaoHBqUlW+"&data="+urllib.AEJmffENNPFRriparsTHobsttCRfAMNQ.quote(KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR+cdazJyeyMAWpjXejxpUJxNErHzPxsgwf)) as r:
        VXAbdgQuhVifwRLxMFDJCwXnWRjYULCt=r.read()
      u+=json.loads(VXAbdgQuhVifwRLxMFDJCwXnWRjYULCt)["result"]
    return u
  def ltsADApOtOTIVZfWWVNIEZOCJmLpfnbX(self,conllu):
    zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe=[]
    xxIgQUVJKzuDcUiwqbeYFPtXLXACKGdS=[]
    for UwPPiaBKixQDGBBvxHkNjWNtugAMEtye in conllu.split("\n"):
      if UwPPiaBKixQDGBBvxHkNjWNtugAMEtye=="" or UwPPiaBKixQDGBBvxHkNjWNtugAMEtye.startswith("#"):
        if e!=[]:
          zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe.append(list(xxIgQUVJKzuDcUiwqbeYFPtXLXACKGdS))
          xxIgQUVJKzuDcUiwqbeYFPtXLXACKGdS=[]
      else:
        KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR=UwPPiaBKixQDGBBvxHkNjWNtugAMEtye.split("\t")
        xxIgQUVJKzuDcUiwqbeYFPtXLXACKGdS.append({"id":int(KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR[0]),"text":KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR[1],"lemma":KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR[2],"upos":KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR[3],"xpos":KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR[4],"misc":KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR[9]})
    from stanza.models.common.doc import Document
    from stanza.utils.conll import CoNLL
    return CoNLL.conll_as_string(CoNLL.convert_dict(self.model(Document(zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe)).to_dict()))
def pIyFUfcMyZnxKdBFPwVjZesSYTTJVXms(jobEtvhVQburTHZejUvpnhBTgQnarPfi=None,UDPipe="japanese-modern"):
  if jobEtvhVQburTHZejUvpnhBTgQnarPfi==UDPipe:
    jobEtvhVQburTHZejUvpnhBTgQnarPfi=None
  return mRxjzrLQByKfHwSQrAFdqEsMtYzFEGPK(jobEtvhVQburTHZejUvpnhBTgQnarPfi,UDPipe)
