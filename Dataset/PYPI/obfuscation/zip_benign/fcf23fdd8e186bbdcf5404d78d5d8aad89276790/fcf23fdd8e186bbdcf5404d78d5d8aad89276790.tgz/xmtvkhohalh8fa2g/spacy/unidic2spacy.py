#! /usr/bin/python3 -tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe
import numpy
from spacy.language import Language
from spacy.symbols import LANG,NORM,LEMMA,POS,TAG,DEP,HEAD
from spacy.tokens import Doc,Span,UnUGUWahAbqdoauLMxFQvFmvHcsGGOks
from spacy.util import get_lang_class
from unidic2ud.cabocha import CuXafWpyckounewrAQlYJoTuoNMRjpUH
class CgCxnpJJRYkFGOYnjSLHKGeaotJnokis(Language):
  vdIicwwaVxEEkuPvxwvCPysrJZiCyOgC="ja"
  WKfbiNwuHgKwYusGeFJwrptfBxSkkMMG=10**6
  def __init__(self,jobEtvhVQburTHZejUvpnhBTgQnarPfi,UDPipe):
    self.Defaults.lex_attr_getters[LANG]=lambda _text:"ja"
    try:
      self.vocab=self.Defaults.create_vocab()
      self.pipeline=[]
    except:
      from spacy.vocab import create_vocab
      self.vocab=create_vocab("ja",self.Defaults)
      self._components=[]
      self._disabled=set()
    self.tokenizer=GOgyliMMkwidSHidhnlSMUznpDbQCDrw(jobEtvhVQburTHZejUvpnhBTgQnarPfi,UDPipe,self.vocab)
    self._meta={
      "author":"Koichi Yasuoka",
      "description":"derived from UniDic2UD",
      "lang":"UniDic_"+jobEtvhVQburTHZejUvpnhBTgQnarPfi if UniDic!=None else "udpipe_ja-modern",
      "license":"MIT",
      "name":jobEtvhVQburTHZejUvpnhBTgQnarPfi if UniDic!=None else "ja-modern",
      "parent_package":"spacy_unidic",
      "pipeline":"Tokenizer, POS-Tagger, Parser",
      "spacy_version":">=2.1.0"
    }
    self._path=None
class GOgyliMMkwidSHidhnlSMUznpDbQCDrw(object):
  owfHIZHBIEHGWAYTXrmiwiEeYFtXYPnE=lambda self,*args,**kwargs:None
  TBkhMsEXLWqcqFldqYvLKjBaaLjvlwJU=lambda self,*args,**kwargs:None
  DJmMXIzbnViRkbUROJyxbhpUWpyHrXaS=lambda self,*args,**kwargs:None
  SyBhsSCxzELTbsjUMOlHqARkWoUHMclq=lambda self,*args,**kwargs:None
  def __init__(self,unidic,udpipe,vocab):
    import unidic2ud
    self.model=unidic2ud.pIyFUfcMyZnxKdBFPwVjZesSYTTJVXms(unidic,udpipe)
    self.vocab=vocab
  def __call__(self,text):
    u=self.model(text,raw=True) if text else ""
    UqjiVEWzYhSeUCiivTuGjAZSdAMiFMSW=self.vocab.strings
    r=UqjiVEWzYhSeUCiivTuGjAZSdAMiFMSW.add("ROOT")
    iCDMsCGjHpSVmxcfgYuhlCiBtxAdUuoB=[]
    sRRSXVojWFKZOLJPcKgiRdGYufXfFXat=[]
    sDsDSTJfNkdRsUXsektmAReMusDXueLm=[]
    oUjKiQItUmRQJuEPfkYkiAcXtlLSIwYz=[]
    wptVguPghfXGZPIXSjIdZkLAXRkwjxDg=[]
    ejsYkueVdcRgcXaAiWTyJHglhvSSYlvy=[]
    fcnSdNYRtRAfbnVQDKRpWYMyKHutAXSm=[]
    nFEqtQpepqcUnrzLfwhSsBjZTPrNMZMW=[]
    zSlJbnHQIRFuYtwRPSGzuShhJBoOoKar=[]
    for KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR in u.split("\n"):
      if KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR=="" or KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR.startswith("#"):
        continue
      UwPPiaBKixQDGBBvxHkNjWNtugAMEtye=KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR.split("\t")
      if len(UwPPiaBKixQDGBBvxHkNjWNtugAMEtye)!=10:
        continue
      id,SUIkmCGlhwlHKovaIPUvdIqEsYipNDSF,IAxSwhoIhOaxTzWwkcEHjQRdUnQPDuib,lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS,oEwGufqOIJjxdaGKsdIMCFVbgUIfoMJd,MMJRpexkvvnyvqFTdQyOHPAoNbmyVCeB,QpticPwshsLBghshfYvuYDcHKJLzokCQ,zSGiFziCrxBmkbkTdGUuzkpipfMLOkEi,uGmmZDIBEWSUHJEJnJxEpxzCIxjTsMAB,oMCQDdKGDXNwGIwXjvYVQyHRtpwGcWVb=UwPPiaBKixQDGBBvxHkNjWNtugAMEtye
      iCDMsCGjHpSVmxcfgYuhlCiBtxAdUuoB.append(SUIkmCGlhwlHKovaIPUvdIqEsYipNDSF)
      sRRSXVojWFKZOLJPcKgiRdGYufXfFXat.append(UqjiVEWzYhSeUCiivTuGjAZSdAMiFMSW.add(IAxSwhoIhOaxTzWwkcEHjQRdUnQPDuib))
      sDsDSTJfNkdRsUXsektmAReMusDXueLm.append(UqjiVEWzYhSeUCiivTuGjAZSdAMiFMSW.add(lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS))
      oUjKiQItUmRQJuEPfkYkiAcXtlLSIwYz.append(UqjiVEWzYhSeUCiivTuGjAZSdAMiFMSW.add(oEwGufqOIJjxdaGKsdIMCFVbgUIfoMJd))
      wptVguPghfXGZPIXSjIdZkLAXRkwjxDg.append(MMJRpexkvvnyvqFTdQyOHPAoNbmyVCeB)
      if zSGiFziCrxBmkbkTdGUuzkpipfMLOkEi=="root":
        ejsYkueVdcRgcXaAiWTyJHglhvSSYlvy.append(0)
        fcnSdNYRtRAfbnVQDKRpWYMyKHutAXSm.append(r)
      else:
        IauKiVeAXdYjPpdDebxzFLcCYFdtVNQv=int(QpticPwshsLBghshfYvuYDcHKJLzokCQ)-int(id)
        ejsYkueVdcRgcXaAiWTyJHglhvSSYlvy.append(2**64+IauKiVeAXdYjPpdDebxzFLcCYFdtVNQv if h<0 else IauKiVeAXdYjPpdDebxzFLcCYFdtVNQv)
        fcnSdNYRtRAfbnVQDKRpWYMyKHutAXSm.append(UqjiVEWzYhSeUCiivTuGjAZSdAMiFMSW.add(zSGiFziCrxBmkbkTdGUuzkpipfMLOkEi))
      nFEqtQpepqcUnrzLfwhSsBjZTPrNMZMW.append(False if "SpaceAfter=No" in oMCQDdKGDXNwGIwXjvYVQyHRtpwGcWVb else True)
      tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe=oMCQDdKGDXNwGIwXjvYVQyHRtpwGcWVb.find("Translit=")
      zSlJbnHQIRFuYtwRPSGzuShhJBoOoKar.append(UqjiVEWzYhSeUCiivTuGjAZSdAMiFMSW.add(SUIkmCGlhwlHKovaIPUvdIqEsYipNDSF if i<0 else oMCQDdKGDXNwGIwXjvYVQyHRtpwGcWVb[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe+9:]))
    HfpncyymToTsJYHDAzIeTsUfAlRTdXSo=Doc(self.vocab,iCDMsCGjHpSVmxcfgYuhlCiBtxAdUuoB=iCDMsCGjHpSVmxcfgYuhlCiBtxAdUuoB,nFEqtQpepqcUnrzLfwhSsBjZTPrNMZMW=nFEqtQpepqcUnrzLfwhSsBjZTPrNMZMW)
    HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd=numpy.array(list(zip(sRRSXVojWFKZOLJPcKgiRdGYufXfFXat,sDsDSTJfNkdRsUXsektmAReMusDXueLm,oUjKiQItUmRQJuEPfkYkiAcXtlLSIwYz,fcnSdNYRtRAfbnVQDKRpWYMyKHutAXSm,ejsYkueVdcRgcXaAiWTyJHglhvSSYlvy,zSlJbnHQIRFuYtwRPSGzuShhJBoOoKar)),dtype="uint64")
    HfpncyymToTsJYHDAzIeTsUfAlRTdXSo.from_array([LEMMA,POS,TAG,DEP,HEAD,NORM],HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd)
    try:
      HfpncyymToTsJYHDAzIeTsUfAlRTdXSo.is_tagged=True
      HfpncyymToTsJYHDAzIeTsUfAlRTdXSo.is_parsed=True
    except:
      for tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe,GPuPzBsbrAtoFChYzHFHVecNaINEoEOc in enumerate(wptVguPghfXGZPIXSjIdZkLAXRkwjxDg):
        if j!="_" and j!="":
          HfpncyymToTsJYHDAzIeTsUfAlRTdXSo[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].set_morph(GPuPzBsbrAtoFChYzHFHVecNaINEoEOc)
    KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR=CuXafWpyckounewrAQlYJoTuoNMRjpUH(u)
    KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR.PlcmyTWTZtSioeUrCKIStiQwgeVVymLn()
    nxFJWZvoexqIqTCGMKSNNSMEJMwKoXWC=["I"]*len(HfpncyymToTsJYHDAzIeTsUfAlRTdXSo)
    for UwPPiaBKixQDGBBvxHkNjWNtugAMEtye in KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr._sentences:
      for peRZKciRbOWeRRHXWWSgducMSzIWuRrB in UwPPiaBKixQDGBBvxHkNjWNtugAMEtye:
        try:
          nxFJWZvoexqIqTCGMKSNNSMEJMwKoXWC[peRZKciRbOWeRRHXWWSgducMSzIWuRrB[0]-1]="B"
        except:
          pass
    HfpncyymToTsJYHDAzIeTsUfAlRTdXSo.user_data["bunsetu_bi_labels"]=nxFJWZvoexqIqTCGMKSNNSMEJMwKoXWC
    return HfpncyymToTsJYHDAzIeTsUfAlRTdXSo
class RAsLiUicJteSLfhGFDpyzWTBHkXWTRGa(object):
  def __init__(self,jobEtvhVQburTHZejUvpnhBTgQnarPfi):
    import unidic2ud
    self.tagger=unidic2ud.mRxjzrLQByKfHwSQrAFdqEsMtYzFEGPK(jobEtvhVQburTHZejUvpnhBTgQnarPfi,None)
    self.jobEtvhVQburTHZejUvpnhBTgQnarPfi=jobEtvhVQburTHZejUvpnhBTgQnarPfi
  def __call__(self,text):
    r=[]
    for KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR in text.split("\n"):
      for UwPPiaBKixQDGBBvxHkNjWNtugAMEtye in self.tagger.mecab(KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR).split("\n"):
        if UwPPiaBKixQDGBBvxHkNjWNtugAMEtye=="" or UwPPiaBKixQDGBBvxHkNjWNtugAMEtye=="EOS":
          continue
        if UwPPiaBKixQDGBBvxHkNjWNtugAMEtye.find("\t")>0:
          if self.jobEtvhVQburTHZejUvpnhBTgQnarPfi in {"gendai","spoken"}:
            b=UwPPiaBKixQDGBBvxHkNjWNtugAMEtye.split("\t")
            HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd=b[1].split(",")
            if len(HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd)>20:
              HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[9]=HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[20]
            if len(HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd)>10:
              HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[10]=HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[9]
            for tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe in range(len(HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd)):
              if HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]=="":
                HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]="*"
            r.append(rdEhgCWkEObbobzlKtIavCHdQxUUPWBy(b[0]+"\t"+",".join(HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd)))
          else:
            r.append(rdEhgCWkEObbobzlKtIavCHdQxUUPWBy(UwPPiaBKixQDGBBvxHkNjWNtugAMEtye))
        else:
          HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd=UwPPiaBKixQDGBBvxHkNjWNtugAMEtye.split(",")
          if HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[1]!="B" and HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[1]!="I":
            continue
          if HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[4]=="名詞":
            UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt=["名詞","普通名詞","一般","*"]
          else:
            UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt=(HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[4]+"-*-*-*-*").split("-")
          r.append(rdEhgCWkEObbobzlKtIavCHdQxUUPWBy(HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[2]+"\t"+",".join([UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt[0],UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt[1],UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt[2],UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt[3],"*","*","*",HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[3],HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[2],HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[5],HwXNEDkwHBXvuhZlRhSXBMYwQepWEKAd[5]])))
    return r
class rdEhgCWkEObbobzlKtIavCHdQxUUPWBy(object):
  def __init__(self,line):
    self.morph_line=line.split("\t")
  def jXJRBVzPoIUlgGKJRsKfaFfwponVragx(self):
    return self.morph_line[0]
  def RHzHIbfWxCFFNlMPUuWACpQQSnHfmqvT(self):
    try:
      return self.morph_line[1].split(",")[0:6]
    except:
      return ["名詞","普通名詞","一般","*","*","*"]
  def aKoLxLNzXgmpDDDmMRxXErpZNZaHLAup(self):
    try:
      TFrXFRafqYQClFvLGAWbltmLGNUhnmlr=self.morph_line[1].split(",")[7]
    except:
      return self.jXJRBVzPoIUlgGKJRsKfaFfwponVragx()
    tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe=TFrXFRafqYQClFvLGAWbltmLGNUhnmlr.find("-")
    if i<1:
      return TFrXFRafqYQClFvLGAWbltmLGNUhnmlr
    return TFrXFRafqYQClFvLGAWbltmLGNUhnmlr[0:tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]
  def gXThGMEukOxGwaTiMDTZrwyeKMlFeEeq(self):
    return self.aKoLxLNzXgmpDDDmMRxXErpZNZaHLAup()
  def vdWwcaDKYvZzPXVMMPWRWpIwAiZFBIuL(self):
    try:
      return self.morph_line[1].split(",")[10]
    except:
      return ""
  def split(self,mode):
    return [self]
def pIyFUfcMyZnxKdBFPwVjZesSYTTJVXms(jobEtvhVQburTHZejUvpnhBTgQnarPfi=None,gsiFZnmevurVUktPqzbizzpksZwMroFB="japanese-modern"):
  if gsiFZnmevurVUktPqzbizzpksZwMroFB==None:
    return CgCxnpJJRYkFGOYnjSLHKGeaotJnokis(jobEtvhVQburTHZejUvpnhBTgQnarPfi,None)
  if jobEtvhVQburTHZejUvpnhBTgQnarPfi==gsiFZnmevurVUktPqzbizzpksZwMroFB:
    jobEtvhVQburTHZejUvpnhBTgQnarPfi=None
  if jobEtvhVQburTHZejUvpnhBTgQnarPfi==None or not gsiFZnmevurVUktPqzbizzpksZwMroFB.startswith("ja_"):
    return CgCxnpJJRYkFGOYnjSLHKGeaotJnokis(jobEtvhVQburTHZejUvpnhBTgQnarPfi,gsiFZnmevurVUktPqzbizzpksZwMroFB)
  import spacy
  ddsKIefhkbkMABhtbwLboboYqIUUWKqY=spacy.pIyFUfcMyZnxKdBFPwVjZesSYTTJVXms(gsiFZnmevurVUktPqzbizzpksZwMroFB)
  ddsKIefhkbkMABhtbwLboboYqIUUWKqY.tokenizer.tokenizer.tokenize=RAsLiUicJteSLfhGFDpyzWTBHkXWTRGa(jobEtvhVQburTHZejUvpnhBTgQnarPfi)
  return ddsKIefhkbkMABhtbwLboboYqIUUWKqY
def RcUqjIpSQWlmArnFUvytKPkzCsoCIJbz(item,offset=1):
  if type(item)==Doc:
    return "".join(RcUqjIpSQWlmArnFUvytKPkzCsoCIJbz(UwPPiaBKixQDGBBvxHkNjWNtugAMEtye)+"\n" for UwPPiaBKixQDGBBvxHkNjWNtugAMEtye in item.sents)
  elif type(item)==Span:
    return "# text = "+str(item)+"\n"+"".join(RcUqjIpSQWlmArnFUvytKPkzCsoCIJbz(KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR,1-item.start)+"\n" for KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR in item)
  elif type(item)==UnUGUWahAbqdoauLMxFQvFmvHcsGGOks:
    BAkXoxPcTQqyaxxiaJuJVbTqFFmDTqLS="_"
    if item.ent_iob_ in {"B","I"}:
      BAkXoxPcTQqyaxxiaJuJVbTqFFmDTqLS="NE="+item.ent_iob_+"-"+item.ent_type_
    if not item.whitespace_:
      BAkXoxPcTQqyaxxiaJuJVbTqFFmDTqLS+="|SpaceAfter=No"
    if item.norm_!="":
      if item.norm_!=item.orth_:
        BAkXoxPcTQqyaxxiaJuJVbTqFFmDTqLS+="|Translit="+item.norm_
    BAkXoxPcTQqyaxxiaJuJVbTqFFmDTqLS=BAkXoxPcTQqyaxxiaJuJVbTqFFmDTqLS.replace("_|","")
    DXQSJgyqFLyzyvzxlCPHbMNMktxpFZKr=item.lemma_
    if DXQSJgyqFLyzyvzxlCPHbMNMktxpFZKr=="":
      DXQSJgyqFLyzyvzxlCPHbMNMktxpFZKr="_"
    KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR=item.tag_
    if KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR=="":
      KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR="_"
    try:
      f=str(item.morph)
      if f.startswith("<spacy") or f=="":
        f="_"
    except:
      f="_"
    return "\t".join([str(item.tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe+offset),item.orth_,DXQSJgyqFLyzyvzxlCPHbMNMktxpFZKr,item.pos_,KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR,f,str(0 if item.QpticPwshsLBghshfYvuYDcHKJLzokCQ==item else item.QpticPwshsLBghshfYvuYDcHKJLzokCQ.tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe+offset),item.dep_.lower(),"_",BAkXoxPcTQqyaxxiaJuJVbTqFFmDTqLS])
  return "".join(RcUqjIpSQWlmArnFUvytKPkzCsoCIJbz(UwPPiaBKixQDGBBvxHkNjWNtugAMEtye)+"\n" for UwPPiaBKixQDGBBvxHkNjWNtugAMEtye in item)
def BcTEMnYSOCBAnJkgIBUPYccYwPYMlTGC(HfpncyymToTsJYHDAzIeTsUfAlRTdXSo):
  if type(HfpncyymToTsJYHDAzIeTsUfAlRTdXSo)==Doc:
    b=[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe for tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe,GPuPzBsbrAtoFChYzHFHVecNaINEoEOc in enumerate(HfpncyymToTsJYHDAzIeTsUfAlRTdXSo.user_data["bunsetu_bi_labels"]) if GPuPzBsbrAtoFChYzHFHVecNaINEoEOc=="B"]
    b.append(len(HfpncyymToTsJYHDAzIeTsUfAlRTdXSo))
    return [Span(HfpncyymToTsJYHDAzIeTsUfAlRTdXSo,tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe,GPuPzBsbrAtoFChYzHFHVecNaINEoEOc) for tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe,GPuPzBsbrAtoFChYzHFHVecNaINEoEOc in zip(b,b[1:])]
  elif type(HfpncyymToTsJYHDAzIeTsUfAlRTdXSo)==Span:
    b=HfpncyymToTsJYHDAzIeTsUfAlRTdXSo[0].HfpncyymToTsJYHDAzIeTsUfAlRTdXSo.user_data["bunsetu_bi_labels"]
    UwPPiaBKixQDGBBvxHkNjWNtugAMEtye=[HqRZfmSbTseTnYioojuXuDLoZLDtoeML(HfpncyymToTsJYHDAzIeTsUfAlRTdXSo[0])] if b[HfpncyymToTsJYHDAzIeTsUfAlRTdXSo[0].tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]=="I" else []
    for KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR in HfpncyymToTsJYHDAzIeTsUfAlRTdXSo:
      if b[KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR.tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]=="B":
        UwPPiaBKixQDGBBvxHkNjWNtugAMEtye.append(HqRZfmSbTseTnYioojuXuDLoZLDtoeML(KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR))
    return UwPPiaBKixQDGBBvxHkNjWNtugAMEtye
  elif type(HfpncyymToTsJYHDAzIeTsUfAlRTdXSo)==UnUGUWahAbqdoauLMxFQvFmvHcsGGOks:
    return [HqRZfmSbTseTnYioojuXuDLoZLDtoeML(HfpncyymToTsJYHDAzIeTsUfAlRTdXSo)]
def HqRZfmSbTseTnYioojuXuDLoZLDtoeML(NHNpExAngTXDYXWrrIJMyZtQFXgqRsSX):
  b="".join(NHNpExAngTXDYXWrrIJMyZtQFXgqRsSX.HfpncyymToTsJYHDAzIeTsUfAlRTdXSo.user_data["bunsetu_bi_labels"])+"B"
  return Span(NHNpExAngTXDYXWrrIJMyZtQFXgqRsSX.HfpncyymToTsJYHDAzIeTsUfAlRTdXSo,b.rindex("B",0,NHNpExAngTXDYXWrrIJMyZtQFXgqRsSX.tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe+1),b.index("B",NHNpExAngTXDYXWrrIJMyZtQFXgqRsSX.tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe+1))
