import sys
from .unidic2ud import oDkeNAyzRVMwSLiPRgTJqKzDwTOPwAwO,xbJLNJlOhzbNcDdYQSFlUUhVqkYXlpZP
if sys.argv[1]=="download":
  oDkeNAyzRVMwSLiPRgTJqKzDwTOPwAwO(sys.argv[2],None)
elif sys.argv[1]=="download.unidic":
  oDkeNAyzRVMwSLiPRgTJqKzDwTOPwAwO(sys.argv[2],"unidic")
elif sys.argv[1]=="download.udpipe":
  oDkeNAyzRVMwSLiPRgTJqKzDwTOPwAwO(sys.argv[2],"udpipe")
elif sys.argv[1]=="dictlist":
  print(xbJLNJlOhzbNcDdYQSFlUUhVqkYXlpZP().replace("\n"," (unidic)\n").replace(".udpipe (unidic)"," (udpipe)"),end="")
elif sys.argv[1]=="where":
  from .unidic2ud import KVHfBWxvtsZcePaikyCcTlpLrgOLDVqA
  print(" DicDir: "+KVHfBWxvtsZcePaikyCcTlpLrgOLDVqA)
  tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe=KVHfBWxvtsZcePaikyCcTlpLrgOLDVqA.rindex("/lib/")
  print("Command: "+KVHfBWxvtsZcePaikyCcTlpLrgOLDVqA[0:tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]+"/bin/udcabocha")
