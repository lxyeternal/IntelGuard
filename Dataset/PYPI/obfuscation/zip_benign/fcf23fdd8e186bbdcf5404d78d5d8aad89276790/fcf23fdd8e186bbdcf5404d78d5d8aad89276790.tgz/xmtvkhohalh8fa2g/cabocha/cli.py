import sys
def TCpdYMlSNaYxDrhgDrRYyietaWRNoBQT():
  ELRtbGVzykyUfLQzfxXkESdXUzINceVX=len(sys.argv)
  tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe=1
  f=0
  u=None
  while i<ELRtbGVzykyUfLQzfxXkESdXUzINceVX:
    nrMGelbRJivkvfHuloqcVGZwAVcCqLaO=sys.argv[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]
    if nrMGelbRJivkvfHuloqcVGZwAVcCqLaO.startswith("-f"):
      if nrMGelbRJivkvfHuloqcVGZwAVcCqLaO=="-f":
        tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe+=1
        f=int(sys.argv[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe])
      else:
        f=int(sys.argv[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe][2:])
      if f<0 or f>8:
        TvqKyjGxwuRXqOrufHESFATAeBiGrvpe()
    elif nrMGelbRJivkvfHuloqcVGZwAVcCqLaO.startswith("-U"):
      if nrMGelbRJivkvfHuloqcVGZwAVcCqLaO=="-U":
        tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe+=1
        u=sys.argv[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]
      else:
        u=sys.argv[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe][2:]
    elif nrMGelbRJivkvfHuloqcVGZwAVcCqLaO.startswith("--download="):
      zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe=sys.argv[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe][11:]
      if d>"":
        from unidic2ud import oDkeNAyzRVMwSLiPRgTJqKzDwTOPwAwO,xbJLNJlOhzbNcDdYQSFlUUhVqkYXlpZP
        UwPPiaBKixQDGBBvxHkNjWNtugAMEtye=xbJLNJlOhzbNcDdYQSFlUUhVqkYXlpZP().replace(".udpipe","").split()
        if zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe in UwPPiaBKixQDGBBvxHkNjWNtugAMEtye:
          print("udcabocha: "+zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe+" was already downloaded",file=sys.stderr)
        else:
          oDkeNAyzRVMwSLiPRgTJqKzDwTOPwAwO(zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe)
      TvqKyjGxwuRXqOrufHESFATAeBiGrvpe()
    elif nrMGelbRJivkvfHuloqcVGZwAVcCqLaO=="-h" or nrMGelbRJivkvfHuloqcVGZwAVcCqLaO=="--help" or nrMGelbRJivkvfHuloqcVGZwAVcCqLaO=="-v" or nrMGelbRJivkvfHuloqcVGZwAVcCqLaO=="--version":
      TvqKyjGxwuRXqOrufHESFATAeBiGrvpe()
    else:
      break
    tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe+=1
  else:
    qclbXdbTwaeevNOumMKWawpwRjPBoXls=gsiFZnmevurVUktPqzbizzpksZwMroFB(u,f)
    while True:
      try:
        UwPPiaBKixQDGBBvxHkNjWNtugAMEtye=input()
      except:
        return
      print(qclbXdbTwaeevNOumMKWawpwRjPBoXls(UwPPiaBKixQDGBBvxHkNjWNtugAMEtye),end="")
  qclbXdbTwaeevNOumMKWawpwRjPBoXls=gsiFZnmevurVUktPqzbizzpksZwMroFB(u,f)
  while i<ELRtbGVzykyUfLQzfxXkESdXUzINceVX:
    UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt=open(sys.argv[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe],"r",encoding="utf-8")
    UwPPiaBKixQDGBBvxHkNjWNtugAMEtye=UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt.read()
    UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt.close()
    print(qclbXdbTwaeevNOumMKWawpwRjPBoXls(UwPPiaBKixQDGBBvxHkNjWNtugAMEtye),end="")
    tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe+=1
class gsiFZnmevurVUktPqzbizzpksZwMroFB(object):
  def __init__(self,jobEtvhVQburTHZejUvpnhBTgQnarPfi,format):
    self.format=format
    if format>3:
      from unidic2ud import pIyFUfcMyZnxKdBFPwVjZesSYTTJVXms
      self.AEJmffENNPFRriparsTHobsttCRfAMNQ=pIyFUfcMyZnxKdBFPwVjZesSYTTJVXms(jobEtvhVQburTHZejUvpnhBTgQnarPfi)
    else:
      from unidic2ud.cabocha import HckFloDXIwwdPvbXaEgpmbIqbmFmTnXm
      self.AEJmffENNPFRriparsTHobsttCRfAMNQ=HckFloDXIwwdPvbXaEgpmbIqbmFmTnXm(jobEtvhVQburTHZejUvpnhBTgQnarPfi).AEJmffENNPFRriparsTHobsttCRfAMNQ
  def __call__(self,SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF):
    if self.format==4:
      return self.AEJmffENNPFRriparsTHobsttCRfAMNQ(SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF,raw=True)
    elif self.format==5:
      return self.AEJmffENNPFRriparsTHobsttCRfAMNQ(SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF).DcQHfhSdsuUhhopxhzVHteInRjUdTJBq()
    elif self.format==6:
      return self.AEJmffENNPFRriparsTHobsttCRfAMNQ(SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF).DcQHfhSdsuUhhopxhzVHteInRjUdTJBq(2)
    elif self.format==7:
      return self.AEJmffENNPFRriparsTHobsttCRfAMNQ(SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF).duKmUQvmemXWsFbprxCApHlrZCYcOcoP()
    elif self.format==8:
      import deplacy
      zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe=deplacy.dot(self.AEJmffENNPFRriparsTHobsttCRfAMNQ(SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF,raw=True)).split("\n")
      zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe[0]=zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe[0].replace("deplacy","udcabocha")
      return "\n".join(zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe)
    return self.AEJmffENNPFRriparsTHobsttCRfAMNQ(SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF).FKAfpmGLZqNLzBQIuaicysXRLFGuPMSI(self.format)
def TvqKyjGxwuRXqOrufHESFATAeBiGrvpe():
  from pkg_resources import get_distribution
  from unidic2ud import xbJLNJlOhzbNcDdYQSFlUUhVqkYXlpZP
  print("UniDic2UD Version "+get_distribution("unidic2ud").version,file=sys.stderr)
  print("Usage: udcabocha -U Dict [-f 0-8] file",file=sys.stderr)
  print("       udcabocha --download=Dict",file=sys.stderr)
  UwPPiaBKixQDGBBvxHkNjWNtugAMEtye=" Dict:\n"+xbJLNJlOhzbNcDdYQSFlUUhVqkYXlpZP().replace(".udpipe","(udpipe)")
  print(UwPPiaBKixQDGBBvxHkNjWNtugAMEtye.replace("\n"," ").rstrip(),file=sys.stderr)
  sys.exit()
if __name__=="__main__":
  TCpdYMlSNaYxDrhgDrRYyietaWRNoBQT()
