#! /usr/bin/python3 -tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe
import unidic2ud
class CuXafWpyckounewrAQlYJoTuoNMRjpUH(unidic2ud.NursDaahDHWeifFiRnFzGDRRJOUzUakq):
  EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr=type("UniDic2Cabocha",(object,),{})
  def PlcmyTWTZtSioeUrCKIStiQwgeVVymLn(self):
    BAkXoxPcTQqyaxxiaJuJVbTqFFmDTqLS={"NOUN","PROPN","PRON","NUM","VERB","ADJ","DET","ADV","SYM"}
    UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt,UwPPiaBKixQDGBBvxHkNjWNtugAMEtye,GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP=[],[],[]
    ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw=0
    for tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe in range(1,len(self)):
      id=self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].id
      if id==1:
        if c!=[]:
          UwPPiaBKixQDGBBvxHkNjWNtugAMEtye.append(GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP)
          GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP=[]
        if s!=[]:
          UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt.append(UwPPiaBKixQDGBBvxHkNjWNtugAMEtye)
          UwPPiaBKixQDGBBvxHkNjWNtugAMEtye=[]
      if x>id:
        GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP.append(tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe)
      elif ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw==id:
        GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP.append(tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe)
        ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw=0
        zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe=self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].zSGiFziCrxBmkbkTdGUuzkpipfMLOkEi
        if zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe=="compound" or zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe=="nummod":
          if self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].QpticPwshsLBghshfYvuYDcHKJLzokCQ.id>id:
            ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw=self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].QpticPwshsLBghshfYvuYDcHKJLzokCQ.id
        elif zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe=="advcl" or zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe=="obl":
          if self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].QpticPwshsLBghshfYvuYDcHKJLzokCQ.id-id==1 and self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].upos!="ADJ":
            ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw=id+1
      elif self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS in BAkXoxPcTQqyaxxiaJuJVbTqFFmDTqLS:
        if self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].QpticPwshsLBghshfYvuYDcHKJLzokCQ.id<id:
          GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP.append(tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe)
        else:
          if c!=[]:
            UwPPiaBKixQDGBBvxHkNjWNtugAMEtye.append(GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP)
          GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP=[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]
          zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe=self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].zSGiFziCrxBmkbkTdGUuzkpipfMLOkEi
          if zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe=="compound" or zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe=="nummod":
            if self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].QpticPwshsLBghshfYvuYDcHKJLzokCQ.id>id:
              ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw=self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].QpticPwshsLBghshfYvuYDcHKJLzokCQ.id
          elif zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe=="advcl" or zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe=="obl":
            if self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].QpticPwshsLBghshfYvuYDcHKJLzokCQ.id-id==1 and self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].upos!="ADJ":
              ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw=id+1
      elif self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS=="INTJ":
        if self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].QpticPwshsLBghshfYvuYDcHKJLzokCQ.id<id:
          GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP.append(tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe)
        elif self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe-1].lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS=="INTJ":
          GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP.append(tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe)
        else:
          if c!=[]:
            UwPPiaBKixQDGBBvxHkNjWNtugAMEtye.append(GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP)
          GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP=[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]
      elif self[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe].lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS=="PUNCT":
        GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP.append(tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe)
        UwPPiaBKixQDGBBvxHkNjWNtugAMEtye.append(GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP)
        GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP=[]
      else:
        GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP.append(tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe)
    if c!=[]:
      UwPPiaBKixQDGBBvxHkNjWNtugAMEtye.append(GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP)
    if s!=[]:
      UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt.append(UwPPiaBKixQDGBBvxHkNjWNtugAMEtye)
    self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr._sentences=UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt
    self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr._chunkinfo=[]
    lnNYckBjoYMooooEDQqPrAOAkgKYAGHo=0
    for UwPPiaBKixQDGBBvxHkNjWNtugAMEtye in UPyklnzyMgPQoRQbYsfdFVwWTZOjxijt:
      nbpkgqLYWmyAVlycLyzfbGohHVPdQNFN=[-1]
      for tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe,GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP in enumerate(UwPPiaBKixQDGBBvxHkNjWNtugAMEtye):
        nbpkgqLYWmyAVlycLyzfbGohHVPdQNFN.extend([tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]*len(GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP))
      PERvqaSelXLsDudulHPPMJKmQgTPgVLd=[]
      for tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe,GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP in enumerate(UwPPiaBKixQDGBBvxHkNjWNtugAMEtye):
        YFHwplCcEovtfvOOgtnMDpzFCDFDKVJQ=dbBANPZxQfFEUunoLhlMXdJgIKRaiqHs=-1
        for GPuPzBsbrAtoFChYzHFHVecNaINEoEOc,KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR in enumerate(GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP):
          if nbpkgqLYWmyAVlycLyzfbGohHVPdQNFN[self[KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR].QpticPwshsLBghshfYvuYDcHKJLzokCQ.id]!=tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe:
            YFHwplCcEovtfvOOgtnMDpzFCDFDKVJQ=GPuPzBsbrAtoFChYzHFHVecNaINEoEOc
            dbBANPZxQfFEUunoLhlMXdJgIKRaiqHs=nbpkgqLYWmyAVlycLyzfbGohHVPdQNFN[self[KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR].QpticPwshsLBghshfYvuYDcHKJLzokCQ.id]
          elif self[KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR].QpticPwshsLBghshfYvuYDcHKJLzokCQ is self[KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR]:
            YFHwplCcEovtfvOOgtnMDpzFCDFDKVJQ=GPuPzBsbrAtoFChYzHFHVecNaINEoEOc
          elif y<0 or self[KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR].lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS in BAkXoxPcTQqyaxxiaJuJVbTqFFmDTqLS:
            pass
          else:
            break
        else:
          YFHwplCcEovtfvOOgtnMDpzFCDFDKVJQ=max(YFHwplCcEovtfvOOgtnMDpzFCDFDKVJQ,0)
          GPuPzBsbrAtoFChYzHFHVecNaINEoEOc=YFHwplCcEovtfvOOgtnMDpzFCDFDKVJQ
        peRZKciRbOWeRRHXWWSgducMSzIWuRrB=""
        for KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR in GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP:
          peRZKciRbOWeRRHXWWSgducMSzIWuRrB+=self[KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR].SUIkmCGlhwlHKovaIPUvdIqEsYipNDSF
          if self[KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR].oMCQDdKGDXNwGIwXjvYVQyHRtpwGcWVb.find("SpaceAfter=No")<0:
            peRZKciRbOWeRRHXWWSgducMSzIWuRrB+=" "
        PERvqaSelXLsDudulHPPMJKmQgTPgVLd.append((tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe,dbBANPZxQfFEUunoLhlMXdJgIKRaiqHs,GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP[0]-1,YFHwplCcEovtfvOOgtnMDpzFCDFDKVJQ,GPuPzBsbrAtoFChYzHFHVecNaINEoEOc,peRZKciRbOWeRRHXWWSgducMSzIWuRrB.rstrip(),lnNYckBjoYMooooEDQqPrAOAkgKYAGHo))
        lnNYckBjoYMooooEDQqPrAOAkgKYAGHo+=1
      self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr._chunkinfo.append(PERvqaSelXLsDudulHPPMJKmQgTPgVLd)
  def QURuogrdygKIjVBsHTYKuoNkmGhgvfbN(self):
    self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr._features=[""]
    for KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR in range(1,len(self)):
      ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw=(self[KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR].oEwGufqOIJjxdaGKsdIMCFVbgUIfoMJd+"-*-*-*-*-*-*-*-*-*").split("-")
      ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[6]=self[KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR].IAxSwhoIhOaxTzWwkcEHjQRdUnQPDuib
      GPuPzBsbrAtoFChYzHFHVecNaINEoEOc=self[KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR].oMCQDdKGDXNwGIwXjvYVQyHRtpwGcWVb.find("Translit=")
      if j>=0:
        ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[7]=self[KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR].oMCQDdKGDXNwGIwXjvYVQyHRtpwGcWVb[GPuPzBsbrAtoFChYzHFHVecNaINEoEOc+9:]
      ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[9]=self[KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR].lQljDBHuVyxoYdDRzaYsCVxpQgIBdrbS
      self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr._features.append(",".join(ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw[0:10]))
  def biKMwaIURnObgbXneacDIYrFQhzLPthC(self,index):
    f=self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr._features[index]
    if f.startswith("名詞,固有名詞,"):
      KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR=f.split(",")
      if KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR[2]=="人名":
        return("B-PERSON")
      if KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR[2]=="地名":
        return("B-LOCATION")
      return("B-ORGANIZATION")
    return("O")
  def FKAfpmGLZqNLzBQIuaicysXRLFGuPMSI(self,format=4):
    if format==4:
      return str(self)
    if not hasattr(self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr,"_sentences"):
      self.PlcmyTWTZtSioeUrCKIStiQwgeVVymLn()
    if format>0 and not hasattr(self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr,"_features"):
      self.QURuogrdygKIjVBsHTYKuoNkmGhgvfbN()
    cpryiJhFpOzrnstfFiDqLhBEDLiUcxpI=""
    for lnNYckBjoYMooooEDQqPrAOAkgKYAGHo,UwPPiaBKixQDGBBvxHkNjWNtugAMEtye in enumerate(self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr._sentences):
      if format==0 or format==2:
        ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw=len(self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr._chunkinfo[lnNYckBjoYMooooEDQqPrAOAkgKYAGHo])
        DXQSJgyqFLyzyvzxlCPHbMNMktxpFZKr,BAkXoxPcTQqyaxxiaJuJVbTqFFmDTqLS,TFrXFRafqYQClFvLGAWbltmLGNUhnmlr=[],[],[" "*(ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw*2)]*ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw
        for tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe,zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe,KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR,IauKiVeAXdYjPpdDebxzFLcCYFdtVNQv,f,peRZKciRbOWeRRHXWWSgducMSzIWuRrB,dbBANPZxQfFEUunoLhlMXdJgIKRaiqHs in self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr._chunkinfo[lnNYckBjoYMooooEDQqPrAOAkgKYAGHo]:
          DXQSJgyqFLyzyvzxlCPHbMNMktxpFZKr.append(len(peRZKciRbOWeRRHXWWSgducMSzIWuRrB)+len([GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP for GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP in peRZKciRbOWeRRHXWWSgducMSzIWuRrB if ord(GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP)>127]))
          BAkXoxPcTQqyaxxiaJuJVbTqFFmDTqLS.append(peRZKciRbOWeRRHXWWSgducMSzIWuRrB)
          if d<0:
            continue
          TFrXFRafqYQClFvLGAWbltmLGNUhnmlr[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]="-"*(zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe*2-1)+"D"+TFrXFRafqYQClFvLGAWbltmLGNUhnmlr[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe][zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe*2:]
          for GPuPzBsbrAtoFChYzHFHVecNaINEoEOc in range(tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe+1,zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe-1):
            TFrXFRafqYQClFvLGAWbltmLGNUhnmlr[GPuPzBsbrAtoFChYzHFHVecNaINEoEOc]=TFrXFRafqYQClFvLGAWbltmLGNUhnmlr[GPuPzBsbrAtoFChYzHFHVecNaINEoEOc][0:zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe*2-1]+"|"+TFrXFRafqYQClFvLGAWbltmLGNUhnmlr[GPuPzBsbrAtoFChYzHFHVecNaINEoEOc][zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe*2:]
        IauKiVeAXdYjPpdDebxzFLcCYFdtVNQv=max([(ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw-tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe)*2+GPuPzBsbrAtoFChYzHFHVecNaINEoEOc for tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe,GPuPzBsbrAtoFChYzHFHVecNaINEoEOc in enumerate(DXQSJgyqFLyzyvzxlCPHbMNMktxpFZKr)])
        for tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe in range(ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw):
          cpryiJhFpOzrnstfFiDqLhBEDLiUcxpI+=" "*(IauKiVeAXdYjPpdDebxzFLcCYFdtVNQv-(ZccJYlBEmanoRnxWJXifvRNDMBmXBSXw-tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe)*2-DXQSJgyqFLyzyvzxlCPHbMNMktxpFZKr[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe])+BAkXoxPcTQqyaxxiaJuJVbTqFFmDTqLS[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]+TFrXFRafqYQClFvLGAWbltmLGNUhnmlr[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe][tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe*2:].rstrip()+"\n"
        cpryiJhFpOzrnstfFiDqLhBEDLiUcxpI+="EOS\n"
      if format==1 or format==2:
        for tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe,zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe,KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR,IauKiVeAXdYjPpdDebxzFLcCYFdtVNQv,f,peRZKciRbOWeRRHXWWSgducMSzIWuRrB,dbBANPZxQfFEUunoLhlMXdJgIKRaiqHs in self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr._chunkinfo[lnNYckBjoYMooooEDQqPrAOAkgKYAGHo]:
          cpryiJhFpOzrnstfFiDqLhBEDLiUcxpI+="* "+str(tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe)+" "+str(zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe)+"D "+str(IauKiVeAXdYjPpdDebxzFLcCYFdtVNQv)+"/"+str(f)+" 0.000000\n"
          for KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR in UwPPiaBKixQDGBBvxHkNjWNtugAMEtye[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]:
            cpryiJhFpOzrnstfFiDqLhBEDLiUcxpI+=self[KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR].SUIkmCGlhwlHKovaIPUvdIqEsYipNDSF+"\t"+self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr._features[KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR]+"\t"+self.biKMwaIURnObgbXneacDIYrFQhzLPthC(KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR)+"\t"+str(self[KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR].id)+"<-"+self[KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR].zSGiFziCrxBmkbkTdGUuzkpipfMLOkEi
            if self[KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR] is self[KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR].QpticPwshsLBghshfYvuYDcHKJLzokCQ:
              cpryiJhFpOzrnstfFiDqLhBEDLiUcxpI+="\n"
            else:
              cpryiJhFpOzrnstfFiDqLhBEDLiUcxpI+="-"+str(self[KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR].QpticPwshsLBghshfYvuYDcHKJLzokCQ.id)+"\n"
        cpryiJhFpOzrnstfFiDqLhBEDLiUcxpI+="EOS\n"
      if format==3:
        cpryiJhFpOzrnstfFiDqLhBEDLiUcxpI+="<sentence>\n"
        for tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe,zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe,KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR,IauKiVeAXdYjPpdDebxzFLcCYFdtVNQv,f,peRZKciRbOWeRRHXWWSgducMSzIWuRrB,dbBANPZxQfFEUunoLhlMXdJgIKRaiqHs in self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr._chunkinfo[lnNYckBjoYMooooEDQqPrAOAkgKYAGHo]:
          cpryiJhFpOzrnstfFiDqLhBEDLiUcxpI+=' <chunk id="'+str(i)+'" link="'+str(d)+'" rel="D" score="0.000000" head="'+str(self[s[i][h]].id)+'" func="'+str(self[s[i][f]].id)+'">\n'
          for KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR in UwPPiaBKixQDGBBvxHkNjWNtugAMEtye[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]:
            cpryiJhFpOzrnstfFiDqLhBEDLiUcxpI+='  <tok id="'+str(self[t].id)+'" feature="'+self._cabocha._features[t]+'" head="'+str(self[t].head.id)+'" rel="'+self[t].deprel+'">'+self[KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR].SUIkmCGlhwlHKovaIPUvdIqEsYipNDSF+'</tok>\n'
          cpryiJhFpOzrnstfFiDqLhBEDLiUcxpI+=" </chunk>\n"
        cpryiJhFpOzrnstfFiDqLhBEDLiUcxpI+="</sentence>\n"
    return cpryiJhFpOzrnstfFiDqLhBEDLiUcxpI
  def lhIzHMBkGDqTURlcfWWSHHeFJjPEdLCZ(self):
    return len(self)-1
  def mTKvCShivSvrmJDOvQQpSIdQJRaeMwnl(self):
    return len(self)-1
  def NHNpExAngTXDYXWrrIJMyZtQFXgqRsSX(self,index):
    if not hasattr(self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr,"_sentences"):
      self.PlcmyTWTZtSioeUrCKIStiQwgeVVymLn()
    GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP=None
    for iIdaQaxYRQsHuxppWLrOhECWYRtDFGop,vyqqOIxyKqPdGksJFSSLYYtfHTNwbtjY in zip(self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr._sentences,self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr._chunkinfo):
      for QrHvPokbGPftSOgQFqJBgbDavRfFtNet,YsOjONmFsWucWhFyAAsEOAnPwkvODkwZ in zip(iIdaQaxYRQsHuxppWLrOhECWYRtDFGop,vyqqOIxyKqPdGksJFSSLYYtfHTNwbtjY):
        tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe,zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe,KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR,IauKiVeAXdYjPpdDebxzFLcCYFdtVNQv,f,peRZKciRbOWeRRHXWWSgducMSzIWuRrB,dbBANPZxQfFEUunoLhlMXdJgIKRaiqHs=YsOjONmFsWucWhFyAAsEOAnPwkvODkwZ
        if KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR==index:
          GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP=gkkllvRzVTuSfyOAJhDziexaqfdAIyzK(QrHvPokbGPftSOgQFqJBgbDavRfFtNet,YsOjONmFsWucWhFyAAsEOAnPwkvODkwZ)
          break
    return UnUGUWahAbqdoauLMxFQvFmvHcsGGOks(self,GIeuqPHVijNwVQTvemiRkOqcCsLmKmsP,index)
  def DOglPYsKUzpFdzsrWCDSGPvKplRvJYIN(self):
    if not hasattr(self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr,"_sentences"):
      self.PlcmyTWTZtSioeUrCKIStiQwgeVVymLn()
    return sum(len(UwPPiaBKixQDGBBvxHkNjWNtugAMEtye) for UwPPiaBKixQDGBBvxHkNjWNtugAMEtye in self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr._sentences)
  def TPQJlWOGCbfWolAWWBZrEkFUjySyJOEr(self,index):
    if not hasattr(self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr,"_sentences"):
      self.PlcmyTWTZtSioeUrCKIStiQwgeVVymLn()
    for iIdaQaxYRQsHuxppWLrOhECWYRtDFGop,vyqqOIxyKqPdGksJFSSLYYtfHTNwbtjY in zip(self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr._sentences,self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr._chunkinfo):
      for QrHvPokbGPftSOgQFqJBgbDavRfFtNet,YsOjONmFsWucWhFyAAsEOAnPwkvODkwZ in zip(iIdaQaxYRQsHuxppWLrOhECWYRtDFGop,vyqqOIxyKqPdGksJFSSLYYtfHTNwbtjY):
        tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe,zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe,KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR,IauKiVeAXdYjPpdDebxzFLcCYFdtVNQv,f,peRZKciRbOWeRRHXWWSgducMSzIWuRrB,dbBANPZxQfFEUunoLhlMXdJgIKRaiqHs=YsOjONmFsWucWhFyAAsEOAnPwkvODkwZ
        if dbBANPZxQfFEUunoLhlMXdJgIKRaiqHs==index:
          return gkkllvRzVTuSfyOAJhDziexaqfdAIyzK(QrHvPokbGPftSOgQFqJBgbDavRfFtNet,YsOjONmFsWucWhFyAAsEOAnPwkvODkwZ)
    return None
  def vBhaPqxguUgXqCNjUqISCtkPyfWwdrox(self):
    if not hasattr(self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr,"_sentences"):
      self.PlcmyTWTZtSioeUrCKIStiQwgeVVymLn()
    return len(self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr._sentences)
  def SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF(self,index=0):
    if self._result>"":
      return self._result.split("# text = ")[index+1].split("\n")[0]
    if not hasattr(self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr,"_sentences"):
      self.PlcmyTWTZtSioeUrCKIStiQwgeVVymLn()
    return "".join(peRZKciRbOWeRRHXWWSgducMSzIWuRrB for tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe,zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe,KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR,IauKiVeAXdYjPpdDebxzFLcCYFdtVNQv,f,peRZKciRbOWeRRHXWWSgducMSzIWuRrB,dbBANPZxQfFEUunoLhlMXdJgIKRaiqHs in self.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr._chunkinfo[index])
  def tvsFlljbPQzFoBCgmPaPheMoSMRIKMSG(self):
    self.PlcmyTWTZtSioeUrCKIStiQwgeVVymLn()
    self.QURuogrdygKIjVBsHTYKuoNkmGhgvfbN()
class gkkllvRzVTuSfyOAJhDziexaqfdAIyzK(object):
  jGfoODUEQSyLWrSHDNBalDWRFdbcExlG=None
  OtKULlQuRygSCapPTwCZUEFCnPfXgwVo=0
  wpxJzUkqLuYXJgdsnBeUyFkhdngYWTIv=0.0
  def __init__(self,TPQJlWOGCbfWolAWWBZrEkFUjySyJOEr,chunkinfo):
    tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe,zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe,KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR,IauKiVeAXdYjPpdDebxzFLcCYFdtVNQv,f,peRZKciRbOWeRRHXWWSgducMSzIWuRrB,dbBANPZxQfFEUunoLhlMXdJgIKRaiqHs=chunkinfo
    self.token_pos=KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR
    self.head_pos=IauKiVeAXdYjPpdDebxzFLcCYFdtVNQv
    self.func_pos=f
    self.link=-1 if d<0 else zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe-tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe+dbBANPZxQfFEUunoLhlMXdJgIKRaiqHs
    self.mTKvCShivSvrmJDOvQQpSIdQJRaeMwnl=len(TPQJlWOGCbfWolAWWBZrEkFUjySyJOEr)
    self._surface=peRZKciRbOWeRRHXWWSgducMSzIWuRrB
  def __repr__(self):
    return self._surface
  def MeHOYboRfeIVIEATrdWJjqvrgllPuekt(self,index):
    return None
class UnUGUWahAbqdoauLMxFQvFmvHcsGGOks(object):
  jGfoODUEQSyLWrSHDNBalDWRFdbcExlG=ne=None
  def __init__(self,tree,TPQJlWOGCbfWolAWWBZrEkFUjySyJOEr,index):
    self.jXJRBVzPoIUlgGKJRsKfaFfwponVragx=self.normalized_surface=tree[index+1].SUIkmCGlhwlHKovaIPUvdIqEsYipNDSF
    self.TPQJlWOGCbfWolAWWBZrEkFUjySyJOEr=TPQJlWOGCbfWolAWWBZrEkFUjySyJOEr
    if not hasattr(tree.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr,"_features"):
      tree.QURuogrdygKIjVBsHTYKuoNkmGhgvfbN()
    self.feature=tree.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr._features[index+1]
    self.OtKULlQuRygSCapPTwCZUEFCnPfXgwVo=len(self.feature.split(","))
    self.ne=tree.biKMwaIURnObgbXneacDIYrFQhzLPthC(index+1)
  def __repr__(self):
    return self.normalized_surface
  def MeHOYboRfeIVIEATrdWJjqvrgllPuekt(self,index):
    return self.feature.split(",")[index]
class HckFloDXIwwdPvbXaEgpmbIqbmFmTnXm(object):
  def __init__(self,jobEtvhVQburTHZejUvpnhBTgQnarPfi=None):
    self.mRxjzrLQByKfHwSQrAFdqEsMtYzFEGPK=unidic2ud.mRxjzrLQByKfHwSQrAFdqEsMtYzFEGPK(jobEtvhVQburTHZejUvpnhBTgQnarPfi,UDPipe="japanese-modern")
  def AEJmffENNPFRriparsTHobsttCRfAMNQ(self,SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF):
    KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR=CuXafWpyckounewrAQlYJoTuoNMRjpUH(self.mRxjzrLQByKfHwSQrAFdqEsMtYzFEGPK(SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF,raw=True))
    KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR.EPqqgIkMjafSGAYJDoTfpgZvxUvOzmTr._parser=self
    return KmxNxEENwDRpqlRdKGdwNkdvYcwZVAoR
  def UilwqkvOUtPPtLuXDSBDaRVnnCGJzEue(self,SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF):
    return self.AEJmffENNPFRriparsTHobsttCRfAMNQ(SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF).FKAfpmGLZqNLzBQIuaicysXRLFGuPMSI(0)
