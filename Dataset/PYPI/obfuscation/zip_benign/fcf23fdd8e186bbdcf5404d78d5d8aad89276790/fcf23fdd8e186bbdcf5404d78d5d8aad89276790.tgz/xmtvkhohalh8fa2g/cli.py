import sys
import unidic2ud
def TCpdYMlSNaYxDrhgDrRYyietaWRNoBQT():
  ELRtbGVzykyUfLQzfxXkESdXUzINceVX=len(sys.argv)
  zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe="japanese-modern"
  HDNLDRnYrDhkQxFEWYrfqVxyOtOxwEur=bIokBFTqHBXOxscXbVkQXLnPefdKxLPA=False
  tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe=peRZKciRbOWeRRHXWWSgducMSzIWuRrB=1
  while i<ELRtbGVzykyUfLQzfxXkESdXUzINceVX:
    nrMGelbRJivkvfHuloqcVGZwAVcCqLaO=sys.argv[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]
    if nrMGelbRJivkvfHuloqcVGZwAVcCqLaO=="-h" or nrMGelbRJivkvfHuloqcVGZwAVcCqLaO=="--help" or nrMGelbRJivkvfHuloqcVGZwAVcCqLaO=="-v" or nrMGelbRJivkvfHuloqcVGZwAVcCqLaO=="--version":
      TvqKyjGxwuRXqOrufHESFATAeBiGrvpe()
    elif nrMGelbRJivkvfHuloqcVGZwAVcCqLaO.startswith("-U"):
      if nrMGelbRJivkvfHuloqcVGZwAVcCqLaO=="-U":
        tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe+=1
        zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe=sys.argv[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe]
      else:
        zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe=sys.argv[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe][2:]
    elif nrMGelbRJivkvfHuloqcVGZwAVcCqLaO=="-u":
      HDNLDRnYrDhkQxFEWYrfqVxyOtOxwEur=True
    elif nrMGelbRJivkvfHuloqcVGZwAVcCqLaO=="-t" or nrMGelbRJivkvfHuloqcVGZwAVcCqLaO=="-t1":
      bIokBFTqHBXOxscXbVkQXLnPefdKxLPA=True
      peRZKciRbOWeRRHXWWSgducMSzIWuRrB=1
    elif nrMGelbRJivkvfHuloqcVGZwAVcCqLaO=="-t2":
      bIokBFTqHBXOxscXbVkQXLnPefdKxLPA=True
      peRZKciRbOWeRRHXWWSgducMSzIWuRrB=2
    elif nrMGelbRJivkvfHuloqcVGZwAVcCqLaO.startswith("--download="):
      zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe=sys.argv[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe][11:]
      if d>"":
        UwPPiaBKixQDGBBvxHkNjWNtugAMEtye=unidic2ud.xbJLNJlOhzbNcDdYQSFlUUhVqkYXlpZP().replace(".udpipe","").split()
        if zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe in UwPPiaBKixQDGBBvxHkNjWNtugAMEtye:
          print("unidic2ud: "+zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe+" was already downloaded",file=sys.stderr)
        else:
          unidic2ud.oDkeNAyzRVMwSLiPRgTJqKzDwTOPwAwO(zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe)
      TvqKyjGxwuRXqOrufHESFATAeBiGrvpe()
    else:
      break
    tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe+=1
  else:
    if zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe.find("-")>0:
      ddsKIefhkbkMABhtbwLboboYqIUUWKqY=unidic2ud.pIyFUfcMyZnxKdBFPwVjZesSYTTJVXms(None,zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe)
    else:
      ddsKIefhkbkMABhtbwLboboYqIUUWKqY=unidic2ud.pIyFUfcMyZnxKdBFPwVjZesSYTTJVXms(zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe)
    while True:
      try:
        UwPPiaBKixQDGBBvxHkNjWNtugAMEtye=input()
      except:
        return
      print(MdVArFoAvEXbxtoJjKDGCcjdFZCAsFqZ(ddsKIefhkbkMABhtbwLboboYqIUUWKqY,HDNLDRnYrDhkQxFEWYrfqVxyOtOxwEur,bIokBFTqHBXOxscXbVkQXLnPefdKxLPA,peRZKciRbOWeRRHXWWSgducMSzIWuRrB,UwPPiaBKixQDGBBvxHkNjWNtugAMEtye),end="")
  if zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe.find("-")>0:
    ddsKIefhkbkMABhtbwLboboYqIUUWKqY=unidic2ud.pIyFUfcMyZnxKdBFPwVjZesSYTTJVXms(None,zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe)
  else:
    ddsKIefhkbkMABhtbwLboboYqIUUWKqY=unidic2ud.pIyFUfcMyZnxKdBFPwVjZesSYTTJVXms(zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe)
  while i<ELRtbGVzykyUfLQzfxXkESdXUzINceVX:
    f=open(sys.argv[tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe],"r",encoding="utf-8")
    UwPPiaBKixQDGBBvxHkNjWNtugAMEtye=f.read()
    f.close()
    print(MdVArFoAvEXbxtoJjKDGCcjdFZCAsFqZ(ddsKIefhkbkMABhtbwLboboYqIUUWKqY,HDNLDRnYrDhkQxFEWYrfqVxyOtOxwEur,bIokBFTqHBXOxscXbVkQXLnPefdKxLPA,peRZKciRbOWeRRHXWWSgducMSzIWuRrB,UwPPiaBKixQDGBBvxHkNjWNtugAMEtye),end="")
    tJZqsZtwPhIxHNfIPXUAseEsARSLaxYe+=1
def MdVArFoAvEXbxtoJjKDGCcjdFZCAsFqZ(ddsKIefhkbkMABhtbwLboboYqIUUWKqY,HDNLDRnYrDhkQxFEWYrfqVxyOtOxwEur,bIokBFTqHBXOxscXbVkQXLnPefdKxLPA,width,SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF):
  if HDNLDRnYrDhkQxFEWYrfqVxyOtOxwEur:
    if bIokBFTqHBXOxscXbVkQXLnPefdKxLPA:
      return ddsKIefhkbkMABhtbwLboboYqIUUWKqY(SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF).duKmUQvmemXWsFbprxCApHlrZCYcOcoP()
    return ddsKIefhkbkMABhtbwLboboYqIUUWKqY(SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF,raw=True)
  if bIokBFTqHBXOxscXbVkQXLnPefdKxLPA:
    return ddsKIefhkbkMABhtbwLboboYqIUUWKqY(SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF).DcQHfhSdsuUhhopxhzVHteInRjUdTJBq(BoxDrawingWidth=width,Japanese=True)
  return ddsKIefhkbkMABhtbwLboboYqIUUWKqY(SBnhyVWfrwneyMYVQkROJnXeQvSgXSpF,raw=True)
def TvqKyjGxwuRXqOrufHESFATAeBiGrvpe():
  from pkg_resources import get_distribution
  print("Unidic2UD Version "+get_distribution("unidic2ud").version,file=sys.stderr)
  print("Usage: unidic2ud -U Dict [-u|-t|-t2] file",file=sys.stderr)
  print("       unidic2ud --download=Dict",file=sys.stderr)
  UwPPiaBKixQDGBBvxHkNjWNtugAMEtye=" Dict:\n"+unidic2ud.xbJLNJlOhzbNcDdYQSFlUUhVqkYXlpZP().replace(".udpipe","(udpipe)")
  print(UwPPiaBKixQDGBBvxHkNjWNtugAMEtye.replace("\n"," ").rstrip(),file=sys.stderr)
  sys.exit()
if __name__=="__main__":
  TCpdYMlSNaYxDrhgDrRYyietaWRNoBQT()
