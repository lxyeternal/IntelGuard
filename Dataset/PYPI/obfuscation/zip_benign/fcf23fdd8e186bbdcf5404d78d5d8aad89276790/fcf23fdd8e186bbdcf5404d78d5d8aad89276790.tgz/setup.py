import os, platform, setuptools, subprocess
with open('README.md', 'r', encoding='utf-8') as r:
    WkqdccnXukPqYMTEQPFltDbcZZePKOkR = r.read()
PbnKyeNcEHrVQIXLaTeBqPVZssrpnrGc = 'https://github.com/KoichiYasuoka/UniDic2UD'
BFstTSdcahPcXIZwYyHrzdsiGMYehdQD = platform.platform()
if BFstTSdcahPcXIZwYyHrzdsiGMYehdQD.startswith('CYGWIN'):
    oCgRKGvlabOTJNVaVZDuUTWlxwOQMQgT = ['ufal.udpipe>=1.2.0.3', 'mecab-cygwin>=0.5.0',
        'deplacy>=2.1.0']
else:
    import sys
    tekqZkuJsbeTroviCHkiJLtpIiZWuLyH = sys.version_info.major == 3 and sys.version_info.minor > 4
    try:
        zBZysnUCFLfqMPjbxdTXSrnWpNtfxXHe = subprocess.check_output(['mecab-config', '--libs-only-L'])
    except:
        import os
        tekqZkuJsbeTroviCHkiJLtpIiZWuLyH &= os.name == 'nt'
    if tekqZkuJsbeTroviCHkiJLtpIiZWuLyH:
        oCgRKGvlabOTJNVaVZDuUTWlxwOQMQgT = ['ufal.udpipe>=1.2.0.3', 'fugashi>=1.3.3',
            'deplacy>=2.1.0']
    else:
        oCgRKGvlabOTJNVaVZDuUTWlxwOQMQgT = ['ufal.udpipe>=1.2.0.3',
            'mecab-python3>=0.996.5', 'deplacy>=2.1.0']
setuptools.setup(name='unidic2ud', version='3.0.6', description=
    'Tokenizer POS-tagger Lemmatizer and Dependency-parser for modern and contemporary Japanese'
    , WkqdccnXukPqYMTEQPFltDbcZZePKOkR=WkqdccnXukPqYMTEQPFltDbcZZePKOkR, long_description_content_type=
    'text/markdown', url=PbnKyeNcEHrVQIXLaTeBqPVZssrpnrGc, author='Koichi Yasuoka', author_email=
    'yasuoka@kanji.zinbun.kyoto-u.ac.jp', license='MIT', keywords=
    'unidic udpipe mecab nlp', packages=setuptools.find_packages(),
    oCgRKGvlabOTJNVaVZDuUTWlxwOQMQgT=oCgRKGvlabOTJNVaVZDuUTWlxwOQMQgT, python_requires='>=3.6',
    wFutfseSOQAqtRISPlCMbPNZTCBgqQoB={'unidic2ud': ['./mecabrc', './download/*.udpipe']},
    ZEobrMyfIbfwvXwGEJlNmvFvPjjfknpL={'console_scripts': ['unidic2ud=unidic2ud.cli:main',
    'udcabocha=unidic2ud.cabocha.cli:main']}, classifiers=[
    'License :: OSI Approved :: MIT License',
    'Programming Language :: Python :: 3',
    'Operating System :: OS Independent',
    'Topic :: Text Processing :: Linguistic',
    'Natural Language :: Japanese'], project_urls={'japanese-modern':
    'https://github.com/UniversalDependencies/UD_Japanese-Modern',
    'ud-ja-kanbun':
    'https://corpus.kanji.zinbun.kyoto-u.ac.jp/gitlab/Kanbun/ud-ja-kanbun',
    'Source': PbnKyeNcEHrVQIXLaTeBqPVZssrpnrGc, 'Tracker': PbnKyeNcEHrVQIXLaTeBqPVZssrpnrGc + '/issues'})
