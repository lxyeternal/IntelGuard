#! /usr/bin/python -IQzGQILulYCfCAKMbSqsNolLvHvoCHVD
import os
OHwxZAZGvdQcBmaRwlmIjivaNjjnSvjo=os.path.abspath(os.path.dirname(__file__))
class EPKCjsuWgxdpqkCONbjYoEFBqIgsJAFv(object):
  def __init__(self,result):
    if "\n" in result:
      LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ=[EPKCjsuWgxdpqkCONbjYoEFBqIgsJAFv("0\t_\t_\t_\t_\t_\t0\t_\t_\t_")]
      for r in result.split("\n"):
        PGWZjDncDcGUiQrBuviamhlnUylvQhoA=EPKCjsuWgxdpqkCONbjYoEFBqIgsJAFv(r)
        if PGWZjDncDcGUiQrBuviamhlnUylvQhoA.id>0:
          LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ.append(PGWZjDncDcGUiQrBuviamhlnUylvQhoA)
      self._tokens=LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ
      for PGWZjDncDcGUiQrBuviamhlnUylvQhoA in LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ:
        PGWZjDncDcGUiQrBuviamhlnUylvQhoA._parent=self
        PGWZjDncDcGUiQrBuviamhlnUylvQhoA.mHiqzRXXofXwVcUBUJwlvaprmuFjOJwu=PGWZjDncDcGUiQrBuviamhlnUylvQhoA._head
      self._result=result
    else:
      PGWZjDncDcGUiQrBuviamhlnUylvQhoA=result.split("\t")
      try:
        PGWZjDncDcGUiQrBuviamhlnUylvQhoA[0],PGWZjDncDcGUiQrBuviamhlnUylvQhoA[6]=int(PGWZjDncDcGUiQrBuviamhlnUylvQhoA[0]),int(PGWZjDncDcGUiQrBuviamhlnUylvQhoA[6])
      except:
        PGWZjDncDcGUiQrBuviamhlnUylvQhoA=[0]*10
      self.id,self.ISpSJMmbCvMaZNlholvAgVBTRMeftmmu,self.goHmRkXpwUXKGNBrSJtTaezJQpYJWlFI,self.pcgkAGJpoVEdqyAwPtIbMLXvqtUYyqET,self.vhGWbJcxcJGXzTSRFcCZvpFOHMMhaUvP,self.xsPDyFjWhhSbzhPsCQXTDEOpmxGWHLUR,self._head,self.VWDKMNpWAJkqlYZqstfrgricdNgtjcsG,self.exJvwULFWQSdEMpNlGvLMePMEPZJKnEk,self.QjqtZPJAFTqJawUnTMFhpQBzEvVfaSXc=PGWZjDncDcGUiQrBuviamhlnUylvQhoA if len(PGWZjDncDcGUiQrBuviamhlnUylvQhoA)==10 else [0]*10
      self._result=""
  def __setattr__(self,name,value):
    zqIBtvtLROHjFgmIjHFEFTxJIzHYZYhR=value
    if name=="head":
      LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ=self._parent._tokens
      IQzGQILulYCfCAKMbSqsNolLvHvoCHVD=LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ.index(self)
      zqIBtvtLROHjFgmIjHFEFTxJIzHYZYhR=self if zqIBtvtLROHjFgmIjHFEFTxJIzHYZYhR==0 else LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD+zqIBtvtLROHjFgmIjHFEFTxJIzHYZYhR-self.id]
    if hasattr(self,name):
      if getattr(self,name)!=zqIBtvtLROHjFgmIjHFEFTxJIzHYZYhR:
        super(EPKCjsuWgxdpqkCONbjYoEFBqIgsJAFv,self._parent).__setattr__("_result","")
        if name=="id":
          LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ=self._parent._tokens
          IQzGQILulYCfCAKMbSqsNolLvHvoCHVD=LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ.index(self)
          KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf=IQzGQILulYCfCAKMbSqsNolLvHvoCHVD+zqIBtvtLROHjFgmIjHFEFTxJIzHYZYhR-self.id
          super(EPKCjsuWgxdpqkCONbjYoEFBqIgsJAFv,LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]).__setattr__("id",LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].id)
          LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD],LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]=LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf],LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]
    super(EPKCjsuWgxdpqkCONbjYoEFBqIgsJAFv,self).__setattr__(name,zqIBtvtLROHjFgmIjHFEFTxJIzHYZYhR)
  def __repr__(self):
    if self._result!="":
      r=self._result
    elif hasattr(self,"_tokens"):
      r="".join(str(LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ)+"\n" for LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ in self._tokens[1:]).replace("\n1\t","\n\n1\t")
    else:
      r="\t".join([str(self.id),self.ISpSJMmbCvMaZNlholvAgVBTRMeftmmu,self.goHmRkXpwUXKGNBrSJtTaezJQpYJWlFI,self.pcgkAGJpoVEdqyAwPtIbMLXvqtUYyqET,self.vhGWbJcxcJGXzTSRFcCZvpFOHMMhaUvP,self.xsPDyFjWhhSbzhPsCQXTDEOpmxGWHLUR,str(0 if self.mHiqzRXXofXwVcUBUJwlvaprmuFjOJwu is self else self.mHiqzRXXofXwVcUBUJwlvaprmuFjOJwu.id),self.VWDKMNpWAJkqlYZqstfrgricdNgtjcsG,self.exJvwULFWQSdEMpNlGvLMePMEPZJKnEk,self.QjqtZPJAFTqJawUnTMFhpQBzEvVfaSXc])
    return r if type(r) is str else r.encode("utf-8")
  def __getitem__(self,item):
    return self._tokens[item]
  def __len__(self):
    return len(self._tokens)
  def index(self,item):
    return self._tokens.index(item)
  def lUyrxYvjXRaKuQRMczfpWtJzVGZSxHIQ(self,item=0):
    if not hasattr(self,"_tokens"):
      return self._parent.lUyrxYvjXRaKuQRMczfpWtJzVGZSxHIQ(self._parent.index(self))
    ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj='<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"  width="100%" height="100%" onload="conllusvg.view(this,+conllu+)" onresize="conllusvg.rewrite(+conllu+)">\n'.replace("+","'")
    ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj+='<text id="conllu" fill="none" visibility="hidden">\n'
    if item==0:
      ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj+=str(self)
    else:
      from itertools import takewhile
      IQzGQILulYCfCAKMbSqsNolLvHvoCHVD=item-self[item].id
      for KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf in takewhile(lambda KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf:KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf-self[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf].id==IQzGQILulYCfCAKMbSqsNolLvHvoCHVD,range(IQzGQILulYCfCAKMbSqsNolLvHvoCHVD+1,len(self))):
        ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj+=str(self[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf])+'\n'
    ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj+='</text>\n<script type="text/javascript"><![CDATA[\n'
    import deplacy
    f=open(os.path.join(deplacy.OHwxZAZGvdQcBmaRwlmIjivaNjjnSvjo,"conllusvgview.js"),"r",encoding="utf-8")
    ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj+=f.read()
    f.close()
    ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj+=']]></script>\n</svg>\n'
    return ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj
class RiiZirufkOJTMHHtRcHNTXkCgUpNZWTO(EPKCjsuWgxdpqkCONbjYoEFBqIgsJAFv):
  def XxfUijMKOvwOWSRxHzkieipWvZiNSOdO(self):
    import udkanbun.kaeriten
    ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC=udkanbun.XxfUijMKOvwOWSRxHzkieipWvZiNSOdO.XxfUijMKOvwOWSRxHzkieipWvZiNSOdO(self)
    ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj="".join("\n"+self[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].ISpSJMmbCvMaZNlholvAgVBTRMeftmmu+ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD] if self[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].id==1 else self[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].ISpSJMmbCvMaZNlholvAgVBTRMeftmmu+ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD] for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(1,len(self))).strip()
    return ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj+"\n"
  def vFuRupDnCbvQRdsyrXngqwnEpxVlFcqM(self,BoxDrawingWidth=1,XxfUijMKOvwOWSRxHzkieipWvZiNSOdO=False,Japanese=False,CatenaAnalysis=True):
    import deplacy
    if not hasattr(self,"_tokens"):
      return None
    pnZSserZDdOtDsPTzHFgQeipgihdqoiS=deplacy.renderMatrix(self,CatenaAnalysis)
    if XxfUijMKOvwOWSRxHzkieipWvZiNSOdO:
      import udkanbun.kaeriten
      ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC=udkanbun.XxfUijMKOvwOWSRxHzkieipWvZiNSOdO.XxfUijMKOvwOWSRxHzkieipWvZiNSOdO(self)
    else:
      ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC=[[]]*len(self)
    u=[" ","\u2578","\u257A","\u2550","\u2579","\u255D","\u255A","\u2569","\u257B","\u2557","\u2554","\u2566","\u2551","\u2563","\u2560","\u256C","<"]
    if CatenaAnalysis:
      u[7]=u[5]
      u[11]=u[9]
      u[15]=u[12]
    if Japanese:
      import deplacy.deprelja
      r=deplacy.deprelja.deprelja
    else:
      r={}
    ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj=""
    for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(1,len(self)):
      PGWZjDncDcGUiQrBuviamhlnUylvQhoA=self[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].ISpSJMmbCvMaZNlholvAgVBTRMeftmmu[0]
      PGWZjDncDcGUiQrBuviamhlnUylvQhoA="  " if PGWZjDncDcGUiQrBuviamhlnUylvQhoA=="_" else PGWZjDncDcGUiQrBuviamhlnUylvQhoA
      LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ="".join(u[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf] for KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf in pnZSserZDdOtDsPTzHFgQeipgihdqoiS[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD-1])
      if BoxDrawingWidth>1:
        LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ=LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ.replace(" "," "*BoxDrawingWidth).replace("<"," "*(BoxDrawingWidth-1)+"<")
      if self[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG in r:
        ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj+=PGWZjDncDcGUiQrBuviamhlnUylvQhoA+" "+LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ+" "+self[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG+"("+r[self[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG]+")\n"
      else:
        ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj+=PGWZjDncDcGUiQrBuviamhlnUylvQhoA+" "+LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ+" "+self[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG+"\n"
      if len(self[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].ISpSJMmbCvMaZNlholvAgVBTRMeftmmu)>1 or ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]!=[]:
        LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ="".join(u[((j&8)>>1)*3] for KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf in pnZSserZDdOtDsPTzHFgQeipgihdqoiS[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD-1])
        if BoxDrawingWidth>1:
          LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ=LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ.replace(" "," "*BoxDrawingWidth)
        for PGWZjDncDcGUiQrBuviamhlnUylvQhoA in self[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].ISpSJMmbCvMaZNlholvAgVBTRMeftmmu[1:]:
          ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj+=(PGWZjDncDcGUiQrBuviamhlnUylvQhoA+" "+LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ).rstrip()+"\n"
        for PGWZjDncDcGUiQrBuviamhlnUylvQhoA in ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]:
          ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj+=(PGWZjDncDcGUiQrBuviamhlnUylvQhoA+" "+LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ).rstrip()+"\n"
    return ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj
class WuzJucHHwysGGyWgHPDEbMJUDJXDfIph(object):
  def __init__(self,RxiTTpPUDZSXtHKBJWfvVPxWrKKuZwWv,danku,model):
    import ufal.udpipe
    XZQtdLIKQaGwvRVtlxIdBxuWerIVXYQS=False
    if model==None:
      VtmZYtZAMTBjeBqAypZyxslZUgYiCIXc=ufal.udpipe.Model.gCbPRtZtesuUiSAMKIXRmiDNxJLKGyVD(os.path.join(OHwxZAZGvdQcBmaRwlmIjivaNjjnSvjo,"ud-kanbun.udpipe"))
    elif model.startswith("guwenbert-"):
      VtmZYtZAMTBjeBqAypZyxslZUgYiCIXc=model+".supar"
      RxiTTpPUDZSXtHKBJWfvVPxWrKKuZwWv=XZQtdLIKQaGwvRVtlxIdBxuWerIVXYQS=True
    else:
      VtmZYtZAMTBjeBqAypZyxslZUgYiCIXc=ufal.udpipe.Model.gCbPRtZtesuUiSAMKIXRmiDNxJLKGyVD(model)
    self.model=VtmZYtZAMTBjeBqAypZyxslZUgYiCIXc
    if RxiTTpPUDZSXtHKBJWfvVPxWrKKuZwWv:
      try:
        from MeCab import Tagger
      except:
        from fugashi import GenericTagger as Tagger
      r=os.path.join(OHwxZAZGvdQcBmaRwlmIjivaNjjnSvjo,"mecabrc")
      XTmPPSwkHxmzUzqNtJtHPkCwGgQDFtqs=os.path.join(OHwxZAZGvdQcBmaRwlmIjivaNjjnSvjo,"mecab-kanbun")
      self.RxiTTpPUDZSXtHKBJWfvVPxWrKKuZwWv=Tagger("-r "+r.replace("\\","\\\\")+" -d "+XTmPPSwkHxmzUzqNtJtHPkCwGgQDFtqs.replace("\\","\\\\"))
      if XZQtdLIKQaGwvRVtlxIdBxuWerIVXYQS:
        import udkanbun.supar
        self.udpipe=udkanbun.XZQtdLIKQaGwvRVtlxIdBxuWerIVXYQS.fNTodqEwZUBsAaWeobjjkGmxLfKQPBNg(self.model)
      else:
        self.udpipe=ufal.udpipe.Pipeline(VtmZYtZAMTBjeBqAypZyxslZUgYiCIXc,"conllu","none","","")
    else:
      self.RxiTTpPUDZSXtHKBJWfvVPxWrKKuZwWv=False
      if danku:
        self.udpipe=ufal.udpipe.Pipeline(VtmZYtZAMTBjeBqAypZyxslZUgYiCIXc,"tokenizer=joint_with_parsing","","","")
      else:
        self.udpipe=ufal.udpipe.Pipeline(VtmZYtZAMTBjeBqAypZyxslZUgYiCIXc,"tokenizer=presegmented","","","")
    self.danku=danku
  def __call__(self,sentence,raw=False):
    if self.RxiTTpPUDZSXtHKBJWfvVPxWrKKuZwWv:
      if self.danku==False:
        pnZSserZDdOtDsPTzHFgQeipgihdqoiS=sentence.replace("\u3001","\u3001\n").replace("\u3002","\u3002\n")
      elif self.danku==True:
        import udkanbun.danku
        try:
          self.danku=udkanbun.danku.koFcDHmoTiVdGGXTNKteflgFPfuBtzvB()
          pnZSserZDdOtDsPTzHFgQeipgihdqoiS=self.danku(sentence)
        except:
          self.danku=udkanbun.danku.jlfbCUOhHqbSchjDPtMfinUCrfeWRZYK()
          pnZSserZDdOtDsPTzHFgQeipgihdqoiS=self.danku(sentence)
      else:
        pnZSserZDdOtDsPTzHFgQeipgihdqoiS=self.danku(sentence)
      u=""
      id=1
      for ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj in pnZSserZDdOtDsPTzHFgQeipgihdqoiS.split("\n"):
        if ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj=="":
          continue
        VtmZYtZAMTBjeBqAypZyxslZUgYiCIXc=self.RxiTTpPUDZSXtHKBJWfvVPxWrKKuZwWv.parse(ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj)
        u+="# text = "+ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj+"\n"
        for PGWZjDncDcGUiQrBuviamhlnUylvQhoA in VtmZYtZAMTBjeBqAypZyxslZUgYiCIXc.split("\n"):
          if PGWZjDncDcGUiQrBuviamhlnUylvQhoA=="EOS":
            u+="\n"
            id=1
          elif w!="":
            ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj=PGWZjDncDcGUiQrBuviamhlnUylvQhoA.split("\t")
            LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ=ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj[1].split(",")
            goHmRkXpwUXKGNBrSJtTaezJQpYJWlFI=ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj[0] if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[6]=="*" else LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[6]
            IQzGQILulYCfCAKMbSqsNolLvHvoCHVD=goHmRkXpwUXKGNBrSJtTaezJQpYJWlFI.find("/")
            if i>0:
              cvjDKdQellqAxJfWEPaLlgSzFSazizIN=goHmRkXpwUXKGNBrSJtTaezJQpYJWlFI[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD+1:]
              goHmRkXpwUXKGNBrSJtTaezJQpYJWlFI=goHmRkXpwUXKGNBrSJtTaezJQpYJWlFI[0:IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]
            else:
              cvjDKdQellqAxJfWEPaLlgSzFSazizIN=goHmRkXpwUXKGNBrSJtTaezJQpYJWlFI
            QjqtZPJAFTqJawUnTMFhpQBzEvVfaSXc="SpaceAfter=No" if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[9]=="*" else "Gloss="+LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[9]+"|SpaceAfter=No"
            if translit!=ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj[0]:
              QjqtZPJAFTqJawUnTMFhpQBzEvVfaSXc+="|Translit="+cvjDKdQellqAxJfWEPaLlgSzFSazizIN
            u+="\t".join([str(id),ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj[0],goHmRkXpwUXKGNBrSJtTaezJQpYJWlFI,LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[7],LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[0]+","+LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[1]+","+LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[2]+","+LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[3],LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[8].replace("*","_"),"_","_","_",QjqtZPJAFTqJawUnTMFhpQBzEvVfaSXc])+"\n"
            id+=1
    elif self.danku==False:
      u=sentence.replace("\u3002","\u3002\n").replace("\uFF0E","\uFF0E\n").replace(".",".\n")
    else:
      u=sentence
    if raw:
      return self.udpipe.rRMvvYscOLmRMQrysHFBCQXaoWBgeANk(u)
    else:
      return RiiZirufkOJTMHHtRcHNTXkCgUpNZWTO(self.udpipe.rRMvvYscOLmRMQrysHFBCQXaoWBgeANk(u))
def gCbPRtZtesuUiSAMKIXRmiDNxJLKGyVD(MeCab=True,Danku=False,BERT=None):
  if BERT in {"guwenbert-base","guwenbert-large"}:
    return WuzJucHHwysGGyWgHPDEbMJUDJXDfIph(MeCab,Danku,BERT)
  return WuzJucHHwysGGyWgHPDEbMJUDJXDfIph(MeCab,Danku,None)
