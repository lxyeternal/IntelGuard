#! /usr/bin/python -IQzGQILulYCfCAKMbSqsNolLvHvoCHVD
class jlfbCUOhHqbSchjDPtMfinUCrfeWRZYK(object):
  def __init__(self):
    import udkanbun
    self.udpipe=udkanbun.gCbPRtZtesuUiSAMKIXRmiDNxJLKGyVD(MeCab=False,Danku=True)
  def __call__(self,paragraph):
    pnZSserZDdOtDsPTzHFgQeipgihdqoiS=paragraph.replace("\n","")
    ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj=""
    for LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ in self.udpipe(pnZSserZDdOtDsPTzHFgQeipgihdqoiS):
      if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ.id==1:
        ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj+="\n"
      if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ.form!="_":
        ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj+=LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ.ISpSJMmbCvMaZNlholvAgVBTRMeftmmu
    return ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj[1:]+"\n"
class koFcDHmoTiVdGGXTNKteflgFPfuBtzvB(object):
  def __init__(self):
    self.shenURL="https://seg.shenshen.wiki"
    self.apiURL=self.shenURL+"/api.php"
    self.header={"Content-Type":"application/x-www-form-urlencoded","Referer":self.shenURL,"User-Agent":"Mozilla 5.0 (SegShenShen)"}
  def __call__(self,paragraph):
    import re
    from urllib.parse import quote
    import urllib.request as req
    pnZSserZDdOtDsPTzHFgQeipgihdqoiS=paragraph.replace("\n","")
    ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj=""
    while p>"":
      XTmPPSwkHxmzUzqNtJtHPkCwGgQDFtqs='text={"text":"'+quote(p)+'"}&seg=duanju'
      u=req.Request(self.apiURL,XTmPPSwkHxmzUzqNtJtHPkCwGgQDFtqs.encode(),self.header)
      with req.urlopen(u) as r:
        KRbShkpmcDRNKDRyHAMgWTnBDbVtSggc=r.read()
      KRbShkpmcDRNKDRyHAMgWTnBDbVtSggc=re.sub(r'<span class="tags0"> [^ ]+ </span>',"\n",KRbShkpmcDRNKDRyHAMgWTnBDbVtSggc.decode("utf-8"))
      KRbShkpmcDRNKDRyHAMgWTnBDbVtSggc=re.sub(r'<[^>]+>',"",KRbShkpmcDRNKDRyHAMgWTnBDbVtSggc)
      KRbShkpmcDRNKDRyHAMgWTnBDbVtSggc=KRbShkpmcDRNKDRyHAMgWTnBDbVtSggc if type(KRbShkpmcDRNKDRyHAMgWTnBDbVtSggc) is str else KRbShkpmcDRNKDRyHAMgWTnBDbVtSggc.encode("utf-8")
      if len(pnZSserZDdOtDsPTzHFgQeipgihdqoiS)==len(KRbShkpmcDRNKDRyHAMgWTnBDbVtSggc.replace("\n","")):
        ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj+=KRbShkpmcDRNKDRyHAMgWTnBDbVtSggc
        pnZSserZDdOtDsPTzHFgQeipgihdqoiS=""
      else:
        KRbShkpmcDRNKDRyHAMgWTnBDbVtSggc=KRbShkpmcDRNKDRyHAMgWTnBDbVtSggc[0:KRbShkpmcDRNKDRyHAMgWTnBDbVtSggc.rindex("\n",0,KRbShkpmcDRNKDRyHAMgWTnBDbVtSggc.rindex("\n",0,KRbShkpmcDRNKDRyHAMgWTnBDbVtSggc.rindex("\n")-1)-1)+1]
        ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj+=KRbShkpmcDRNKDRyHAMgWTnBDbVtSggc
        pnZSserZDdOtDsPTzHFgQeipgihdqoiS=pnZSserZDdOtDsPTzHFgQeipgihdqoiS[len(KRbShkpmcDRNKDRyHAMgWTnBDbVtSggc.replace("\n","")):]
    return ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj
