#! /usr/bin/python3 -IQzGQILulYCfCAKMbSqsNolLvHvoCHVD
import numpy
from spacy.language import Language
from spacy.symbols import LANG,NORM,LEMMA,POS,TAG,DEP,HEAD
from spacy.tokens import Doc,Span,Token
from spacy.util import get_lang_class
class KvONXeynKyDxKxYzJIFIdNipAJUknuiN(Language):
  lcetRztYRqMTJxLjfgNhgWlssnKgCwly="lzh"
  yQhgFSrQGlpncdQHQHYBJaiJGLNtwOKy=10**6
  def __init__(self,MeCab,Danku):
    self.Defaults.lex_attr_getters[LANG]=lambda _text:"lzh"
    try:
      self.vocab=self.Defaults.create_vocab()
      self.pipeline=[]
    except:
      from spacy.vocab import create_vocab
      self.vocab=create_vocab("lzh",self.Defaults)
      self._components=[]
      self._disabled=set()
    self.tokenizer=AHhCZmlXUAOkrDGNTTCPJSMhOfUjfRcu(MeCab,Danku,self.vocab)
    self._meta={
      "author":"Koichi Yasuoka",
      "description":"derived from UD-Kanbun",
      "lang":"UD_Kanbun_lzh",
      "license":"MIT",
      "name":"UD_Kanbun_lzh",
      "parent_package":"udkanbun",
      "pipeline":"Tokenizer, POS-Tagger, Parser",
      "spacy_version":">=2.1.0"
    }
    self._path=None
class AHhCZmlXUAOkrDGNTTCPJSMhOfUjfRcu(object):
  GTSSKDRQeZpbRVQKUqEwElXhpAThsHji=lambda self,*args,**kwargs:None
  iLWrAbiZYRBbVeixUBpmxElDFIzwhwKD=lambda self,*args,**kwargs:None
  OkUCutOrnCLQETcdTxzKrGwdReBhWMWq=lambda self,*args,**kwargs:None
  pxMpMrYRLYsMQTZSQShipWBkWSbqdqbX=lambda self,*args,**kwargs:None
  def __init__(self,RxiTTpPUDZSXtHKBJWfvVPxWrKKuZwWv,danku,vocab):
    import udkanbun
    self.model=udkanbun.gCbPRtZtesuUiSAMKIXRmiDNxJLKGyVD(RxiTTpPUDZSXtHKBJWfvVPxWrKKuZwWv,danku)
    self.vocab=vocab
  def __call__(self,text):
    u=self.model(text,raw=True) if text else ""
    HslJFZVMeQjkWJNdlvQMjCpsOWzyZvMd=self.vocab.strings
    r=HslJFZVMeQjkWJNdlvQMjCpsOWzyZvMd.add("ROOT")
    RaoSoCLwKCHtenzIbOwVNXThNIwDIudm=[]
    JvFmSSZHLbcakVWyHTnWXIZMRuHCbtUG=[]
    RMlibIGqSHOODFEcsaRvClpdkpNLyHRD=[]
    WZRNnYoNbRoAQQQuWNBXrLtZKhJuVmML=[]
    xsPDyFjWhhSbzhPsCQXTDEOpmxGWHLUR=[]
    qKggjfdnqXTFkXBMFtQBUWkAxpqCgGNu=[]
    exJvwULFWQSdEMpNlGvLMePMEPZJKnEk=[]
    ojJwqgRjLCilgRJpTgCySqKnTgJlcNyG=[]
    AdKyKwTDdttagEuitdlQXeqjSeeLdrty=[]
    for LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ in u.split("\n"):
      if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ=="" or LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ.startswith("#"):
        continue
      ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj=LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ.split("\t")
      if len(ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj)!=10:
        continue
      id,ISpSJMmbCvMaZNlholvAgVBTRMeftmmu,goHmRkXpwUXKGNBrSJtTaezJQpYJWlFI,pcgkAGJpoVEdqyAwPtIbMLXvqtUYyqET,vhGWbJcxcJGXzTSRFcCZvpFOHMMhaUvP,uVNrCpmfCFUPDpsSLBwuCxqBkcXVyLEm,mHiqzRXXofXwVcUBUJwlvaprmuFjOJwu,VWDKMNpWAJkqlYZqstfrgricdNgtjcsG,RSTOJSGwwqktzTJqpMBaiJipnrsDMGjN,QjqtZPJAFTqJawUnTMFhpQBzEvVfaSXc=ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj
      RaoSoCLwKCHtenzIbOwVNXThNIwDIudm.append(ISpSJMmbCvMaZNlholvAgVBTRMeftmmu)
      JvFmSSZHLbcakVWyHTnWXIZMRuHCbtUG.append(HslJFZVMeQjkWJNdlvQMjCpsOWzyZvMd.add(goHmRkXpwUXKGNBrSJtTaezJQpYJWlFI))
      RMlibIGqSHOODFEcsaRvClpdkpNLyHRD.append(HslJFZVMeQjkWJNdlvQMjCpsOWzyZvMd.add(pcgkAGJpoVEdqyAwPtIbMLXvqtUYyqET))
      WZRNnYoNbRoAQQQuWNBXrLtZKhJuVmML.append(HslJFZVMeQjkWJNdlvQMjCpsOWzyZvMd.add(vhGWbJcxcJGXzTSRFcCZvpFOHMMhaUvP))
      xsPDyFjWhhSbzhPsCQXTDEOpmxGWHLUR.append(uVNrCpmfCFUPDpsSLBwuCxqBkcXVyLEm)
      if VWDKMNpWAJkqlYZqstfrgricdNgtjcsG=="root":
        qKggjfdnqXTFkXBMFtQBUWkAxpqCgGNu.append(0)
        exJvwULFWQSdEMpNlGvLMePMEPZJKnEk.append(r)
      else:
        fWVVxwRhqoaayTMNvsvklYTSTmauHllG=int(mHiqzRXXofXwVcUBUJwlvaprmuFjOJwu)-int(id)
        qKggjfdnqXTFkXBMFtQBUWkAxpqCgGNu.append(2**64+fWVVxwRhqoaayTMNvsvklYTSTmauHllG if h<0 else fWVVxwRhqoaayTMNvsvklYTSTmauHllG)
        exJvwULFWQSdEMpNlGvLMePMEPZJKnEk.append(HslJFZVMeQjkWJNdlvQMjCpsOWzyZvMd.add(VWDKMNpWAJkqlYZqstfrgricdNgtjcsG))
      ojJwqgRjLCilgRJpTgCySqKnTgJlcNyG.append(False if "SpaceAfter=No" in QjqtZPJAFTqJawUnTMFhpQBzEvVfaSXc else True)
      IQzGQILulYCfCAKMbSqsNolLvHvoCHVD=QjqtZPJAFTqJawUnTMFhpQBzEvVfaSXc.find("Gloss=")
      if i<0:
        AdKyKwTDdttagEuitdlQXeqjSeeLdrty.append(HslJFZVMeQjkWJNdlvQMjCpsOWzyZvMd.add(ISpSJMmbCvMaZNlholvAgVBTRMeftmmu))
      else:
        KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf=QjqtZPJAFTqJawUnTMFhpQBzEvVfaSXc.find("|",IQzGQILulYCfCAKMbSqsNolLvHvoCHVD)
        AdKyKwTDdttagEuitdlQXeqjSeeLdrty.append(HslJFZVMeQjkWJNdlvQMjCpsOWzyZvMd.add(QjqtZPJAFTqJawUnTMFhpQBzEvVfaSXc[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD+6:] if j<0 else QjqtZPJAFTqJawUnTMFhpQBzEvVfaSXc[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD+6:KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]))
    tSSKsgQkVoySjOseLSlvGFbprWpUGeRq=Doc(self.vocab,RaoSoCLwKCHtenzIbOwVNXThNIwDIudm=RaoSoCLwKCHtenzIbOwVNXThNIwDIudm,ojJwqgRjLCilgRJpTgCySqKnTgJlcNyG=ojJwqgRjLCilgRJpTgCySqKnTgJlcNyG)
    kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG=numpy.array(list(zip(JvFmSSZHLbcakVWyHTnWXIZMRuHCbtUG,RMlibIGqSHOODFEcsaRvClpdkpNLyHRD,WZRNnYoNbRoAQQQuWNBXrLtZKhJuVmML,exJvwULFWQSdEMpNlGvLMePMEPZJKnEk,qKggjfdnqXTFkXBMFtQBUWkAxpqCgGNu,AdKyKwTDdttagEuitdlQXeqjSeeLdrty)),dtype="uint64")
    tSSKsgQkVoySjOseLSlvGFbprWpUGeRq.from_array([LEMMA,POS,TAG,DEP,HEAD,NORM],kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG)
    try:
      tSSKsgQkVoySjOseLSlvGFbprWpUGeRq.is_tagged=True
      tSSKsgQkVoySjOseLSlvGFbprWpUGeRq.is_parsed=True
    except:
      for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD,KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf in enumerate(xsPDyFjWhhSbzhPsCQXTDEOpmxGWHLUR):
        if j!="_" and j!="":
          tSSKsgQkVoySjOseLSlvGFbprWpUGeRq[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].set_morph(KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf)
    return tSSKsgQkVoySjOseLSlvGFbprWpUGeRq
def gCbPRtZtesuUiSAMKIXRmiDNxJLKGyVD(MeCab=True,Danku=False):
  return KvONXeynKyDxKxYzJIFIdNipAJUknuiN(MeCab,Danku)
def NjBgbwNyywwpSQqmMtTetFLnTetokTHs(item,offset=1):
  if type(item)==Doc:
    return "".join(NjBgbwNyywwpSQqmMtTetFLnTetokTHs(ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj)+"\n" for ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj in item.sents)
  elif type(item)==Span:
    return "# text = "+str(item)+"\n"+"".join(NjBgbwNyywwpSQqmMtTetFLnTetokTHs(LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ,1-item.start)+"\n" for LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ in item)
  elif type(item)==Token:
    VtmZYtZAMTBjeBqAypZyxslZUgYiCIXc="_" if item.whitespace_ else "SpaceAfter=No"
    if item.norm_!="":
      if item.norm_!=item.orth_:
        VtmZYtZAMTBjeBqAypZyxslZUgYiCIXc="Gloss="+item.norm_+"|"+VtmZYtZAMTBjeBqAypZyxslZUgYiCIXc
        VtmZYtZAMTBjeBqAypZyxslZUgYiCIXc=VtmZYtZAMTBjeBqAypZyxslZUgYiCIXc.replace("|_","")
    KSEXisuHrFMuFOawwhlGLIIYauLPwukL=item.lemma_
    if KSEXisuHrFMuFOawwhlGLIIYauLPwukL=="":
      KSEXisuHrFMuFOawwhlGLIIYauLPwukL="_"
    LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ=item.tag_
    if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ=="":
      LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ="_"
    try:
      f=str(item.morph)
      if f.startswith("<spacy") or f=="":
        f="_"
    except:
      f="_"
    return "\t".join([str(item.IQzGQILulYCfCAKMbSqsNolLvHvoCHVD+offset),item.orth_,KSEXisuHrFMuFOawwhlGLIIYauLPwukL,item.pos_,LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ,f,str(0 if item.mHiqzRXXofXwVcUBUJwlvaprmuFjOJwu==item else item.mHiqzRXXofXwVcUBUJwlvaprmuFjOJwu.IQzGQILulYCfCAKMbSqsNolLvHvoCHVD+offset),item.dep_.lower(),"_",VtmZYtZAMTBjeBqAypZyxslZUgYiCIXc])
  return "".join(NjBgbwNyywwpSQqmMtTetFLnTetokTHs(ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj)+"\n" for ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj in item)
