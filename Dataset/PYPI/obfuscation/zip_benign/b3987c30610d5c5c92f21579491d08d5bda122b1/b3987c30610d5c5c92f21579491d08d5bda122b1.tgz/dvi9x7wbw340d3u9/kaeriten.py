def XxfUijMKOvwOWSRxHzkieipWvZiNSOdO(ud,matrix=False):
  PGWZjDncDcGUiQrBuviamhlnUylvQhoA=len(ud)
  LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ=[[] for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(PGWZjDncDcGUiQrBuviamhlnUylvQhoA)]
  fWVVxwRhqoaayTMNvsvklYTSTmauHllG=[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD+LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ.mHiqzRXXofXwVcUBUJwlvaprmuFjOJwu.id-LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ.id for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD,LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ in enumerate(ud)]
  ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj=[0]*PGWZjDncDcGUiQrBuviamhlnUylvQhoA
  KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf=PGWZjDncDcGUiQrBuviamhlnUylvQhoA
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in reversed(range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA)):
    ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]=KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf
    if ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].id==1:
      KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf=IQzGQILulYCfCAKMbSqsNolLvHvoCHVD
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA):
    if ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG=="obj" and fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]<IQzGQILulYCfCAKMbSqsNolLvHvoCHVD:
      LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].append((fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD],1))
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA):
    if ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG.startswith("obl") and fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]<IQzGQILulYCfCAKMbSqsNolLvHvoCHVD:
      LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].append((fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD],2))
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA):
    if ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG=="expl" and fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]<IQzGQILulYCfCAKMbSqsNolLvHvoCHVD:
      LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].append((fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD],3))
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA):
    if (ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG=="ccomp" or ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG=="xcomp" or ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG=="advcl") and fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]<IQzGQILulYCfCAKMbSqsNolLvHvoCHVD:
      LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].append((fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD],4))
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA):
    if ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG=="cop" and fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]>IQzGQILulYCfCAKMbSqsNolLvHvoCHVD:
      LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]].append((IQzGQILulYCfCAKMbSqsNolLvHvoCHVD,5))
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA):
    if (ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG=="case" or ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG=="mark") and fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]>IQzGQILulYCfCAKMbSqsNolLvHvoCHVD:
      if not ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].vhGWbJcxcJGXzTSRFcCZvpFOHMMhaUvP.startswith("v,前置詞,基盤,"):
        LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]].append((IQzGQILulYCfCAKMbSqsNolLvHvoCHVD,6))
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA):
    if ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG=="aux" and fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]>IQzGQILulYCfCAKMbSqsNolLvHvoCHVD:
      LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]].append((IQzGQILulYCfCAKMbSqsNolLvHvoCHVD,7))
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA):
    if ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG=="advmod" and fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]>IQzGQILulYCfCAKMbSqsNolLvHvoCHVD:
      XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].vhGWbJcxcJGXzTSRFcCZvpFOHMMhaUvP.split(",")
      if XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf[1]=="副詞":
        if XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf[2]=="否定" or (XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf[2]=="判断" and XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf[3]=="逆接") or (XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf[2]=="時相" and XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf[3]=="将来"):
          LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]].append((IQzGQILulYCfCAKMbSqsNolLvHvoCHVD,8))
      f=ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].ISpSJMmbCvMaZNlholvAgVBTRMeftmmu
      if f=="難" or f=="易" or f=="無":
        LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]].append((IQzGQILulYCfCAKMbSqsNolLvHvoCHVD,8))
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA):
    if ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG=="cc" and fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]>IQzGQILulYCfCAKMbSqsNolLvHvoCHVD:
      if ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].vhGWbJcxcJGXzTSRFcCZvpFOHMMhaUvP.startswith("v,前置詞,関係,"):
        LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]].append((IQzGQILulYCfCAKMbSqsNolLvHvoCHVD,9))
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA):
    if ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].ISpSJMmbCvMaZNlholvAgVBTRMeftmmu=="況":
      for KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf in reversed(range(IQzGQILulYCfCAKMbSqsNolLvHvoCHVD+1,ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD])):
        XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=[(kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b) for kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b in LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf] if kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG==IQzGQILulYCfCAKMbSqsNolLvHvoCHVD and b<5]
        if x!=[]:
          LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]=[]
          for ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC in reversed(range(IQzGQILulYCfCAKMbSqsNolLvHvoCHVD+1,KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf)):
            if fWVVxwRhqoaayTMNvsvklYTSTmauHllG[ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC]==KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf and (ud[ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG=="case" or ud[ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG=="mark"):
              LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf].append((ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC,10))
              break
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA):
    if ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].ISpSJMmbCvMaZNlholvAgVBTRMeftmmu=="所":
      if ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG=="case" or ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG=="mark":
        if ud[fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]].ISpSJMmbCvMaZNlholvAgVBTRMeftmmu=="謂" and fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]>IQzGQILulYCfCAKMbSqsNolLvHvoCHVD:
          for KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf in reversed(range(fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]+1,ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD])):
            XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=[(kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b) for kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b in LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf] if kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG==fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD] and b<5]
            if x!=[]:
              LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]=[]
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA):
    if ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].ISpSJMmbCvMaZNlholvAgVBTRMeftmmu=="請":
      XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=[ud[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG for KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf in range(IQzGQILulYCfCAKMbSqsNolLvHvoCHVD-ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].id+1,ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]) if fWVVxwRhqoaayTMNvsvklYTSTmauHllG[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]==IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]
      if "vocative" in XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf:
        for KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf in reversed(range(IQzGQILulYCfCAKMbSqsNolLvHvoCHVD+1,ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD])):
          XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=[(kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b) for kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b in LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf] if kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG==IQzGQILulYCfCAKMbSqsNolLvHvoCHVD and b<5]
          if x!=[]:
            LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]=[]
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA):
    if ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].form!="焉":
      continue
    if ud[fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]].vhGWbJcxcJGXzTSRFcCZvpFOHMMhaUvP.startswith("v,動詞,描写,"):
      continue
    XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=[(kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b) for kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b in LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD] if b==2]
    if x!=[]:
      LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]=[]
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA):
    if ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].deprel!="xcomp" and ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].deprel!="ccomp":
      continue
    for kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b in LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]:
      f=ud[kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG].goHmRkXpwUXKGNBrSJtTaezJQpYJWlFI
      if b==4 and (f=="如" or f=="若" or f=="奈"):
        XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=[ud[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG for KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf in range(IQzGQILulYCfCAKMbSqsNolLvHvoCHVD-ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].id+1,ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]) if fWVVxwRhqoaayTMNvsvklYTSTmauHllG[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]==kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG]
        if "obj" in XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf or "expl" in XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf:
          LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].remove((kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,4))
          LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].extend(LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG])
          LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG]=[]
        break
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in reversed(range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA)):
    if ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].deprel!="xcomp":
      continue
    for kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b in LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]:
      if b==4 and ud[kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG].goHmRkXpwUXKGNBrSJtTaezJQpYJWlFI=="助":
        LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].remove((kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,4))
        LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].extend(LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG])
        LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG]=[]
        break
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in reversed(range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA)):
    if ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].deprel!="xcomp":
      continue
    for kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b in LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]:
      if b==4 and ud[kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG].goHmRkXpwUXKGNBrSJtTaezJQpYJWlFI=="勸":
        LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].remove((kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,4))
        LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].extend(LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG])
        LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG]=[]
        break
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA):
    KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf=fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]
    if ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].form!="所" or ud[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf].form!="以":
      continue
    if ud[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf].deprel!="advmod":
      continue
    XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=[(kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,17) for kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b in LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf] if b==6]
    if x!=[]:
      LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[fWVVxwRhqoaayTMNvsvklYTSTmauHllG[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]].extend(XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf)
      LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]=[]
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA):
    KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf=fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]
    if ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].form!="所" or ud[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf].form!="以":
      continue
    if ud[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG=="advmod":
      continue
    XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=[(kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b) for kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b in LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf] if b==6]
    if XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf==[]:
      continue
    XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=[(kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,18) for kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b in LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf] if b!=6 or a!=IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]
    LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]=[]
    for ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC in range(KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf-ud[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf].id+1,ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]):
      for ijhlhrmuUroarXlMudOLVttcmMTuUvoF,(kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b) in enumerate(LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC]):
        if kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG==KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf:
          LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC][ijhlhrmuUroarXlMudOLVttcmMTuUvoF]=(IQzGQILulYCfCAKMbSqsNolLvHvoCHVD,18)
    LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].extend(XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf)
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA):
    if ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].form!="能":
      continue
    if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]!=[]:
      continue
    KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf=fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]
    XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=[(kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b) for kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b in LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf] if kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG==IQzGQILulYCfCAKMbSqsNolLvHvoCHVD and b==7]
    if x!=[]:
      LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf].remove((IQzGQILulYCfCAKMbSqsNolLvHvoCHVD,7))
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA):
    if ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].form!="敢" and ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].form!="肯":
      continue
    KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf=fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]
    XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=[(kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b) for kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b in LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf] if kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG==IQzGQILulYCfCAKMbSqsNolLvHvoCHVD and b==7]
    if XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf==[]:
      continue
    LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf].remove((IQzGQILulYCfCAKMbSqsNolLvHvoCHVD,7))
    LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf].extend(LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD])
    LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]=[]
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA):
    KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf=fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]
    if ud[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf].form!="得" or ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].form!="而":
      continue
    if IQzGQILulYCfCAKMbSqsNolLvHvoCHVD-j!=1:
      continue
    ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC=fWVVxwRhqoaayTMNvsvklYTSTmauHllG[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]
    XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=[(kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b) for kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b in LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC] if kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG==KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf and b==7]
    if XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf==[]:
      continue
    LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC].remove((KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf,7))
    LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC].extend(LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf])
    LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]=[]
  for XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf in range(2):
    for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in reversed(range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA)):
      KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf=fWVVxwRhqoaayTMNvsvklYTSTmauHllG[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]
      if j>IQzGQILulYCfCAKMbSqsNolLvHvoCHVD:
        continue
      XTmPPSwkHxmzUzqNtJtHPkCwGgQDFtqs=ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].VWDKMNpWAJkqlYZqstfrgricdNgtjcsG
      if XTmPPSwkHxmzUzqNtJtHPkCwGgQDFtqs=="clf" or XTmPPSwkHxmzUzqNtJtHPkCwGgQDFtqs=="flat" or XTmPPSwkHxmzUzqNtJtHPkCwGgQDFtqs=="case":
        LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].extend(LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf])
        LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]=[]
      elif XTmPPSwkHxmzUzqNtJtHPkCwGgQDFtqs=="conj":
        for kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b in LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]:
          if b!=8:
            LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD].append((kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b))
            LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf].remove((kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b))
  pnZSserZDdOtDsPTzHFgQeipgihdqoiS=[]
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(PGWZjDncDcGUiQrBuviamhlnUylvQhoA):
    pnZSserZDdOtDsPTzHFgQeipgihdqoiS.append(None)
    for kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b in LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]:
      if pnZSserZDdOtDsPTzHFgQeipgihdqoiS[kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG]!=None:
        KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf,ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC,KSEXisuHrFMuFOawwhlGLIIYauLPwukL=pnZSserZDdOtDsPTzHFgQeipgihdqoiS[kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG]
        LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf].remove((ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC,KSEXisuHrFMuFOawwhlGLIIYauLPwukL))
      pnZSserZDdOtDsPTzHFgQeipgihdqoiS[kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG]=(IQzGQILulYCfCAKMbSqsNolLvHvoCHVD,kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b)
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA):
    if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]==[]:
      continue
    LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]=list(set(kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG for kWDTDjKTEbYCKHkiTHDUJXOxdEJqxebG,b in LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]))
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in reversed(range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA)):
    if len(LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD])<2:
      continue
    VtmZYtZAMTBjeBqAypZyxslZUgYiCIXc=max(LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD])
    for KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf in LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]:
      if j<VtmZYtZAMTBjeBqAypZyxslZUgYiCIXc:
        LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[VtmZYtZAMTBjeBqAypZyxslZUgYiCIXc].append(KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf)
    LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]=[VtmZYtZAMTBjeBqAypZyxslZUgYiCIXc]
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in reversed(range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA)):
    if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]==[]:
      continue
    KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf=LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD][0]
    for ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC in range(KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf+1,IQzGQILulYCfCAKMbSqsNolLvHvoCHVD):
      if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC]!=[]:
        if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC][0]<KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf:
          break
    else:
      continue
    LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]=[]
  if matrix:
    return LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ
  ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC=[]
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in range(PGWZjDncDcGUiQrBuviamhlnUylvQhoA-1):
    if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD+1]==[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD] and len(ud[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD+1].ISpSJMmbCvMaZNlholvAgVBTRMeftmmu)==1:
      ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC.append("\u3191")
      LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD+1]=[]
    else:
      ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC.append("")
  ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC.append("")
  pnZSserZDdOtDsPTzHFgQeipgihdqoiS="\u3192\u3193\u3194\u3195五六七八九十"
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in reversed(range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA)):
    if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]==[]:
      continue
    XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf for KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf in range(IQzGQILulYCfCAKMbSqsNolLvHvoCHVD+1,ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]) if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]==[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]]
    if x!=[]:
      continue
    XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=IQzGQILulYCfCAKMbSqsNolLvHvoCHVD
    ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo=1
    while LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]!=[]:
      ijhlhrmuUroarXlMudOLVttcmMTuUvoF=LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf][0]
      XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf for KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf in range(ijhlhrmuUroarXlMudOLVttcmMTuUvoF+1,XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf) if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]!=[]]
      if x!=[]:
        ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo=0
        break
      XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=ijhlhrmuUroarXlMudOLVttcmMTuUvoF
      ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo+=1
    if ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo==0 or n>len(pnZSserZDdOtDsPTzHFgQeipgihdqoiS):
      continue
    XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=IQzGQILulYCfCAKMbSqsNolLvHvoCHVD
    ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo=0
    while LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]!=[]:
      ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]=pnZSserZDdOtDsPTzHFgQeipgihdqoiS[ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo]+ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]
      ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo+=1
      ijhlhrmuUroarXlMudOLVttcmMTuUvoF=LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf][0]
      LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]=[]
      XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=ijhlhrmuUroarXlMudOLVttcmMTuUvoF
    ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]=pnZSserZDdOtDsPTzHFgQeipgihdqoiS[ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo]+ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]
  pnZSserZDdOtDsPTzHFgQeipgihdqoiS="\u3196\u3197\u3198"
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in reversed(range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA)):
    if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]==[]:
      continue
    XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf for KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf in range(IQzGQILulYCfCAKMbSqsNolLvHvoCHVD+1,ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]) if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]==[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]]
    if x!=[]:
      continue
    XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=IQzGQILulYCfCAKMbSqsNolLvHvoCHVD
    ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo=1
    while LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]!=[]:
      ijhlhrmuUroarXlMudOLVttcmMTuUvoF=LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf][0]
      XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf for KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf in range(ijhlhrmuUroarXlMudOLVttcmMTuUvoF+1,XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf) if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]!=[]]
      if x!=[]:
        ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo=0
        break
      XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=ijhlhrmuUroarXlMudOLVttcmMTuUvoF
      ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo+=1
    if ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo==0 or n>len(pnZSserZDdOtDsPTzHFgQeipgihdqoiS):
      continue
    XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=IQzGQILulYCfCAKMbSqsNolLvHvoCHVD
    ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo=0
    while LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]!=[]:
      ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]=pnZSserZDdOtDsPTzHFgQeipgihdqoiS[ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo]+ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]
      ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo+=1
      ijhlhrmuUroarXlMudOLVttcmMTuUvoF=LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf][0]
      LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]=[]
      XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=ijhlhrmuUroarXlMudOLVttcmMTuUvoF
    ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]=pnZSserZDdOtDsPTzHFgQeipgihdqoiS[2]+ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]
  pnZSserZDdOtDsPTzHFgQeipgihdqoiS="\u3199\u319A\u319B\u319C戊己庚辛壬癸"
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in reversed(range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA)):
    if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]==[]:
      continue
    XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf for KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf in range(IQzGQILulYCfCAKMbSqsNolLvHvoCHVD+1,ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]) if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]==[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]]
    if x!=[]:
      continue
    XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=IQzGQILulYCfCAKMbSqsNolLvHvoCHVD
    ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo=1
    while LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]!=[]:
      ijhlhrmuUroarXlMudOLVttcmMTuUvoF=LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf][0]
      XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf for KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf in range(ijhlhrmuUroarXlMudOLVttcmMTuUvoF+1,XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf) if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]!=[]]
      if x!=[]:
        ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo=0
        break
      XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=ijhlhrmuUroarXlMudOLVttcmMTuUvoF
      ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo+=1
    if ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo==0 or n>len(pnZSserZDdOtDsPTzHFgQeipgihdqoiS):
      continue
    XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=IQzGQILulYCfCAKMbSqsNolLvHvoCHVD
    ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo=0
    while LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]!=[]:
      ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]=pnZSserZDdOtDsPTzHFgQeipgihdqoiS[ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo]+ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]
      ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo+=1
      ijhlhrmuUroarXlMudOLVttcmMTuUvoF=LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf][0]
      LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]=[]
      XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=ijhlhrmuUroarXlMudOLVttcmMTuUvoF
    ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]=pnZSserZDdOtDsPTzHFgQeipgihdqoiS[ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo]+ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]
  pnZSserZDdOtDsPTzHFgQeipgihdqoiS="\u319D\u319E\u319F"
  for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD in reversed(range(1,PGWZjDncDcGUiQrBuviamhlnUylvQhoA)):
    if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]==[]:
      continue
    XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=IQzGQILulYCfCAKMbSqsNolLvHvoCHVD
    ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo=1
    while LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]!=[]:
      ijhlhrmuUroarXlMudOLVttcmMTuUvoF=LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf][0]
      XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf for KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf in range(ijhlhrmuUroarXlMudOLVttcmMTuUvoF+1,XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf) if LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[KwFbWKmsmDBDwsesxYFFBHkjwrWjIjUf]!=[]]
      if x!=[]:
        ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo=0
        break
      XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=ijhlhrmuUroarXlMudOLVttcmMTuUvoF
      ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo+=1
    if ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo==0 or n>len(pnZSserZDdOtDsPTzHFgQeipgihdqoiS):
      continue
    XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=IQzGQILulYCfCAKMbSqsNolLvHvoCHVD
    ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo=0
    while LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]!=[]:
      ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]=pnZSserZDdOtDsPTzHFgQeipgihdqoiS[ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo]+ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]
      ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo+=1
      ijhlhrmuUroarXlMudOLVttcmMTuUvoF=LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf][0]
      LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]=[]
      XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf=ijhlhrmuUroarXlMudOLVttcmMTuUvoF
    ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]=pnZSserZDdOtDsPTzHFgQeipgihdqoiS[ikfcUnDPPxVTxIuLXPkNZTuwhAPXOrqo]+ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC[XkxBNvRrdQVuxgaGCWPtzKDcXpGTIAuf]
  return ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC
