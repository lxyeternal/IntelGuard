#! /usr/bin/python3 -IQzGQILulYCfCAKMbSqsNolLvHvoCHVD
import os,sys,time
ULOtEFnGgfdOVjkMeQYiLcXSdqirFEKf=time.time()
YBPGvnIkGrpRtAdgiVKeptifnFrHPBIK=yMBCXbYfMizysSULdHiivNQFWCMdpDII=0
def tHYCLNIFmRvyicUQgqAMANnONVbhIrqv(block_count,block_size,total_size):
  LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ=time.time()
  pnZSserZDdOtDsPTzHFgQeipgihdqoiS=100.0*(block_count*block_size+YBPGvnIkGrpRtAdgiVKeptifnFrHPBIK)/yMBCXbYfMizysSULdHiivNQFWCMdpDII
  if p<1:
    LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ=-1
  elif p>=100:
    pnZSserZDdOtDsPTzHFgQeipgihdqoiS=100
    LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ-=ULOtEFnGgfdOVjkMeQYiLcXSdqirFEKf
  else:
    LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ=(LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ-ULOtEFnGgfdOVjkMeQYiLcXSdqirFEKf)*(100-pnZSserZDdOtDsPTzHFgQeipgihdqoiS)/pnZSserZDdOtDsPTzHFgQeipgihdqoiS
  b=int(pnZSserZDdOtDsPTzHFgQeipgihdqoiS/2)
  if b==50:
    ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj="="*50
  else:
    ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj=("="*b)+">"+(" "*(49-b))
  if t<0:
    u="   "
  elif t<3600:
    u=time.strftime("%M:%S   ",time.gmtime(LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ))
  elif t<86400:
    u=time.strftime("%H:%M:%S   ",time.gmtime(LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ))
  else:
    u=time.strftime("%d+%H:%M:%S   ",time.gmtime(LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ))
  print("\r ["+ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj+"] "+str(int(pnZSserZDdOtDsPTzHFgQeipgihdqoiS))+"% "+u,end="",file=sys.stderr)
def yvJYoEjMkABqhuspYUUwYntbudJXNeSe(url,file,dir="."):
  import urllib.request
  global YBPGvnIkGrpRtAdgiVKeptifnFrHPBIK,yMBCXbYfMizysSULdHiivNQFWCMdpDII,ULOtEFnGgfdOVjkMeQYiLcXSdqirFEKf
  LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ=os.path.join(dir,"filesize.txt")
  urllib.request.urlretrieve(url+"filesize.txt",LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ)
  with open(LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ,"r") as f:
    r=f.read()
  yMBCXbYfMizysSULdHiivNQFWCMdpDII=0
  for LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ in r.split("\n"):
    ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj=LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ.split()
    if len(ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj)==2:
      if ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj[0]==file:
        yMBCXbYfMizysSULdHiivNQFWCMdpDII=int(ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj[1])
  ULOtEFnGgfdOVjkMeQYiLcXSdqirFEKf=time.time()
  with open(os.path.join(dir,file),"wb") as f:
    YBPGvnIkGrpRtAdgiVKeptifnFrHPBIK=0
    IQzGQILulYCfCAKMbSqsNolLvHvoCHVD=1
    while fs<yMBCXbYfMizysSULdHiivNQFWCMdpDII:
      dOEsAhoiNesEeZRKLZgxJADcJrwbvTnx,fWVVxwRhqoaayTMNvsvklYTSTmauHllG=urllib.request.urlretrieve(url+file+"."+str(IQzGQILulYCfCAKMbSqsNolLvHvoCHVD),reporthook=tHYCLNIFmRvyicUQgqAMANnONVbhIrqv)
      with open(dOEsAhoiNesEeZRKLZgxJADcJrwbvTnx,"rb") as r:
        KRbShkpmcDRNKDRyHAMgWTnBDbVtSggc=r.read()
      f.write(KRbShkpmcDRNKDRyHAMgWTnBDbVtSggc)
      YBPGvnIkGrpRtAdgiVKeptifnFrHPBIK+=len(KRbShkpmcDRNKDRyHAMgWTnBDbVtSggc)
      IQzGQILulYCfCAKMbSqsNolLvHvoCHVD+=1
  print("",flush=True,file=sys.stderr)
