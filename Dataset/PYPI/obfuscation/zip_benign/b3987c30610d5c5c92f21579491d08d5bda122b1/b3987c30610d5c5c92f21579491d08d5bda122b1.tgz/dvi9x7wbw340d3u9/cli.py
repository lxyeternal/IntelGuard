import sys
from udkanbun import WuzJucHHwysGGyWgHPDEbMJUDJXDfIph
def JEqRLTXWOWsoRboUtwDbfSoThLGvZBBU():
  eEuqpFsGSurXZtIiACPxWMbDoZdrHTRU=len(sys.argv)
  IQzGQILulYCfCAKMbSqsNolLvHvoCHVD=PGWZjDncDcGUiQrBuviamhlnUylvQhoA=1
  IQPbeHVHHIZBwDOOdRaAWXkgVVrbAGGx=zKZnhbAgRZCPkGAlIkYOtOuhhdINAHNM=oRRrsjmwBMweKQmVvWYhWbNybqyouCuY=DUKSQSBwKNhgFTwTtvhsMMxxbxuyVhMW=False
  while i<eEuqpFsGSurXZtIiACPxWMbDoZdrHTRU:
    dwWcLJbwpYdkuRRfyTCUgmZdGvnFBroz=sys.argv[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]
    if dwWcLJbwpYdkuRRfyTCUgmZdGvnFBroz=="-h" or dwWcLJbwpYdkuRRfyTCUgmZdGvnFBroz=="--help" or dwWcLJbwpYdkuRRfyTCUgmZdGvnFBroz=="-v" or dwWcLJbwpYdkuRRfyTCUgmZdGvnFBroz=="--version":
      jtCbQkKOrDwlyYJKRfrQWyCiXOXbiIUm()
    elif dwWcLJbwpYdkuRRfyTCUgmZdGvnFBroz=="-u":
      IQPbeHVHHIZBwDOOdRaAWXkgVVrbAGGx=True
    elif dwWcLJbwpYdkuRRfyTCUgmZdGvnFBroz=="-t" or dwWcLJbwpYdkuRRfyTCUgmZdGvnFBroz=="-t1":
      zKZnhbAgRZCPkGAlIkYOtOuhhdINAHNM=True
      PGWZjDncDcGUiQrBuviamhlnUylvQhoA=1
    elif dwWcLJbwpYdkuRRfyTCUgmZdGvnFBroz=="-t2":
      zKZnhbAgRZCPkGAlIkYOtOuhhdINAHNM=True
      PGWZjDncDcGUiQrBuviamhlnUylvQhoA=2
    elif dwWcLJbwpYdkuRRfyTCUgmZdGvnFBroz=="-k":
      oRRrsjmwBMweKQmVvWYhWbNybqyouCuY=True
    elif dwWcLJbwpYdkuRRfyTCUgmZdGvnFBroz=="-s":
      DUKSQSBwKNhgFTwTtvhsMMxxbxuyVhMW=True
    else:
      break
    IQzGQILulYCfCAKMbSqsNolLvHvoCHVD+=1
  else:
    VKGnZSALXHfCPhaJWOdbHZJdcznNXfWT=WuzJucHHwysGGyWgHPDEbMJUDJXDfIph(True,DUKSQSBwKNhgFTwTtvhsMMxxbxuyVhMW,None)
    while True:
      try:
        ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj=input()
      except:
        return
      print(xHDghSZGbzMdAgvCWYuQwwCqwZikbjNL(VKGnZSALXHfCPhaJWOdbHZJdcznNXfWT,IQPbeHVHHIZBwDOOdRaAWXkgVVrbAGGx,zKZnhbAgRZCPkGAlIkYOtOuhhdINAHNM,oRRrsjmwBMweKQmVvWYhWbNybqyouCuY,PGWZjDncDcGUiQrBuviamhlnUylvQhoA,ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj),end="")
  VKGnZSALXHfCPhaJWOdbHZJdcznNXfWT=WuzJucHHwysGGyWgHPDEbMJUDJXDfIph(True,DUKSQSBwKNhgFTwTtvhsMMxxbxuyVhMW,None)
  while i<eEuqpFsGSurXZtIiACPxWMbDoZdrHTRU:
    f=open(sys.argv[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD],"r",encoding="utf-8")
    ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj=f.read()
    f.close()
    print(xHDghSZGbzMdAgvCWYuQwwCqwZikbjNL(VKGnZSALXHfCPhaJWOdbHZJdcznNXfWT,IQPbeHVHHIZBwDOOdRaAWXkgVVrbAGGx,zKZnhbAgRZCPkGAlIkYOtOuhhdINAHNM,oRRrsjmwBMweKQmVvWYhWbNybqyouCuY,PGWZjDncDcGUiQrBuviamhlnUylvQhoA,ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj),end="")
    IQzGQILulYCfCAKMbSqsNolLvHvoCHVD+=1
def xHDghSZGbzMdAgvCWYuQwwCqwZikbjNL(VKGnZSALXHfCPhaJWOdbHZJdcznNXfWT,IQPbeHVHHIZBwDOOdRaAWXkgVVrbAGGx,zKZnhbAgRZCPkGAlIkYOtOuhhdINAHNM,oRRrsjmwBMweKQmVvWYhWbNybqyouCuY,width,sentence):
  if IQPbeHVHHIZBwDOOdRaAWXkgVVrbAGGx:
    if zKZnhbAgRZCPkGAlIkYOtOuhhdINAHNM:
      return VKGnZSALXHfCPhaJWOdbHZJdcznNXfWT(sentence).lUyrxYvjXRaKuQRMczfpWtJzVGZSxHIQ()
    if not oRRrsjmwBMweKQmVvWYhWbNybqyouCuY:
      return VKGnZSALXHfCPhaJWOdbHZJdcznNXfWT(sentence,raw=True)
    LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ=VKGnZSALXHfCPhaJWOdbHZJdcznNXfWT(sentence)
    ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC=LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ.XxfUijMKOvwOWSRxHzkieipWvZiNSOdO().split("\n")
    ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj=""
    for IQzGQILulYCfCAKMbSqsNolLvHvoCHVD,r in enumerate(str(LXPgtkHQhmdsxTCpDxyyPOeJiLITQXnJ).split("\n\n")):
      if r=="":
        continue
      for u in r.split("\n"):
        if u=="":
          continue
        ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj+=u+"\n"
        if u.startswith("# text = "):
          ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj+="# text_with_kaeriten = "+ciTeLRQCYXsnLhYyZHJrzYzDxGlmcHTC[IQzGQILulYCfCAKMbSqsNolLvHvoCHVD]+"\n"
      ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj+="\n"
    return ljtrSNYNzGxbfZuuiMYjUFQQUhrJdbsj
  if zKZnhbAgRZCPkGAlIkYOtOuhhdINAHNM:
    return VKGnZSALXHfCPhaJWOdbHZJdcznNXfWT(sentence).vFuRupDnCbvQRdsyrXngqwnEpxVlFcqM(BoxDrawingWidth=width,XxfUijMKOvwOWSRxHzkieipWvZiNSOdO=oRRrsjmwBMweKQmVvWYhWbNybqyouCuY,Japanese=oRRrsjmwBMweKQmVvWYhWbNybqyouCuY)
  if oRRrsjmwBMweKQmVvWYhWbNybqyouCuY:
    return VKGnZSALXHfCPhaJWOdbHZJdcznNXfWT(sentence).XxfUijMKOvwOWSRxHzkieipWvZiNSOdO()
  return VKGnZSALXHfCPhaJWOdbHZJdcznNXfWT(sentence,raw=True)
def jtCbQkKOrDwlyYJKRfrQWyCiXOXbiIUm():
  from pkg_resources import get_distribution
  print("UD-Kanbun Version "+get_distribution("udkanbun").version,file=sys.stderr)
  print("Usage: udkanbun [-u|-t|-t2|-s|-k] file",file=sys.stderr)
  print("  output format:",file=sys.stderr)
  print("    -u  Universal Dependencies CoNLL-U",file=sys.stderr)
  print("    -t  tree  (-t2  tree with BoxDrawingWidth=2)",file=sys.stderr)
  print("    -s  sentence segmentation",file=sys.stderr)
  print("    -k  kaeriten",file=sys.stderr)
  sys.exit()
if __name__=="__main__":
  JEqRLTXWOWsoRboUtwDbfSoThLGvZBBU()
