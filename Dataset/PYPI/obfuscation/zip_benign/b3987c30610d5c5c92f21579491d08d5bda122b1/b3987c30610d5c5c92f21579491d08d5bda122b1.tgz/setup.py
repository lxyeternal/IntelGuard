import setuptools
import subprocess
import platform
with open('README.md', 'r', encoding='utf-8') as r:
    LSUikTaRlmJlBTYRzRTTRRmSplPIAeXl = r.read()
aFQUbKPNYbZaMsxfpJxjOFWNLmBTMPJT = 'https://github.com/KoichiYasuoka/UD-Kanbun'
bXeZIzodJkYKEFPxVdFInevKjjrdxQez = platform.platform()
if bXeZIzodJkYKEFPxVdFInevKjjrdxQez.startswith('CYGWIN'):
    TyJhfklsTfMMMmZcrxQPauRFMhvHGBny = ['ufal.udpipe>=1.2.0.3', 'mecab-cygwin>=0.5.0',
        'deplacy>=2.1.0']
else:
    import sys
    IDtGPMXlLgWlIWEdqLMEfQlJJtYCDkua = sys.version_info.major == 3 and sys.version_info.minor > 4
    try:
        XTmPPSwkHxmzUzqNtJtHPkCwGgQDFtqs = subprocess.check_output(['mecab-config', '--libs-only-L'])
    except:
        import os
        IDtGPMXlLgWlIWEdqLMEfQlJJtYCDkua &= os.name == 'nt'
    if IDtGPMXlLgWlIWEdqLMEfQlJJtYCDkua:
        TyJhfklsTfMMMmZcrxQPauRFMhvHGBny = ['ufal.udpipe>=1.2.0.3', 'fugashi>=1.3.3',
            'deplacy>=2.1.0']
    else:
        TyJhfklsTfMMMmZcrxQPauRFMhvHGBny = ['ufal.udpipe>=1.2.0.3',
            'mecab-python3>=0.996.5', 'deplacy>=2.1.0']
setuptools.setup(name='udkanbun', version='3.4.5', description=
    'Tokenizer POS-tagger and Dependency-parser for Classical Chinese',
    LSUikTaRlmJlBTYRzRTTRRmSplPIAeXl=LSUikTaRlmJlBTYRzRTTRRmSplPIAeXl, long_description_content_type=
    'text/markdown', url=aFQUbKPNYbZaMsxfpJxjOFWNLmBTMPJT, author='Koichi Yasuoka', author_email=
    'yasuoka@kanji.zinbun.kyoto-u.ac.jp', license='MIT', keywords=
    'udpipe mecab nlp', packages=setuptools.find_packages(),
    TyJhfklsTfMMMmZcrxQPauRFMhvHGBny=TyJhfklsTfMMMmZcrxQPauRFMhvHGBny, python_requires='>=3.6',
    ZrSxGkuQMnEMdwdFcdwTOiBvAxTXmOQD={'udkanbun': ['mecabrc', 'ud-kanbun.udpipe',
    'mecab-kanbun/*', 'supar-kanbun/*.txt']}, entry_points={
    'console_scripts': ['udkanbun=udkanbun.cli:main']}, classifiers=[
    'License :: OSI Approved :: MIT License',
    'Programming Language :: Python :: 3',
    'Operating System :: OS Independent',
    'Topic :: Text Processing :: Linguistic'], project_urls={'ud-kanbun':
    'https://corpus.kanji.zinbun.kyoto-u.ac.jp/gitlab/Kanbun/ud-kanbun',
    'Source': aFQUbKPNYbZaMsxfpJxjOFWNLmBTMPJT, 'Tracker': aFQUbKPNYbZaMsxfpJxjOFWNLmBTMPJT + '/issues'})
