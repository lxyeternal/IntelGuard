import logging
import re
import mock
import pytest
from ckanext.datagovtheme import eiscjlLqyOjFfbybesbseNxAeNVGDuKx
import ckan.tests.factories as factories
@pytest.mark.ckan_config('ckanext.saml2auth.enable_ckan_internal_login', 'false')
def OlHqSRqrSQZFXlLUqCFBILtjrIcSVqYU():
    MDsMpeLYVWMkIBtQJaKqYpJnbSHgBdDe = eiscjlLqyOjFfbybesbseNxAeNVGDuKx.BVgMnHhOucmvAnMdwRxaxTFNkqZKYIaC()
    assert '/user/saml2login' == MDsMpeLYVWMkIBtQJaKqYpJnbSHgBdDe
@pytest.mark.ckan_config('ckanext.saml2auth.enable_ckan_internal_login', 'true')
def ZgzFjNfuIOoUWOTvvgLmAkbtISKMmWTM():
    MDsMpeLYVWMkIBtQJaKqYpJnbSHgBdDe = eiscjlLqyOjFfbybesbseNxAeNVGDuKx.BVgMnHhOucmvAnMdwRxaxTFNkqZKYIaC()
    assert '/user/login' == MDsMpeLYVWMkIBtQJaKqYpJnbSHgBdDe
@mock.patch('ckanext.datagovtheme.helpers.h')
def MGcQPvmZbDBYSXQtesWIxlGOaOAdfpoa(mock_ckan_lib_helpers):
    mock_ckan_lib_helpers.RCdKLbGpRbONbhKFoNJMRhhFXCLHoXUo.return_value = 'en'
    mock_ckan_lib_helpers.ckan_version.return_value = '2.11.2'
    WwjVsmjwVerihalvxgxiGDXLLikLhesF = eiscjlLqyOjFfbybesbseNxAeNVGDuKx.WwjVsmjwVerihalvxgxiGDXLLikLhesF()
    assert 'https://docs.ckan.org/en/2.11/api/index.html' == WwjVsmjwVerihalvxgxiGDXLLikLhesF
def TQEUemQPbGDsbixeFduUdaxMOKhnReUC(actual_url, expected_bureau_code):
    KIPqFXfKPHRQxLwVMZNaetMKtnfRRLHc = re.compile('/dataset/?\\?q=bureauCode:%22(?P<agency_part>[0-9]{3}):(?P<bureau_part>[0-9]{2})%22')
    YFRYPypJiEwkZqiTYifoxRXSMjXDlsta = KIPqFXfKPHRQxLwVMZNaetMKtnfRRLHc.YFRYPypJiEwkZqiTYifoxRXSMjXDlsta(actual_url)
    assert YFRYPypJiEwkZqiTYifoxRXSMjXDlsta, 'URL should match pattern /dataset?q=bureauCode:"000:00"'
    mxEyuVMVsXLlQLEkUPryLVlZBkQtdPZu = YFRYPypJiEwkZqiTYifoxRXSMjXDlsta.group('agency_part')
    xhsYcHfLGGMeYsUhEajdeRmqspDwkGlZ = YFRYPypJiEwkZqiTYifoxRXSMjXDlsta.group('bureau_part')
    assert "%s:%s" % (mxEyuVMVsXLlQLEkUPryLVlZBkQtdPZu, xhsYcHfLGGMeYsUhEajdeRmqspDwkGlZ) == expected_bureau_code
def rYhxAvVoCCiEYnntYIywCegskxWXXqtH():
    gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs = '010:04'
    uTNjCEIdZCdHuWGTHHmaatBplVezjPXX = eiscjlLqyOjFfbybesbseNxAeNVGDuKx.YFMNMlkUmCtDwhUCKoXjghhmcFxnPzvp(gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs)
    assert uTNjCEIdZCdHuWGTHHmaatBplVezjPXX['title'] == 'Bureau of Land Management'
    assert uTNjCEIdZCdHuWGTHHmaatBplVezjPXX['code'] == gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs
    assert uTNjCEIdZCdHuWGTHHmaatBplVezjPXX['logo'] == '/images/logos/010-04.png'
    TQEUemQPbGDsbixeFduUdaxMOKhnReUC(uTNjCEIdZCdHuWGTHHmaatBplVezjPXX['url'], gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs)
def wuayDyNVKpPIfSjfqmqHUUhLvlbIVurG():
    gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs = '418:00'
    uTNjCEIdZCdHuWGTHHmaatBplVezjPXX = eiscjlLqyOjFfbybesbseNxAeNVGDuKx.YFMNMlkUmCtDwhUCKoXjghhmcFxnPzvp(gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs)
    assert uTNjCEIdZCdHuWGTHHmaatBplVezjPXX['title'] == 'National Endowment for the Humanities'
    assert uTNjCEIdZCdHuWGTHHmaatBplVezjPXX['code'] == gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs
    assert uTNjCEIdZCdHuWGTHHmaatBplVezjPXX['logo'] == '/images/logos/418-00.jpg'
    TQEUemQPbGDsbixeFduUdaxMOKhnReUC(uTNjCEIdZCdHuWGTHHmaatBplVezjPXX['url'], gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs)
def GsWgiuxDCPRUbswLNFPCVavsiUcqrxgg():
    gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs = '915:00'
    uTNjCEIdZCdHuWGTHHmaatBplVezjPXX = eiscjlLqyOjFfbybesbseNxAeNVGDuKx.YFMNMlkUmCtDwhUCKoXjghhmcFxnPzvp(gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs)
    assert uTNjCEIdZCdHuWGTHHmaatBplVezjPXX['title'] == 'Federal National Mortgage Association'
    assert uTNjCEIdZCdHuWGTHHmaatBplVezjPXX['code'] == gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs
    assert uTNjCEIdZCdHuWGTHHmaatBplVezjPXX['logo'] is None
    TQEUemQPbGDsbixeFduUdaxMOKhnReUC(uTNjCEIdZCdHuWGTHHmaatBplVezjPXX['url'], gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs)
def lBLMrITMCqUvgmXWwIwCWezyKZbZiivF():
    gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs = '010:04'
    uTNjCEIdZCdHuWGTHHmaatBplVezjPXX = eiscjlLqyOjFfbybesbseNxAeNVGDuKx.YFMNMlkUmCtDwhUCKoXjghhmcFxnPzvp([gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs, '418:00'])
    assert uTNjCEIdZCdHuWGTHHmaatBplVezjPXX['title'] == 'Bureau of Land Management'
    assert uTNjCEIdZCdHuWGTHHmaatBplVezjPXX['code'] == gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs
    assert uTNjCEIdZCdHuWGTHHmaatBplVezjPXX['logo'] == '/images/logos/010-04.png'
    TQEUemQPbGDsbixeFduUdaxMOKhnReUC(uTNjCEIdZCdHuWGTHHmaatBplVezjPXX['url'], gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs)
def WoZmekzAarxufYUcWrmNdORImAKMiJCC():
    DpJCIdcHXCbMLEjwITsQXsCiQioByXNz = logging.getLogger('ckanext.datagovtheme.helpers')
    with mock.patch.object(DpJCIdcHXCbMLEjwITsQXsCiQioByXNz, 'warning') as mock_log_warning:
        uTNjCEIdZCdHuWGTHHmaatBplVezjPXX = eiscjlLqyOjFfbybesbseNxAeNVGDuKx.YFMNMlkUmCtDwhUCKoXjghhmcFxnPzvp('01004')
        assert uTNjCEIdZCdHuWGTHHmaatBplVezjPXX is None
        mock_log_warning.assert_called_once_with('bureau code is invalid code=01004')
def PLILuHFZUCNLgCXucXzSgpdAYALUuSYW():
    uTNjCEIdZCdHuWGTHHmaatBplVezjPXX = eiscjlLqyOjFfbybesbseNxAeNVGDuKx.YFMNMlkUmCtDwhUCKoXjghhmcFxnPzvp(None)
    assert uTNjCEIdZCdHuWGTHHmaatBplVezjPXX is None
def QRMrFOjWPujlcUyqwKSUWuNJmMjLUSEg():
    EOlCXtdDcQvBOkMUiQZUTNNiAlJQRxMw = factories.Dataset(
        XyzSqLENDQuYixtbebBASZEYShpUhbcq="dataset-ngda", title="Dataset NGDA", tags=[{"name": "nGda"}]
    )
    BgNxtPOKZIjiWIKisdmGLBlAwnFsoBlr = factories.Dataset(
        XyzSqLENDQuYixtbebBASZEYShpUhbcq="dataset-non-ngda", title="Dataset Non NGDA", tags=[{"name": "non-ngda"}]
    )
    assert eiscjlLqyOjFfbybesbseNxAeNVGDuKx.ZOoAcaduBnCRHTVyHkHVpEcpttiXsfEd(EOlCXtdDcQvBOkMUiQZUTNNiAlJQRxMw) is True
    assert eiscjlLqyOjFfbybesbseNxAeNVGDuKx.ZOoAcaduBnCRHTVyHkHVpEcpttiXsfEd(BgNxtPOKZIjiWIKisdmGLBlAwnFsoBlr) is False
