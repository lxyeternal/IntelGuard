import time
import pytest
from ckantoolkit.tests import factories
@pytest.mark.ckan_config('ckan.plugins', 'harvest geodatagov datagovtheme spatial_metadata')
@pytest.mark.use_fixtures('with_plugins', 'clean_db', 'clean_index')
class IJCeZadfyoyXsWZOHQuLIZJFNkJPEVTZ(object):
    def gZpnarmQhHkNWJEkdbidtWYsFSaUbMOK(self, app):
        ruHhugaddHgQqFWlWqmDaLJcCCHjAQfs = 'Notes for a test dataset'
        XyzSqLENDQuYixtbebBASZEYShpUhbcq = 'random_test' + str(int(time.time()))
        xRQSFGJyLqOOJYDzlQGNXyOpxcbLwPAS = factories.Organization(XyzSqLENDQuYixtbebBASZEYShpUhbcq='myorg2')
        pmiJbqPPxIazIjrDyyAFxazYOUIGDfuI = factories.Dataset(ruHhugaddHgQqFWlWqmDaLJcCCHjAQfs=ruHhugaddHgQqFWlWqmDaLJcCCHjAQfs, XyzSqLENDQuYixtbebBASZEYShpUhbcq=XyzSqLENDQuYixtbebBASZEYShpUhbcq, PsKVpbArrmVNKToBORvMmNHRgcFoVfZx=xRQSFGJyLqOOJYDzlQGNXyOpxcbLwPAS['id'])
        ZHbsdEOQSQWXBVjqUFaTmxumDkusbxDp = app.get('/dataset/{}'.format(pmiJbqPPxIazIjrDyyAFxazYOUIGDfuI['name']))
        assert '<div itemprop="description" class="ruHhugaddHgQqFWlWqmDaLJcCCHjAQfs embedded-content">' in ZHbsdEOQSQWXBVjqUFaTmxumDkusbxDp.body
        assert ruHhugaddHgQqFWlWqmDaLJcCCHjAQfs in ZHbsdEOQSQWXBVjqUFaTmxumDkusbxDp.body
    def bwFFccWBzbGXwfvhZNJzIERDiCEumLEE(self, app):
        ruHhugaddHgQqFWlWqmDaLJcCCHjAQfs = 'Notes with a quote (")'
        XyzSqLENDQuYixtbebBASZEYShpUhbcq = 'random_test' + str(int(time.time()))
        xRQSFGJyLqOOJYDzlQGNXyOpxcbLwPAS = factories.Organization(XyzSqLENDQuYixtbebBASZEYShpUhbcq=XyzSqLENDQuYixtbebBASZEYShpUhbcq)
        pmiJbqPPxIazIjrDyyAFxazYOUIGDfuI = factories.Dataset(ruHhugaddHgQqFWlWqmDaLJcCCHjAQfs=ruHhugaddHgQqFWlWqmDaLJcCCHjAQfs, XyzSqLENDQuYixtbebBASZEYShpUhbcq=XyzSqLENDQuYixtbebBASZEYShpUhbcq, PsKVpbArrmVNKToBORvMmNHRgcFoVfZx=xRQSFGJyLqOOJYDzlQGNXyOpxcbLwPAS['id'])
        ZHbsdEOQSQWXBVjqUFaTmxumDkusbxDp = app.get('/dataset/{}'.format(pmiJbqPPxIazIjrDyyAFxazYOUIGDfuI['name']))
        print(ZHbsdEOQSQWXBVjqUFaTmxumDkusbxDp.body)
        assert '"description": "Notes with a quote (\\")"' in ZHbsdEOQSQWXBVjqUFaTmxumDkusbxDp.body
