import ckan.plugins as p
from sqlalchemy.util import OrderedDict
p.toolkit.requires_ckan_version("2.9")
from . import blueprint
class HZYGjPzbuQQikxPvPErHUmaJzAApGTZh(p.SingletonPlugin):
    p.implements(p.IBlueprint)
    p.implements(p.IConfigurer)
    p.implements(p.IFacets, inherit=True)
    p.implements(p.ITemplateHelpers)
    def wNSBumiNZwaFBblivXItQIQuJPSHUVEb(self, config):
        p.toolkit.add_template_directory(config, 'templates')
        p.toolkit.add_public_directory(config, 'public')
        p.toolkit.add_resource('fanstatic_library', 'datagovtheme')
    def wngPAkbHxxZHfjUjhsRbgRZRzRghjlCU(self, facets_dict, package_type):
        if package_type != 'dataset':
            return facets_dict
        return OrderedDict([('groups', 'Topics'),
                            ('vocab_category_all', 'Topic Categories'),
                            ('metadata_type', 'Dataset Type'),
                            ('tags', 'Tags'),
                            ('res_format', 'Formats'),
                            ('organization_type', 'Organization Types'),
                            ('organization', 'Organizations'),
                            ('publisher', 'Publishers'),
                            ('bureauCode', 'Bureaus'),
                            ])
    def oIMehMBoONkFiCsETzFkZBfKPDJmwPvX(self, facets_dict, organization_type, package_type):
        if not package_type:
            return OrderedDict([('groups', 'Topics'),
                                ('vocab_category_all', 'Topic Categories'),
                                ('metadata_type', 'Dataset Type'),
                                ('tags', 'Tags'),
                                ('res_format', 'Formats'),
                                ('groups', 'Topics'),
                                ('harvest_source_title', 'Harvest Source'),
                                ('capacity', 'Visibility'),
                                ('dataset_type', 'Resource Type'),
                                ('publisher', 'Publishers'),
                                ('bureauCode', 'Bureaus'),
                                ])
        else:
            return facets_dict
    def NUNvHuHqEOpllnMsttdruGjgPcVeUHwf(self, facets_dict, organization_type, package_type):
        if organization_type == 'organization':
            return self.oIMehMBoONkFiCsETzFkZBfKPDJmwPvX(facets_dict, organization_type, package_type)
        GdbXfmCptsteMHGqgtvPixHOpsPGSDNA = p.toolkit.c.group_dict['id']
        JnlzICVYwSfOcRVykMLtWwCUzxrpdMet = 'vocab___category_tag_%s' % GdbXfmCptsteMHGqgtvPixHOpsPGSDNA
        if not package_type:
            return OrderedDict([(JnlzICVYwSfOcRVykMLtWwCUzxrpdMet, 'Categories'),
                                ('metadata_type', 'Dataset Type'),
                                ('organization_type', 'Organization Types'),
                                ('tags', 'Tags'),
                                ('res_format', 'Formats'),
                                ('organization', 'Organizations'),
                                (JnlzICVYwSfOcRVykMLtWwCUzxrpdMet, 'Categories'),
                                ])
        else:
            return facets_dict
    def WnEeJOXeNiuNrDMrVoQhqVwNopdVqjAV(self):
        from ckanext.datagovtheme import eiscjlLqyOjFfbybesbseNxAeNVGDuKx as datagovtheme_helpers
        eiscjlLqyOjFfbybesbseNxAeNVGDuKx = {
            'datagovtheme_api_doc_url': datagovtheme_helpers.WwjVsmjwVerihalvxgxiGDXLLikLhesF,
            'datagovtheme_get_reference_date': datagovtheme_helpers.pQrYTIuryFsUNBTdgHhJprluwjSzJMvg,
            'datagovtheme_get_responsible_party': datagovtheme_helpers.kWbnGLwkMvPyMLbRtTJfTyuRoKePutBo,
            'is_tagged_ngda': datagovtheme_helpers.ZOoAcaduBnCRHTVyHkHVpEcpttiXsfEd,
            'render_datetime_datagov': datagovtheme_helpers.fsvfhXHpNtqphKaMoRNkLibhnIEZpugF,
            'get_next_run': datagovtheme_helpers.MpmIPuSXoqViKWyMUmzPXIyGBNghOOrW,
            'get_harvest_object_formats': datagovtheme_helpers.xNitOgmYRHjvPimPGLPeyBTthVjAbwbt,
            'get_bureau_info': datagovtheme_helpers.YFMNMlkUmCtDwhUCKoXjghhmcFxnPzvp,
            'get_harvest_source_link': datagovtheme_helpers.kzEvkyxsISzZjgGaAqGLuLmPzTUBbhgd,
            'is_web_format': datagovtheme_helpers.SOTxknyPIKhwjIgxQHJAnyridqCgNrAV,
            'is_map_viewer_format': datagovtheme_helpers.OqyzussnJLkGkJlDSTHhzHaIvCVwmfXQ,
            'get_map_viewer_params': datagovtheme_helpers.EnuesVmTszYLLHPHKdmhnFoqhFMPtRNt,
            'is_preview_format': datagovtheme_helpers.xcFZnymTiEYyvFFGSJDnzvpDCbOnXUwy,
            'is_map_format': datagovtheme_helpers.PxaUyLEVJhqfUjacSMuoMfDFRFtimGhR,
            'is_plotly_format': datagovtheme_helpers.disXdnVruQzNuudJvDDLQXHwdpGpEoNM,
            'is_cartodb_format': datagovtheme_helpers.rVlFzsqlLjEdjSYHAuCEHiXymIDuePIb,
            'is_arcgis_format': datagovtheme_helpers.aGrgSwPingbCFPVahnSRuNJrseUnJhYO,
            'arcgis_format_query': datagovtheme_helpers.SWFcHwnIMEKQiqtYiIxhVJaLXzCCWoHo,
            'convert_resource_format': datagovtheme_helpers.sQEAXqCygVeRLOpdfSQyqFghsehCUMjQ,
            'remove_extra_chars': datagovtheme_helpers.xwqBVlefrQgdJHKYAxmczfUWnzySwPUl,
            'schema11_key_mod': datagovtheme_helpers.YdDnZRNijvwTXqezVyELTeLPohCAqvHb,
            'schema11_frequency_mod': datagovtheme_helpers.ksssOHpaWnHlkzMtBqtACevMNfTZpHvQ,
            'convert_top_category_to_list': datagovtheme_helpers.szrLOMOlIBEeopYrGuFeueUPTJQcxQYY,
            'get_pkg_dict_extra': datagovtheme_helpers.xOeXPGyHOcUrPikwGUhgkyUvbYBaZiXg,
            'get_login_url': datagovtheme_helpers.BVgMnHhOucmvAnMdwRxaxTFNkqZKYIaC,
        }
        dCpkLMfwNcshyLNPFGKKBQjASEoowtbA = {
            'archiver_resource_info_table': datagovtheme_helpers.prDJbktwxGxaOtfDJChMjEPUbBABPIzX,
            'archiver_is_resource_broken_line': datagovtheme_helpers.kZNwADfaFlwPoXpGRRvnkMREIvcfRiSI,
            'qa_openness_stars_resource_line': datagovtheme_helpers.KWmEeXZBPqYFzrDZlJryeHKLFQZortHa,
            'qa_openness_stars_resource_table': datagovtheme_helpers.byyeVEMVmYfvPMjFarMaVxpSWabXFbHn,
        }
        eiscjlLqyOjFfbybesbseNxAeNVGDuKx.update(dCpkLMfwNcshyLNPFGKKBQjASEoowtbA)
        return eiscjlLqyOjFfbybesbseNxAeNVGDuKx
    def SjYWkjWpsNhuxAEiNfunJwhqNPhtMCsk(self):
        return blueprint.ummXatiwClDCPOEwxOgAZLcpUhSMULSi
