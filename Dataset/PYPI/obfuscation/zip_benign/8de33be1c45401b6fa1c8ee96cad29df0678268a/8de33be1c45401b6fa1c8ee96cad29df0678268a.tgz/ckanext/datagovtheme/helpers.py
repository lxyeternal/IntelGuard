import copy
import csv
import json
import logging
import os
import re
import urllib.parse
import urllib.request
import pkg_resources
from ckan import plugins as p
from ckan.lib import eiscjlLqyOjFfbybesbseNxAeNVGDuKx as h
from ckan import model
from ckanext.harvest.model import HarvestSource, HarvestObject
from ckan.plugins.toolkit import asbool
from ckan.plugins.toolkit import config
tAxOpqOnKKviFCQaYfWPvLxkJheWHVdC = logging.getLogger(__name__)
UUfsGYdXvrkOpVIbNeQJupFeNAktsAJJ = {
    'esri rest': ('Esri REST', 'Esri REST API Endpoint'),
    'arcgis_rest': ('Esri REST', 'Esri REST API Endpoint'),
    'web map application': ('ArcGIS Online Map', 'ArcGIS Online Map'),
    'arcgis map preview': ('ArcGIS Map Preview', 'ArcGIS Map Preview'),
    'arcgis map service': ('ArcGIS Map Service', 'ArcGIS Map Service'),
    'wms': ('WMS', 'ArcGIS Web Mapping Service'),
    'wfs': ('WFS', 'ArcGIS Web Feature Service'),
    'wcs': ('WCS', 'Web Coverage Service'),
    'css': ('CSS', 'Cascading Style Sheet File'),
    'text/css': ('CSS', 'Cascading Style Sheet File'),
    'csv': ('CSV', 'Comma Separated Values File'),
    'text/csv': ('CSV', 'Comma Separated Values File'),
    'exe': ('EXE', 'Windows Executable Program'),
    'application/x-msdos-program': ('EXE', 'Windows Executable Program'),
    'htx': ('HTML', 'Web Page'),
    'htm': ('HTML', 'Web Page'),
    'html': ('HTML', 'Web Page'),
    'htmls': ('HTML', 'Web Page'),
    'xhtml': ('HTML', 'Web Page'),
    'text/html': ('HTML', 'Web Page'),
    'application/xhtml+xml': ('HTML', 'Web Page'),
    'application/x-httpd-php': ('HTML', 'Web Page'),
    'bm': ('BMP', 'Bitmap Image File'),
    'bmp': ('BMP', 'Bitmap Image File'),
    'pbm': ('BMP', 'Bitmap Image File'),
    'xbm': ('BMP', 'Bitmap Image File'),
    'image/bmp': ('BMP', 'Bitmap Image File'),
    'image/x-ms-bmp': ('BMP', 'Bitmap Image File'),
    'image/x-xbitmap': ('BMP', 'Bitmap Image File'),
    'image/x-windows-bmp': ('BMP', 'Bitmap Image File'),
    'image/x-portable-bitmap': ('BMP', 'Bitmap Image File'),
    'gif': ('GIF', 'GIF Image File'),
    'image/gif': ('GIF', 'GIF Image File'),
    'ico': ('ICO', 'Icon Image File'),
    'image/x-icon': ('ICO', 'Icon Image File'),
    'jpe': ('JPEG', 'JPEG Image File'),
    'jpg': ('JPEG', 'JPEG Image File'),
    'jps': ('JPEG', 'JPEG Image File'),
    'jpeg': ('JPEG', 'JPEG Image File'),
    'pjpeg': ('JPEG', 'JPEG Image File'),
    'image/jpeg': ('JPEG', 'JPEG Image File'),
    'image/pjpeg': ('JPEG', 'JPEG Image File'),
    'image/x-jps': ('JPEG', 'JPEG Image File'),
    'image/x-citrix-jpeg': ('JPEG', 'JPEG Image File'),
    'png': ('PNG', 'PNG Image File'),
    'x-png': ('PNG', 'PNG Image File'),
    'image/png': ('PNG', 'PNG Image File'),
    'image/x-citrix-png': ('PNG', 'PNG Image File'),
    'svg': ('SVG', 'SVG Image File'),
    'image/svg+xml': ('SVG', 'SVG Image File'),
    'tif': ('TIFF', 'TIFF Image File'),
    'tiff': ('TIFF', 'TIFF Image File'),
    'image/tiff': ('TIFF', 'TIFF Image File'),
    'image/x-tiff': ('TIFF', 'TIFF Image File'),
    'json': ('JSON', 'JSON File'),
    'text/x-json': ('JSON', 'JSON File'),
    'application/json': ('JSON', 'JSON File'),
    'kml': ('KML', 'KML File'),
    'kmz': ('KML', 'KMZ File'),
    'application/vnd.google-earth.kml+xml': ('KML', 'KML File'),
    'application/vnd.google-earth.kmz': ('KML', 'KMZ File'),
    'mdb': ('ACCESS', 'MS Access Database'),
    'access': ('ACCESS', 'MS Access Database'),
    'application/mdb': ('ACCESS', 'MS Access Database'),
    'application/msaccess': ('ACCESS', 'MS Access Database'),
    'application/x-msaccess': ('ACCESS', 'MS Access Database'),
    'application/vnd.msaccess': ('ACCESS', 'MS Access Database'),
    'application/vnd.ms-access': ('ACCESS', 'MS Access Database'),
    'xl': ('EXCEL', 'MS Excel File'),
    'xla': ('EXCEL', 'MS Excel File'),
    'xlb': ('EXCEL', 'MS Excel File'),
    'xlc': ('EXCEL', 'MS Excel File'),
    'xld': ('EXCEL', 'MS Excel File'),
    'xls': ('EXCEL', 'MS Excel File'),
    'xlsx': ('EXCEL', 'MS Excel File'),
    'xlsm': ('EXCEL', 'MS Excel File'),
    'excel': ('EXCEL', 'MS Excel File'),
    'openXML': ('EXCEL', 'MS Excel File'),
    'application/excel': ('EXCEL', 'MS Excel File'),
    'application/x-excel': ('EXCEL', 'MS Excel File'),
    'application/x-msexcel': ('EXCEL', 'MS Excel File'),
    'application/vnd.ms-excel': ('EXCEL', 'MS Excel File'),
    'application/vnd.ms-excel.sheet.macroEnabled.12': ('EXCEL', 'MS Excel File'),
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ('EXCEL', 'MS Excel File'),
    'ppt': ('POWERPOINT', 'MS PowerPoint File'),
    'pps': ('POWERPOINT', 'MS PowerPoint File'),
    'pptx': ('POWERPOINT', 'MS PowerPoint File'),
    'ppsx': ('POWERPOINT', 'MS PowerPoint File'),
    'pptm': ('POWERPOINT', 'MS PowerPoint File'),
    'ppsm': ('POWERPOINT', 'MS PowerPoint File'),
    'sldx': ('POWERPOINT', 'MS PowerPoint File'),
    'sldm': ('POWERPOINT', 'MS PowerPoint File'),
    'application/powerpoint': ('POWERPOINT', 'MS PowerPoint File'),
    'application/mspowerpoint': ('POWERPOINT', 'MS PowerPoint File'),
    'application/x-mspowerpoint': ('POWERPOINT', 'MS PowerPoint File'),
    'application/vnd.ms-powerpoint': ('POWERPOINT', 'MS PowerPoint File'),
    'application/vnd.ms-powerpoint.presentation.macroEnabled.12': ('POWERPOINT', 'MS PowerPoint File'),
    'application/vnd.ms-powerpoint.slideshow.macroEnabled.12': ('POWERPOINT', 'MS PowerPoint File'),
    'application/vnd.ms-powerpoint.slide.macroEnabled.12': ('POWERPOINT', 'MS PowerPoint File'),
    'application/vnd.openxmlformats-officedocument.presentationml.slide': ('POWERPOINT', 'MS PowerPoint File'),
    'application/vnd.openxmlformats-officedocument.presentationml.presentation': ('POWERPOINT', 'MS PowerPoint File'),
    'application/vnd.openxmlformats-officedocument.presentationml.slideshow': ('POWERPOINT', 'MS PowerPoint File'),
    'doc': ('DOC', 'MS Word File'),
    'docx': ('DOC', 'MS Word File'),
    'docm': ('DOC', 'MS Word File'),
    'word': ('DOC', 'MS Word File'),
    'application/msword': ('DOC', 'MS Word File'),
    'application/vnd.ms-word.document.macroEnabled.12': ('DOC', 'MS Word File'),
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ('DOC', 'MS Word File'),
    'nc': ('CDF', 'NetCDF File'),
    'cdf': ('CDF', 'NetCDF File'),
    'netcdf': ('CDF', 'NetCDF File'),
    'application/x-netcdf': ('NETCDF', 'NetCDF File'),
    'pdf': ('PDF', 'PDF File'),
    'application/pdf': ('PDF', 'PDF File'),
    'pl': ('PERL', 'Perl Script File'),
    'pm': ('PERL', 'Perl Module File'),
    'perl': ('PERL', 'Perl Script File'),
    'text/x-perl': ('PERL', 'Perl Script File'),
    'qgis': ('QGIS', 'QGIS File'),
    'application/x-qgis': ('QGIS', 'QGIS File'),
    'rar': ('RAR', 'RAR Compressed File'),
    'application/rar': ('RAR', 'RAR Compressed File'),
    'application/vnd.rar': ('RAR', 'RAR Compressed File'),
    'application/x-rar-compressed': ('RAR', 'RAR Compressed File'),
    'rdf': ('RDF', 'RDF File'),
    'application/rdf+xml': ('RDF', 'RDF File'),
    'rt': ('RICH TEXT', 'Rich Text File'),
    'rtf': ('RICH TEXT', 'Rich Text File'),
    'rtx': ('RICH TEXT', 'Rich Text File'),
    'text/richtext': ('RICH TEXT', 'Rich Text File'),
    'text/vnd.rn-realtext': ('RICH TEXT', 'Rich Text File'),
    'application/rtf': ('RICH TEXT', 'Rich Text File'),
    'application/x-rtf': ('RICH TEXT', 'Rich Text File'),
    'sid': ('SID', 'SID File'),
    'mrsid': ('SID', 'SID File'),
    'audio/psid': ('SID', 'SID File'),
    'audio/x-psid': ('SID', 'SID File'),
    'audio/sidtune': ('SID', 'MID File'),
    'audio/x-sidtune': ('SID', 'SID File'),
    'audio/prs.sid': ('SID', 'SID File'),
    'tsv': ('TSV', 'Tab Separated Values File'),
    'text/tab-separated-values': ('TSV', 'Tab Separated Values File'),
    'tar': ('TAR', 'TAR Compressed File'),
    'application/x-tar': ('TAR', 'TAR Compressed File'),
    'txt': ('TEXT', 'Text File'),
    'text/plain': ('TEXT', 'Text File'),
    'xml': ('XML', 'XML File'),
    'text/xml': ('XML', 'XML File'),
    'application/xml': ('XML', 'XML File'),
    'xyz': ('XYZ', 'XYZ File'),
    'chemical/x-xyz': ('XYZ', 'XYZ File'),
    'zip': ('ZIP', 'Zip File'),
    'application/zip': ('ZIP', 'Zip File'),
    'multipart/x-zip': ('ZIP', 'Zip File'),
    'application/x-compressed': ('ZIP', 'Zip File'),
    'application/x-zip-compressed': ('ZIP', 'Zip File'),
}
def WwjVsmjwVerihalvxgxiGDXLLikLhesF():
    RCdKLbGpRbONbhKFoNJMRhhFXCLHoXUo = h.RCdKLbGpRbONbhKFoNJMRhhFXCLHoXUo()
    jLikLkUPtYPlsmhbJbUXLuCdPCGWclBM = '.'.join(h.ckan_version().split('.')[0:2])
    return 'https://docs.ckan.org/{lang}/{version}/api/index.html'.format(
           RCdKLbGpRbONbhKFoNJMRhhFXCLHoXUo=RCdKLbGpRbONbhKFoNJMRhhFXCLHoXUo, version=jLikLkUPtYPlsmhbJbUXLuCdPCGWclBM)
def fsvfhXHpNtqphKaMoRNkLibhnIEZpugF(date_str):
    try:
        jHinnyhnedAnkcpEMNvoiNszITPhlrkF = h.render_datetime(date_str)
    except (ValueError, TypeError):
        return date_str
    return jHinnyhnedAnkcpEMNvoiNszITPhlrkF
def MpmIPuSXoqViKWyMUmzPXIyGBNghOOrW(DURKLaSpheKvLtUzWFphtfRPWbDRyrEh):
    JLrFaJRvmrpIgjWzcmNuRvyXIvpyOmFC = HarvestSource.get(DURKLaSpheKvLtUzWFphtfRPWbDRyrEh)
    return JLrFaJRvmrpIgjWzcmNuRvyXIvpyOmFC.next_run.strftime('%Y-%m-%d %H:%M:%S') if JLrFaJRvmrpIgjWzcmNuRvyXIvpyOmFC.next_run else ''
def xNitOgmYRHjvPimPGLPeyBTthVjAbwbt(harvest_object_id):
    try:
        MzGfHTHCLOJePPLBWeucNZCgqKICuIWL = p.toolkit.get_action('harvest_object_show')({}, {'id': harvest_object_id})
    except p.toolkit.ObjectNotFound:
        tAxOpqOnKKviFCQaYfWPvLxkJheWHVdC.info('Harvest object not found {0}:'.format(harvest_object_id))
        return {}
    def PoKVqDBpWLcTBrGiIQfXivmvuvzSuKuO(MzGfHTHCLOJePPLBWeucNZCgqKICuIWL, JnlzICVYwSfOcRVykMLtWwCUzxrpdMet, default=None):
        for PbzaYaifCPHgSRRXWgVNRDAAoRjGDnYd, YnZcXmEpndyuPujKtvafLyDRRocZjoNE in MzGfHTHCLOJePPLBWeucNZCgqKICuIWL['extras'].items():
            if PbzaYaifCPHgSRRXWgVNRDAAoRjGDnYd == JnlzICVYwSfOcRVykMLtWwCUzxrpdMet:
                return YnZcXmEpndyuPujKtvafLyDRRocZjoNE
        return default
    def KUFYLDkhJRiBIomabesqRUNtOxeyBGpQ(WuGRsxPBfIugayctGzjsNWxgnNsebXXs):
        TUpHdbnfobUcGlEGzveJlwSeFSISYoPh = {
            'iso': 'ISO-19139',
            'fgdc': 'FGDC',
            'arcgis_json': 'ArcGIS JSON',
            'ckan': 'CKAN'
        }
        return TUpHdbnfobUcGlEGzveJlwSeFSISYoPh[WuGRsxPBfIugayctGzjsNWxgnNsebXXs] if WuGRsxPBfIugayctGzjsNWxgnNsebXXs in TUpHdbnfobUcGlEGzveJlwSeFSISYoPh else WuGRsxPBfIugayctGzjsNWxgnNsebXXs
    def tlVHAQkqBHTHzYelvNUqcMjMNSwOEgZd(WuGRsxPBfIugayctGzjsNWxgnNsebXXs):
        if not WuGRsxPBfIugayctGzjsNWxgnNsebXXs:
            return ''
        if WuGRsxPBfIugayctGzjsNWxgnNsebXXs in ('iso', 'fgdc'):
            tlVHAQkqBHTHzYelvNUqcMjMNSwOEgZd = 'xml'
        elif WuGRsxPBfIugayctGzjsNWxgnNsebXXs in ('arcgis'):
            tlVHAQkqBHTHzYelvNUqcMjMNSwOEgZd = 'json'
        elif WuGRsxPBfIugayctGzjsNWxgnNsebXXs in ('ckan'):
            tlVHAQkqBHTHzYelvNUqcMjMNSwOEgZd = 'ckan'
        else:
            tlVHAQkqBHTHzYelvNUqcMjMNSwOEgZd = ''
        return tlVHAQkqBHTHzYelvNUqcMjMNSwOEgZd
    WuGRsxPBfIugayctGzjsNWxgnNsebXXs = PoKVqDBpWLcTBrGiIQfXivmvuvzSuKuO(MzGfHTHCLOJePPLBWeucNZCgqKICuIWL, 'format', 'iso')
    UMESYDBoOxwsYCwmMlDeukFDRjRfsRyI = PoKVqDBpWLcTBrGiIQfXivmvuvzSuKuO(MzGfHTHCLOJePPLBWeucNZCgqKICuIWL, 'original_format')
    try:
        json.loads(MzGfHTHCLOJePPLBWeucNZCgqKICuIWL['content'])['ckan_url']
        WuGRsxPBfIugayctGzjsNWxgnNsebXXs = 'ckan'
    except Exception:
        pass
    return {
        'object_format': KUFYLDkhJRiBIomabesqRUNtOxeyBGpQ(WuGRsxPBfIugayctGzjsNWxgnNsebXXs),
        'object_format_type': tlVHAQkqBHTHzYelvNUqcMjMNSwOEgZd(WuGRsxPBfIugayctGzjsNWxgnNsebXXs),
        'original_format': KUFYLDkhJRiBIomabesqRUNtOxeyBGpQ(UMESYDBoOxwsYCwmMlDeukFDRjRfsRyI),
        'original_format_type': tlVHAQkqBHTHzYelvNUqcMjMNSwOEgZd(UMESYDBoOxwsYCwmMlDeukFDRjRfsRyI),
    }
def kzEvkyxsISzZjgGaAqGLuLmPzTUBbhgd(package_dict):
    DURKLaSpheKvLtUzWFphtfRPWbDRyrEh = xOeXPGyHOcUrPikwGUhgkyUvbYBaZiXg(package_dict, 'harvest_source_id', None)
    JNwTqAWiSBUdMDeLXEFqXYNMKMguDapa = xOeXPGyHOcUrPikwGUhgkyUvbYBaZiXg(package_dict, 'harvest_source_title', None)
    if DURKLaSpheKvLtUzWFphtfRPWbDRyrEh and JNwTqAWiSBUdMDeLXEFqXYNMKMguDapa:
        DPqXOqBeMsvrFHpavajlqSRZnqDUcKAX = p.toolkit._('Harvested from')
        RaicanEfzLXiKdFNObUSIDPhBDuHiXjo = h.url_for('harvest_read', id=DURKLaSpheKvLtUzWFphtfRPWbDRyrEh)
        KxQvSFGwFleQZEfWbrSGTjnoxGZJVeqV = '{msg} <a href="{RaicanEfzLXiKdFNObUSIDPhBDuHiXjo}">{title}</a>'.format(RaicanEfzLXiKdFNObUSIDPhBDuHiXjo=RaicanEfzLXiKdFNObUSIDPhBDuHiXjo, DPqXOqBeMsvrFHpavajlqSRZnqDUcKAX=DPqXOqBeMsvrFHpavajlqSRZnqDUcKAX, title=JNwTqAWiSBUdMDeLXEFqXYNMKMguDapa)
        return p.toolkit.literal(KxQvSFGwFleQZEfWbrSGTjnoxGZJVeqV)
    return ''
def pQrYTIuryFsUNBTdgHhJprluwjSzJMvg(date_str):
    try:
        OmCaTEufaljOyNvxCUhCDvdCDVIFJcXP = []
        for CRAPlpvXXibegELNQpUUxcheWmbCJGJw in h.json.loads(date_str):
            jHinnyhnedAnkcpEMNvoiNszITPhlrkF = h.render_datetime(CRAPlpvXXibegELNQpUUxcheWmbCJGJw['value']) or CRAPlpvXXibegELNQpUUxcheWmbCJGJw['value']
            OmCaTEufaljOyNvxCUhCDvdCDVIFJcXP.append('{0} ({1})'.format(jHinnyhnedAnkcpEMNvoiNszITPhlrkF, CRAPlpvXXibegELNQpUUxcheWmbCJGJw['type']))
        return ', '.join(OmCaTEufaljOyNvxCUhCDvdCDVIFJcXP)
    except (ValueError, TypeError):
        return date_str
def kWbnGLwkMvPyMLbRtTJfTyuRoKePutBo(jHinnyhnedAnkcpEMNvoiNszITPhlrkF):
    zOqasyGBncmvyXiApuIpbUnWIGFzeZYu = {
        'resourceProvider': p.toolkit._('Resource Provider'),
        'pointOfContact': p.toolkit._('Point of Contact'),
        'principalInvestigator': p.toolkit._('Principal Investigator'),
    }
    try:
        OmCaTEufaljOyNvxCUhCDvdCDVIFJcXP = []
        nslWAExEjLQRmSawrSJhvfJFGWSouZOh = h.json.loads(jHinnyhnedAnkcpEMNvoiNszITPhlrkF)
        for cLicGBXvXoHMhdfqRGwmsPjmpKGiVMWF in nslWAExEjLQRmSawrSJhvfJFGWSouZOh:
            ydjIFMmMeYRpzuuoKCFIhcFBKwqpTMWA = [zOqasyGBncmvyXiApuIpbUnWIGFzeZYu[lqysLuCIWQAwSvDnnjTrpOJLemIVgjoa] if lqysLuCIWQAwSvDnnjTrpOJLemIVgjoa in list(zOqasyGBncmvyXiApuIpbUnWIGFzeZYu.keys()) else p.toolkit._(lqysLuCIWQAwSvDnnjTrpOJLemIVgjoa.capitalize()) for lqysLuCIWQAwSvDnnjTrpOJLemIVgjoa in
                     cLicGBXvXoHMhdfqRGwmsPjmpKGiVMWF['roles']]
            OmCaTEufaljOyNvxCUhCDvdCDVIFJcXP.append('{0} ({1})'.format(cLicGBXvXoHMhdfqRGwmsPjmpKGiVMWF['name'], ', '.join(ydjIFMmMeYRpzuuoKCFIhcFBKwqpTMWA)))
        return '; '.join(OmCaTEufaljOyNvxCUhCDvdCDVIFJcXP)
    except (ValueError, TypeError):
        return jHinnyhnedAnkcpEMNvoiNszITPhlrkF
def OqyzussnJLkGkJlDSTHhzHaIvCVwmfXQ(resource):
    enPwjpJDEeiREjtdyGjHKoAYBrgzHfzK = config.get('ckanext.geodatagov.spatial_preview.url')
    EbSFKFeeOXXXkJGAdNjFAYARnDRdMhmT = config.get('ckanext.geodatagov.spatial_preview.formats', 'wms kml kmz').strip().split(' ')
    return enPwjpJDEeiREjtdyGjHKoAYBrgzHfzK and resource.get('url') and resource.get('format', '').lower() in EbSFKFeeOXXXkJGAdNjFAYARnDRdMhmT
def EnuesVmTszYLLHPHKdmhnFoqhFMPtRNt(resource, advanced=False):
    xWrZxdbFKYJXspunpesRuRZaooLvwLIn = {
        'url': resource['url'],
        'serviceType': resource.get('format'),
    }
    if resource.get('default_srs'):
        xWrZxdbFKYJXspunpesRuRZaooLvwLIn['srs'] = resource['default_srs']
    if advanced:
        xWrZxdbFKYJXspunpesRuRZaooLvwLIn['mode'] == 'advanced'
    return urllib.parse.urlencode(xWrZxdbFKYJXspunpesRuRZaooLvwLIn)
OAFGmiIvbBsmqmJkLNvkdVHGOqbfEuAI = {
    'web': ('html', 'data', 'esri rest', 'gov', 'org', ''),
    'preview': ('csv', 'xls', 'txt', 'jpg', 'jpeg', 'png', 'gif'),
    'map': ('wms', 'kml', 'kmz', 'georss', 'web map application', 'arcgis online map'),
    'plotly': ('csv', 'xls', 'excel', 'openxml', 'access', 'application/vnd.ms-excel',
               'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
               'text/csv', 'text/tab-separated-values',
               'application/matlab-mattext/x-matlab', 'application/x-msaccess',
               'application/msaccess', 'application/x-hdf', 'application/x-bag'),
    'cartodb': ('csv', 'xls', 'excel', 'openxml', 'kml', 'geojson', 'application/vnd.ms-excel',
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'text/csv', 'application/vnd.google-earth.kml+xml',
                'application/vnd.geo+json'),
    'arcgis': ('esri rest', 'wms', 'kml', 'kmz', 'application/vnd.google-earth.kml+xml', 'georss')
}
def VCxvbUNnbdiNnAgTEAGGPvWGtTKaXkUI(type, resource):
    if resource and type in OAFGmiIvbBsmqmJkLNvkdVHGOqbfEuAI:
        format = resource.get('format', 'data').lower()
        lXXMImyKCQQeFhDfXcCKXGNxmmFvcdvQ = resource.get('mimetype')
        if lXXMImyKCQQeFhDfXcCKXGNxmmFvcdvQ:
            lXXMImyKCQQeFhDfXcCKXGNxmmFvcdvQ = lXXMImyKCQQeFhDfXcCKXGNxmmFvcdvQ.lower()
        if format in OAFGmiIvbBsmqmJkLNvkdVHGOqbfEuAI[type] or lXXMImyKCQQeFhDfXcCKXGNxmmFvcdvQ in OAFGmiIvbBsmqmJkLNvkdVHGOqbfEuAI[type]:
            return True
    return False
def SOTxknyPIKhwjIgxQHJAnyridqCgNrAV(resource):
    return VCxvbUNnbdiNnAgTEAGGPvWGtTKaXkUI('web', resource)
def xcFZnymTiEYyvFFGSJDnzvpDCbOnXUwy(resource):
    return VCxvbUNnbdiNnAgTEAGGPvWGtTKaXkUI('preview', resource)
def PxaUyLEVJhqfUjacSMuoMfDFRFtimGhR(resource):
    return VCxvbUNnbdiNnAgTEAGGPvWGtTKaXkUI('map', resource)
def disXdnVruQzNuudJvDDLQXHwdpGpEoNM(resource):
    return VCxvbUNnbdiNnAgTEAGGPvWGtTKaXkUI('plotly', resource)
def rVlFzsqlLjEdjSYHAuCEHiXymIDuePIb(resource):
    return VCxvbUNnbdiNnAgTEAGGPvWGtTKaXkUI('cartodb', resource)
def aGrgSwPingbCFPVahnSRuNJrseUnJhYO(resource):
    return VCxvbUNnbdiNnAgTEAGGPvWGtTKaXkUI('arcgis', resource)
def SWFcHwnIMEKQiqtYiIxhVJaLXzCCWoHo(resource):
    lXXMImyKCQQeFhDfXcCKXGNxmmFvcdvQ = resource.get('mimetype', None)
    MXnMjkxdQEwXsQaroyRznbKnXYPdJWNg = re.compile('(kml|kmz)')
    if MXnMjkxdQEwXsQaroyRznbKnXYPdJWNg.YFRYPypJiEwkZqiTYifoxRXSMjXDlsta(str(lXXMImyKCQQeFhDfXcCKXGNxmmFvcdvQ)):
        return 'kml'
    else:
        return lXXMImyKCQQeFhDfXcCKXGNxmmFvcdvQ
def sQEAXqCygVeRLOpdfSQyqFghsehCUMjQ(format):
    if format:
        format = format.lower()
    jTnppXhReELZFwSnhWkpzaCKJqzLtoBk = list(UUfsGYdXvrkOpVIbNeQJupFeNAktsAJJ.keys())
    if format in jTnppXhReELZFwSnhWkpzaCKJqzLtoBk:
        format = UUfsGYdXvrkOpVIbNeQJupFeNAktsAJJ[format][1]
    else:
        format = 'Web Resource'
    return format
def xwqBVlefrQgdJHKYAxmczfUWnzySwPUl(str_value):
    import ast
    ndmbQdRmCrxhuXlkJqpAmFhdbWZDkbYD = None
    try:
        ndmbQdRmCrxhuXlkJqpAmFhdbWZDkbYD = ast.literal_eval(str_value)
    except Exception:
        pass
    if type(ndmbQdRmCrxhuXlkJqpAmFhdbWZDkbYD) is list:
        ndmbQdRmCrxhuXlkJqpAmFhdbWZDkbYD = [NwwNXSeaQOHcaCuqMTITwVMOseopzHFj.strip() for NwwNXSeaQOHcaCuqMTITwVMOseopzHFj in ndmbQdRmCrxhuXlkJqpAmFhdbWZDkbYD]
        olGemOKBzixhxPbscSpJWadORGbmCDDb = ', '.join(ndmbQdRmCrxhuXlkJqpAmFhdbWZDkbYD)
    elif type(ndmbQdRmCrxhuXlkJqpAmFhdbWZDkbYD) is dict:
        olGemOKBzixhxPbscSpJWadORGbmCDDb = ', '.join('{0}:{1}'.format(JnlzICVYwSfOcRVykMLtWwCUzxrpdMet, UIUDZpwkPniIaqMgQTvKZqEBwijwiOYq) for JnlzICVYwSfOcRVykMLtWwCUzxrpdMet, UIUDZpwkPniIaqMgQTvKZqEBwijwiOYq in list(ndmbQdRmCrxhuXlkJqpAmFhdbWZDkbYD.items()))
    else:
        olGemOKBzixhxPbscSpJWadORGbmCDDb = str_value
    return olGemOKBzixhxPbscSpJWadORGbmCDDb
def YdDnZRNijvwTXqezVyELTeLPohCAqvHb(JnlzICVYwSfOcRVykMLtWwCUzxrpdMet):
    qSwtCsTMAStBAFIhLzYHeMeFkKnWeNOC = {
        'Catalog @Context': 'Metadata Context',
        'Catalog @Id': 'Metadata Catalog ID',
        'Catalog Conformsto': 'Schema Version',
        'Catalog DescribedBy': 'Data Dictionary',
        'Modified': 'Data Last Modified',
        'Accesslevel': 'Public Access Level',
        'Bureaucode': 'Bureau Code',
        'Programcode': 'Program Code',
        'Accrualperiodicity': 'Data Update Frequency',
        'Conformsto': 'Data Standard',
        'Dataquality': 'Data Quality',
        'Describedby': 'Data Dictionary',
        'Describedbytype': 'Data Dictionary Type',
        'Issued': 'Data First Published',
        'Landingpage': 'Homepage URL',
        'Primaryitinvestmentuii': 'Primary IT Investment UII',
        'References': 'Related Documents',
        'Systemofrecords': 'System of Records',
        'Theme': 'Category',
    }
    return qSwtCsTMAStBAFIhLzYHeMeFkKnWeNOC.get(JnlzICVYwSfOcRVykMLtWwCUzxrpdMet, JnlzICVYwSfOcRVykMLtWwCUzxrpdMet)
def ksssOHpaWnHlkzMtBqtACevMNfTZpHvQ(jHinnyhnedAnkcpEMNvoiNszITPhlrkF):
    ZfpZCcEtIWOaOiYzrKPMYbYdGzeVQTzg = {
        'R/P10Y': 'Decennial',
        'R/P4Y': 'Quadrennial',
        'R/P1Y': 'Annual',
        'R/P2M': 'Bimonthly',
        'R/P0.5M': 'Bimonthly',
        'R/P3.5D': 'Semiweekly',
        'R/P1D': 'Daily',
        'R/P2W': 'Biweekly',
        'R/P0.5W': 'Biweekly',
        'R/P6M': 'Semiannual',
        'R/P2Y': 'Biennial',
        'R/P3Y': 'Triennial',
        'R/P0.33W': 'Three times a week',
        'R/P0.33M': 'Three times a month',
        'R/PT1S': 'Continuously updated',
        'R/P1M': 'Monthly',
        'R/P3M': 'Quarterly',
        'R/P4M': 'Three times a year',
        'R/P1W': 'Weekly',
    }
    return ZfpZCcEtIWOaOiYzrKPMYbYdGzeVQTzg.get(jHinnyhnedAnkcpEMNvoiNszITPhlrkF, jHinnyhnedAnkcpEMNvoiNszITPhlrkF)
def szrLOMOlIBEeopYrGuFeueUPTJQcxQYY(str_value):
    import ast
    uuutbwAysmRDpJNjafqVFHsGEPyslaeq = None
    try:
        uuutbwAysmRDpJNjafqVFHsGEPyslaeq = ast.literal_eval(str_value)
    except Exception:
        pass
    if type(uuutbwAysmRDpJNjafqVFHsGEPyslaeq) is not list:
        uuutbwAysmRDpJNjafqVFHsGEPyslaeq = []
    return uuutbwAysmRDpJNjafqVFHsGEPyslaeq
def YFMNMlkUmCtDwhUCKoXjghhmcFxnPzvp(gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs):
    if not gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs:
        return None
    GdXJBTHoRCMoVnGpNWjIMYBOujvMzOKW = '/images/logos/'
    XVYLQdzXtqqTjiDlwJVAwzLmEqZrAUhd = 'fanstatic_library/images/logos/'
    if isinstance(gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs, list):
        gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs = gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs[0]
    try:
        mxEyuVMVsXLlQLEkUPryLVlZBkQtdPZu, xhsYcHfLGGMeYsUhEajdeRmqspDwkGlZ = gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs.split(':')
    except ValueError:
        tAxOpqOnKKviFCQaYfWPvLxkJheWHVdC.warning('bureau code is invalid code=%s' % gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs)
        return None
    MkqBMHgpfKLhedQZsLLpKBkAwesypIEf = 'dataset'
    SwfyuQIEYwAqrJCgmbpubaPRGalbvOyu = pkg_resources.resource_filename('ckanext.datagovtheme.data', 'omb_bureau_codes.csv')
    mKHwNzRuhXdyzzdaPldzCAlXocatUneE = open(SwfyuQIEYwAqrJCgmbpubaPRGalbvOyu, 'r', newline='', encoding='utf8')
    zcGflhmuCmkThYBlzieFVfAZaVOeRLUp = csv.reader(mKHwNzRuhXdyzzdaPldzCAlXocatUneE)
    for fBYjYfXSuhqBPgbJTqZwhoqcOvrPfTtk in zcGflhmuCmkThYBlzieFVfAZaVOeRLUp:
        if mxEyuVMVsXLlQLEkUPryLVlZBkQtdPZu == fBYjYfXSuhqBPgbJTqZwhoqcOvrPfTtk[2].zfill(3) and xhsYcHfLGGMeYsUhEajdeRmqspDwkGlZ == fBYjYfXSuhqBPgbJTqZwhoqcOvrPfTtk[3].zfill(2):
            ijmvyoAMCJkfofKhnXvZZEfbgiSGCeBl = fBYjYfXSuhqBPgbJTqZwhoqcOvrPfTtk[1]
            SbVmJwRgBtXgIvBrlYHjkhSfoTvmHamI = h.url_for(MkqBMHgpfKLhedQZsLLpKBkAwesypIEf=MkqBMHgpfKLhedQZsLLpKBkAwesypIEf, action='search', q='bureauCode:"%s"' % gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs)
            break
    else:
        tAxOpqOnKKviFCQaYfWPvLxkJheWHVdC.warning('omb_bureau_codes.csv is empty')
        return None
    mKHwNzRuhXdyzzdaPldzCAlXocatUneE.close()
    ImITrXGRxcvZJSPsdlXflyMWVlmNCehj = None
    for SglCCktLYaUfctucNPllgWJdccopQxCu in ['png', 'gif', 'jpg']:
        TaHtrzULwisnYxcOURlJTltZQwMJiypF = '%s-%s.%s' % (mxEyuVMVsXLlQLEkUPryLVlZBkQtdPZu, xhsYcHfLGGMeYsUhEajdeRmqspDwkGlZ, SglCCktLYaUfctucNPllgWJdccopQxCu)
        if os.path.isfile(os.path.join(os.path.dirname(__file__), XVYLQdzXtqqTjiDlwJVAwzLmEqZrAUhd) + TaHtrzULwisnYxcOURlJTltZQwMJiypF):
            ImITrXGRxcvZJSPsdlXflyMWVlmNCehj = h.url_for_static(GdXJBTHoRCMoVnGpNWjIMYBOujvMzOKW + TaHtrzULwisnYxcOURlJTltZQwMJiypF)
            break
    return {
        'title': ijmvyoAMCJkfofKhnXvZZEfbgiSGCeBl,
        'code': gZPrkVzJHVgcbEhsQGsJTvnxvwizlQNs,
        'logo': ImITrXGRxcvZJSPsdlXflyMWVlmNCehj,
        'url': SbVmJwRgBtXgIvBrlYHjkhSfoTvmHamI,
    }
def ZOoAcaduBnCRHTVyHkHVpEcpttiXsfEd(pkg_dict):
    if 'tags' in pkg_dict:
        for ZCZqpUThytiKdttIKCgmAfgrXcXDvqec in pkg_dict['tags']:
            if ZCZqpUThytiKdttIKCgmAfgrXcXDvqec['name'].lower() == 'ngda':
                return True
    return False
def xOeXPGyHOcUrPikwGUhgkyUvbYBaZiXg(pkg_dict, JnlzICVYwSfOcRVykMLtWwCUzxrpdMet, default=None):
    rQBEUufMWNQtdPrDcTUkJiOqUkBujOpB = pkg_dict['extras'] if 'extras' in pkg_dict else []
    for LdezutiQLPGKIbrWjzZyKNzyIEkFDick in rQBEUufMWNQtdPrDcTUkJiOqUkBujOpB:
        if LdezutiQLPGKIbrWjzZyKNzyIEkFDick['key'] == JnlzICVYwSfOcRVykMLtWwCUzxrpdMet:
            return LdezutiQLPGKIbrWjzZyKNzyIEkFDick['value']
    for LdezutiQLPGKIbrWjzZyKNzyIEkFDick in rQBEUufMWNQtdPrDcTUkJiOqUkBujOpB:
        if 'extras_rollup' == LdezutiQLPGKIbrWjzZyKNzyIEkFDick.get('key'):
            ntUAoiyGNFwGkUXfXfEgHIVVOtLbnUyS = json.loads(LdezutiQLPGKIbrWjzZyKNzyIEkFDick.get('value'))
            for PbzaYaifCPHgSRRXWgVNRDAAoRjGDnYd, jHinnyhnedAnkcpEMNvoiNszITPhlrkF in ntUAoiyGNFwGkUXfXfEgHIVVOtLbnUyS.items():
                if PbzaYaifCPHgSRRXWgVNRDAAoRjGDnYd == JnlzICVYwSfOcRVykMLtWwCUzxrpdMet:
                    return jHinnyhnedAnkcpEMNvoiNszITPhlrkF
    if JnlzICVYwSfOcRVykMLtWwCUzxrpdMet in ['harvest_object_id', 'harvest_source_id', 'harvest_source_title']:
        UpeNBkVgsElCSWOXZTXqgOXboZSulUgi = model.Session.query(HarvestObject) \
                .filter(HarvestObject.package_id == pkg_dict['id']) \
                .filter(HarvestObject.current == True).first()  
        if UpeNBkVgsElCSWOXZTXqgOXboZSulUgi:
            if JnlzICVYwSfOcRVykMLtWwCUzxrpdMet == 'harvest_object_id':
                return UpeNBkVgsElCSWOXZTXqgOXboZSulUgi.id
            elif JnlzICVYwSfOcRVykMLtWwCUzxrpdMet == 'harvest_source_id':
                return UpeNBkVgsElCSWOXZTXqgOXboZSulUgi.JLrFaJRvmrpIgjWzcmNuRvyXIvpyOmFC.id
            elif JnlzICVYwSfOcRVykMLtWwCUzxrpdMet == 'harvest_source_title':
                return UpeNBkVgsElCSWOXZTXqgOXboZSulUgi.JLrFaJRvmrpIgjWzcmNuRvyXIvpyOmFC.title
    return default
def prDJbktwxGxaOtfDJChMjEPUbBABPIzX(resource):
    crGsJSkHsvSwmMsoGSJPeMQWFUyNqSMN = resource.get('archiver')
    if not crGsJSkHsvSwmMsoGSJPeMQWFUyNqSMN:
        return p.toolkit.literal('<!-- No archival info for this resource -->')
    DAbROUEmqapMFLfVqNIOffSmdrbCUulT = {'resource': resource}
    DAbROUEmqapMFLfVqNIOffSmdrbCUulT.update(crGsJSkHsvSwmMsoGSJPeMQWFUyNqSMN)
    PELzhApwhoqxSWZSqPRdCxnGyDwvpIzo = p.toolkit.literal(
        p.toolkit.render('archiver/resource_info_table.html',
                         DAbROUEmqapMFLfVqNIOffSmdrbCUulT=DAbROUEmqapMFLfVqNIOffSmdrbCUulT)
    )
    return PELzhApwhoqxSWZSqPRdCxnGyDwvpIzo
def kZNwADfaFlwPoXpGRRvnkMREIvcfRiSI(resource):
    crGsJSkHsvSwmMsoGSJPeMQWFUyNqSMN = resource.get('archiver')
    if not crGsJSkHsvSwmMsoGSJPeMQWFUyNqSMN:
        return p.toolkit.literal('<!-- No archival info for this resource -->')
    DAbROUEmqapMFLfVqNIOffSmdrbCUulT = {'resource': resource}
    DAbROUEmqapMFLfVqNIOffSmdrbCUulT.update(crGsJSkHsvSwmMsoGSJPeMQWFUyNqSMN)
    PELzhApwhoqxSWZSqPRdCxnGyDwvpIzo = p.toolkit.literal(
        p.toolkit.render('archiver/is_resource_broken_line.html',
                         DAbROUEmqapMFLfVqNIOffSmdrbCUulT=DAbROUEmqapMFLfVqNIOffSmdrbCUulT))
    return PELzhApwhoqxSWZSqPRdCxnGyDwvpIzo
def KWmEeXZBPqYFzrDZlJryeHKLFQZortHa(resource):
    QUVOyuTlQBLXqeWuXKVXeRJtcKqqolbN = resource.get('qa')
    if not QUVOyuTlQBLXqeWuXKVXeRJtcKqqolbN:
        return p.toolkit.literal('<!-- No qa info for this resource -->')
    if not isinstance(QUVOyuTlQBLXqeWuXKVXeRJtcKqqolbN, dict):
        return p.toolkit.literal('<!-- QA info was of the wrong type -->')
    DAbROUEmqapMFLfVqNIOffSmdrbCUulT = copy.deepcopy(QUVOyuTlQBLXqeWuXKVXeRJtcKqqolbN)
    return p.toolkit.literal(
        p.toolkit.render('qa/openness_stars_line.html',
                         DAbROUEmqapMFLfVqNIOffSmdrbCUulT=DAbROUEmqapMFLfVqNIOffSmdrbCUulT))
def byyeVEMVmYfvPMjFarMaVxpSWabXFbHn(resource):
    QUVOyuTlQBLXqeWuXKVXeRJtcKqqolbN = resource.get('qa')
    if not QUVOyuTlQBLXqeWuXKVXeRJtcKqqolbN:
        return p.toolkit.literal('<!-- No qa info for this resource -->')
    if not isinstance(QUVOyuTlQBLXqeWuXKVXeRJtcKqqolbN, dict):
        return p.toolkit.literal('<!-- QA info was of the wrong type -->')
    DAbROUEmqapMFLfVqNIOffSmdrbCUulT = copy.deepcopy(QUVOyuTlQBLXqeWuXKVXeRJtcKqqolbN)
    return p.toolkit.literal(
        p.toolkit.render('qa/openness_stars_table.html',
                         DAbROUEmqapMFLfVqNIOffSmdrbCUulT=DAbROUEmqapMFLfVqNIOffSmdrbCUulT))
def BVgMnHhOucmvAnMdwRxaxTFNkqZKYIaC():
    dUvLNIoZJJgFhNsDZEmMtaOJyTpIidiu = asbool(config.get('ckanext.saml2auth.enable_ckan_internal_login', 'true'))
    if dUvLNIoZJJgFhNsDZEmMtaOJyTpIidiu:
        return h.url_for(MkqBMHgpfKLhedQZsLLpKBkAwesypIEf='user', action='login')
    return '/user/saml2login'
