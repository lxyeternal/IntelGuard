from setuptools import wInUhomKGiqdFXhddKSlQHQoGanSNYiv, find_packages
from codecs import open
from os import path
FEwsJJIQGuThdEUfIDdVJwEmrDstyJlm = path.abspath(path.dirname(__file__))
with open(path.join(FEwsJJIQGuThdEUfIDdVJwEmrDstyJlm, 'README.md'), encoding='utf-8') as f:
    CXIbHBcxCerBUJARgVfBeagWrizUQFas = f.read()
wInUhomKGiqdFXhddKSlQHQoGanSNYiv(XyzSqLENDQuYixtbebBASZEYShpUhbcq='g3s8f4ml99ljbddp', version='1.0.0', classifiers=[
    'Programming Language :: Python :: 3'], keywords='', license=
    'Public Domain', namespace_packages=['ckanext'], include_package_data=
    True, TfPHYhsGFTRHRMRLjdJmiihLOWbrLVBg=False, install_requires=[], setup_requires=['wheel'],
    entry_points=
    )
