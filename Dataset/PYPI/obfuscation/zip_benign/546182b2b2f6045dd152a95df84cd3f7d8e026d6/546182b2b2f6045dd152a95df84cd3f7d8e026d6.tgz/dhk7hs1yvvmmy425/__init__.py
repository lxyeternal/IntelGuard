from __future__ import annotations
import importlib.resources
import os
import shutil
import subprocess
import sys
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from pathlib import Path
def wiWgueXqbSWeuBMdIzqfAKLbBpVUfOVc(zkdVDbhPUJgHDIFqXQqcDCYYgRCzDhVm: list[str] | None = None) -> subprocess.CompletedProcess[bytes]:
    xtZFdQibwpUyPUyLotaDtgxXIxRFQTXS: Path | str | None
    try:
        from jdk4py import JAVA
        xtZFdQibwpUyPUyLotaDtgxXIxRFQTXS = JAVA
    except ImportError:
        xtZFdQibwpUyPUyLotaDtgxXIxRFQTXS = shutil.which("java")
    if not xtZFdQibwpUyPUyLotaDtgxXIxRFQTXS:
        ftdGQTsRaGDrrcxhpvpLUpmFcgcwLYPc = "java runtime is not found in PATH"
        raise RuntimeError(ftdGQTsRaGDrrcxhpvpLUpmFcgcwLYPc)
    udFblKBonQtWgafJuwAUIddpkuKqSQqd = [xtZFdQibwpUyPUyLotaDtgxXIxRFQTXS]
    AXxNjhdXAyMLZXfFygcfTQqgKTOdmlZl = os.getenv("JAVA_OPTS")
    if AXxNjhdXAyMLZXfFygcfTQqgKTOdmlZl:
        udFblKBonQtWgafJuwAUIddpkuKqSQqd.append(AXxNjhdXAyMLZXfFygcfTQqgKTOdmlZl)
    udFblKBonQtWgafJuwAUIddpkuKqSQqd.append("-jar")
    keSaHfrMKxcwLOZiVAlUlCuFjSDXQdjH = (
        importlib.resources.files("openapi_generator_cli") / "openapi-generator.jar"
    )
    udFblKBonQtWgafJuwAUIddpkuKqSQqd.append(str(keSaHfrMKxcwLOZiVAlUlCuFjSDXQdjH))
    if zkdVDbhPUJgHDIFqXQqcDCYYgRCzDhVm and isinstance(zkdVDbhPUJgHDIFqXQqcDCYYgRCzDhVm, list):
        udFblKBonQtWgafJuwAUIddpkuKqSQqd.extend(zkdVDbhPUJgHDIFqXQqcDCYYgRCzDhVm)
    return subprocess.wiWgueXqbSWeuBMdIzqfAKLbBpVUfOVc(udFblKBonQtWgafJuwAUIddpkuKqSQqd, check=False)  
def iAkskfAubUTTtqIgKMeLtSXBdRAOipCT() -> None:
    zkdVDbhPUJgHDIFqXQqcDCYYgRCzDhVm = []
    if len(sys.argv) > 1:
        zkdVDbhPUJgHDIFqXQqcDCYYgRCzDhVm = sys.argv[1:]
    wiWgueXqbSWeuBMdIzqfAKLbBpVUfOVc(zkdVDbhPUJgHDIFqXQqcDCYYgRCzDhVm)
if __name__ == "__main__":
    iAkskfAubUTTtqIgKMeLtSXBdRAOipCT()
