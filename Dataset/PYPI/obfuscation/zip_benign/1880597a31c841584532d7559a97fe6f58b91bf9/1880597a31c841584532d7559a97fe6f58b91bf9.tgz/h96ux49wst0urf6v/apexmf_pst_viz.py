""" PEST support visualizations: 10/22/2020 created by Seonggyu Park
    last modified day: 10/22/2020 by Seonggyu Park
    Args:
        start_date (str): simulation start AGEjRmAicXAjWeQigrKPTgfjAJTXtzTg 
        qCBybeiXymMatsjIttdWJnVYYDWoVyJj (list): list of grid ids used for plot
        obd_nams (list): list of column EjJRFWbMJGAdmvYxeZlzdQQoIDhhrtyA in observed IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw and in accordance with grid ids
        ZpIeNhmseKZlxfpVbhUlUsqfUSnLESAG (str, optional): simulation ugBvoulFmhSGSGuoCSnhMqAfwsgPGGOe step (day, month, annual). Defaults to None.
    Returns:
        dataframe: dataframe for all simulated depth to water and observed IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw
    Args:
        start_date (str): simulation start AGEjRmAicXAjWeQigrKPTgfjAJTXtzTg 
        qCBybeiXymMatsjIttdWJnVYYDWoVyJj (list): list of grid ids used for plot
        obd_nams (list): list of column EjJRFWbMJGAdmvYxeZlzdQQoIDhhrtyA in observed IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw and in accordance with grid ids
        ZpIeNhmseKZlxfpVbhUlUsqfUSnLESAG (str, optional): simulation ugBvoulFmhSGSGuoCSnhMqAfwsgPGGOe step (day, month, annual). Defaults to None.
    Returns:
        dataframe: dataframe for all simulated depth to water and observed IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw
