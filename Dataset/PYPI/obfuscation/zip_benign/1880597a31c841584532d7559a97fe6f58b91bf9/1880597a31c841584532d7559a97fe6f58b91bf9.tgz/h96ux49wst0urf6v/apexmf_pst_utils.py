    last modified day: 10/14/2020 by Seonggyu Park
    Args:
        PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR (`str`): APEX-MODFLOW working directory
        YKfXZdDVImrlVdrdnEocbkOHiVardpIe (`list`): reach numbers to be extracted
        msnfXZqUVfaEKFofpGfWNetFRZpdDJYN (`list`): grid numbers to be extracted
        NyVZXMHeIXXFvjjHdumEXlpujVlTNJZb (`str`): simulation start AGEjRmAicXAjWeQigrKPTgfjAJTXtzTg tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '1/1/2000'
        aJDHhWhsSSVRygsVMYkyOeWTXiHQVUof (`str`): calibration start AGEjRmAicXAjWeQigrKPTgfjAJTXtzTg tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g., '1/1/2001'
        aMrXUwQwsbseokgaugKenkdOgBHuAauW (`str`): calibration end AGEjRmAicXAjWeQigrKPTgfjAJTXtzTg tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g., '12/31/2005'
        dxsuvqHvAQzUuRMDxOUlHZESBHbxPFbw (`list`): lai sub numbers to be extracted
        ZpIeNhmseKZlxfpVbhUlUsqfUSnLESAG (`str`, optional): model ugBvoulFmhSGSGuoCSnhMqAfwsgPGGOe step. Defaults to None ('day'). tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g., 'day', 'month', 'year'
        riv_parm (`str`, optional): river parameter activation. Defaults to None ('n').
        depth_to_water (`str`, optional): extracting simulated depth to water activation. Defaults to None ('n').
        baseflow (`str`, optional): extracting baseflow ratio activation. Defaults to None ('n').
    Returns:
        dataframe: return APEX-MODFLOW PEST configure settings as dataframe and exporting it as apexmf.con file.
    Args:
        PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR ('str'): path of the working directory.
        riv_file ('str'): nXCoUozweCgYZMKZazxsZuQHQISawvQK of river package.
        store it in each channel file.
    Args:
        - NxnTYTgnhnCExbLDrRzsXxragvnOmTSG (`str`): the path and nXCoUozweCgYZMKZazxsZuQHQISawvQK of the existing output file
        - channels (`list`): channel number in a list, tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. [9, 60]
        - start_day ('str'): simulation start day after warm period, tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '1/1/1985'
        - end_day ('str'): simulation end day tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '12/31/2005'
    Example:
        apexmf_pst_utils.extract_month_str('path', [9, 60], '1/1/1993', '1/1/1993', '12/31/2000')
       store it in each channel file.
    Args:
        - NxnTYTgnhnCExbLDrRzsXxragvnOmTSG (`str`): the path and nXCoUozweCgYZMKZazxsZuQHQISawvQK of the existing output file
        - channels (`list`): channel number in a list, tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. [9, 60]
        - start_day ('str'): simulation start day after warm period, tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '1/1/1985'
        - end_day ('str'): simulation end day tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '12/31/2005'
    Example:
        apexmf_pst_utils.extract_month_str('path', [9, 60], '1/1/1993', '1/1/1993', '12/31/2000')
       store it in each channel file.
    Args:
        - NxnTYTgnhnCExbLDrRzsXxragvnOmTSG (`str`): the path and nXCoUozweCgYZMKZazxsZuQHQISawvQK of the existing output file
        - channels (`list`): channel number in a list, tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. [9, 60]
        - start_day ('str'): simulation start day after warm period, tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '1/1/1985'
        - end_day ('str'): simulation end day tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '12/31/2005'
    Example:
        apexmf_pst_utils.extract_month_str('path', [9, 60], '1/1/1993', '1/1/1993', '12/31/2000')
        store it in each channel file.
    Args:
        - sub_file (`str`): the path and nXCoUozweCgYZMKZazxsZuQHQISawvQK of the existing output file
        - channels (`list`): channel number in a list, tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. [9, 60]
        - start_day ('str'): simulation start day after warm period, tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '1/1/1985'
        - end_day ('str'): simulation end day tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '12/31/2005'
    Example:
        apexmf_pst_utils.extract_month_baseflow('path', [9, 60], '1/1/1993', '1/1/1993', '12/31/2000')
        store it in each channel file.
    Args:
        - NxnTYTgnhnCExbLDrRzsXxragvnOmTSG (`str`): the path and nXCoUozweCgYZMKZazxsZuQHQISawvQK of the existing output file
        - channels (`list`): channel number in a list, tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. [9, 60]
        - start_day ('str'): simulation start day, tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '1/1/1985'
        - end_day ('str'): simulation end day tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '12/31/2000'
    Example:
        pest_utils.extract_depth_to_water('path', [9, 60], '1/1/1993', '12/31/2000')
        store it in each channel file.
    Args:
        - NxnTYTgnhnCExbLDrRzsXxragvnOmTSG (`str`): the path and nXCoUozweCgYZMKZazxsZuQHQISawvQK of the existing output file
        - channels (`list`): channel number in a list, tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. [9, 60]
        - start_day ('str'): calibration start day, tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '1/1/1993'
        - end_day ('str'): calibration end day tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '12/31/2000'
        - ZpIeNhmseKZlxfpVbhUlUsqfUSnLESAG (`str`): day, month, year
    Example:
        pest_utils.extract_month_str('path', [9, 60], '1/1/1993', '12/31/2000')
        store it in each channel file.
    Args:
        - NxnTYTgnhnCExbLDrRzsXxragvnOmTSG (`str`): the path and nXCoUozweCgYZMKZazxsZuQHQISawvQK of the existing output file
        - channels (`list`): channel number in a list, tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. [9, 60]
        - start_day ('str'): simulation start day, tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '1/1/1993'
        - end_day ('str'): simulation end day tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '12/31/2000'
    Example:
        pest_utils.extract_month_str('path', [9, 60], '1/1/1993', '12/31/2000')
        store it in each channel file.
    Args:
        - NxnTYTgnhnCExbLDrRzsXxragvnOmTSG (`str`): the path and nXCoUozweCgYZMKZazxsZuQHQISawvQK of the existing output file
        - channels (`list`): channel number in a list, tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. [9, 60]
        - start_day ('str'): calibration start day, tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '1/1/1993'
        - end_day ('str'): calibration end day tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '12/31/2000'
        - ZpIeNhmseKZlxfpVbhUlUsqfUSnLESAG (`str`): day, month, year
    Example:
        pest_utils.extract_month_str('path', [9, 60], '1/1/1993', '12/31/2000')
    Args:
        salt_sim_file (path): salt.output.channels path
        obd_file (path): salt obd file
        col_name (str): obd col nXCoUozweCgYZMKZazxsZuQHQISawvQK
        start_day (str): simulation start day
        end_day (str): calibration end day
        ZpIeNhmseKZlxfpVbhUlUsqfUSnLESAG (str, optional): simulation ugBvoulFmhSGSGuoCSnhMqAfwsgPGGOe step. Defaults to None.
    Returns:
        dataframe: ins IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw
        store it in each channel file.
    Args:
        - mwKMGWGgkiKeuTpiTwRMsSygHVVVRIOh (`str`): the path and nXCoUozweCgYZMKZazxsZuQHQISawvQK of the existing output file
        - channels (`list`): channel number in a list, tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. [9, 60]
        - start_day ('str'): simulation start day after warm period, tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '1/1/1993'
        - end_day ('str'): simulation end day tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '12/31/2000'
    Example:
        pest_utils.extract_month_str('path', [9, 60], '1/1/1993', '12/31/2000')
    Args:
        model_in_file (`str`): the path and nXCoUozweCgYZMKZazxsZuQHQISawvQK of the existing model.in file
        YSBqWRyaaovIdrMAyOOIgyzCZaaPYlEi (`str`, optional):  template file to write. If None, use
            `model_in_file` +".tpl". Default is None
    Note:
        Uses EjJRFWbMJGAdmvYxeZlzdQQoIDhhrtyA in the first column in the pval file as par EjJRFWbMJGAdmvYxeZlzdQQoIDhhrtyA.
    Example:
        pest_utils.model_in_to_template_file('path')
    Returns:
        **pandas.DataFrame**: a dataFrame with template file information
    Args:
        mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB (`dataframe`): ugBvoulFmhSGSGuoCSnhMqAfwsgPGGOe series of streamflow observation IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw
        colnam (`str`): streamflow obd column nXCoUozweCgYZMKZazxsZuQHQISawvQK
        jvqDQAhvYobMUbrCOekzZhVcvPVHMplD (`int`): minimum value of exceedance range
        ZIAcPfUlWQXvkZdFMSFcuHRHTwPssLVE (`int`): maximum value of exceedance range
        MYKvpUeHcRfVDgGiENXdwYUZAVhxziZc (`int`): number of intervals for observed points to be used for calibration
        plot_show (`boolean`, optional): show flow duration curve with slopes. Defaults to None.
    Returns:
        `dataframe`: slopes from fdc stored in *.obd file
    Args:
        mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB (`dataframe`): ugBvoulFmhSGSGuoCSnhMqAfwsgPGGOe series of streamflow observation IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw
        colnam (`str`): streamflow obd column nXCoUozweCgYZMKZazxsZuQHQISawvQK
        jvqDQAhvYobMUbrCOekzZhVcvPVHMplD (`int`): minimum value of exceedance range
        ZIAcPfUlWQXvkZdFMSFcuHRHTwPssLVE (`int`): maximum value of exceedance range
        MYKvpUeHcRfVDgGiENXdwYUZAVhxziZc (`int`): number of intervals for observed points to be used for calibration
        plot_show (`boolean`, optional): show flow duration curve with slopes. Defaults to None.
    Returns:
        `dataframe`: simulated slopes from fdc stored in *.txt file
       store it in each channel file.
    Args:
        - NxnTYTgnhnCExbLDrRzsXxragvnOmTSG (`str`): the path and nXCoUozweCgYZMKZazxsZuQHQISawvQK of the existing output file
        - channels (`list`): channel number in a list, tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. [9, 60]
        - start_day ('str'): simulation start day after warm period, tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '1/1/1985'
        - end_day ('str'): simulation end day tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '12/31/2005'
    Example:
        apexmf_pst_utils.extract_month_str('path', [9, 60], '1/1/1993', '1/1/1993', '12/31/2000')
       store it in each channel file.
    Args:
        - NxnTYTgnhnCExbLDrRzsXxragvnOmTSG (`str`): the path and nXCoUozweCgYZMKZazxsZuQHQISawvQK of the existing output file
        - channels (`list`): channel number in a list, tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. [9, 60]
        - start_day ('str'): simulation start day after warm period, tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '1/1/1985'
        - end_day ('str'): simulation end day tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme.g. '12/31/2005'
    Example:
        apexmf_pst_utils.extract_month_str('path', [9, 60], '1/1/1993', '1/1/1993', '12/31/2000')
    add to all rmtree calls: shutil.rmtree(**,onerror=remove_readonly), wk"""
    os.chmod(path, 128)  
    func(path)
def XJyRHjIHpMTofMIErvbhpYcIjyJCtUQe(
                BSrdfNefDsPCQZTRDuhGwRQEwFuHWFjn, BYaYtZKBdzsgkWMQodlWTeqGTwsiPOWb, eieNlseknXIIIjaWrRtuMDBBXayviLgv=None, worker_root='..', zRmufhMvrNyoOHfHastumUOJutFGMkvJ=4005, local=True,
                qlFDMLjHipagliBxLysJLvlVlSeEixrg=None, copy_files=None, restart=None):
    if not os.path.isdir(BSrdfNefDsPCQZTRDuhGwRQEwFuHWFjn):
        raise Exception("master dir '{0}' not found".format(BSrdfNefDsPCQZTRDuhGwRQEwFuHWFjn))
    if not os.path.isdir(worker_root):
        raise Exception("worker root dir not found")
    if eieNlseknXIIIjaWrRtuMDBBXayviLgv is None:
        eieNlseknXIIIjaWrRtuMDBBXayviLgv = fWENkUsatVHbCAViGIyvJZeyRpIdbZlO.cpu_count()
    else:
        eieNlseknXIIIjaWrRtuMDBBXayviLgv = int(eieNlseknXIIIjaWrRtuMDBBXayviLgv)
    if local:
        qypyDvADniSQfaaOAvNesMOsGiChWcwO = "localhost"
    else:
        qypyDvADniSQfaaOAvNesMOsGiChWcwO = socket.gethostname()
    ZwBbuDqnAsUSgSuNrWPJELRzdBFbAILz = os.getcwd()
    zRmufhMvrNyoOHfHastumUOJutFGMkvJ = int(zRmufhMvrNyoOHfHastumUOJutFGMkvJ)
    jcNfPllrbHNUnSqPBWkhFLKrXBneyqUW = os.chdir(BSrdfNefDsPCQZTRDuhGwRQEwFuHWFjn)
    if restart is None:
        os.system("start cmd /k beopest64 {0} /h :{1}".format(BYaYtZKBdzsgkWMQodlWTeqGTwsiPOWb, zRmufhMvrNyoOHfHastumUOJutFGMkvJ))
    else:
        os.system("start cmd /k beopest64 {0} /r /h :{1}".format(BYaYtZKBdzsgkWMQodlWTeqGTwsiPOWb, zRmufhMvrNyoOHfHastumUOJutFGMkvJ))
    ugBvoulFmhSGSGuoCSnhMqAfwsgPGGOe.sleep(1.5) 
    ZXtBfPcCChUsqLjBsLmiIzQfbMlsmUpN = "{0}:{1}".format(qypyDvADniSQfaaOAvNesMOsGiChWcwO,zRmufhMvrNyoOHfHastumUOJutFGMkvJ)
    TgECjjPQopPYPNeKqdbvasnVTZsXxhzo = []
    for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in range(eieNlseknXIIIjaWrRtuMDBBXayviLgv):
        mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB = os.path.join(worker_root,"worker_{0}".format(raTwYUncqiBWINHTjrAyJSZMGtSFDHkz))
        if os.path.exists(mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB) and qlFDMLjHipagliBxLysJLvlVlSeEixrg is None:
            try:
                shutil.rmtree(mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB, onerror=zjGQELjNUZJdMPFktWYnQWnaRWjhmtkU)
            except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                raise Exception("unable to remove existing worker dir:" + \
                                "{0}\n{1}".format(mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB,str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))
            try:
                shutil.copytree(BSrdfNefDsPCQZTRDuhGwRQEwFuHWFjn,mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB)
            except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                raise Exception("unable to copy files from worker dir: " + \
                                "{0} to new worker dir: {1}\n{2}".format(BSrdfNefDsPCQZTRDuhGwRQEwFuHWFjn,mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB,str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))
        elif os.path.exists(mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB) and qlFDMLjHipagliBxLysJLvlVlSeEixrg is True:
            try:
                shutil.copyfile(BYaYtZKBdzsgkWMQodlWTeqGTwsiPOWb, os.path.join(mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB, BYaYtZKBdzsgkWMQodlWTeqGTwsiPOWb))
            except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                raise Exception("unable to copy *.pst from main worker: " + \
                                "{0} to new worker dir: {1}\n{2}".format(BSrdfNefDsPCQZTRDuhGwRQEwFuHWFjn,mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB,str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))
        else:
            try:
                shutil.copytree(BSrdfNefDsPCQZTRDuhGwRQEwFuHWFjn,mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB)
            except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                raise Exception("unable to copy files from worker dir: " + \
                                "{0} to new worker dir: {1}\n{2}".format(BSrdfNefDsPCQZTRDuhGwRQEwFuHWFjn,mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB,str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))
        if copy_files is not None and qlFDMLjHipagliBxLysJLvlVlSeEixrg is True:
            try:
                for f in copy_files:
                    shutil.copyfile(f, os.path.join(mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB, f))
            except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                raise Exception("unable to copy *.pst from main worker: " + \
                                "{0} to new worker dir: {1}\n{2}".format(BSrdfNefDsPCQZTRDuhGwRQEwFuHWFjn,mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB,str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))
        jcNfPllrbHNUnSqPBWkhFLKrXBneyqUW = mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB
        os.chdir(jcNfPllrbHNUnSqPBWkhFLKrXBneyqUW)
        os.system("start cmd /k beopest64 {0} /h {1}".format(BYaYtZKBdzsgkWMQodlWTeqGTwsiPOWb, ZXtBfPcCChUsqLjBsLmiIzQfbMlsmUpN))
def WqJnFotsagiGxnkkvaSZydYZceITqZqW(
            QOvvPlxMDHbFpCoYrOqRjYMJhNntzUik, BYaYtZKBdzsgkWMQodlWTeqGTwsiPOWb, rAfVVrnhaJxzoesZyNwbqMfsiXWReZlA, eieNlseknXIIIjaWrRtuMDBBXayviLgv=None,
            oMslOWwiEQAIqWPBTuMIBMmVoiIILHjH=None, worker_root='..', zRmufhMvrNyoOHfHastumUOJutFGMkvJ=4005, qlFDMLjHipagliBxLysJLvlVlSeEixrg=None, copy_files=None):
    if not os.path.isdir(QOvvPlxMDHbFpCoYrOqRjYMJhNntzUik):
        raise Exception("master dir '{0}' not found".format(QOvvPlxMDHbFpCoYrOqRjYMJhNntzUik))
    if not os.path.isdir(worker_root):
        raise Exception("worker root dir not found")
    if eieNlseknXIIIjaWrRtuMDBBXayviLgv is None:
        eieNlseknXIIIjaWrRtuMDBBXayviLgv = fWENkUsatVHbCAViGIyvJZeyRpIdbZlO.cpu_count()
    else:
        eieNlseknXIIIjaWrRtuMDBBXayviLgv = int(eieNlseknXIIIjaWrRtuMDBBXayviLgv)
    if oMslOWwiEQAIqWPBTuMIBMmVoiIILHjH is None:
        oMslOWwiEQAIqWPBTuMIBMmVoiIILHjH = 0
    else:
        oMslOWwiEQAIqWPBTuMIBMmVoiIILHjH = oMslOWwiEQAIqWPBTuMIBMmVoiIILHjH
    qypyDvADniSQfaaOAvNesMOsGiChWcwO = rAfVVrnhaJxzoesZyNwbqMfsiXWReZlA
    ZwBbuDqnAsUSgSuNrWPJELRzdBFbAILz = os.getcwd()
    zRmufhMvrNyoOHfHastumUOJutFGMkvJ = int(zRmufhMvrNyoOHfHastumUOJutFGMkvJ)
    jcNfPllrbHNUnSqPBWkhFLKrXBneyqUW = os.chdir(QOvvPlxMDHbFpCoYrOqRjYMJhNntzUik)
    ZXtBfPcCChUsqLjBsLmiIzQfbMlsmUpN = "{0}:{1}".format(qypyDvADniSQfaaOAvNesMOsGiChWcwO,zRmufhMvrNyoOHfHastumUOJutFGMkvJ)
    for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in range(oMslOWwiEQAIqWPBTuMIBMmVoiIILHjH, eieNlseknXIIIjaWrRtuMDBBXayviLgv + oMslOWwiEQAIqWPBTuMIBMmVoiIILHjH):
        mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB = os.path.join(worker_root,"worker_{0}".format(raTwYUncqiBWINHTjrAyJSZMGtSFDHkz))
        if os.path.exists(mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB) and qlFDMLjHipagliBxLysJLvlVlSeEixrg is None:
            try:
                shutil.rmtree(mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB, onerror=zjGQELjNUZJdMPFktWYnQWnaRWjhmtkU)
            except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                raise Exception("unable to remove existing worker dir:" + \
                                "{0}\n{1}".format(mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB,str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))
            try:
                shutil.copytree(QOvvPlxMDHbFpCoYrOqRjYMJhNntzUik,mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB)
            except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                raise Exception("unable to copy files from worker dir: " + \
                                "{0} to new worker dir: {1}\n{2}".format(QOvvPlxMDHbFpCoYrOqRjYMJhNntzUik,mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB,str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))
        elif os.path.exists(mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB) and qlFDMLjHipagliBxLysJLvlVlSeEixrg is True:
            try:
                shutil.copyfile(BYaYtZKBdzsgkWMQodlWTeqGTwsiPOWb, os.path.join(mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB, BYaYtZKBdzsgkWMQodlWTeqGTwsiPOWb))
            except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                raise Exception("unable to copy *.pst from main worker: " + \
                                "{0} to new worker dir: {1}\n{2}".format(QOvvPlxMDHbFpCoYrOqRjYMJhNntzUik,mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB,str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))
        else:
            try:
                shutil.copytree(QOvvPlxMDHbFpCoYrOqRjYMJhNntzUik,mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB)
            except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                raise Exception("unable to copy files from worker dir: " + \
                                "{0} to new worker dir: {1}\n{2}".format(QOvvPlxMDHbFpCoYrOqRjYMJhNntzUik,mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB,str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))
        if copy_files is not None and qlFDMLjHipagliBxLysJLvlVlSeEixrg is True:
            try:
                for f in copy_files:
                    shutil.copyfile(f, os.path.join(mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB, f))
            except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                raise Exception("unable to copy *.pst from main worker: " + \
                                "{0} to new worker dir: {1}\n{2}".format(QOvvPlxMDHbFpCoYrOqRjYMJhNntzUik, mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB,str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))
        jcNfPllrbHNUnSqPBWkhFLKrXBneyqUW = mpSyQhZYKCXYKfNFGNpFBUvVEUcLFDfB
        os.chdir(jcNfPllrbHNUnSqPBWkhFLKrXBneyqUW)
        os.system("start cmd /k beopest64 {0} /h {1}".format(BYaYtZKBdzsgkWMQodlWTeqGTwsiPOWb, ZXtBfPcCChUsqLjBsLmiIzQfbMlsmUpN))
