import numpy as np
import datetime
import os
class QFaNSBiGrOOnaWiWccfcewhOOcxfHsQs:
    def __init__(self) -> None:
        pass
    @staticmethod
    def plIEfnRqZUKUKFxGlEqtQnMKJQUNKjzO(sims, obds):
        MaxEKyZsdhRXacLfKzAlmuIDYiIucRCR = 1 - (
                np.sum((obds - sims) ** 2, OgXfQJVecXQhSxkBUlhpOuzeXSHWRJxo=0, dtype=np.float64)
                / np.sum((obds - np.mean(obds)) ** 2, dtype=np.float64)
        )
        return round(MaxEKyZsdhRXacLfKzAlmuIDYiIucRCR, 4)
    @staticmethod
    def TcuOYdDPTzEWPIEWEQUsokCgNQMizzLn(sims, obds):
        iLRVNKrVlCUEclWYLTofyreMpEbaZBTt = np.sqrt(np.mean((obds - sims) ** 2,
                                OgXfQJVecXQhSxkBUlhpOuzeXSHWRJxo=0, dtype=np.float64))
        return round(iLRVNKrVlCUEclWYLTofyreMpEbaZBTt, 4)
    @staticmethod
    def YwLSIwNakSCDNHXbjtKVYivCxMCnBXGl(sims, obds):
        xzhmPqFuNVdUtEDvFCruneOjHNGtGSBC = (100 * np.sum(obds - sims, OgXfQJVecXQhSxkBUlhpOuzeXSHWRJxo=0, dtype=np.float64)
                / np.sum(obds))
        return round(xzhmPqFuNVdUtEDvFCruneOjHNGtGSBC, 4)
    @staticmethod
    def OzHcsYNAyVbcddkPsMjSLdKqQXBVBXMr(sims, obds):
        lAGwkcWWPZGcZHeNylXPDOoDtZcrFEUK = (
            (
                (sum((obds - obds.mean())*(sims-sims.mean())))**2
            ) 
            /
            (
                (sum((obds - obds.mean())**2)* (sum((sims-sims.mean())**2))
            ))
        )
        return round(lAGwkcWWPZGcZHeNylXPDOoDtZcrFEUK, 4)
class GaAyAynraHeegRfeYWJpBXQfAMXRTMXm:
    def __init__(self) -> None:
        pass
    def DHihYoQjMEUmckmHUlhNfrQCilUQXFha(self):
        kEhDEpQzmyUwokJUeoFIjVPrgyqEkJTQ = self.dirs_and_paths()
        PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR = kEhDEpQzmyUwokJUeoFIjVPrgyqEkJTQ['apexmf_model']
        if os.path.isfile(os.path.join(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR, "APEXCONT.DAT")):
            with open(os.path.join(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR, 'APEXCONT.DAT'), "r") as f:
                IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw = [FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp.strip().split() for FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp in f if FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp.strip()]
            BSurSckitAbHNIZRhnXmjYjAhCANnjAf = int(IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw[0][0])
            AMCwgJjdkqpyGgejcaUnIKqbxMHrQiVg = int(IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw[0][1])
            BcSYwrWYZcGEAcXrUKttCLzOrzUqbsvO = int(IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw[0][2])
            PDJkecBjXmJvfMDGNzLAkzpKgoUYgEte = int(IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw[0][3])
            ubcoSKozcBHLrmpexcxFtYcefPkMrTIs = int(IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw[0][4])
            VVZmJXbNBOCYeRwTHpeNlQIPvduPLpRw = AMCwgJjdkqpyGgejcaUnIKqbxMHrQiVg + BSurSckitAbHNIZRhnXmjYjAhCANnjAf -1
            acHZPxFsxSffqckKlumpETMaaIOUXoNB = datetime.datetime(AMCwgJjdkqpyGgejcaUnIKqbxMHrQiVg, BcSYwrWYZcGEAcXrUKttCLzOrzUqbsvO, 1) + datetime.timedelta(PDJkecBjXmJvfMDGNzLAkzpKgoUYgEte - 1)
            PBYXtGIMrOoDbIKPDXRikddmhJMyllwE = datetime.datetime(VVZmJXbNBOCYeRwTHpeNlQIPvduPLpRw, 12, 31)
            blTghiUrTeLmGOBDvoqcnzBHiYCbwOQO = acHZPxFsxSffqckKlumpETMaaIOUXoNB.strftime("%m/%d/%Y")
            MmZeDVcwvBLvlGMsjFigdBXzIyYeINIW = PBYXtGIMrOoDbIKPDXRikddmhJMyllwE.strftime("%m/%d/%Y")
            return blTghiUrTeLmGOBDvoqcnzBHiYCbwOQO, MmZeDVcwvBLvlGMsjFigdBXzIyYeINIW, ptcode