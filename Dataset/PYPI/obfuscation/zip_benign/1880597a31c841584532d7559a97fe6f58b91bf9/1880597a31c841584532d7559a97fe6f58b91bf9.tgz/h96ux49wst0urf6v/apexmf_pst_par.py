import os
import shutil
import glob
from datetime import datetime
import pandas as pd
from pyemu.pst.pst_utils import SFMT,IFMT,FFMT
import numpy as np
PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR = os.getcwd()
os.chdir(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR)
def aElfoXppYTkjrZPlVAxDthegZwGmBQOE(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR, chns, qQPaQIMxJsdooXhILgOaflxMNHbKZwMz=None, PMRkwxQhYgkVBHqTFVnbXMfajaCWTAWZ=None, MPnIeVsyLJOFLBrPGVxPvMtNwiokIvIu=None, EIBnWFfsaIHXrddqyqcHvdrhTNJwvaKr=None):
    os.chdir(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR)
    if PMRkwxQhYgkVBHqTFVnbXMfajaCWTAWZ is None:
        PMRkwxQhYgkVBHqTFVnbXMfajaCWTAWZ =  ['rivcd_{}'.format(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp) for FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp in chns]
    if MPnIeVsyLJOFLBrPGVxPvMtNwiokIvIu is None:
        MPnIeVsyLJOFLBrPGVxPvMtNwiokIvIu =  ['rivbot_{}'.format(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp) for FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp in chns]
    if qQPaQIMxJsdooXhILgOaflxMNHbKZwMz is None:
        qQPaQIMxJsdooXhILgOaflxMNHbKZwMz = 'unfchg'
    if EIBnWFfsaIHXrddqyqcHvdrhTNJwvaKr is None:
        EIBnWFfsaIHXrddqyqcHvdrhTNJwvaKr = 0.001
    QfSTCimHjGtAaKmFcXqWxtGeYRSjrfqr = PMRkwxQhYgkVBHqTFVnbXMfajaCWTAWZ + MPnIeVsyLJOFLBrPGVxPvMtNwiokIvIu
    mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB = pd.DataFrame()
    mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB['parnme'] = QfSTCimHjGtAaKmFcXqWxtGeYRSjrfqr
    mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB['chg_type'] = qQPaQIMxJsdooXhILgOaflxMNHbKZwMz
    mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB['val'] = EIBnWFfsaIHXrddqyqcHvdrhTNJwvaKr
    mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB.index = mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB.parnme
    with open('mf_riv.par', 'w') as f:
        f.write("# modflow_par file.\n")
        f.write("NAME   CHG_TYPE    VAL\n")
        f.write(
            mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB.loc[:, ["parnme", "chg_type", "val"]].to_string(
                                                        HjmjXniWvVfMzgtGlgbMayPkVOvKDSyL=0,
                                                        uhRMcnXCkFRPfWYNaPrPDtiHOSebMINH=[SFMT, SFMT, SFMT],
                                                        index=False,
                                                        lMRlaNApGTntLyCiinIcllWUqdNcQeVc=False,
                                                        YbjyhmclCxPqPXvvfuvVfXzKcLWyrZka="left")
            )
    print("'mf_riv.par' file has been exported to the MODFLOW working directory!")
    return mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB
def ldFokkJLkMuewCKBcmBWIQuEoUpjNSMW(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR):
    os.chdir(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR)
    DZCNglVsoCaZfemhQmlteVrRXEUtwdnb = pd.read_csv('mf_riv.par', litrZTOxkDMQONopjRPXEwPHqlnFkgwo=r'\s+', sNZcjLwePglwMbhVpnmiFltQhShjcdsK='#', index_col=0)
    DZCNglVsoCaZfemhQmlteVrRXEUtwdnb['par_type'] = [FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp.split('_')[0] for FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp in DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.index]
    DZCNglVsoCaZfemhQmlteVrRXEUtwdnb['chn_no'] = [FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp.split('_')[1] for FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp in DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.index]
    return DZCNglVsoCaZfemhQmlteVrRXEUtwdnb
def ZKTxMCqQfPGfxGNldBDSaMIzhlApaoMQ(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR):
    os.chdir(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR)
    EaKAXPpukwiJiNFWWmNhcxZEuFoPKyvo = [f for f in glob.glob(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR + "/*.riv")]
    if len(EaKAXPpukwiJiNFWWmNhcxZEuFoPKyvo) == 1:
        QfSTCimHjGtAaKmFcXqWxtGeYRSjrfqr = os.path.basename(EaKAXPpukwiJiNFWWmNhcxZEuFoPKyvo[0])
        if not os.path.exists('riv_package.org'):
            shutil.copy(QfSTCimHjGtAaKmFcXqWxtGeYRSjrfqr, 'riv_package.org')
            print('The original river package "{}" has been backed up...'.format(QfSTCimHjGtAaKmFcXqWxtGeYRSjrfqr))
        else:
            print('The "riv_package.org" file already exists...')
        with open('riv_package.org') as f:
            PYyDUNWYntuCunvIyqNDSjVKjdaxvnSB = f.readline()
            TEYIeVasnsSEpUNNxyHIIwzRtbtlRZOQ = f.readline()
            czdFdJqmjSyHpXCpIbuStFpZOcdOrLmB = f.readline()
        GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL = pd.read_csv('riv_package.org', litrZTOxkDMQONopjRPXEwPHqlnFkgwo=r'\s+', ixDVzsxrKELjjTIkmlewsjeCWnapKmnk=3, lMRlaNApGTntLyCiinIcllWUqdNcQeVc=None)
        DZCNglVsoCaZfemhQmlteVrRXEUtwdnb = ldFokkJLkMuewCKBcmBWIQuEoUpjNSMW(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR)
        for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in range(len(DZCNglVsoCaZfemhQmlteVrRXEUtwdnb)):
            if DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 2] == 'rivcd':
                hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS = GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL[GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[:, -1] == DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 3]]
                if DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 0] == 'pctchg':
                    YdmmvEDLPKTvjTdKQwNhsuiOLbNWmgZm = hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS.iloc[:, 4] + (hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS.iloc[:, 4] * float(DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 1]) / 100)
                elif DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 0] == 'unfchg':
                    YdmmvEDLPKTvjTdKQwNhsuiOLbNWmgZm = hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS.iloc[:, 4] + float(DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 1])
                else:
                    hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS.iloc[:, 4] = float(DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 1])
                    YdmmvEDLPKTvjTdKQwNhsuiOLbNWmgZm = hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS.iloc[:, 4]
                count = 0
                for KItnZpuMYJrEORIoDuefWfBiuzIrgQUm in range(len(GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL)):
                    if GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[KItnZpuMYJrEORIoDuefWfBiuzIrgQUm, -1] == DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 3]:
                        GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[KItnZpuMYJrEORIoDuefWfBiuzIrgQUm, 4] = YdmmvEDLPKTvjTdKQwNhsuiOLbNWmgZm.iloc[count]
                        count += 1
            elif DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 2] == 'rivbot':
                hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS = GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL[GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[:, -1] == DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 3]]
                if DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 0] == 'pctchg':
                    hFWNIQJUdnaKbRRQGmqfnJtBKwiGTpms = hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS.iloc[:, 5] + (hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS.iloc[:, 4] * float(DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 1]) / 100)
                elif DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 0] == 'unfchg':
                    hFWNIQJUdnaKbRRQGmqfnJtBKwiGTpms = hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS.iloc[:, 5] + float(DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 1])
                else:
                    hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS.iloc[:, 5] = float(DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 1])
                    hFWNIQJUdnaKbRRQGmqfnJtBKwiGTpms = hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS.iloc[:, 5]
                count = 0
                for KItnZpuMYJrEORIoDuefWfBiuzIrgQUm in range(len(GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL)):
                    if GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[KItnZpuMYJrEORIoDuefWfBiuzIrgQUm, -1] == DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 3]:
                        GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[KItnZpuMYJrEORIoDuefWfBiuzIrgQUm, 5] = hFWNIQJUdnaKbRRQGmqfnJtBKwiGTpms.iloc[count]
                        count += 1
        GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[:, 4] = GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[:, 4].map(lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp: '{:.10e}'.format(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp))
        GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[:, 3] = GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[:, 3].map(lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp: '{:.10e}'.format(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp))
        GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[:, 5] = GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[:, 5].map(lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp: '{:.10e}'.format(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp))
        paYCCjKxMjIBhgyYmEGMkrxJhByrdhQz = "version 1.2."
        ugBvoulFmhSGSGuoCSnhMqAfwsgPGGOe = datetime.now().strftime('- %m/%d/%y %H:%M:%S -')
        with open(QfSTCimHjGtAaKmFcXqWxtGeYRSjrfqr, 'w') as f:
            f.write("# RIV: River package file is parameterized. " + paYCCjKxMjIBhgyYmEGMkrxJhByrdhQz + ugBvoulFmhSGSGuoCSnhMqAfwsgPGGOe + "\n")
            f.write(PYyDUNWYntuCunvIyqNDSjVKjdaxvnSB)
            f.write(TEYIeVasnsSEpUNNxyHIIwzRtbtlRZOQ)
            f.write(czdFdJqmjSyHpXCpIbuStFpZOcdOrLmB)
            GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.to_csv(
                        f, litrZTOxkDMQONopjRPXEwPHqlnFkgwo='\t',
                        lMRlaNApGTntLyCiinIcllWUqdNcQeVc=False,
                        index=False,
                        aubUhrfolUVvDKTnbLbvGvXbWlnllVjp='\n',
                        kAnUtOBCruNMXqmimeUoUhknuriotKBY='utf-8'
                        )
        print(os.path.basename(QfSTCimHjGtAaKmFcXqWxtGeYRSjrfqr) + " file is overwritten successfully!")
    elif len(EaKAXPpukwiJiNFWWmNhcxZEuFoPKyvo) > 1:
        print(
                "You have more than one River Package file!("+str(len(EaKAXPpukwiJiNFWWmNhcxZEuFoPKyvo))+")"+"\n"
                + str(EaKAXPpukwiJiNFWWmNhcxZEuFoPKyvo)+"\n"
                + "Solution: Keep only one file!")
    else:
        print("File Not Found! - We couldn't find your *.riv file.")
def oAOvAILmDeTLOGdZRNwbiSdPJlpmmhzr(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR):
    os.chdir(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR)
    EaKAXPpukwiJiNFWWmNhcxZEuFoPKyvo = [f for f in glob.glob(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR + "/*.riv")]
    if len(EaKAXPpukwiJiNFWWmNhcxZEuFoPKyvo) == 1:
        QfSTCimHjGtAaKmFcXqWxtGeYRSjrfqr = os.path.basename(EaKAXPpukwiJiNFWWmNhcxZEuFoPKyvo[0])
        if not os.path.exists('riv_package.org'):
            shutil.copy(QfSTCimHjGtAaKmFcXqWxtGeYRSjrfqr, 'riv_package.org')
            print('The original river package "{}" has been backed up...'.format(QfSTCimHjGtAaKmFcXqWxtGeYRSjrfqr))
        else:
            print('The "riv_package.org" file already exists...')
        with open('riv_package.org') as f:
            PYyDUNWYntuCunvIyqNDSjVKjdaxvnSB = f.readline()
            TEYIeVasnsSEpUNNxyHIIwzRtbtlRZOQ = f.readline()
            czdFdJqmjSyHpXCpIbuStFpZOcdOrLmB = f.readline()
        GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL = pd.read_csv('riv_package.org', litrZTOxkDMQONopjRPXEwPHqlnFkgwo=r'\s+', ixDVzsxrKELjjTIkmlewsjeCWnapKmnk=3, lMRlaNApGTntLyCiinIcllWUqdNcQeVc=None)
        DZCNglVsoCaZfemhQmlteVrRXEUtwdnb = ldFokkJLkMuewCKBcmBWIQuEoUpjNSMW(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR)
        for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in range(len(DZCNglVsoCaZfemhQmlteVrRXEUtwdnb)):
            if DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 2] == 'rivcd':
                if DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 3][0] != 'g':
                    hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS = GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL[GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[:, -3] == int(DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 3])]
                else:
                    hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS = GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL[GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[:, -1] == DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 3]]
                if DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 0] == 'pctchg':
                    YdmmvEDLPKTvjTdKQwNhsuiOLbNWmgZm = hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS.iloc[:, 4] + (hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS.iloc[:, 4] * float(DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 1]) / 100)
                elif DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 0] == 'unfchg':
                    YdmmvEDLPKTvjTdKQwNhsuiOLbNWmgZm = hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS.iloc[:, 4] + float(DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 1])
                else:
                    hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS.iloc[:, 4] = float(DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 1])
                    YdmmvEDLPKTvjTdKQwNhsuiOLbNWmgZm = hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS.iloc[:, 4]
                if DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 3][0] != 'g':         
                    count = 0
                    for KItnZpuMYJrEORIoDuefWfBiuzIrgQUm in range(len(GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL)):
                        if GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[KItnZpuMYJrEORIoDuefWfBiuzIrgQUm, -3] == int(DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 3]):
                            GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[KItnZpuMYJrEORIoDuefWfBiuzIrgQUm, 4] = YdmmvEDLPKTvjTdKQwNhsuiOLbNWmgZm.iloc[count]
                            count += 1
                else:
                    count = 0
                    for KItnZpuMYJrEORIoDuefWfBiuzIrgQUm in range(len(GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL)):
                        if GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[KItnZpuMYJrEORIoDuefWfBiuzIrgQUm, -1] == DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 3]:
                            GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[KItnZpuMYJrEORIoDuefWfBiuzIrgQUm, 4] = YdmmvEDLPKTvjTdKQwNhsuiOLbNWmgZm.iloc[count]
                            count += 1                
            elif DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 2] == 'rivbot':
                if DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 3][0] != 'g':
                    hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS = GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL[GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[:, -3] == int(DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 3])]
                else:
                    hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS = GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL[GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[:, -1] == DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 3]]
                if DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 0] == 'pctchg':
                    hFWNIQJUdnaKbRRQGmqfnJtBKwiGTpms = hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS.iloc[:, 5] + (hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS.iloc[:, 4] * float(DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 1]) / 100)
                elif DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 0] == 'unfchg':
                    hFWNIQJUdnaKbRRQGmqfnJtBKwiGTpms = hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS.iloc[:, 5] + float(DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 1])
                else:
                    hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS.iloc[:, 5] = float(DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 1])
                    hFWNIQJUdnaKbRRQGmqfnJtBKwiGTpms = hulRXzdnBjVlWDEKsHMQpaMYvCuzrkdS.iloc[:, 5]
                if DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 3][0] != 'g':
                    count = 0
                    for KItnZpuMYJrEORIoDuefWfBiuzIrgQUm in range(len(GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL)):
                        if GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[KItnZpuMYJrEORIoDuefWfBiuzIrgQUm, -3] == int(DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 3]):
                            GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[KItnZpuMYJrEORIoDuefWfBiuzIrgQUm, 5] = hFWNIQJUdnaKbRRQGmqfnJtBKwiGTpms.iloc[count]
                            count += 1
                else:
                    count = 0
                    for KItnZpuMYJrEORIoDuefWfBiuzIrgQUm in range(len(GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL)):
                        if GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[KItnZpuMYJrEORIoDuefWfBiuzIrgQUm, -1] == DZCNglVsoCaZfemhQmlteVrRXEUtwdnb.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 3]:
                            GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[KItnZpuMYJrEORIoDuefWfBiuzIrgQUm, 5] = hFWNIQJUdnaKbRRQGmqfnJtBKwiGTpms.iloc[count]
                            count += 1
        GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[:, 4] = GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[:, 4].map(lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp: '{:.10e}'.format(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp))
        GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[:, 3] = GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[:, 3].map(lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp: '{:.10e}'.format(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp))
        GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[:, 5] = GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[:, 5].map(lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp: '{:.10e}'.format(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp))
        GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[:, -2] = GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.iloc[:, -2].map(lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp: '{:.10e}'.format(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp))
        paYCCjKxMjIBhgyYmEGMkrxJhByrdhQz = "version 1.2."
        ugBvoulFmhSGSGuoCSnhMqAfwsgPGGOe = datetime.now().strftime('- %m/%d/%y %H:%M:%S -')
        with open(QfSTCimHjGtAaKmFcXqWxtGeYRSjrfqr, 'w') as f:
            f.write("# RIV: River package file is parameterized. " + paYCCjKxMjIBhgyYmEGMkrxJhByrdhQz + ugBvoulFmhSGSGuoCSnhMqAfwsgPGGOe + "\n")
            f.write(PYyDUNWYntuCunvIyqNDSjVKjdaxvnSB)
            f.write(TEYIeVasnsSEpUNNxyHIIwzRtbtlRZOQ)
            f.write(czdFdJqmjSyHpXCpIbuStFpZOcdOrLmB)
            GjvbMcKQrJCOJyhpxRMBrktHjtnyznQL.to_csv(
                        f, litrZTOxkDMQONopjRPXEwPHqlnFkgwo='\t',
                        lMRlaNApGTntLyCiinIcllWUqdNcQeVc=False,
                        index=False,
                        KtDWybxVskqQYiDkfDMCoPxiHdxALRoA='\n',
                        kAnUtOBCruNMXqmimeUoUhknuriotKBY='utf-8'
                        )
        print(os.path.basename(QfSTCimHjGtAaKmFcXqWxtGeYRSjrfqr) + " file is overwritten successfully!")
    elif len(EaKAXPpukwiJiNFWWmNhcxZEuFoPKyvo) > 1:
        print(
                "You have more than one River Package file!("+str(len(EaKAXPpukwiJiNFWWmNhcxZEuFoPKyvo))+")"+"\n"
                + str(EaKAXPpukwiJiNFWWmNhcxZEuFoPKyvo)+"\n"
                + "Solution: Keep only one file!")
    else:
        print("File Not Found! - We couldn't find your *.riv file.")
def oYEAAZPauRSvJdyVXfhVUgUilQKjIeSK(uGHFEdxekbdTGZOsxKWKQLnnUAAaUdjv=None, xNUkNdZDsVQZQrckkvZyqWeGxvfdRrpG=None, YSBqWRyaaovIdrMAyOOIgyzCZaaPYlEi=None):
    if uGHFEdxekbdTGZOsxKWKQLnnUAAaUdjv is None:
        uGHFEdxekbdTGZOsxKWKQLnnUAAaUdjv = "PARM1501.DAT"
    if xNUkNdZDsVQZQrckkvZyqWeGxvfdRrpG is None:
        xNUkNdZDsVQZQrckkvZyqWeGxvfdRrpG = "apex.parm.xlsx"
    if YSBqWRyaaovIdrMAyOOIgyzCZaaPYlEi is None:
        YSBqWRyaaovIdrMAyOOIgyzCZaaPYlEi = uGHFEdxekbdTGZOsxKWKQLnnUAAaUdjv + ".tpl"
    McDotYjguSoTgLouSCexNDvhFdMXWoFG = pd.read_excel(xNUkNdZDsVQZQrckkvZyqWeGxvfdRrpG, rcyOWgBucQJlmGZskXiHBcVOJLkbgnQH=[0, 7], index_col=0, sNZcjLwePglwMbhVpnmiFltQhShjcdsK="#", engine="openpyxl")
    McDotYjguSoTgLouSCexNDvhFdMXWoFG = McDotYjguSoTgLouSCexNDvhFdMXWoFG.loc[McDotYjguSoTgLouSCexNDvhFdMXWoFG.index.notnull()]
    McDotYjguSoTgLouSCexNDvhFdMXWoFG['temp_idx'] = McDotYjguSoTgLouSCexNDvhFdMXWoFG.index
    McDotYjguSoTgLouSCexNDvhFdMXWoFG['idx'] = 0
    for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in range(len(McDotYjguSoTgLouSCexNDvhFdMXWoFG)):
        McDotYjguSoTgLouSCexNDvhFdMXWoFG.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 2] = int(McDotYjguSoTgLouSCexNDvhFdMXWoFG.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 1][1:]) 
    McDotYjguSoTgLouSCexNDvhFdMXWoFG = McDotYjguSoTgLouSCexNDvhFdMXWoFG.sort_values(by=['idx'])    
    vLyxAwlsOuDGBAYSYUboWkmnSHIrpQIU = McDotYjguSoTgLouSCexNDvhFdMXWoFG[McDotYjguSoTgLouSCexNDvhFdMXWoFG['flag'] == 'y'].index.tolist()
    with open(uGHFEdxekbdTGZOsxKWKQLnnUAAaUdjv, 'r') as f:
        KDQDSAtQQxvCDaPNPwksWByTCTzISoUc = f.readlines()
    CJviXjvWLBlOODvzlKjHmxVOoPipvbrU = [FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp.rstrip() for FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp in KDQDSAtQQxvCDaPNPwksWByTCTzISoUc[:35]] 
    AqqbjKEMkoUnfvzTFGEEUHUPECreOdGP = [FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp.strip() for FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp in KDQDSAtQQxvCDaPNPwksWByTCTzISoUc[35:46]]
    hqxQlmmsFlYWyQqCGYnzeOicSwAosKTR = [FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp.rstrip() for FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp in KDQDSAtQQxvCDaPNPwksWByTCTzISoUc[46:]]
    vlWTwNncDzynMXWhmXZqZybIKLOiCwLY = []
    for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in AqqbjKEMkoUnfvzTFGEEUHUPECreOdGP:
        for KItnZpuMYJrEORIoDuefWfBiuzIrgQUm in raTwYUncqiBWINHTjrAyJSZMGtSFDHkz.split():
            vlWTwNncDzynMXWhmXZqZybIKLOiCwLY.append(KItnZpuMYJrEORIoDuefWfBiuzIrgQUm)
    McDotYjguSoTgLouSCexNDvhFdMXWoFG['nam'] = McDotYjguSoTgLouSCexNDvhFdMXWoFG.index.tolist()
    McDotYjguSoTgLouSCexNDvhFdMXWoFG['value'] = vlWTwNncDzynMXWhmXZqZybIKLOiCwLY
    McDotYjguSoTgLouSCexNDvhFdMXWoFG['tpl'] = np.where(
        McDotYjguSoTgLouSCexNDvhFdMXWoFG['flag'] == 'n',
        McDotYjguSoTgLouSCexNDvhFdMXWoFG['value'].apply(lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp:"{0:>7s}".format(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp)),
        McDotYjguSoTgLouSCexNDvhFdMXWoFG.nam.apply(lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp:"~{0:5s}~".format(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp))
        )
    ClUYbguNWsBAiiqBLrTzVyeMqiheQaPv = McDotYjguSoTgLouSCexNDvhFdMXWoFG.tpl.tolist()
    ivMmLsQiXpTLKPVwWuWEpeXbJZDKzBOG = np.reshape(ClUYbguNWsBAiiqBLrTzVyeMqiheQaPv, (11, 10))
    yvqrfCgFmPSIcXkTkOfSoRxfkQaIxZlw = pd.DataFrame(ivMmLsQiXpTLKPVwWuWEpeXbJZDKzBOG)
    yvqrfCgFmPSIcXkTkOfSoRxfkQaIxZlw.iloc[:, 0] = yvqrfCgFmPSIcXkTkOfSoRxfkQaIxZlw.iloc[:, 0].apply(lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp:"{0:>8s}".format(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp))
    YSBqWRyaaovIdrMAyOOIgyzCZaaPYlEi = uGHFEdxekbdTGZOsxKWKQLnnUAAaUdjv + ".tpl"
    with open(YSBqWRyaaovIdrMAyOOIgyzCZaaPYlEi, 'w') as f:
        f.write("ptf ~\n")
        for KIPbooduXqmXfitBModZmjFkjIOWaDxM in CJviXjvWLBlOODvzlKjHmxVOoPipvbrU:
            f.write(KIPbooduXqmXfitBModZmjFkjIOWaDxM + '\n')
        f.write(yvqrfCgFmPSIcXkTkOfSoRxfkQaIxZlw.to_string(
                                    HjmjXniWvVfMzgtGlgbMayPkVOvKDSyL=0,
                                    index=False,
                                    lMRlaNApGTntLyCiinIcllWUqdNcQeVc=False,
                                    YbjyhmclCxPqPXvvfuvVfXzKcLWyrZka="right"
                                    ))
        f.write('\n')
        for KIPbooduXqmXfitBModZmjFkjIOWaDxM in hqxQlmmsFlYWyQqCGYnzeOicSwAosKTR:
            f.write(KIPbooduXqmXfitBModZmjFkjIOWaDxM + '\n')
    return yvqrfCgFmPSIcXkTkOfSoRxfkQaIxZlw
def UaGyWLvbYmFicAQfXxqDbLosOdUmDwyQ(par):
    McDotYjguSoTgLouSCexNDvhFdMXWoFG =  pd.read_excel(
        "apex.parm.xlsx", index_col=0, rcyOWgBucQJlmGZskXiHBcVOJLkbgnQH=[FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp for FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp in range(8)],
        sNZcjLwePglwMbhVpnmiFltQhShjcdsK='#', engine='openpyxl', na_values=[-999, '']
        )
    vLyxAwlsOuDGBAYSYUboWkmnSHIrpQIU = McDotYjguSoTgLouSCexNDvhFdMXWoFG[McDotYjguSoTgLouSCexNDvhFdMXWoFG['flag'] == 'y']
    dJzPZZPRornRCSMYhSMLDGrIakbovtjg = pd.concat([par, vLyxAwlsOuDGBAYSYUboWkmnSHIrpQIU], OgXfQJVecXQhSxkBUlhpOuzeXSHWRJxo=1)
    dJzPZZPRornRCSMYhSMLDGrIakbovtjg['parval1'] = np.where((dJzPZZPRornRCSMYhSMLDGrIakbovtjg.default_initial.isna()), dJzPZZPRornRCSMYhSMLDGrIakbovtjg.parval1, dJzPZZPRornRCSMYhSMLDGrIakbovtjg.default_initial)
    dJzPZZPRornRCSMYhSMLDGrIakbovtjg['parval1'] = np.where((dJzPZZPRornRCSMYhSMLDGrIakbovtjg.cali_initial.isna()), dJzPZZPRornRCSMYhSMLDGrIakbovtjg.parval1, dJzPZZPRornRCSMYhSMLDGrIakbovtjg.cali_initial)
    dJzPZZPRornRCSMYhSMLDGrIakbovtjg['parval1'] = np.where((dJzPZZPRornRCSMYhSMLDGrIakbovtjg.parval1 == 0), 0.00001, dJzPZZPRornRCSMYhSMLDGrIakbovtjg.parval1)
    dJzPZZPRornRCSMYhSMLDGrIakbovtjg['parlbnd'] = np.where((dJzPZZPRornRCSMYhSMLDGrIakbovtjg.cali_lower.isna()), dJzPZZPRornRCSMYhSMLDGrIakbovtjg.parlbnd, dJzPZZPRornRCSMYhSMLDGrIakbovtjg.cali_lower)
    dJzPZZPRornRCSMYhSMLDGrIakbovtjg['parlbnd'] = np.where((dJzPZZPRornRCSMYhSMLDGrIakbovtjg.absolute_lower.isna()), dJzPZZPRornRCSMYhSMLDGrIakbovtjg.parlbnd, dJzPZZPRornRCSMYhSMLDGrIakbovtjg.absolute_lower)
    dJzPZZPRornRCSMYhSMLDGrIakbovtjg['parlbnd'] = np.where((dJzPZZPRornRCSMYhSMLDGrIakbovtjg.parlbnd == 0), 0.00001, dJzPZZPRornRCSMYhSMLDGrIakbovtjg.parlbnd)
    dJzPZZPRornRCSMYhSMLDGrIakbovtjg['parubnd'] = np.where((dJzPZZPRornRCSMYhSMLDGrIakbovtjg.cali_upper.isna()), dJzPZZPRornRCSMYhSMLDGrIakbovtjg.parubnd, dJzPZZPRornRCSMYhSMLDGrIakbovtjg.cali_upper)
    dJzPZZPRornRCSMYhSMLDGrIakbovtjg['parubnd'] = np.where((dJzPZZPRornRCSMYhSMLDGrIakbovtjg.absolute_upper.isna()), dJzPZZPRornRCSMYhSMLDGrIakbovtjg.parubnd, dJzPZZPRornRCSMYhSMLDGrIakbovtjg.absolute_upper)
    ijbuGeZZAlIRoidNvZNKtNVRylVzuiAf =  dJzPZZPRornRCSMYhSMLDGrIakbovtjg.dropna(OgXfQJVecXQhSxkBUlhpOuzeXSHWRJxo=1)
    return ijbuGeZZAlIRoidNvZNKtNVRylVzuiAf
def inDgZemmnxnViZcVyLjqZAjxXMfvPUXr(par):
    xCWCmUHnZiFuHmQiJGaRejwhrWKBeIwn = pd.read_csv(
                        'MODFLOW/hk0pp.dat',
                        litrZTOxkDMQONopjRPXEwPHqlnFkgwo=r'\s+',
                        rcyOWgBucQJlmGZskXiHBcVOJLkbgnQH=[4],
                        EjJRFWbMJGAdmvYxeZlzdQQoIDhhrtyA=['hk_temp']
                        )
    xCWCmUHnZiFuHmQiJGaRejwhrWKBeIwn.index = [f"hk{i:03d}" for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in range(len(xCWCmUHnZiFuHmQiJGaRejwhrWKBeIwn))]
    dJzPZZPRornRCSMYhSMLDGrIakbovtjg = pd.concat([par, xCWCmUHnZiFuHmQiJGaRejwhrWKBeIwn], OgXfQJVecXQhSxkBUlhpOuzeXSHWRJxo=1)
    dJzPZZPRornRCSMYhSMLDGrIakbovtjg['parval1'] = np.where((dJzPZZPRornRCSMYhSMLDGrIakbovtjg.hk_temp.isna()), dJzPZZPRornRCSMYhSMLDGrIakbovtjg.parval1, dJzPZZPRornRCSMYhSMLDGrIakbovtjg.hk_temp)
    ijbuGeZZAlIRoidNvZNKtNVRylVzuiAf =  dJzPZZPRornRCSMYhSMLDGrIakbovtjg.dropna(OgXfQJVecXQhSxkBUlhpOuzeXSHWRJxo=1)
    return ijbuGeZZAlIRoidNvZNKtNVRylVzuiAf
def KTTkmIhaMQeOcVSqEMNjlPJFpYoNxaWX(par):
    zhBRFRQbXWTVTyWjdjaMXgUoJDyMmFVK = pd.read_csv(
                        'MODFLOW/sy0pp.dat',
                        litrZTOxkDMQONopjRPXEwPHqlnFkgwo=r'\s+',
                        rcyOWgBucQJlmGZskXiHBcVOJLkbgnQH=[4],
                        EjJRFWbMJGAdmvYxeZlzdQQoIDhhrtyA=['sy_temp']
                        )
    zhBRFRQbXWTVTyWjdjaMXgUoJDyMmFVK.index = [f"sy{i:03d}" for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in range(len(zhBRFRQbXWTVTyWjdjaMXgUoJDyMmFVK))]
    dJzPZZPRornRCSMYhSMLDGrIakbovtjg = pd.concat([par, zhBRFRQbXWTVTyWjdjaMXgUoJDyMmFVK], OgXfQJVecXQhSxkBUlhpOuzeXSHWRJxo=1)
    dJzPZZPRornRCSMYhSMLDGrIakbovtjg['parval1'] = np.where((dJzPZZPRornRCSMYhSMLDGrIakbovtjg.sy_temp.isna()), dJzPZZPRornRCSMYhSMLDGrIakbovtjg.parval1, dJzPZZPRornRCSMYhSMLDGrIakbovtjg.sy_temp)
    ijbuGeZZAlIRoidNvZNKtNVRylVzuiAf =  dJzPZZPRornRCSMYhSMLDGrIakbovtjg.dropna(OgXfQJVecXQhSxkBUlhpOuzeXSHWRJxo=1)
    return ijbuGeZZAlIRoidNvZNKtNVRylVzuiAf
def NZFiMlCtFwmdGBVLimcNbOcASxeikDkZ(riv_par_file, YSBqWRyaaovIdrMAyOOIgyzCZaaPYlEi=None):
    if YSBqWRyaaovIdrMAyOOIgyzCZaaPYlEi is None:
        YSBqWRyaaovIdrMAyOOIgyzCZaaPYlEi = riv_par_file + ".tpl"
    mcndJkWVVfCRVURrJMgaBylRsyotQBSV = pd.read_csv(
                        riv_par_file,
                        oJoHvsGSSiXOGKeqNTwBWHsRPdSYSqHO=True,
                        lMRlaNApGTntLyCiinIcllWUqdNcQeVc=None, ixDVzsxrKELjjTIkmlewsjeCWnapKmnk=2,
                        EjJRFWbMJGAdmvYxeZlzdQQoIDhhrtyA=["parnme", "chg_type", "parval1"])
    mcndJkWVVfCRVURrJMgaBylRsyotQBSV.index = mcndJkWVVfCRVURrJMgaBylRsyotQBSV.parnme
    mcndJkWVVfCRVURrJMgaBylRsyotQBSV.loc[:, "tpl"] = mcndJkWVVfCRVURrJMgaBylRsyotQBSV.parnme.apply(lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp: " ~   {0:15s}   ~".format(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp))
    with open(YSBqWRyaaovIdrMAyOOIgyzCZaaPYlEi, 'w') as f:
        f.write("ptf ~\n# modflow_par template file.\n")
        f.write("NAME   CHG_TYPE    VAL\n")
        f.write(mcndJkWVVfCRVURrJMgaBylRsyotQBSV.loc[:, ["parnme", "chg_type", "tpl"]].to_string(
                                                        HjmjXniWvVfMzgtGlgbMayPkVOvKDSyL=0,
                                                        uhRMcnXCkFRPfWYNaPrPDtiHOSebMINH=[SFMT, SFMT, SFMT],
                                                        index=False,
                                                        lMRlaNApGTntLyCiinIcllWUqdNcQeVc=False,
                                                        YbjyhmclCxPqPXvvfuvVfXzKcLWyrZka="left"))
    return mcndJkWVVfCRVURrJMgaBylRsyotQBSV
def lISGpASbtLyxeWkNVtGWbsaORWpRWevh():
    EanIGjApUyBNzzITgohpLwlNxdqGogdu = pd.read_csv('CROPCOM.DAT', litrZTOxkDMQONopjRPXEwPHqlnFkgwo='\t', index_col=0)
    print(EanIGjApUyBNzzITgohpLwlNxdqGogdu)
def ldQspGjnfWQlpDkbKVeYdlkHrIurAlAb():
    YrEfFRuicukgrqNvpTGwZyarFrxyPsee = lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp: "{0:>5s}".format(str(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp))
    VIiapgvaSYiGwAxRUwoEDfzTUOnzhKNy = lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp: "{0:>4s}".format(str(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp))
    LFYulGKEtFuwtgAxtTbBVUHjoWuhxJWQ = lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp: "{0:>7.2f}".format(float(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp))
    HcKXvniURlUZrJlAyOSBzUGsAAzBBnOv = lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp: "{0:>7.3f}".format(float(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp))
    cfNQbhTqxRfAuVrPypSfCveNTgbzfNGm = lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp: "{0:>7.4f}".format(float(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp))
    XnopHwbsgEHcxNcflTFUSSadYoogMPQn = lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp: "{0:>7d}".format(int(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp))
    return YrEfFRuicukgrqNvpTGwZyarFrxyPsee, VIiapgvaSYiGwAxRUwoEDfzTUOnzhKNy, LFYulGKEtFuwtgAxtTbBVUHjoWuhxJWQ, HcKXvniURlUZrJlAyOSBzUGsAAzBBnOv, cfNQbhTqxRfAuVrPypSfCveNTgbzfNGm, XnopHwbsgEHcxNcflTFUSSadYoogMPQn
def inCcVzscMTAWnTjtIdtrtLPQblWYQfvy():
    bdDzMvkuIikZVvwmcGjSuxRqxQbQSlov = pd.read_csv(
            'CROPCOM.DAT',
            ixDVzsxrKELjjTIkmlewsjeCWnapKmnk=2, 
            lMRlaNApGTntLyCiinIcllWUqdNcQeVc=None,
            litrZTOxkDMQONopjRPXEwPHqlnFkgwo=r'\s+',
            rcyOWgBucQJlmGZskXiHBcVOJLkbgnQH=[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in range(58)]
            )
    with open('CROPCOM.DAT', "r") as f:
        for XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX in f.readlines():
            if XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX.split()[0] == 'CROP':
                TDIRbYtpiKJcPbcNDWYzqCdKjdjiRDCY = ['idx']+XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX.split()
            if XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX.split()[0] == '#':
                FMgoKqnfxaSYnBIbhfYviZVrqwhMZcCI = XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX.split()
    bdDzMvkuIikZVvwmcGjSuxRqxQbQSlov.loc[-2] = TDIRbYtpiKJcPbcNDWYzqCdKjdjiRDCY
    bdDzMvkuIikZVvwmcGjSuxRqxQbQSlov.loc[-1] = FMgoKqnfxaSYnBIbhfYviZVrqwhMZcCI
    bdDzMvkuIikZVvwmcGjSuxRqxQbQSlov.index = bdDzMvkuIikZVvwmcGjSuxRqxQbQSlov.index + 2  
    bdDzMvkuIikZVvwmcGjSuxRqxQbQSlov.sort_index(inplace=True)
    bdDzMvkuIikZVvwmcGjSuxRqxQbQSlov.columns = FMgoKqnfxaSYnBIbhfYviZVrqwhMZcCI
    return bdDzMvkuIikZVvwmcGjSuxRqxQbQSlov
def NTueWmBHFerIQejixmBbzgteekPBepKs():
    YrEfFRuicukgrqNvpTGwZyarFrxyPsee, VIiapgvaSYiGwAxRUwoEDfzTUOnzhKNy, LFYulGKEtFuwtgAxtTbBVUHjoWuhxJWQ, HcKXvniURlUZrJlAyOSBzUGsAAzBBnOv, cfNQbhTqxRfAuVrPypSfCveNTgbzfNGm, XnopHwbsgEHcxNcflTFUSSadYoogMPQn = ldQspGjnfWQlpDkbKVeYdlkHrIurAlAb()
    EanIGjApUyBNzzITgohpLwlNxdqGogdu = inCcVzscMTAWnTjtIdtrtLPQblWYQfvy()
    uhRMcnXCkFRPfWYNaPrPDtiHOSebMINH = ([YrEfFRuicukgrqNvpTGwZyarFrxyPsee, VIiapgvaSYiGwAxRUwoEDfzTUOnzhKNy]+([LFYulGKEtFuwtgAxtTbBVUHjoWuhxJWQ]*10) + [XnopHwbsgEHcxNcflTFUSSadYoogMPQn] + [cfNQbhTqxRfAuVrPypSfCveNTgbzfNGm]+([LFYulGKEtFuwtgAxtTbBVUHjoWuhxJWQ]*5)+([cfNQbhTqxRfAuVrPypSfCveNTgbzfNGm]*3)+([LFYulGKEtFuwtgAxtTbBVUHjoWuhxJWQ]*6)+([cfNQbhTqxRfAuVrPypSfCveNTgbzfNGm]*9)+([HcKXvniURlUZrJlAyOSBzUGsAAzBBnOv]*3)+ [XnopHwbsgEHcxNcflTFUSSadYoogMPQn]+([LFYulGKEtFuwtgAxtTbBVUHjoWuhxJWQ]*17))
    for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in range(0, len(uhRMcnXCkFRPfWYNaPrPDtiHOSebMINH)):
        EanIGjApUyBNzzITgohpLwlNxdqGogdu.iloc[2:, raTwYUncqiBWINHTjrAyJSZMGtSFDHkz] = EanIGjApUyBNzzITgohpLwlNxdqGogdu.iloc[2:, raTwYUncqiBWINHTjrAyJSZMGtSFDHkz].map(uhRMcnXCkFRPfWYNaPrPDtiHOSebMINH[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz])
    with open('crop.parm', "r") as f:
        wjjNHPaqqTnwANZqcATnxbTXFjfcdOXK = []
        tijEnLxLueSXdlJgEQurrEKmsvvXHMkV = []
        for XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX in f.readlines():
            if XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX.strip() != "":
                wjjNHPaqqTnwANZqcATnxbTXFjfcdOXK.append(XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX.upper().strip().split("_")[0])
                tijEnLxLueSXdlJgEQurrEKmsvvXHMkV.append(XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX.upper().strip().split("_")[1])
    count = 1
    for KHvNLlUeiYPHKdlhKXvjdSLILTFvrVms, UeWjpnbKJbXdsYzDRUljyQmRbYaRiFcr in zip(wjjNHPaqqTnwANZqcATnxbTXFjfcdOXK, tijEnLxLueSXdlJgEQurrEKmsvvXHMkV):
        UeWjpnbKJbXdsYzDRUljyQmRbYaRiFcr = "{0:>4s}".format(str(UeWjpnbKJbXdsYzDRUljyQmRbYaRiFcr))
        kGLOkiXryjZUxsKXeqdrNdlhqOohBqsc =  "cp{0:02d}".format(count)
        EanIGjApUyBNzzITgohpLwlNxdqGogdu.loc[EanIGjApUyBNzzITgohpLwlNxdqGogdu['NAME'] == UeWjpnbKJbXdsYzDRUljyQmRbYaRiFcr, KHvNLlUeiYPHKdlhKXvjdSLILTFvrVms] = EanIGjApUyBNzzITgohpLwlNxdqGogdu.loc[EanIGjApUyBNzzITgohpLwlNxdqGogdu['NAME'] == UeWjpnbKJbXdsYzDRUljyQmRbYaRiFcr, KHvNLlUeiYPHKdlhKXvjdSLILTFvrVms].apply(
                                                                                            lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp: "~{0:>5s}~".format(kGLOkiXryjZUxsKXeqdrNdlhqOohBqsc))
        count += 1
    with open('CROPCOM.DAT.tpl', 'w') as f:
        f.write("ptf ~\n")
        f.write(EanIGjApUyBNzzITgohpLwlNxdqGogdu.to_string(
                                    HjmjXniWvVfMzgtGlgbMayPkVOvKDSyL=0,
                                    index=False,
                                    lMRlaNApGTntLyCiinIcllWUqdNcQeVc=False,
                                    YbjyhmclCxPqPXvvfuvVfXzKcLWyrZka="right")
            )
    print(EanIGjApUyBNzzITgohpLwlNxdqGogdu)
def FSgxGBzcxdAbnEFouVDLVHAVoxrjMkfk(qQPaQIMxJsdooXhILgOaflxMNHbKZwMz=None, EIBnWFfsaIHXrddqyqcHvdrhTNJwvaKr=None):
    if qQPaQIMxJsdooXhILgOaflxMNHbKZwMz is None:
        qQPaQIMxJsdooXhILgOaflxMNHbKZwMz = 'pctchg'
    else:
        qQPaQIMxJsdooXhILgOaflxMNHbKZwMz ='unfchg'
    if EIBnWFfsaIHXrddqyqcHvdrhTNJwvaKr is None:
        EIBnWFfsaIHXrddqyqcHvdrhTNJwvaKr = 0.0001
    wjjNHPaqqTnwANZqcATnxbTXFjfcdOXK = [
            'init_cno3', 'init_p', 'init_so4', 'init_ca', 'init_mg', 'init_na',
            'init_k', 'init_cl', 'init_co3', 'init_hco3']
    mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB = pd.DataFrame()
    mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB['parnme'] = wjjNHPaqqTnwANZqcATnxbTXFjfcdOXK
    mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB['chg_type'] = qQPaQIMxJsdooXhILgOaflxMNHbKZwMz
    mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB['val'] = EIBnWFfsaIHXrddqyqcHvdrhTNJwvaKr
    mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB.index = mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB.parnme
    with open('MODFLOW/rt3d_initc.par', 'w') as f:
        f.write("# rt3d_initc.par file was created by the 'apexmf' python package.\n")
        f.write("NAME   CHG_TYPE    VAL\n")
        f.write(
            mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB.loc[:, ["parnme", "chg_type", "val"]].to_string(
                                                        HjmjXniWvVfMzgtGlgbMayPkVOvKDSyL=0,
                                                        uhRMcnXCkFRPfWYNaPrPDtiHOSebMINH=[SFMT, SFMT, SFMT],
                                                        index=False,
                                                        lMRlaNApGTntLyCiinIcllWUqdNcQeVc=False,
                                                        YbjyhmclCxPqPXvvfuvVfXzKcLWyrZka="left")
            )
    print("'rt3d_initc.par' file has been exported to the MODFLOW working directory!")
    return mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB
def JPXCRazVsgUmdIhpBzQrAbkYglejcyJb(YSBqWRyaaovIdrMAyOOIgyzCZaaPYlEi=None):
    if YSBqWRyaaovIdrMAyOOIgyzCZaaPYlEi is None:
        YSBqWRyaaovIdrMAyOOIgyzCZaaPYlEi = 'MODFLOW/rt3d_initc.par' + ".tpl"
    ibOXiMKQkHhMxqlWdvIDrfsaDCWkjewN = pd.read_csv(
                        'MODFLOW/rt3d_initc.par',
                        oJoHvsGSSiXOGKeqNTwBWHsRPdSYSqHO=True,
                        lMRlaNApGTntLyCiinIcllWUqdNcQeVc=None, ixDVzsxrKELjjTIkmlewsjeCWnapKmnk=2,
                        EjJRFWbMJGAdmvYxeZlzdQQoIDhhrtyA=["parnme", "chg_type", "parval1"])
    ibOXiMKQkHhMxqlWdvIDrfsaDCWkjewN.index = ibOXiMKQkHhMxqlWdvIDrfsaDCWkjewN.parnme
    ibOXiMKQkHhMxqlWdvIDrfsaDCWkjewN.loc[:, "tpl"] = ibOXiMKQkHhMxqlWdvIDrfsaDCWkjewN.parnme.apply(lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp: " ~   {0:15s}   ~".format(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp))
    with open(YSBqWRyaaovIdrMAyOOIgyzCZaaPYlEi, 'w') as f:
        f.write("ptf ~\n# RT3D Init. Conc. template file.\n")
        f.write("NAME   CHG_TYPE    VAL\n")
        f.write(ibOXiMKQkHhMxqlWdvIDrfsaDCWkjewN.loc[:, ["parnme", "chg_type", "tpl"]].to_string(
                                                        HjmjXniWvVfMzgtGlgbMayPkVOvKDSyL=0,
                                                        uhRMcnXCkFRPfWYNaPrPDtiHOSebMINH=[SFMT, SFMT, SFMT],
                                                        index=False,
                                                        lMRlaNApGTntLyCiinIcllWUqdNcQeVc=False,
                                                        YbjyhmclCxPqPXvvfuvVfXzKcLWyrZka="left"))
    return ibOXiMKQkHhMxqlWdvIDrfsaDCWkjewN
def FgDfyLEaHOmlnnInfreHNyXyedvvQCQG():
    for ntAPSRysSSYnLfEHyRxytFSmIajlopgI in glob.glob("MODFLOW"+"/*.dis"):
        with open(ntAPSRysSSYnLfEHyRxytFSmIajlopgI, "r") as f:
            IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw = []
            for XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX in f.readlines():
                if not XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX.startswith("#"):
                    IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw.append(XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX.replace('\n', '').split())
        eCVXvwXfOOayseqWzXnURDmjDEioKOpY = int(IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw[0][1])
        ERbkDrgAVvxaXQpCsNrbcQAAhHngyaMH = int(IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw[0][2])
    return eCVXvwXfOOayseqWzXnURDmjDEioKOpY
def tUVMEEWgTnABDYgNZzPWnbmLiwvVVNKS():
    eCVXvwXfOOayseqWzXnURDmjDEioKOpY = FgDfyLEaHOmlnnInfreHNyXyedvvQCQG()
    DiJEHKKuhYnBXxyppGLljjTXOEeudkJx = [f for f in glob.glob("MODFLOW" + "/*.btn")]
    if len(DiJEHKKuhYnBXxyppGLljjTXOEeudkJx) == 1:
        JESHGiTMKPmdALZdfGGkKhZqVJWiLhEH = os.path.basename(DiJEHKKuhYnBXxyppGLljjTXOEeudkJx[0])
        if not os.path.exists('MODFLOW/rt3d_btn.org'):
            shutil.copy('MODFLOW/' + JESHGiTMKPmdALZdfGGkKhZqVJWiLhEH, 'MODFLOW/rt3d_btn.org')
            print('The original RT3D BTN "{}" has been backed up...'.format(JESHGiTMKPmdALZdfGGkKhZqVJWiLhEH))
        else:
            print('The "rt3d_btn.org" file already exists...')
    with open('MODFLOW/rt3d_btn.org', "r") as f:
        IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw = f.readlines()
        RuoQFrceUEmbloARJiQePWeyYIQjcnmd = [FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp.split() for FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp in IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw] 
    aKwTpUTGiJUsHyKFvVzIiTGfYYHYuqnh = ["cno3", "p", "so4", "ca", "mg", "na", "k", "cl", "co3", "hco3"]
    for qkCVsxzjpdzKPWGmeHiryyOWsVoorRjE in aKwTpUTGiJUsHyKFvVzIiTGfYYHYuqnh:
        for zDJIhTAGnByUnDvugiSNjarLmDVTwGHQ, XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX in enumerate(RuoQFrceUEmbloARJiQePWeyYIQjcnmd):
            if XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX != [] and len(XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX) >= 3:
                if (XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX[0] == "1") and (XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX[2].lower() == qkCVsxzjpdzKPWGmeHiryyOWsVoorRjE):
                    if not os.path.exists("MODFLOW/init_{}.org".format(qkCVsxzjpdzKPWGmeHiryyOWsVoorRjE)):
                        with open("MODFLOW/init_{}.org".format(qkCVsxzjpdzKPWGmeHiryyOWsVoorRjE), 'w') as usMrXtjqapJxdigbBtXSZmLkkkYYSfDW:
                            for XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX in IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw[zDJIhTAGnByUnDvugiSNjarLmDVTwGHQ+1:zDJIhTAGnByUnDvugiSNjarLmDVTwGHQ+1+eCVXvwXfOOayseqWzXnURDmjDEioKOpY]:
                                usMrXtjqapJxdigbBtXSZmLkkkYYSfDW.write(XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX)
                        print("'init_{}.org' file has been created ...".format(qkCVsxzjpdzKPWGmeHiryyOWsVoorRjE))
                    else:
                        print("'init_{}.org' already exists ...".format(qkCVsxzjpdzKPWGmeHiryyOWsVoorRjE))
def enrsNXGJWuDxRxgkEBZKLVMKfLziIEJN():
    jRvAYNCfxybPLIsMjIkHozfjiGkRhZdy = pd.read_csv('MODFLOW/rt3d_initc.par', litrZTOxkDMQONopjRPXEwPHqlnFkgwo=r'\s+', sNZcjLwePglwMbhVpnmiFltQhShjcdsK='#', index_col=0)
    for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in range(len(jRvAYNCfxybPLIsMjIkHozfjiGkRhZdy)):
        IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw = np.loadtxt("MODFLOW/{}.org".format(jRvAYNCfxybPLIsMjIkHozfjiGkRhZdy.index[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz]), dtype=float)
        if jRvAYNCfxybPLIsMjIkHozfjiGkRhZdy.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 0] == "pctchg":
            IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw = IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw + (IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw * float(jRvAYNCfxybPLIsMjIkHozfjiGkRhZdy.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 1]) / 100)
        elif jRvAYNCfxybPLIsMjIkHozfjiGkRhZdy.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 0] == "unfchg":
            IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw = IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw + float(jRvAYNCfxybPLIsMjIkHozfjiGkRhZdy.iloc[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, 1])
        np.savetxt("MODFLOW/{}.ref".format(jRvAYNCfxybPLIsMjIkHozfjiGkRhZdy.index[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz]), IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw, fmt='%.5e')
        print("{}.ref has been updated ...".format(jRvAYNCfxybPLIsMjIkHozfjiGkRhZdy.index[raTwYUncqiBWINHTjrAyJSZMGtSFDHkz]))
def ginPAbYmfkhRbhCPZcIwpUxvWzjPNwBu():
    eCVXvwXfOOayseqWzXnURDmjDEioKOpY = FgDfyLEaHOmlnnInfreHNyXyedvvQCQG()
    with open('MODFLOW/rt3d_btn.org', "r") as f:
        IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw = f.readlines()
        RuoQFrceUEmbloARJiQePWeyYIQjcnmd = [FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp.split() for FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp in IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw] 
    BUCueFSbnvmynkHCFrGnZmyZNGJQtbRO = ["cno3", "p", "so4", "ca", "mg", "na", "k", "cl", "co3", "hco3"]
    bZOJiFCxwhYdzvbMjsuLlKXJfpZWIkUf = []
    for qkCVsxzjpdzKPWGmeHiryyOWsVoorRjE in BUCueFSbnvmynkHCFrGnZmyZNGJQtbRO:
        for zDJIhTAGnByUnDvugiSNjarLmDVTwGHQ, XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX in enumerate(RuoQFrceUEmbloARJiQePWeyYIQjcnmd):
            if XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX != [] and len(XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX) >= 3:
                if (XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX[0] == "1") and (XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX[2].lower() == qkCVsxzjpdzKPWGmeHiryyOWsVoorRjE):
                    bZOJiFCxwhYdzvbMjsuLlKXJfpZWIkUf.append(zDJIhTAGnByUnDvugiSNjarLmDVTwGHQ)
    DiJEHKKuhYnBXxyppGLljjTXOEeudkJx = [f for f in glob.glob("MODFLOW" + "/*.btn")]
    if len(DiJEHKKuhYnBXxyppGLljjTXOEeudkJx) == 1:
        JESHGiTMKPmdALZdfGGkKhZqVJWiLhEH = os.path.basename(DiJEHKKuhYnBXxyppGLljjTXOEeudkJx[0])
        zEBptwnEsmAsuPrQmyJkjeCRSbylAiJv = "MODFLOW/" + JESHGiTMKPmdALZdfGGkKhZqVJWiLhEH
        with open(zEBptwnEsmAsuPrQmyJkjeCRSbylAiJv,'w') as usMrXtjqapJxdigbBtXSZmLkkkYYSfDW:
            for mxlxVoKqhjXolzezkUewWMQYebUwHDCW in IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw[:bZOJiFCxwhYdzvbMjsuLlKXJfpZWIkUf[0]]:
                usMrXtjqapJxdigbBtXSZmLkkkYYSfDW.write(str(mxlxVoKqhjXolzezkUewWMQYebUwHDCW))      
        for qkCVsxzjpdzKPWGmeHiryyOWsVoorRjE in BUCueFSbnvmynkHCFrGnZmyZNGJQtbRO:
            with open(zEBptwnEsmAsuPrQmyJkjeCRSbylAiJv,'a') as af:
                epeijDKiHgwPpJgZGFqjSBNaqrIzXRWd = np.loadtxt("MODFLOW/{}.ref".format("init_{}".format(qkCVsxzjpdzKPWGmeHiryyOWsVoorRjE)), dtype=float)
                af.write("1 0.00 {}\n".format(qkCVsxzjpdzKPWGmeHiryyOWsVoorRjE.lower()))
                for WGZGrFYGyfVipWequRTciuBoujNVSmWC in epeijDKiHgwPpJgZGFqjSBNaqrIzXRWd:
                    af.write(" ".join(map("{:.5e}".format, WGZGrFYGyfVipWequRTciuBoujNVSmWC)))
                    af.write('\n')
                af.write('\n')
        with open(zEBptwnEsmAsuPrQmyJkjeCRSbylAiJv,'a') as af2:
            for lZmFCZcsjOLIRpeWUBCvFKvRWjfxFpsH in IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw[eCVXvwXfOOayseqWzXnURDmjDEioKOpY+bZOJiFCxwhYdzvbMjsuLlKXJfpZWIkUf[-1]+2:]:
                af2.write(lZmFCZcsjOLIRpeWUBCvFKvRWjfxFpsH)   
        print("{} file has been updated ...".format(JESHGiTMKPmdALZdfGGkKhZqVJWiLhEH))   
def kPTYdncvzDDPKnAVxanzTnJeQAbYbapM():
    if not os.path.exists('SALINITY/salt_input.org'):
        shutil.copy('SALINITY/salt_input', 'SALINITY/salt_input.org')
        print('The original salt_input has been backed up...')
    else:
        print('The "salt_input.org" file already exists...')
    with open('SALINITY/salt_input.org', "r") as f:
        IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw = f.readlines()
        RuoQFrceUEmbloARJiQePWeyYIQjcnmd = [FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp.split() for FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp in IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw] 
    bZOJiFCxwhYdzvbMjsuLlKXJfpZWIkUf = []
    for zDJIhTAGnByUnDvugiSNjarLmDVTwGHQ, XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX in enumerate(RuoQFrceUEmbloARJiQePWeyYIQjcnmd):
        if XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX != [] and len(XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX) >= 3:
            if (XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX[0].lower() == "initial") and (XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX[1].lower() == "concentrations"):
                bZOJiFCxwhYdzvbMjsuLlKXJfpZWIkUf.append(zDJIhTAGnByUnDvugiSNjarLmDVTwGHQ)
            if (XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX[0].lower() == "initial") and (XnIiSvFHbXiOuDztpkaRlLLDJHDyLBXX[1].lower() == "salt"):
                bZOJiFCxwhYdzvbMjsuLlKXJfpZWIkUf.append(zDJIhTAGnByUnDvugiSNjarLmDVTwGHQ)
    return bZOJiFCxwhYdzvbMjsuLlKXJfpZWIkUf
def yVFqSmmnpRBRxJGODtSWnBsUSuqkNxmH():
    BUCueFSbnvmynkHCFrGnZmyZNGJQtbRO = ["so4", "ca", "mg", "na", "k", "cl", "co3", "hco3"]
    ufylCZlofVyBtYKiFOvTVawEIsbvJtwk = pd.DataFrame()
    for qkCVsxzjpdzKPWGmeHiryyOWsVoorRjE in BUCueFSbnvmynkHCFrGnZmyZNGJQtbRO:
        IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw = np.loadtxt("MODFLOW/init_{}.ref".format(qkCVsxzjpdzKPWGmeHiryyOWsVoorRjE), dtype=float)
        luoVuNOETMWscYTKGEkvZuVFMtPyukQe = IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw.flatten().tolist()
        ufylCZlofVyBtYKiFOvTVawEIsbvJtwk[qkCVsxzjpdzKPWGmeHiryyOWsVoorRjE] = luoVuNOETMWscYTKGEkvZuVFMtPyukQe
    ufylCZlofVyBtYKiFOvTVawEIsbvJtwk['grid_id'] = [raTwYUncqiBWINHTjrAyJSZMGtSFDHkz for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in range(1, len(luoVuNOETMWscYTKGEkvZuVFMtPyukQe)+1)]
    ezISUFPPSBhdWMddvPDKQXrIDqqpjKba = pd.read_csv('MODFLOW/link_grid_sa', litrZTOxkDMQONopjRPXEwPHqlnFkgwo=r'\s+', ixDVzsxrKELjjTIkmlewsjeCWnapKmnk=4)
    TksLGtEwNmPJztYJNKRtIKDFFnTUreZJ = pd.DataFrame()
    for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in ezISUFPPSBhdWMddvPDKQXrIDqqpjKba.sub_id.unique():
        wKgoIMmLQiQgASJYbckvuFYhddvTKgaK = ezISUFPPSBhdWMddvPDKQXrIDqqpjKba[ezISUFPPSBhdWMddvPDKQXrIDqqpjKba.loc[:, 'sub_id']==raTwYUncqiBWINHTjrAyJSZMGtSFDHkz]
        mmnQPOyIlYIdTEBwuebTPxBsgUHtLvkf = pd.concat(
            [ufylCZlofVyBtYKiFOvTVawEIsbvJtwk.set_index('grid_id'),wKgoIMmLQiQgASJYbckvuFYhddvTKgaK.set_index('grid_id')], 
            OgXfQJVecXQhSxkBUlhpOuzeXSHWRJxo=1, join='inner'
            ).mean(OgXfQJVecXQhSxkBUlhpOuzeXSHWRJxo=0)
        TksLGtEwNmPJztYJNKRtIKDFFnTUreZJ["sub{:03d}".format(raTwYUncqiBWINHTjrAyJSZMGtSFDHkz)] = mmnQPOyIlYIdTEBwuebTPxBsgUHtLvkf
    IqOYhMJcxybVhEIaCNvFbnEIXVUFBmpl = TksLGtEwNmPJztYJNKRtIKDFFnTUreZJ.T[BUCueFSbnvmynkHCFrGnZmyZNGJQtbRO]
    print('Updated gridded init salt ions have been converted to sub scales ...')
    return IqOYhMJcxybVhEIaCNvFbnEIXVUFBmpl
def ISEvnAoWHthovsvWCQrnNtwSQJhbZSAU():
    bZOJiFCxwhYdzvbMjsuLlKXJfpZWIkUf = kPTYdncvzDDPKnAVxanzTnJeQAbYbapM()
    TksLGtEwNmPJztYJNKRtIKDFFnTUreZJ = yVFqSmmnpRBRxJGODtSWnBsUSuqkNxmH()
    with open('SALINITY/salt_input.org', "r") as f:
        IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw = f.readlines()
        RuoQFrceUEmbloARJiQePWeyYIQjcnmd = [FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp.split() for FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp in IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw] 
    with open('SALINITY/salt_input','w') as usMrXtjqapJxdigbBtXSZmLkkkYYSfDW:
        for mxlxVoKqhjXolzezkUewWMQYebUwHDCW in IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw[:bZOJiFCxwhYdzvbMjsuLlKXJfpZWIkUf[0]+2]:
            usMrXtjqapJxdigbBtXSZmLkkkYYSfDW.write(mxlxVoKqhjXolzezkUewWMQYebUwHDCW)
        TksLGtEwNmPJztYJNKRtIKDFFnTUreZJ.to_csv(
                    usMrXtjqapJxdigbBtXSZmLkkkYYSfDW, litrZTOxkDMQONopjRPXEwPHqlnFkgwo =' ', index=None, lMRlaNApGTntLyCiinIcllWUqdNcQeVc=None, float_format='%.5e',
                    aubUhrfolUVvDKTnbLbvGvXbWlnllVjp='\n', kAnUtOBCruNMXqmimeUoUhknuriotKBY='utf-8'
                    )
        usMrXtjqapJxdigbBtXSZmLkkkYYSfDW.write('\n')
        for mxlxVoKqhjXolzezkUewWMQYebUwHDCW in IcdDiFkYaKoQKhWuOkUHsvxrQAIGdtAw[bZOJiFCxwhYdzvbMjsuLlKXJfpZWIkUf[1]:]:
            usMrXtjqapJxdigbBtXSZmLkkkYYSfDW.write(mxlxVoKqhjXolzezkUewWMQYebUwHDCW)
    print('The "salt_input" file has been updated ...')
if __name__ == '__main__':
    PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR = "D:\\Projects\\RegionalCalibration\\Autocalibration\\ani_apexmf_cal_v03"
    os.chdir(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR)
    lISGpASbtLyxeWkNVtGWbsaORWpRWevh()
