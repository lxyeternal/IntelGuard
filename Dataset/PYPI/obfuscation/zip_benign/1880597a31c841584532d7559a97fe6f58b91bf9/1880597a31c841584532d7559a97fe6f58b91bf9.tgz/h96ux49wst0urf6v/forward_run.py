import os
from datetime import datetime
import pandas as pd
from apexmf import apexmf_pst_par, apexmf_utils
from apexmf import apexmf_pst_utils
import pyemu
PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR = os.getcwd()
os.chdir(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR)
def LndNWdLeiWMWaBkdYCrBkHKomsWypjjc(DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty):
    ugBvoulFmhSGSGuoCSnhMqAfwsgPGGOe = datetime.now().strftime('[%m/%d/%y %H:%M:%S]')
    print('\n' + 35*'+ ')
    print(ugBvoulFmhSGSGuoCSnhMqAfwsgPGGOe + ' |  {} ...'.format(DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty))
    print(35*'+ ' + '\n')
def dQNGqLabBPAaPLxcneXYtFXZRABSkqMn():
    WzEXCbTmwsoNlnsiKkYAuNuvijqHPzij = PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR + "\MODFLOW"
    DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty = "updating river parameters"
    LndNWdLeiWMWaBkdYCrBkHKomsWypjjc(DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty)
    apexmf_pst_par.ZKTxMCqQfPGfxGNldBDSaMIzhlApaoMQ(WzEXCbTmwsoNlnsiKkYAuNuvijqHPzij)
def jaDgfCJhtOhiBQscoAGewxVmEtyLiggS(eZLlysFbFSuEnLvIiCzsAtdqGBoTXTFR):
    WzEXCbTmwsoNlnsiKkYAuNuvijqHPzij = PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR + "\MODFLOW"
    os.chdir(WzEXCbTmwsoNlnsiKkYAuNuvijqHPzij)
    DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty = "modifying MODFLOW HK, VHK, and SY parameters"
    LndNWdLeiWMWaBkdYCrBkHKomsWypjjc(DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty)
    JdRduxgLYeuAcMrChIiElAqSZqCkdcnt = eZLlysFbFSuEnLvIiCzsAtdqGBoTXTFR
    for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in JdRduxgLYeuAcMrChIiElAqSZqCkdcnt:
        EFbonvWeiYTHfPrgkPRyRiriiNZbJOqd = raTwYUncqiBWINHTjrAyJSZMGtSFDHkz + '.ref'
        pyemu.utils.geostats.fac2real(raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, factors_file=raTwYUncqiBWINHTjrAyJSZMGtSFDHkz+'.fac', out_file=EFbonvWeiYTHfPrgkPRyRiriiNZbJOqd)
    os.chdir(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR)
def QAFAECeUCHwtkRuGCRCjLTItPOmSdjRL():
    DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty = "running model"
    LndNWdLeiWMWaBkdYCrBkHKomsWypjjc(DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty)
    pyemu.os_utils.run('apexmf', jcNfPllrbHNUnSqPBWkhFLKrXBneyqUW='.')
def uCmwBepUUlYdEXWlhDCmQHKTTZzuyJmF(mwKMGWGgkiKeuTpiTwRMsSygHVVVRIOh, YKfXZdDVImrlVdrdnEocbkOHiVardpIe, NyVZXMHeIXXFvjjHdumEXlpujVlTNJZb, aJDHhWhsSSVRygsVMYkyOeWTXiHQVUof, aMrXUwQwsbseokgaugKenkdOgBHuAauW):
    if ZpIeNhmseKZlxfpVbhUlUsqfUSnLESAG == 'day':
        DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty = "simulation successfully completed | extracting daily simulated streamflow"
        LndNWdLeiWMWaBkdYCrBkHKomsWypjjc(DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty)
        apexmf_pst_utils.extract_day_stf(mwKMGWGgkiKeuTpiTwRMsSygHVVVRIOh, YKfXZdDVImrlVdrdnEocbkOHiVardpIe, NyVZXMHeIXXFvjjHdumEXlpujVlTNJZb, aJDHhWhsSSVRygsVMYkyOeWTXiHQVUof, aMrXUwQwsbseokgaugKenkdOgBHuAauW)
    elif ZpIeNhmseKZlxfpVbhUlUsqfUSnLESAG == 'month':
        DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty = "simulation successfully completed | extracting monthly simulated streamflow"
        LndNWdLeiWMWaBkdYCrBkHKomsWypjjc(DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty)
        apexmf_pst_utils.extract_month_stf(mwKMGWGgkiKeuTpiTwRMsSygHVVVRIOh, YKfXZdDVImrlVdrdnEocbkOHiVardpIe, NyVZXMHeIXXFvjjHdumEXlpujVlTNJZb, aJDHhWhsSSVRygsVMYkyOeWTXiHQVUof, aMrXUwQwsbseokgaugKenkdOgBHuAauW)
def dTTuJDPYkwsDHRJLVWMfpYIhPGlLhced(msnfXZqUVfaEKFofpGfWNetFRZpdDJYN, NyVZXMHeIXXFvjjHdumEXlpujVlTNJZb, aMrXUwQwsbseokgaugKenkdOgBHuAauW):
    DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty = "simulation successfully completed | extracting depth to water values"
    LndNWdLeiWMWaBkdYCrBkHKomsWypjjc(DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty)
    apexmf_pst_utils.extract_depth_to_water(msnfXZqUVfaEKFofpGfWNetFRZpdDJYN, NyVZXMHeIXXFvjjHdumEXlpujVlTNJZb, aMrXUwQwsbseokgaugKenkdOgBHuAauW)
def jshGOwlfXTsxvLAwJIvUQMfjbDTasNSP(gzumNhNpjlKZNgwkACVZpIVFkJNmLTZf, dxsuvqHvAQzUuRMDxOUlHZESBHbxPFbw, NyVZXMHeIXXFvjjHdumEXlpujVlTNJZb, aJDHhWhsSSVRygsVMYkyOeWTXiHQVUof, aMrXUwQwsbseokgaugKenkdOgBHuAauW):
    if ZpIeNhmseKZlxfpVbhUlUsqfUSnLESAG == 'day':
        DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty = "simulation successfully completed | extracting daily simulated lai"
        LndNWdLeiWMWaBkdYCrBkHKomsWypjjc(DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty)
        JjWjtBAJtEKczodurEJKMxHgSIOZTwmn = apexmf_utils.read_sao(gzumNhNpjlKZNgwkACVZpIVFkJNmLTZf)
        apexmf_pst_utils.extract_day_lai(JjWjtBAJtEKczodurEJKMxHgSIOZTwmn, dxsuvqHvAQzUuRMDxOUlHZESBHbxPFbw, NyVZXMHeIXXFvjjHdumEXlpujVlTNJZb, aJDHhWhsSSVRygsVMYkyOeWTXiHQVUof, aMrXUwQwsbseokgaugKenkdOgBHuAauW)
    elif ZpIeNhmseKZlxfpVbhUlUsqfUSnLESAG == 'month':
        DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty = "simulation successfully completed | extracting monthly simulated lai"
        LndNWdLeiWMWaBkdYCrBkHKomsWypjjc(DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty)
        JjWjtBAJtEKczodurEJKMxHgSIOZTwmn = apexmf_utils.read_sao(gzumNhNpjlKZNgwkACVZpIVFkJNmLTZf)
        apexmf_pst_utils.extract_day_mon(JjWjtBAJtEKczodurEJKMxHgSIOZTwmn, dxsuvqHvAQzUuRMDxOUlHZESBHbxPFbw, NyVZXMHeIXXFvjjHdumEXlpujVlTNJZb, aJDHhWhsSSVRygsVMYkyOeWTXiHQVUof, aMrXUwQwsbseokgaugKenkdOgBHuAauW)
def rnmDJzHnZaruTHPEOxjWKqKoTcAAMCcU(mwKMGWGgkiKeuTpiTwRMsSygHVVVRIOh, YKfXZdDVImrlVdrdnEocbkOHiVardpIe, NyVZXMHeIXXFvjjHdumEXlpujVlTNJZb, aJDHhWhsSSVRygsVMYkyOeWTXiHQVUof, aMrXUwQwsbseokgaugKenkdOgBHuAauW):
    DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty = "simulation successfully completed | calculating baseflow ratio"
    LndNWdLeiWMWaBkdYCrBkHKomsWypjjc(DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty)
    apexmf_pst_utils.extract_month_baseflow(mwKMGWGgkiKeuTpiTwRMsSygHVVVRIOh, YKfXZdDVImrlVdrdnEocbkOHiVardpIe, NyVZXMHeIXXFvjjHdumEXlpujVlTNJZb, aJDHhWhsSSVRygsVMYkyOeWTXiHQVUof, aMrXUwQwsbseokgaugKenkdOgBHuAauW)
def eNCkAjuLLKIOHKlMklNOOLMGFCuBAfwn(mwKMGWGgkiKeuTpiTwRMsSygHVVVRIOh, YKfXZdDVImrlVdrdnEocbkOHiVardpIe, NyVZXMHeIXXFvjjHdumEXlpujVlTNJZb, aJDHhWhsSSVRygsVMYkyOeWTXiHQVUof, aMrXUwQwsbseokgaugKenkdOgBHuAauW, 
            jvqDQAhvYobMUbrCOekzZhVcvPVHMplD, ZIAcPfUlWQXvkZdFMSFcuHRHTwPssLVE, MYKvpUeHcRfVDgGiENXdwYUZAVhxziZc, ZpIeNhmseKZlxfpVbhUlUsqfUSnLESAG=None):
    DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty = "simulation successfully completed | extracting fdc slopes from streamflow"
    LndNWdLeiWMWaBkdYCrBkHKomsWypjjc(DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty)
    apexmf_pst_utils.extract_slopesFrTimeSim(mwKMGWGgkiKeuTpiTwRMsSygHVVVRIOh, YKfXZdDVImrlVdrdnEocbkOHiVardpIe, NyVZXMHeIXXFvjjHdumEXlpujVlTNJZb, aJDHhWhsSSVRygsVMYkyOeWTXiHQVUof, aMrXUwQwsbseokgaugKenkdOgBHuAauW, 
            jvqDQAhvYobMUbrCOekzZhVcvPVHMplD, ZIAcPfUlWQXvkZdFMSFcuHRHTwPssLVE, MYKvpUeHcRfVDgGiENXdwYUZAVhxziZc, ZpIeNhmseKZlxfpVbhUlUsqfUSnLESAG=None)
def OJMXCqKdXPouDkwskKAFsXjHWhsfmhue(dzQOjHsSdaNrOjVIvgooZnErqKWDvGGj, NyVZXMHeIXXFvjjHdumEXlpujVlTNJZb, aJDHhWhsSSVRygsVMYkyOeWTXiHQVUof, aMrXUwQwsbseokgaugKenkdOgBHuAauW):
    DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty = "simulation successfully completed | extracting simulated salt loads and concentrations"
    LndNWdLeiWMWaBkdYCrBkHKomsWypjjc(DYOWzyRDfRHwhWmqvhrQQtOuvDjYYlty)
    apexmf_pst_utils.OJMXCqKdXPouDkwskKAFsXjHWhsfmhue(dzQOjHsSdaNrOjVIvgooZnErqKWDvGGj, NyVZXMHeIXXFvjjHdumEXlpujVlTNJZb, aJDHhWhsSSVRygsVMYkyOeWTXiHQVUof, aMrXUwQwsbseokgaugKenkdOgBHuAauW)
if __name__ == '__main__':
    os.chdir(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR)
    print(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR)
    ZfKFptOhVQqIhrZHHsUOWRidSJqsfgKI = pd.read_csv('apexmf.con', litrZTOxkDMQONopjRPXEwPHqlnFkgwo='\t', EjJRFWbMJGAdmvYxeZlzdQQoIDhhrtyA=['names', 'vals'], index_col=0, sNZcjLwePglwMbhVpnmiFltQhShjcdsK="#")
    NyVZXMHeIXXFvjjHdumEXlpujVlTNJZb = ZfKFptOhVQqIhrZHHsUOWRidSJqsfgKI.loc['sim_start', 'vals']
    aJDHhWhsSSVRygsVMYkyOeWTXiHQVUof = ZfKFptOhVQqIhrZHHsUOWRidSJqsfgKI.loc['cal_start', 'vals']
    aMrXUwQwsbseokgaugKenkdOgBHuAauW = ZfKFptOhVQqIhrZHHsUOWRidSJqsfgKI.loc['cal_end', 'vals']
    mwKMGWGgkiKeuTpiTwRMsSygHVVVRIOh = ZfKFptOhVQqIhrZHHsUOWRidSJqsfgKI.loc['cha_file','vals']
    ZpIeNhmseKZlxfpVbhUlUsqfUSnLESAG = ZfKFptOhVQqIhrZHHsUOWRidSJqsfgKI.loc['time_step','vals']
    gzumNhNpjlKZNgwkACVZpIVFkJNmLTZf = ZfKFptOhVQqIhrZHHsUOWRidSJqsfgKI.loc['lai_file','vals']
    jvqDQAhvYobMUbrCOekzZhVcvPVHMplD = float(ZfKFptOhVQqIhrZHHsUOWRidSJqsfgKI.loc['min_fdc','vals'])
    ZIAcPfUlWQXvkZdFMSFcuHRHTwPssLVE = float(ZfKFptOhVQqIhrZHHsUOWRidSJqsfgKI.loc['max_fdc','vals'])
    MYKvpUeHcRfVDgGiENXdwYUZAVhxziZc = int(ZfKFptOhVQqIhrZHHsUOWRidSJqsfgKI.loc['interval_num','vals'])
    if ZfKFptOhVQqIhrZHHsUOWRidSJqsfgKI.loc['riv_parm', 'vals'] != 'n':
        dQNGqLabBPAaPLxcneXYtFXZRABSkqMn()
    if ZfKFptOhVQqIhrZHHsUOWRidSJqsfgKI.loc['pp_included', 'vals'] != 'n':
        eZLlysFbFSuEnLvIiCzsAtdqGBoTXTFR = ZfKFptOhVQqIhrZHHsUOWRidSJqsfgKI.loc['pp_included','vals'].strip('][').split(', ')
        eZLlysFbFSuEnLvIiCzsAtdqGBoTXTFR = [raTwYUncqiBWINHTjrAyJSZMGtSFDHkz.replace("'", "").strip() for i in pp_included]  
        jaDgfCJhtOhiBQscoAGewxVmEtyLiggS(eZLlysFbFSuEnLvIiCzsAtdqGBoTXTFR)
    QAFAECeUCHwtkRuGCRCjLTItPOmSdjRL()
    if ZfKFptOhVQqIhrZHHsUOWRidSJqsfgKI.loc['cha_file', 'vals'] != 'n':
        YKfXZdDVImrlVdrdnEocbkOHiVardpIe = ZfKFptOhVQqIhrZHHsUOWRidSJqsfgKI.loc['subs','vals'].strip('][').split(', ')
        YKfXZdDVImrlVdrdnEocbkOHiVardpIe = [int(raTwYUncqiBWINHTjrAyJSZMGtSFDHkz) for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in YKfXZdDVImrlVdrdnEocbkOHiVardpIe]
        uCmwBepUUlYdEXWlhDCmQHKTTZzuyJmF(mwKMGWGgkiKeuTpiTwRMsSygHVVVRIOh, YKfXZdDVImrlVdrdnEocbkOHiVardpIe, NyVZXMHeIXXFvjjHdumEXlpujVlTNJZb, aJDHhWhsSSVRygsVMYkyOeWTXiHQVUof, aMrXUwQwsbseokgaugKenkdOgBHuAauW)
    if ZfKFptOhVQqIhrZHHsUOWRidSJqsfgKI.loc['gw_level', 'vals'] == 'y':
        msnfXZqUVfaEKFofpGfWNetFRZpdDJYN = ZfKFptOhVQqIhrZHHsUOWRidSJqsfgKI.loc['grids','vals'].strip('][').split(', ')
        msnfXZqUVfaEKFofpGfWNetFRZpdDJYN = [int(raTwYUncqiBWINHTjrAyJSZMGtSFDHkz) for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in msnfXZqUVfaEKFofpGfWNetFRZpdDJYN]        
        dTTuJDPYkwsDHRJLVWMfpYIhPGlLhced(msnfXZqUVfaEKFofpGfWNetFRZpdDJYN, NyVZXMHeIXXFvjjHdumEXlpujVlTNJZb, aMrXUwQwsbseokgaugKenkdOgBHuAauW)
    if ZfKFptOhVQqIhrZHHsUOWRidSJqsfgKI.loc['lai_file', 'vals'] != 'n':
        dxsuvqHvAQzUuRMDxOUlHZESBHbxPFbw = ZfKFptOhVQqIhrZHHsUOWRidSJqsfgKI.loc['lai_subs','vals'].strip('][').split(', ')
        dxsuvqHvAQzUuRMDxOUlHZESBHbxPFbw = [int(raTwYUncqiBWINHTjrAyJSZMGtSFDHkz) for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in dxsuvqHvAQzUuRMDxOUlHZESBHbxPFbw]
        jshGOwlfXTsxvLAwJIvUQMfjbDTasNSP(gzumNhNpjlKZNgwkACVZpIVFkJNmLTZf, dxsuvqHvAQzUuRMDxOUlHZESBHbxPFbw, NyVZXMHeIXXFvjjHdumEXlpujVlTNJZb, aJDHhWhsSSVRygsVMYkyOeWTXiHQVUof, aMrXUwQwsbseokgaugKenkdOgBHuAauW)
    if ZfKFptOhVQqIhrZHHsUOWRidSJqsfgKI.loc['baseflow', 'vals'] != 'n':
        rnmDJzHnZaruTHPEOxjWKqKoTcAAMCcU(mwKMGWGgkiKeuTpiTwRMsSygHVVVRIOh, YKfXZdDVImrlVdrdnEocbkOHiVardpIe, NyVZXMHeIXXFvjjHdumEXlpujVlTNJZb, aJDHhWhsSSVRygsVMYkyOeWTXiHQVUof, aMrXUwQwsbseokgaugKenkdOgBHuAauW)
    if ZfKFptOhVQqIhrZHHsUOWRidSJqsfgKI.loc['fdc', 'vals'] == 'y':
        eNCkAjuLLKIOHKlMklNOOLMGFCuBAfwn(mwKMGWGgkiKeuTpiTwRMsSygHVVVRIOh, YKfXZdDVImrlVdrdnEocbkOHiVardpIe, NyVZXMHeIXXFvjjHdumEXlpujVlTNJZb, aJDHhWhsSSVRygsVMYkyOeWTXiHQVUof, aMrXUwQwsbseokgaugKenkdOgBHuAauW, 
            jvqDQAhvYobMUbrCOekzZhVcvPVHMplD, ZIAcPfUlWQXvkZdFMSFcuHRHTwPssLVE, MYKvpUeHcRfVDgGiENXdwYUZAVhxziZc, ZpIeNhmseKZlxfpVbhUlUsqfUSnLESAG=None)
