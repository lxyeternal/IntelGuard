import pandas as pd
import numpy as np
import time
import os
import shutil
import socket
import multiprocessing as mp
import csv
import glob
from tqdm import tqdm
def GHEpUAeWEIJNckfCyKpgyEJVvTtmxXDI(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR):
    os.chdir(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR)
    WLOuMtIaZmDQfcKtjhJkPSRLmYzYjWvJ = [nXCoUozweCgYZMKZazxsZuQHQISawvQK for nXCoUozweCgYZMKZazxsZuQHQISawvQK in os.listdir(".") if os.path.isdir(nXCoUozweCgYZMKZazxsZuQHQISawvQK)]
    cBQDGbYpNWohcEuZToYvBxOxNOFXXLTm = [os.path.abspath(nXCoUozweCgYZMKZazxsZuQHQISawvQK) for nXCoUozweCgYZMKZazxsZuQHQISawvQK in os.listdir(".") if os.path.isdir(nXCoUozweCgYZMKZazxsZuQHQISawvQK)]
    print(WLOuMtIaZmDQfcKtjhJkPSRLmYzYjWvJ)
    return WLOuMtIaZmDQfcKtjhJkPSRLmYzYjWvJ, cBQDGbYpNWohcEuZToYvBxOxNOFXXLTm
def eocuTYmWCoVFjgsxXSroALmcSehnOEhl(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR):
    NspMWspxvJCSchqEFnlOVcNtQSwwVdTN, cBQDGbYpNWohcEuZToYvBxOxNOFXXLTm = GHEpUAeWEIJNckfCyKpgyEJVvTtmxXDI(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR)
    for KHvNLlUeiYPHKdlhKXvjdSLILTFvrVms in cBQDGbYpNWohcEuZToYvBxOxNOFXXLTm:
        os.chdir(KHvNLlUeiYPHKdlhKXvjdSLILTFvrVms)
        print("Folder changed to {}".format(KHvNLlUeiYPHKdlhKXvjdSLILTFvrVms))
        fRGrWyhKlbruZzcjydyfpvtEwDSGRKaw = [f for f in glob.glob("*.csv")][0]
        print("{} file found ...".format(fRGrWyhKlbruZzcjydyfpvtEwDSGRKaw))
        mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB =  pd.read_csv(os.path.join(KHvNLlUeiYPHKdlhKXvjdSLILTFvrVms, fRGrWyhKlbruZzcjydyfpvtEwDSGRKaw), index_col=0, parse_dates=True)
        BFgaAFLgRABVzSiLQvOnGrFydIWgMZhu = len(mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB.columns)
        print("  Converting {} to 'pcp1.pcp' file ... processing".format(fRGrWyhKlbruZzcjydyfpvtEwDSGRKaw))
        for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in tqdm(range(BFgaAFLgRABVzSiLQvOnGrFydIWgMZhu)):
            mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB.iloc[:, raTwYUncqiBWINHTjrAyJSZMGtSFDHkz] = mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB.iloc[:, raTwYUncqiBWINHTjrAyJSZMGtSFDHkz].map(lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp: '{:05.1f}'.format(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp))
        mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB.insert(loc=0, column='year', value=mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB.index.year)
        mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB.insert(loc=1, column='jday', value=mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB.index.dayofyear.map(lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp: '{:03d}'.format(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp)))
        zrvFMTbzGIEBBmmyKOZjtKIDeXGyJKEz = mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB.T.astype(str).apply(''.join)
        with open(os.path.join(KHvNLlUeiYPHKdlhKXvjdSLILTFvrVms, 'pcp1.pcp'), 'w') as f:
            for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in range(4):
                f.write('\n')
            zrvFMTbzGIEBBmmyKOZjtKIDeXGyJKEz.to_csv(f, KtDWybxVskqQYiDkfDMCoPxiHdxALRoA='\n', index=False, lMRlaNApGTntLyCiinIcllWUqdNcQeVc=None)
        print("  Converting GCM format file to 'pcp1.pcp' file ... passed")
    print("  Done!")
def UGFKWbMMprtbMhjUmKFmvjFmeRmbjEAZ(pcp_path, nloc):
    with open(pcp_path, 'r') as f:
        KDQDSAtQQxvCDaPNPwksWByTCTzISoUc = f.readlines()
    ayPYzwfCWDLsUUoNFcFrqUjNZCruxhEc = [int(raTwYUncqiBWINHTjrAyJSZMGtSFDHkz[:7]) for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in KDQDSAtQQxvCDaPNPwksWByTCTzISoUc[4:]]
    AGEjRmAicXAjWeQigrKPTgfjAJTXtzTg = pd.to_datetime(ayPYzwfCWDLsUUoNFcFrqUjNZCruxhEc, format='%Y%j')
    mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB = pd.DataFrame(index=AGEjRmAicXAjWeQigrKPTgfjAJTXtzTg)
    SekYOrRCybmwZnbmbmYBXSznxOIrnJiP = 7
    for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in tqdm(range(nloc)):
        zmvARnxIOraulKNsIBvlbUsTywipnLHZ = [float(raTwYUncqiBWINHTjrAyJSZMGtSFDHkz[SekYOrRCybmwZnbmbmYBXSznxOIrnJiP:SekYOrRCybmwZnbmbmYBXSznxOIrnJiP+5]) for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in KDQDSAtQQxvCDaPNPwksWByTCTzISoUc[4:]]
        SekYOrRCybmwZnbmbmYBXSznxOIrnJiP += 5
        mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB["sub_{}".format(raTwYUncqiBWINHTjrAyJSZMGtSFDHkz+1)] = zmvARnxIOraulKNsIBvlbUsTywipnLHZ
    return mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB
def URiqZtTdnbtCUcvuthEeQYTkILDdYsmQ(
        nloc, base_file, scenario_dir, base_start_date, 
        base_end_date, scn_start_date, scn_end_date, output_dir
        ):
    cWXFIccyZDKEFnxjHooODJNDxfOqBpRf = UGFKWbMMprtbMhjUmKFmvjFmeRmbjEAZ(base_file, nloc)
    cWXFIccyZDKEFnxjHooODJNDxfOqBpRf = cWXFIccyZDKEFnxjHooODJNDxfOqBpRf[base_start_date:base_end_date]
    NspMWspxvJCSchqEFnlOVcNtQSwwVdTN, cBQDGbYpNWohcEuZToYvBxOxNOFXXLTm = GHEpUAeWEIJNckfCyKpgyEJVvTtmxXDI(scenario_dir)
    for BEcTBMfqLBgnuvucWAlBztLEuXfytfbk, KHvNLlUeiYPHKdlhKXvjdSLILTFvrVms in zip(NspMWspxvJCSchqEFnlOVcNtQSwwVdTN, cBQDGbYpNWohcEuZToYvBxOxNOFXXLTm):
        os.chdir(KHvNLlUeiYPHKdlhKXvjdSLILTFvrVms)
        DhNzSgOxzqkzPtCmDNHpUeWutnGbsWdd = UGFKWbMMprtbMhjUmKFmvjFmeRmbjEAZ('pcp1.pcp', nloc)
        DhNzSgOxzqkzPtCmDNHpUeWutnGbsWdd = DhNzSgOxzqkzPtCmDNHpUeWutnGbsWdd[scn_start_date:scn_end_date]
        mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB = pd.concat([cWXFIccyZDKEFnxjHooODJNDxfOqBpRf, DhNzSgOxzqkzPtCmDNHpUeWutnGbsWdd], OgXfQJVecXQhSxkBUlhpOuzeXSHWRJxo=0)
        BFgaAFLgRABVzSiLQvOnGrFydIWgMZhu = len(mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB.columns)
        print("  Combining base pcp and scenario pcp data in {} ... processing".format(BEcTBMfqLBgnuvucWAlBztLEuXfytfbk))
        for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in tqdm(range(BFgaAFLgRABVzSiLQvOnGrFydIWgMZhu)):
            mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB.iloc[:, raTwYUncqiBWINHTjrAyJSZMGtSFDHkz] = mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB.iloc[:, raTwYUncqiBWINHTjrAyJSZMGtSFDHkz].map(lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp: '{:05.1f}'.format(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp))
        mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB.insert(loc=0, column='year', value=mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB.index.year)
        mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB.insert(loc=1, column='jday', value=mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB.index.dayofyear.map(lambda FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp: '{:03d}'.format(FABYjpCLWzYzzjJIFTEvohvZvdoYoWHp)))
        zrvFMTbzGIEBBmmyKOZjtKIDeXGyJKEz = mrDcHdKNGRrnZeMiXPWGbAGLOlsPsOvB.T.astype(str).apply(''.join)
        dWrwpLjfDRRfqNWPhkXHlvYcLwJtkVIL = os.path.join(output_dir, BEcTBMfqLBgnuvucWAlBztLEuXfytfbk)
        if not os.path.exists(dWrwpLjfDRRfqNWPhkXHlvYcLwJtkVIL):
            os.mkdir(dWrwpLjfDRRfqNWPhkXHlvYcLwJtkVIL)
        try:
            with open(os.path.join(dWrwpLjfDRRfqNWPhkXHlvYcLwJtkVIL, 'pcp1.pcp'), 'w') as f:
                for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in range(4):
                    f.write('\n')
                zrvFMTbzGIEBBmmyKOZjtKIDeXGyJKEz.to_csv(f, KtDWybxVskqQYiDkfDMCoPxiHdxALRoA='\n', index=False, lMRlaNApGTntLyCiinIcllWUqdNcQeVc=None)
            print("  Combining base pcp and scenario pcp data in {} ... passed".format(BEcTBMfqLBgnuvucWAlBztLEuXfytfbk))
        except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                raise Exception("unable to copy {} from model: " + \
                                "to new worker dir: {1}\n{2}".format(f, dWrwpLjfDRRfqNWPhkXHlvYcLwJtkVIL, str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))  
    print("   Done!")
def zjGQELjNUZJdMPFktWYnQWnaRWjhmtkU(func, path, excinfo):
    os.chmod(path, 128)  
    func(path)
def gSbPiLUpitJBKUiNCBYaSyfLkySROaSm(
            euwCZqnHJGOuZcaNhqDNXDtpvMqhhRGJ, wwNKJFxKKJCNNyOrbFqdKIUuKYQKKNyJ,
            QiJZGHscptXgkNDRFwmXxfwUPEILYRWC=None, model_lists=None, weather_lists=None,
            VcUUOdmbtkZxFDpowprEIylLSQxHrNTf=None,
            EwYuwCmRfysQfltSsrOSCpzQdgbGhMJj=None,
            oSHHZnmHwsGhRGwagaVmcoKGhZdDUdMH=None,
            ):
    if model_lists is None:
        os.chdir(euwCZqnHJGOuZcaNhqDNXDtpvMqhhRGJ)
        fBTHeyiptSQyWzkTeRbsWvkCKYJgFmkU = [nXCoUozweCgYZMKZazxsZuQHQISawvQK for nXCoUozweCgYZMKZazxsZuQHQISawvQK in os.listdir(".") if os.path.isdir(nXCoUozweCgYZMKZazxsZuQHQISawvQK)]
        gmBDwosYJYvpSqVkxAAGlRtvcgCYApBy = [os.path.abspath(nXCoUozweCgYZMKZazxsZuQHQISawvQK) for nXCoUozweCgYZMKZazxsZuQHQISawvQK in os.listdir(".") if os.path.isdir(nXCoUozweCgYZMKZazxsZuQHQISawvQK)]
    if weather_lists is None:
        os.chdir(wwNKJFxKKJCNNyOrbFqdKIUuKYQKKNyJ)
        PVIhfbNwOdFOJjCyccdJFZxqhcCAIdOF = [nXCoUozweCgYZMKZazxsZuQHQISawvQK for nXCoUozweCgYZMKZazxsZuQHQISawvQK in os.listdir(".") if os.path.isdir(nXCoUozweCgYZMKZazxsZuQHQISawvQK)]
        BvnaUCsvsyErTLBTvkNiglTxfQAwvQCj = [os.path.abspath(nXCoUozweCgYZMKZazxsZuQHQISawvQK) for nXCoUozweCgYZMKZazxsZuQHQISawvQK in os.listdir(".") if os.path.isdir(nXCoUozweCgYZMKZazxsZuQHQISawvQK)]
    if QiJZGHscptXgkNDRFwmXxfwUPEILYRWC is None:
        QiJZGHscptXgkNDRFwmXxfwUPEILYRWC = '..'
    for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, fWENkUsatVHbCAViGIyvJZeyRpIdbZlO in zip(fBTHeyiptSQyWzkTeRbsWvkCKYJgFmkU, gmBDwosYJYvpSqVkxAAGlRtvcgCYApBy):
        for KItnZpuMYJrEORIoDuefWfBiuzIrgQUm, DgQrDEQiwNakfRKytHjrHGViHIMiZwJC in zip(PVIhfbNwOdFOJjCyccdJFZxqhcCAIdOF, BvnaUCsvsyErTLBTvkNiglTxfQAwvQCj):
            HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh = os.path.join(QiJZGHscptXgkNDRFwmXxfwUPEILYRWC, "{}_{}".format(raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, KItnZpuMYJrEORIoDuefWfBiuzIrgQUm))
            if os.path.exists(HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh) and oSHHZnmHwsGhRGwagaVmcoKGhZdDUdMH is None:
                try:
                    shutil.rmtree(HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh, onerror=zjGQELjNUZJdMPFktWYnQWnaRWjhmtkU)
                except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                    raise Exception("unable to remove existing worker dir:" + \
                                    "{0}\n{1}".format(HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh,str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))
                print("  Creating new model: {}_{} ... processing".format(raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, KItnZpuMYJrEORIoDuefWfBiuzIrgQUm))
                try:
                    shutil.copytree(fWENkUsatVHbCAViGIyvJZeyRpIdbZlO, HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh)
                except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                    raise Exception("unable to copy files from worker dir: " + \
                                    "{0} to new worker dir: {1}\n{2}".format(fWENkUsatVHbCAViGIyvJZeyRpIdbZlO, HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh,str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))
                print("  Creating new model: {}_{} ... passed".format(raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, KItnZpuMYJrEORIoDuefWfBiuzIrgQUm)) 
            elif os.path.exists(HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh) and oSHHZnmHwsGhRGwagaVmcoKGhZdDUdMH is True:
                try:
                    os.chdir(fWENkUsatVHbCAViGIyvJZeyRpIdbZlO)
                    shutil.copyfile('file.cio', os.path.join(HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh, 'file.cio'))
                except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                    raise Exception("unable to copy *.pst from main worker: " + \
                                    "{0} to new worker dir: {1}\n{2}".format(fWENkUsatVHbCAViGIyvJZeyRpIdbZlO, HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh,str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))
                print("  Using existing model: {}_{} ... passed".format(raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, KItnZpuMYJrEORIoDuefWfBiuzIrgQUm)) 
            else:
                try:
                    shutil.copytree(fWENkUsatVHbCAViGIyvJZeyRpIdbZlO, HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh)
                except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                    raise Exception("unable to copy files from worker dir: " + \
                                    "{0} to new worker dir: {1}\n{2}".format(fWENkUsatVHbCAViGIyvJZeyRpIdbZlO, HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh,str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))
                print("  Creating new model: {}_{} ... passed".format(raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, KItnZpuMYJrEORIoDuefWfBiuzIrgQUm)) 
            if VcUUOdmbtkZxFDpowprEIylLSQxHrNTf is not None and oSHHZnmHwsGhRGwagaVmcoKGhZdDUdMH is True:
                try:
                    os.chdir(fWENkUsatVHbCAViGIyvJZeyRpIdbZlO)
                    for f in VcUUOdmbtkZxFDpowprEIylLSQxHrNTf:
                        shutil.copyfile(f, os.path.join(HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh,f))
                except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                    raise Exception("unable to copy {0} from model dir: " + \
                                    "{1} to new model dir: {2}\n{3}".format(f, fWENkUsatVHbCAViGIyvJZeyRpIdbZlO, HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh,str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))      
            if EwYuwCmRfysQfltSsrOSCpzQdgbGhMJj is not None and oSHHZnmHwsGhRGwagaVmcoKGhZdDUdMH is True:
                try:
                    os.chdir(DgQrDEQiwNakfRKytHjrHGViHIMiZwJC)
                    for f in EwYuwCmRfysQfltSsrOSCpzQdgbGhMJj:
                        shutil.copyfile(f, os.path.join(HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh,f))
                except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                    raise Exception("unable to copy {0} from model dir: " + \
                                    "{1} to new model dir: {2}\n{3}".format(f, fWENkUsatVHbCAViGIyvJZeyRpIdbZlO, HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh,str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))               
            jcNfPllrbHNUnSqPBWkhFLKrXBneyqUW = HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh
            os.chdir(jcNfPllrbHNUnSqPBWkhFLKrXBneyqUW)
            os.system("start cmd /k apexmf.exe")
def GimLvxACyQhsByoHXewrstfFPrsZfrxh(
                    euwCZqnHJGOuZcaNhqDNXDtpvMqhhRGJ, UcjIJoCdVvayLEqtwaqKKWpwHSaSSHLd, ZBcZMoJAxTDCpMaLzjadZRyoiTEhLkTJ=None, YgXkIkBnoBtCYlqUJjXAMMvdiUxZVxzI=None, KCqxOsDUsPesAzmTIvxdaeWoVZLdqiUT=None,     
                    ):
    os.chdir(euwCZqnHJGOuZcaNhqDNXDtpvMqhhRGJ)
    if KCqxOsDUsPesAzmTIvxdaeWoVZLdqiUT is None:
        KCqxOsDUsPesAzmTIvxdaeWoVZLdqiUT = '_results'
    if YgXkIkBnoBtCYlqUJjXAMMvdiUxZVxzI is None:
        YgXkIkBnoBtCYlqUJjXAMMvdiUxZVxzI = [nXCoUozweCgYZMKZazxsZuQHQISawvQK for nXCoUozweCgYZMKZazxsZuQHQISawvQK in os.listdir(".") if os.path.isdir(nXCoUozweCgYZMKZazxsZuQHQISawvQK)]
        gmBDwosYJYvpSqVkxAAGlRtvcgCYApBy = [os.path.abspath(nXCoUozweCgYZMKZazxsZuQHQISawvQK) for nXCoUozweCgYZMKZazxsZuQHQISawvQK in os.listdir(".") if os.path.isdir(nXCoUozweCgYZMKZazxsZuQHQISawvQK)]
    else:
        gmBDwosYJYvpSqVkxAAGlRtvcgCYApBy = [os.path.abspath(nXCoUozweCgYZMKZazxsZuQHQISawvQK) for nXCoUozweCgYZMKZazxsZuQHQISawvQK in YgXkIkBnoBtCYlqUJjXAMMvdiUxZVxzI if os.path.isdir(nXCoUozweCgYZMKZazxsZuQHQISawvQK)]
    if ZBcZMoJAxTDCpMaLzjadZRyoiTEhLkTJ is None:
        ZBcZMoJAxTDCpMaLzjadZRyoiTEhLkTJ = '..'
    for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz , fWENkUsatVHbCAViGIyvJZeyRpIdbZlO in tqdm(zip(YgXkIkBnoBtCYlqUJjXAMMvdiUxZVxzI, gmBDwosYJYvpSqVkxAAGlRtvcgCYApBy)):
        JPgwuHPRYhjscFWNWLQvDTNtRmaUPYcW = os.path.join(ZBcZMoJAxTDCpMaLzjadZRyoiTEhLkTJ, "{}{}".format(raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, KCqxOsDUsPesAzmTIvxdaeWoVZLdqiUT))
        if not os.path.exists(JPgwuHPRYhjscFWNWLQvDTNtRmaUPYcW):
            os.mkdir(JPgwuHPRYhjscFWNWLQvDTNtRmaUPYcW)
        try:
            print("  Coyping output files from {} to {} ... processing".format(raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, fWENkUsatVHbCAViGIyvJZeyRpIdbZlO))  
            os.chdir(fWENkUsatVHbCAViGIyvJZeyRpIdbZlO)
            for f in UcjIJoCdVvayLEqtwaqKKWpwHSaSSHLd:
                shutil.copyfile(f, os.path.join(JPgwuHPRYhjscFWNWLQvDTNtRmaUPYcW, f))
            print("  Coyping output files from {} to {} ... passed".format(raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, fWENkUsatVHbCAViGIyvJZeyRpIdbZlO))  
        except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                raise Exception("unable to copy {} from model: " + \
                                "to new worker dir: {1}\n{2}".format(f, fWENkUsatVHbCAViGIyvJZeyRpIdbZlO, str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))            
def tWeAnhjigvYLhZRLipOPdWJgEISSkwQD(wd_base):
    with open(os.path.join(wd_base, "input.std"), "r") as fRGrWyhKlbruZzcjydyfpvtEwDSGRKaw:
        KDQDSAtQQxvCDaPNPwksWByTCTzISoUc = fRGrWyhKlbruZzcjydyfpvtEwDSGRKaw.readlines()
        for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, TDIRbYtpiKJcPbcNDWYzqCdKjdjiRDCY in enumerate(fRGrWyhKlbruZzcjydyfpvtEwDSGRKaw, 1):
            if TDIRbYtpiKJcPbcNDWYzqCdKjdjiRDCY.strip().startswith("HRU Input Summary Table 1:"):
                yslwWKRhjWyREXZDnGkfmCaBubdWidEh = raTwYUncqiBWINHTjrAyJSZMGtSFDHkz
            if TDIRbYtpiKJcPbcNDWYzqCdKjdjiRDCY.strip().startswith("HRU CN Input Summary Table:"):
                bTPZkmEaXpAbNTjQdpBVipwdWYKmXWsb = raTwYUncqiBWINHTjrAyJSZMGtSFDHkz
    fLNMhmTOsUBlnajdfMSWoRjVXfMNRzYi = []
    JjDZSqIJtgaBKThvGXcEzvVgxaCxElOA = []
    for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in KDQDSAtQQxvCDaPNPwksWByTCTzISoUc[yslwWKRhjWyREXZDnGkfmCaBubdWidEh+1:bTPZkmEaXpAbNTjQdpBVipwdWYKmXWsb-2]:
        fLNMhmTOsUBlnajdfMSWoRjVXfMNRzYi.append(raTwYUncqiBWINHTjrAyJSZMGtSFDHkz.split()[1])
        JjDZSqIJtgaBKThvGXcEzvVgxaCxElOA.append(raTwYUncqiBWINHTjrAyJSZMGtSFDHkz.split()[2])
    zpIxugvJUgYNZkSmBSiXWJIpUQehfkJf = pd.DataFrame({'hru':fLNMhmTOsUBlnajdfMSWoRjVXfMNRzYi, 'area(ha)':JjDZSqIJtgaBKThvGXcEzvVgxaCxElOA})
    zpIxugvJUgYNZkSmBSiXWJIpUQehfkJf = zpIxugvJUgYNZkSmBSiXWJIpUQehfkJf.astype({'hru':int, 'area(ha)':float})
    zpIxugvJUgYNZkSmBSiXWJIpUQehfkJf['area(m2)'] = zpIxugvJUgYNZkSmBSiXWJIpUQehfkJf.loc[:, 'area(ha)']*10000
    return zpIxugvJUgYNZkSmBSiXWJIpUQehfkJf
def xLGhqYsLFlxjwIGADWjQJmYGbfBhwnGs(
            fQVoIwtGmjRshenJrRdFUsDcziohiFcE,
            JlbsMTjEuAwXPHjvWrXPTjFGsrOXERmE, 
            wwNKJFxKKJCNNyOrbFqdKIUuKYQKKNyJ,
            SvpVmCclamaohoHcgHNUibkxnlORSCNc=None, model_lists=None, weather_lists=None,
            VcUUOdmbtkZxFDpowprEIylLSQxHrNTf=None,
            EwYuwCmRfysQfltSsrOSCpzQdgbGhMJj=None,
            oSHHZnmHwsGhRGwagaVmcoKGhZdDUdMH=None,
            ):
    if weather_lists is None:
        os.chdir(wwNKJFxKKJCNNyOrbFqdKIUuKYQKKNyJ)
        PVIhfbNwOdFOJjCyccdJFZxqhcCAIdOF = [nXCoUozweCgYZMKZazxsZuQHQISawvQK for nXCoUozweCgYZMKZazxsZuQHQISawvQK in os.listdir(".") if os.path.isdir(nXCoUozweCgYZMKZazxsZuQHQISawvQK)]
        BvnaUCsvsyErTLBTvkNiglTxfQAwvQCj = [os.path.abspath(nXCoUozweCgYZMKZazxsZuQHQISawvQK) for nXCoUozweCgYZMKZazxsZuQHQISawvQK in os.listdir(".") if os.path.isdir(nXCoUozweCgYZMKZazxsZuQHQISawvQK)]
    if SvpVmCclamaohoHcgHNUibkxnlORSCNc is None:
        SvpVmCclamaohoHcgHNUibkxnlORSCNc = '..'
    for KItnZpuMYJrEORIoDuefWfBiuzIrgQUm, DgQrDEQiwNakfRKytHjrHGViHIMiZwJC in zip(PVIhfbNwOdFOJjCyccdJFZxqhcCAIdOF, BvnaUCsvsyErTLBTvkNiglTxfQAwvQCj):
        HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh = os.path.join(SvpVmCclamaohoHcgHNUibkxnlORSCNc, "{}_{}".format(JlbsMTjEuAwXPHjvWrXPTjFGsrOXERmE, KItnZpuMYJrEORIoDuefWfBiuzIrgQUm))
        if os.path.exists(HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh) and oSHHZnmHwsGhRGwagaVmcoKGhZdDUdMH is None:
            try:
                shutil.rmtree(HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh, onerror=zjGQELjNUZJdMPFktWYnQWnaRWjhmtkU)
            except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                raise Exception("unable to remove existing worker dir:" + \
                                "{0}\n{1}".format(HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh,str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))
            print("  Creating new model: {}_{} ... processing".format(JlbsMTjEuAwXPHjvWrXPTjFGsrOXERmE, KItnZpuMYJrEORIoDuefWfBiuzIrgQUm))
            try:
                shutil.copytree(fQVoIwtGmjRshenJrRdFUsDcziohiFcE, HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh)
            except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                raise Exception("unable to copy files from worker dir: " + \
                                "{0} to new worker dir: {1}\n{2}".format(fQVoIwtGmjRshenJrRdFUsDcziohiFcE, HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh,str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))
            print("  Creating new model: {}_{} ... passed".format(JlbsMTjEuAwXPHjvWrXPTjFGsrOXERmE, KItnZpuMYJrEORIoDuefWfBiuzIrgQUm)) 
        elif os.path.exists(HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh) and oSHHZnmHwsGhRGwagaVmcoKGhZdDUdMH is True:
            try:
                os.chdir(fQVoIwtGmjRshenJrRdFUsDcziohiFcE)
            except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                raise Exception("unable to copy *.pst from main worker: " + \
                                "{0} to new worker dir: {1}\n{2}".format(fQVoIwtGmjRshenJrRdFUsDcziohiFcE, HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh,str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))
            print("  Using existing model: {}_{} ... passed".format(JlbsMTjEuAwXPHjvWrXPTjFGsrOXERmE, KItnZpuMYJrEORIoDuefWfBiuzIrgQUm)) 
        else:
            try:
                shutil.copytree(fQVoIwtGmjRshenJrRdFUsDcziohiFcE, HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh)
                print("  Copying model: {}_{} ... passed".format(JlbsMTjEuAwXPHjvWrXPTjFGsrOXERmE, KItnZpuMYJrEORIoDuefWfBiuzIrgQUm)) 
                zlcHAyUyJkVYBEbkLRqRTSmLoVjGTNng = os.listdir(DgQrDEQiwNakfRKytHjrHGViHIMiZwJC)
                for usMrXtjqapJxdigbBtXSZmLkkkYYSfDW in zlcHAyUyJkVYBEbkLRqRTSmLoVjGTNng:
                    shutil.copyfile(os.path.join(DgQrDEQiwNakfRKytHjrHGViHIMiZwJC, usMrXtjqapJxdigbBtXSZmLkkkYYSfDW), os.path.join(HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh, usMrXtjqapJxdigbBtXSZmLkkkYYSfDW))
                print("  Copying weather inputs: {}_{} ... passed".format(JlbsMTjEuAwXPHjvWrXPTjFGsrOXERmE, KItnZpuMYJrEORIoDuefWfBiuzIrgQUm)) 
            except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                raise Exception("unable to copy files from worker dir: " + \
                                "{0} to new worker dir: {1}\n{2}".format(fQVoIwtGmjRshenJrRdFUsDcziohiFcE, HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh,str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))
            print("  Creating new model: {}_{} ... passed".format(JlbsMTjEuAwXPHjvWrXPTjFGsrOXERmE, KItnZpuMYJrEORIoDuefWfBiuzIrgQUm)) 
        if VcUUOdmbtkZxFDpowprEIylLSQxHrNTf is not None and oSHHZnmHwsGhRGwagaVmcoKGhZdDUdMH is True:
            try:
                os.chdir(fQVoIwtGmjRshenJrRdFUsDcziohiFcE)
                for f in VcUUOdmbtkZxFDpowprEIylLSQxHrNTf:
                    shutil.copyfile(f, os.path.join(HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh,f))
            except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                raise Exception("unable to copy {0} from model dir: " + \
                                "{1} to new model dir: {2}\n{3}".format(f, fQVoIwtGmjRshenJrRdFUsDcziohiFcE, HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh,str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))      
        if EwYuwCmRfysQfltSsrOSCpzQdgbGhMJj is not None and oSHHZnmHwsGhRGwagaVmcoKGhZdDUdMH is True:
            try:
                os.chdir(DgQrDEQiwNakfRKytHjrHGViHIMiZwJC)
                for f in EwYuwCmRfysQfltSsrOSCpzQdgbGhMJj:
                    shutil.copyfile(f, os.path.join(HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh,f))
            except Exception as tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme:
                raise Exception("unable to copy {0} from model dir: " + \
                                "{1} to new model dir: {2}\n{3}".format(f, fQVoIwtGmjRshenJrRdFUsDcziohiFcE, HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh,str(tDlvKcNXwEaCJpYVJeeqmQgpOIcGwHme)))               
        jcNfPllrbHNUnSqPBWkhFLKrXBneyqUW = HEPAijxsUqiJHhJlrqpaKaUVxvcbfgwh
        os.chdir(jcNfPllrbHNUnSqPBWkhFLKrXBneyqUW)
        os.system("start cmd /k apexmf.exe")
if __name__ == '__main__':
    fQVoIwtGmjRshenJrRdFUsDcziohiFcE = "D:\\Projects\\manuscript_CRB_PCP\\Data\\calibrated_models\\animas"
    JlbsMTjEuAwXPHjvWrXPTjFGsrOXERmE = "animas"
    wwNKJFxKKJCNNyOrbFqdKIUuKYQKKNyJ = "D:\\Projects\\manuscript_CRB_PCP\\Data\\pcp_products\\animas"
    meaQUmqgdPzSNXRrtyZwvegUjxlatNQr = "D:\\Projects\\manuscript_CRB_PCP\\Analysis\\gridpp_models"
    xLGhqYsLFlxjwIGADWjQJmYGbfBhwnGs(fQVoIwtGmjRshenJrRdFUsDcziohiFcE, JlbsMTjEuAwXPHjvWrXPTjFGsrOXERmE, wwNKJFxKKJCNNyOrbFqdKIUuKYQKKNyJ, SvpVmCclamaohoHcgHNUibkxnlORSCNc=meaQUmqgdPzSNXRrtyZwvegUjxlatNQr, oSHHZnmHwsGhRGwagaVmcoKGhZdDUdMH=True)
