import os
from datetime import datetime
import pyemu
from apexmf_pst_utils import extract_month_str, extract_watertable_sim, extract_month_sed
from apexmf_pst_par import ZKTxMCqQfPGfxGNldBDSaMIzhlApaoMQ
import subprocess
import numpy as np
import pandas as pd
PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR = os.getcwd()
os.chdir(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR)
print(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR)
WzEXCbTmwsoNlnsiKkYAuNuvijqHPzij = PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR + "\MODFLOW"
NxnTYTgnhnCExbLDrRzsXxragvnOmTSG = 'SITE64.RCH'
YKfXZdDVImrlVdrdnEocbkOHiVardpIe = [21, 26, 64, 67, 84, 111]
qCBybeiXymMatsjIttdWJnVYYDWoVyJj = [8489]
ugBvoulFmhSGSGuoCSnhMqAfwsgPGGOe = datetime.now().strftime('[%m/%d/%y %H:%M:%S]')
print('\n' + 30*'+ ')
print(ugBvoulFmhSGSGuoCSnhMqAfwsgPGGOe + ' |  modifying river parameters...')
print(30*'+ ' + '\n')
os.chdir(WzEXCbTmwsoNlnsiKkYAuNuvijqHPzij)
ugBvoulFmhSGSGuoCSnhMqAfwsgPGGOe = datetime.now().strftime('[%m/%d/%y %H:%M:%S]')
print(ugBvoulFmhSGSGuoCSnhMqAfwsgPGGOe + ' |  modifying MODFLOW HK, VHK, and SY parameters...')
JdRduxgLYeuAcMrChIiElAqSZqCkdcnt = ['hk0pp.dat', 'sy0pp.dat']
for raTwYUncqiBWINHTjrAyJSZMGtSFDHkz in JdRduxgLYeuAcMrChIiElAqSZqCkdcnt:
    EFbonvWeiYTHfPrgkPRyRiriiNZbJOqd = raTwYUncqiBWINHTjrAyJSZMGtSFDHkz + '.ref'
    pyemu.utils.geostats.fac2real(raTwYUncqiBWINHTjrAyJSZMGtSFDHkz, factors_file=raTwYUncqiBWINHTjrAyJSZMGtSFDHkz+'.fac', out_file=EFbonvWeiYTHfPrgkPRyRiriiNZbJOqd)
os.chdir(PdMHnciMJDIVnYBurUeeCSYfnYrPEcLR)
ugBvoulFmhSGSGuoCSnhMqAfwsgPGGOe = datetime.now().strftime('[%m/%d/%y %H:%M:%S]')
print('\n' + 30*'+ ')
print(ugBvoulFmhSGSGuoCSnhMqAfwsgPGGOe + ' |  running model...')
print(30*'+ ' + '\n')
KHvNLlUeiYPHKdlhKXvjdSLILTFvrVms = subprocess.Popen('APEX1501.exe' , jcNfPllrbHNUnSqPBWkhFLKrXBneyqUW = '.')
KHvNLlUeiYPHKdlhKXvjdSLILTFvrVms.wait()
ugBvoulFmhSGSGuoCSnhMqAfwsgPGGOe = datetime.now().strftime('[%m/%d/%y %H:%M:%S]')
print('\n' + 50*'+ ')
print(ugBvoulFmhSGSGuoCSnhMqAfwsgPGGOe + ' | simulation successfully completed | extracting simulated values...')
print(50*'+ ' + '\n')
extract_month_str(NxnTYTgnhnCExbLDrRzsXxragvnOmTSG, YKfXZdDVImrlVdrdnEocbkOHiVardpIe, '1/1/2007', '1/1/2011', '12/31/2017')
extract_watertable_sim(qCBybeiXymMatsjIttdWJnVYYDWoVyJj, '1/1/2007', '12/31/2017')
print(ugBvoulFmhSGSGuoCSnhMqAfwsgPGGOe + ' | Complete ...')
