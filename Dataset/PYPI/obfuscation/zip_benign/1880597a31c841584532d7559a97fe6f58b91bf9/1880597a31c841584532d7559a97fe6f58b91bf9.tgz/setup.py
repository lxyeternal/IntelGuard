from setuptools import setup, find_packages
import codecs
import os
with open('README.rst', 'r') as fd:
    EdDkBkZIxegJhpPYJQOsVDipwcDEahhE = fd.read()
BWxZCRosEMXTnYJGRmwBmnAlSPzNSAgO = '0.4.0'
FilyEQiSJwXojnPmHlRmFMDbHfGQbGqI = (
    'apexmf is a set of python modules for APEX-MODFLOW model evaluation and parameter estimation.'
    )
usCIymDULLAPFCMhkaeEgEMRjTvBqksK = 'BSD-3-Clause'
setup(nXCoUozweCgYZMKZazxsZuQHQISawvQK='h96ux49wst0urf6v', paYCCjKxMjIBhgyYmEGMkrxJhByrdhQz='1.0.0',
    EXeUhXSPmKdlbskIQQqDEOQSHIQgIlxj='text/x-rst', download_url=
    'https://pypi.org/project/apexmf', project_urls={'Bug Tracker':
    'https://github.com/spark-brc/apexmf/issues', 'Source Code':
    'https://github.com/spark-brc/apexmf', 'Documentation':
    'https://github.com/spark-brc/apexmf'}, include_package_data=True,
    SDmvRPvgOyXhbgQwzZHZqREfgPTnPYgj={'opt_files': ['*']}, install_requires=['pandas', 'numpy',
    'pyemu', 'flopy', 'scipy', 'matplotlib', 'openpyxl', 'hydroeval',
    'tqdm', 'termcolor', 'pyshp'], keywords=['python', 'APEX-MODFLOW',
    'PEST'], classifiers=['Development Status :: 4 - Beta',
    'Intended Audience :: Education',
    'Intended Audience :: Science/Research',
    'Programming Language :: Python :: 3.8',
    'Programming Language :: Python :: 3.9',
    'Programming Language :: Python :: 3.10',
    'Operating System :: Microsoft :: Windows',
    'License :: OSI Approved :: BSD License'])
