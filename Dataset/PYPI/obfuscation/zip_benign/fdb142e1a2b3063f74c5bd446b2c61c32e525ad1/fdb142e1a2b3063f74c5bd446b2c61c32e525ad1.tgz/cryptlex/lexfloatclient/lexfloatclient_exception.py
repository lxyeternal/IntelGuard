from cryptlex.lexfloatclient.lexfloatstatus_codes import BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs
class ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(Exception):
    def __init__(self, code):
        super(ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW, self).__init__(
            ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW.ZhGGFtzrICemQKVtvjtHOsKAFUkCkuRS(code))
        self.message = ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW.ZhGGFtzrICemQKVtvjtHOsKAFUkCkuRS(code)
        self.code = code
    @staticmethod
    def ZhGGFtzrICemQKVtvjtHOsKAFUkCkuRS(code):
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.WMyHpBOeLwIyfssjrXwmmHoRgAHUWlLV:
            return 'The product id is incorrect.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.FjmCGPShTSvfDpKXZNLexCFenFTXLcCp:
            return 'Invalid or missing callback function.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.BryFSZnEmHqUDVRzDcKqaxHWPGJQSlSC:
            return 'Missing or invalid server url.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.KAnMHVmqOVoymBQkgLYIYBaCDsrKitws:
            return 'Ensure system date and time settings are correct.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.OchWzQueoQJLkgmvTJILZHmNIMJFTacz:
            return 'Failed to connect to the server due to network error.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.acaRikJJYtvtQeIYZAycizJUdQThEBIl:
            return 'License has not been leased yet.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.cXqyyZtEcfDUCViullMtNxjcsdvqAIsD:
            return 'License has already been leased.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.xMKJwilDXWtnIPnpBoWUbpOifTYkWllH:
            return 'License does not exist on server or has already expired.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.BTpnOhcODzITWtKmCBtcqmIjMDcsnqcf:
            return 'License lease has expired due to network error.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.JAayuVrUyyJyivwmPjOBIckHVbElXakt:
            return 'The server has reached it\'s allowed limit of floating licenses.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.nnZuVatABXqKzOPpRTKiFtQLixjQENgA:
            return 'The buffer size was smaller than required.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.hJHHVsNBgGJxORDCCiLrsvIeqXBPBSBW:
            return 'The metadata key does not exist.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.DCccoJcYqyQSpceawYargPeXJGlxiyCd:
            return 'Metadata key length is more than 256 characters.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.kbLuDQtnBDPPBerkQxIWLbugOszgwSfA:
            return 'Metadata value length is more than 4096 characters.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.lPYDJkdFZyxBugMEyDmzpASnDEmbeInr:
            return 'The floating client has reached it\'s metadata fields limit.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.ewKGRBxcdDDDlvBDqepDNxrrTulGAsrG:
            return 'The meter attribute does not exist.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.OKieziWhexWkAlTEAFhBVsanqylVtPiS:
            return 'The meter attribute has reached it\'s usage limit.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.hTeajTZLOfEfFhbSluhNdGvyYZzXidWS:
            return 'No product version is linked with the license.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.TJaSLowAWzyCqJcicsPAdjSSBXTRRuWn:
            return 'The product version feature flag does not exist.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.uNmGnrveepCvBWgDhiXwoKZNbBCIRjUq:
            return 'IP address is not allowed.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.vIQHDBNEZfREqWcEXCzUNhWUeJAhRZRg:
            return 'Client error.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.vwllAATfrouJcAiUDznLMWFgZFBnDXNy:
            return 'Server error.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.JKSyLBiGrwnwaADVGVZEhKuLiyMlPcpy:
            return 'System time on server has been tampered with.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.gcKnbYDNOzddapLeWdkIiRKEGSxuhyOZ:
            return 'The server has not been activated using a license key.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.NjPHDpafJXjEVfJWTUFkORaKRUjwDaVo:
            return 'The server license has expired.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.afCZqbvWlbrwKBaJzPxdJqHtVnMghlaR:
            return 'The server license has been suspended.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.fettBcUqgqDIrrsnATfadTxlufYFXsEF:
            return 'The grace period for server license is over.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.FKNsrACcmNCMiQyTNcJXCTBGjSmoJZKV:
            return 'Insufficient system permissions.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.RYNDUcwpiykJnnlLVyiiBEjeoTszqZDI:
            return 'Invalid permission flag.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.GIsTaGXGWOUPOGREJHBlOtALqFaAZDyg:
            return 'Offline floating license is not allowed for per-instance leasing strategy.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.HAklaRnBlEATtFUSbyWbyCxKoXuymZyN:
            return 'Maximum offline lease duration exceeded.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.HqlZyrTxUmbhdAUoUbfkNxLUvPIyhQBs:
            return 'Allowed offline floating clients limit reached.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.lKoidcbZWfhJnTkGTgNFUxgVHPczqOmC:
            return "Fingerprint couldn't be generated because Windows Management Instrumentation (WMI) service has been disabled. This error is specific to Windows only."
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.nHIGcggdIzSrSiDrdrHEgdlsGPVaWkYg:
            return 'Machine fingerprint has changed since activation.'
        if code == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.VSxopXrIsHGwZhCMCTIhmNboNurRPZkZ:
            return 'Request blocked due to untrusted proxy.'
        return 'Unknown error!'
