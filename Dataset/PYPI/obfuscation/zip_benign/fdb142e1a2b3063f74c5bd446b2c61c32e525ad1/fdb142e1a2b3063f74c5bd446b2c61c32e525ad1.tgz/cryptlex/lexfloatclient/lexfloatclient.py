import ctypes
import json
from cryptlex.lexfloatclient import lexfloatclient_native as LexFloatClientNative
from cryptlex.lexfloatclient.lexfloatstatus_codes import BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs
from cryptlex.lexfloatclient.lexfloatclient_exception import ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW
PKtKkmBepqCewvFVpheFODYlWSGYahPa = []
class wjZhNsddHJBSqwWgFutrnPSvbqouTUtx:
        ZjaEBDKWRZzRKLDXDPZhvEGhyfgJHQvX = 10
        XpjueVIPbGYWNrduoVYYPHIXNxmtPmtN = 11
class vBniStdFRIMrUIyKkkRUANCHtSSFLNbK(object):
    def __init__(self, name, OAJJzSQNDkNwbYEwXPLNglGVLctZSxjm, ciJGsFtwwAeJONMiFPMejJDcWfopqFxz, jQjxugpVzkwsTwAIkYZJEgNlkwQpqrGi):
        self.name = name
        self.OAJJzSQNDkNwbYEwXPLNglGVLctZSxjm = OAJJzSQNDkNwbYEwXPLNglGVLctZSxjm
        self.ciJGsFtwwAeJONMiFPMejJDcWfopqFxz = ciJGsFtwwAeJONMiFPMejJDcWfopqFxz
        self.jQjxugpVzkwsTwAIkYZJEgNlkwQpqrGi = jQjxugpVzkwsTwAIkYZJEgNlkwQpqrGi
class afWXzGUpgQcDYtliowdVdcGIGtRaosHn(object):
    def __init__(self, name, HEjbCMWqvaptZbZrEPYrGRLSwLxJQyWp, data):
        self.name = name
        self.HEjbCMWqvaptZbZrEPYrGRLSwLxJQyWp = HEjbCMWqvaptZbZrEPYrGRLSwLxJQyWp
        self.data = data
class wvFJGDGSlOhViRkNcpEdZiizEulgShyX(object):
    def __init__(self, max_offline_lease_duration):
        self.max_offline_lease_duration = max_offline_lease_duration
class zJzbaiYMZpIXPsueWdpNcgXuFZGilSvD:
    @staticmethod
    def VUVIOsTQSyiaFUmwGoWrwkkQaFlPYNzk(product_id):
        AZdJmQYOiTHivIJtbXktAIEbxYmpxUJl = LexFloatClientNative.uAuMXHCdxBfmtFiLXedkeeAgKkVGDFTq(product_id)
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.VUVIOsTQSyiaFUmwGoWrwkkQaFlPYNzk(AZdJmQYOiTHivIJtbXktAIEbxYmpxUJl)
        if BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD != ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
    @staticmethod
    def wMYoxbJbcYTTygfRmDkSchEuPvRKoxIQ(host_url):
        ZMPKnVAJYvtdaUzhlwwqLbCJhobmdWhN = LexFloatClientNative.uAuMXHCdxBfmtFiLXedkeeAgKkVGDFTq(host_url)
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.wMYoxbJbcYTTygfRmDkSchEuPvRKoxIQ(ZMPKnVAJYvtdaUzhlwwqLbCJhobmdWhN)
        if BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD != ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
    @staticmethod
    def PZTSgBKpmEUHshRHaQBgnFRHuMBoGZdF(license_callback):
        mnGCiauSCUJczMRxWxJLAGyLKWznUtQW = LexFloatClientNative.KhKNoiVKHRUbvWiAemAUXWiNLRfEjhjG(
            license_callback)
        PKtKkmBepqCewvFVpheFODYlWSGYahPa.append(mnGCiauSCUJczMRxWxJLAGyLKWznUtQW)
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.PZTSgBKpmEUHshRHaQBgnFRHuMBoGZdF(
            mnGCiauSCUJczMRxWxJLAGyLKWznUtQW)
        if BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD != ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
    @staticmethod
    def ccKphElmmGdFICAiZHOklWWAfXUYoXXt(key, value):
        uERZkfMhIxCVlkdfJZfEPIXYSevjaaVK = LexFloatClientNative.uAuMXHCdxBfmtFiLXedkeeAgKkVGDFTq(key)
        xiivIIAMTrwqoFcACJOmjEBuiRIAfnMw = LexFloatClientNative.uAuMXHCdxBfmtFiLXedkeeAgKkVGDFTq(value)
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.ccKphElmmGdFICAiZHOklWWAfXUYoXXt(
            uERZkfMhIxCVlkdfJZfEPIXYSevjaaVK, xiivIIAMTrwqoFcACJOmjEBuiRIAfnMw)
        if BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD != ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
    @staticmethod
    def jfdbCgylArFEiiZajVIQXFhyDvWqprHc(flag):
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.jfdbCgylArFEiiZajVIQXFhyDvWqprHc(flag)
        if BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD != ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
    @staticmethod
    def UAXmPTwPrzvVbkKAkUuAjTvqscOBfCEv():
        gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS = 256
        hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG = LexFloatClientNative.lVSXdoEgOoLzHWCSoCkLJEyBRUPqOEZZ(gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS)
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.UAXmPTwPrzvVbkKAkUuAjTvqscOBfCEv(hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG,gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS)
        if ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe != BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
        return LexFloatClientNative.mvwBphXmTAsDEQcgDZFRnCoUBRghoOZT(hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG.value)  
    @staticmethod
    def UeVBiDEpGpeIHGJxIuwXBgkHFCNPNZVI():
        gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS = 1024      
        hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG = LexFloatClientNative.lVSXdoEgOoLzHWCSoCkLJEyBRUPqOEZZ(gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS)
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.UeVBiDEpGpeIHGJxIuwXBgkHFCNPNZVI(hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG, gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS)
        if ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD:
            ikGDafuSFlSbQfVcvXHbwKGDolWuoZCI = LexFloatClientNative.mvwBphXmTAsDEQcgDZFRnCoUBRghoOZT(hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG.value)
            if not ikGDafuSFlSbQfVcvXHbwKGDolWuoZCI.strip():
                return None
            else:
                KVrdgulRRQKsQyCEwaaRJYVcuoKqEuId = json.loads(ikGDafuSFlSbQfVcvXHbwKGDolWuoZCI)
                return wvFJGDGSlOhViRkNcpEdZiizEulgShyX(KVrdgulRRQKsQyCEwaaRJYVcuoKqEuId["maxOfflineLeaseDuration"])
        else:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
    @staticmethod
    def JASBSuMrMSfDUuPChAdlJmKxMtQBeMmQ():
        gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS = 256
        hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG = LexFloatClientNative.lVSXdoEgOoLzHWCSoCkLJEyBRUPqOEZZ(gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS)
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.JASBSuMrMSfDUuPChAdlJmKxMtQBeMmQ(hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG,gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS)
        if ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe != BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
        return LexFloatClientNative.mvwBphXmTAsDEQcgDZFRnCoUBRghoOZT(hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG.value)
    @staticmethod
    def JxazeSxcYDaOljAWnEbWCFOvvehdqlDX():
        gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS = 256
        hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG = LexFloatClientNative.lVSXdoEgOoLzHWCSoCkLJEyBRUPqOEZZ(gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS)
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.JxazeSxcYDaOljAWnEbWCFOvvehdqlDX(hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG,gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS)
        if ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe != BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
        return LexFloatClientNative.mvwBphXmTAsDEQcgDZFRnCoUBRghoOZT(hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG.value)
    @staticmethod
    def ZgXYfTYnDuRqOAexiTjkGgQzauXNIFXR(name):
        SFSBysEPUArKeJqSGvBGKuBITCtLGWoU = LexFloatClientNative.uAuMXHCdxBfmtFiLXedkeeAgKkVGDFTq(name)
        HEjbCMWqvaptZbZrEPYrGRLSwLxJQyWp = ctypes.c_uint()
        gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS = 256
        hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG = LexFloatClientNative.lVSXdoEgOoLzHWCSoCkLJEyBRUPqOEZZ(gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS)
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.ZgXYfTYnDuRqOAexiTjkGgQzauXNIFXR(SFSBysEPUArKeJqSGvBGKuBITCtLGWoU, ctypes.byref(HEjbCMWqvaptZbZrEPYrGRLSwLxJQyWp), hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG, gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS)
        if ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD:
            cjHiroohLrNEXXbvbrZwiPXKWieXqbZr = HEjbCMWqvaptZbZrEPYrGRLSwLxJQyWp.value > 0
            return afWXzGUpgQcDYtliowdVdcGIGtRaosHn(name, cjHiroohLrNEXXbvbrZwiPXKWieXqbZr, LexFloatClientNative.mvwBphXmTAsDEQcgDZFRnCoUBRghoOZT(hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG.value))
        else:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
    @staticmethod
    def uWzvaBMCLtslnkOdZNSmBbzLkbCSxCgq(key):
        uERZkfMhIxCVlkdfJZfEPIXYSevjaaVK = LexFloatClientNative.uAuMXHCdxBfmtFiLXedkeeAgKkVGDFTq(key)
        gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS = 256
        hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG = LexFloatClientNative.lVSXdoEgOoLzHWCSoCkLJEyBRUPqOEZZ(gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS)
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.uWzvaBMCLtslnkOdZNSmBbzLkbCSxCgq(
            uERZkfMhIxCVlkdfJZfEPIXYSevjaaVK, hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG, gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS)
        if ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe != BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
        return LexFloatClientNative.mvwBphXmTAsDEQcgDZFRnCoUBRghoOZT(hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG.value)
    @staticmethod
    def KMnmxomvoPHRVijzYGmMjDwJMthrPPyH(name):
        SFSBysEPUArKeJqSGvBGKuBITCtLGWoU = LexFloatClientNative.uAuMXHCdxBfmtFiLXedkeeAgKkVGDFTq(name)
        OAJJzSQNDkNwbYEwXPLNglGVLctZSxjm = ctypes.c_int64()
        ciJGsFtwwAeJONMiFPMejJDcWfopqFxz = ctypes.c_uint64()
        jQjxugpVzkwsTwAIkYZJEgNlkwQpqrGi = ctypes.c_uint64()
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.KMnmxomvoPHRVijzYGmMjDwJMthrPPyH(
            SFSBysEPUArKeJqSGvBGKuBITCtLGWoU, ctypes.byref(OAJJzSQNDkNwbYEwXPLNglGVLctZSxjm), ctypes.byref(ciJGsFtwwAeJONMiFPMejJDcWfopqFxz), ctypes.byref(jQjxugpVzkwsTwAIkYZJEgNlkwQpqrGi))
        if ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD:
            return vBniStdFRIMrUIyKkkRUANCHtSSFLNbK(name, OAJJzSQNDkNwbYEwXPLNglGVLctZSxjm.value, ciJGsFtwwAeJONMiFPMejJDcWfopqFxz.value, jQjxugpVzkwsTwAIkYZJEgNlkwQpqrGi.value)
        else:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
    @staticmethod
    def wTThEPxqIYMkeSYsvJJtTKmaoYWavpaE():
        ilEgVcGMsEjedlOjTumxyZePqqBClcrl = ctypes.c_uint()
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.wTThEPxqIYMkeSYsvJJtTKmaoYWavpaE(
            ctypes.byref(ilEgVcGMsEjedlOjTumxyZePqqBClcrl))
        if ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD:
            return ilEgVcGMsEjedlOjTumxyZePqqBClcrl.value
        else:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
    @staticmethod
    def mmNdXnUHOCNChnzYqxjcVnzKmvaPwiNs():
        hkxZEICNHdCWwKapVDdqIchoIXvxdJaC = ctypes.c_uint()
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.mmNdXnUHOCNChnzYqxjcVnzKmvaPwiNs(
            ctypes.byref(hkxZEICNHdCWwKapVDdqIchoIXvxdJaC))
        if ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD:
            return hkxZEICNHdCWwKapVDdqIchoIXvxdJaC.value
        else:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
    @staticmethod
    def kqajyASmXbfFsZeqvSXiZRKIELUtaICD(name):
        SFSBysEPUArKeJqSGvBGKuBITCtLGWoU = LexFloatClientNative.uAuMXHCdxBfmtFiLXedkeeAgKkVGDFTq(name)
        XYbIbdjVbfVHysyrpxHYbNUXvreHwfEW = ctypes.c_uint()
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.kqajyASmXbfFsZeqvSXiZRKIELUtaICD(
            SFSBysEPUArKeJqSGvBGKuBITCtLGWoU, ctypes.byref(XYbIbdjVbfVHysyrpxHYbNUXvreHwfEW))
        if ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe == BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD:
            return XYbIbdjVbfVHysyrpxHYbNUXvreHwfEW.value
        else:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
    @staticmethod
    def UmmJfLjaNPeDxYZMJELxtbscmKpxdOaj():
        gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS = 256
        hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG = LexFloatClientNative.lVSXdoEgOoLzHWCSoCkLJEyBRUPqOEZZ(gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS)
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.UmmJfLjaNPeDxYZMJELxtbscmKpxdOaj(hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG,gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS)
        if ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe != BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
        return LexFloatClientNative.mvwBphXmTAsDEQcgDZFRnCoUBRghoOZT(hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG.value)   
    @staticmethod
    def BLDqGYGCQTgCWqUttXfairaNyhpFsoKf(key):
        uERZkfMhIxCVlkdfJZfEPIXYSevjaaVK = LexFloatClientNative.uAuMXHCdxBfmtFiLXedkeeAgKkVGDFTq(key)
        gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS = 4096
        hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG = LexFloatClientNative.lVSXdoEgOoLzHWCSoCkLJEyBRUPqOEZZ(gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS)
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.BLDqGYGCQTgCWqUttXfairaNyhpFsoKf(
            uERZkfMhIxCVlkdfJZfEPIXYSevjaaVK, hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG, gDGXPOwWjbUjNxDqiRGSzHgVvDHFhNXS)
        if ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe != BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
        return LexFloatClientNative.mvwBphXmTAsDEQcgDZFRnCoUBRghoOZT(hxculNtEyjgyQJZpvzLSSOgqRDBzPSXG.value)
    @staticmethod
    def QDnXNqWBlkwcncWvLDMFBQUcJPYRtpww():
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.QDnXNqWBlkwcncWvLDMFBQUcJPYRtpww()
        if BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD != ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
    @staticmethod
    def AKswBJLBDoUYszEiNimMtfptTSGcddKu(lease_duration):
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.AKswBJLBDoUYszEiNimMtfptTSGcddKu(lease_duration)
        if BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD != ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
    @staticmethod
    def nzolFtINXKRPObSLBMCPqxZsoYGUncaK():
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.nzolFtINXKRPObSLBMCPqxZsoYGUncaK()
        if BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD != ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
    @staticmethod
    def nLgEXJBCkxHdgINyGnkdRQdxwOmidUBj():
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.nLgEXJBCkxHdgINyGnkdRQdxwOmidUBj()
        if BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD == ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe:
            return True
        elif BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.acaRikJJYtvtQeIYZAycizJUdQThEBIl == ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe:
            return False
        elif BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yGbgUtVQOyTVprROfwIMxIoByDMfgXoT == ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe:
            return False
        else:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
    @staticmethod
    def FhbOtoMzDeqlfXfniKQUTqhvRKjynEiz(name, increment):
        SFSBysEPUArKeJqSGvBGKuBITCtLGWoU = LexFloatClientNative.uAuMXHCdxBfmtFiLXedkeeAgKkVGDFTq(name)
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.FhbOtoMzDeqlfXfniKQUTqhvRKjynEiz(
            SFSBysEPUArKeJqSGvBGKuBITCtLGWoU, increment)
        if BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD != ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
    @staticmethod
    def nqeZokllKeXoUEtiEjZvlaeiPtIqvzDd(name, decrement):
        SFSBysEPUArKeJqSGvBGKuBITCtLGWoU = LexFloatClientNative.uAuMXHCdxBfmtFiLXedkeeAgKkVGDFTq(name)
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.nqeZokllKeXoUEtiEjZvlaeiPtIqvzDd(
            SFSBysEPUArKeJqSGvBGKuBITCtLGWoU, decrement)
        if BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD != ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
    @staticmethod
    def zufnJqATqJKTzSipvKNJUktLxvItCKJY(name):
        SFSBysEPUArKeJqSGvBGKuBITCtLGWoU = LexFloatClientNative.uAuMXHCdxBfmtFiLXedkeeAgKkVGDFTq(name)
        ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe = LexFloatClientNative.zufnJqATqJKTzSipvKNJUktLxvItCKJY(
            SFSBysEPUArKeJqSGvBGKuBITCtLGWoU)
        if BgiYNjTgsuQaFLntDMhvkbrKGcGZDUQs.yIppOcRaTUMBxwDTqmZXsbZazweSTSkD != ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe:
            raise ZZPRxcIlnmtVsLWXtjIQyPuCAxkEWMGW(ccpiCeAIahiXiaRpZzzMqeDNxmyRsOJe)
