from ctypes import *
import os
import sys
import platform
import inspect
import subprocess
import ctypes
import ctypes.util
def FsHFLKypPWfoDvxfnXiaATWuisYvzwmS(type):
    if (hasattr(type, "_type_") and isinstance(type._type_, str)
            and type._type_ != "P"):
        return type
    else:
        return c_void_p
def RPMYhNXqSDoYCEADPlMkwJnqKctJCKzn():
    return platform.OTdOBiwJduZVjEyTXvobHIqTwcOpNZfP().endswith('64')
def keqKcYnhXeTJxwXcPaAoHEAgIdcOifYQ():
    dqyVRAWGSEnydhBcQJjwJaAUBViwoeIf = sys.maxsize > 2**32
    OTdOBiwJduZVjEyTXvobHIqTwcOpNZfP = platform.OTdOBiwJduZVjEyTXvobHIqTwcOpNZfP().lower()
    if 'arm' in OTdOBiwJduZVjEyTXvobHIqTwcOpNZfP or 'aarch64' in OTdOBiwJduZVjEyTXvobHIqTwcOpNZfP:
        if dqyVRAWGSEnydhBcQJjwJaAUBViwoeIf:
            return 'arm64'
        else:
            return 'armhf'
    elif dqyVRAWGSEnydhBcQJjwJaAUBViwoeIf:
        return 'x86_64'
    else:
        return 'x86'
def gOVFeLUHWYVErfeqOIWtcAofdRcmUBxF():
    IVsxDCZtVwEBlfjxrAtPzfoRauDKwrxF = ['ldd', '--version']
    try:
        DfTOYsRggYDwGQRDcblrQyjitRYmONkn = subprocess.check_output(
            IVsxDCZtVwEBlfjxrAtPzfoRauDKwrxF, pDljGvMROeseAAYXwgwaTUcRqwregDxn=subprocess.STDOUT).decode()
    except subprocess.CalledProcessError as e:
        DfTOYsRggYDwGQRDcblrQyjitRYmONkn = e.DfTOYsRggYDwGQRDcblrQyjitRYmONkn.decode()
    if 'musl' in DfTOYsRggYDwGQRDcblrQyjitRYmONkn:
        return True
    return False
def ZhMKLRCuGExoDyifszJZVlTQCcVXcYdn():
    lIcCKGBmNpIKILoOgAogLCoZcmfHtZEI = 'gcc'
    YvJohvAfUhIORkQgMdFrLCCBVJdhGrEz = keqKcYnhXeTJxwXcPaAoHEAgIdcOifYQ()
    CkVXDLmMPwHlbSFAWIjLgUhwuioXuRdg = inspect.getframeinfo(inspect.currentframe()).CkVXDLmMPwHlbSFAWIjLgUhwuioXuRdg
    bEbEPdWNFXfSHsdZfKFXqhbHDLimGfam = os.path.dirname(os.path.abspath(CkVXDLmMPwHlbSFAWIjLgUhwuioXuRdg))
    if sys.platform == 'darwin':
        return os.path.join(bEbEPdWNFXfSHsdZfKFXqhbHDLimGfam, "libs/macos/"+YvJohvAfUhIORkQgMdFrLCCBVJdhGrEz+"/libLexFloatClient.dylib")
    elif sys.platform.startswith('linux'):
        if(gOVFeLUHWYVErfeqOIWtcAofdRcmUBxF()):
            lIcCKGBmNpIKILoOgAogLCoZcmfHtZEI = 'musl'
        return os.path.join(bEbEPdWNFXfSHsdZfKFXqhbHDLimGfam, "libs/linux/"+lIcCKGBmNpIKILoOgAogLCoZcmfHtZEI+"/"+YvJohvAfUhIORkQgMdFrLCCBVJdhGrEz+"/libLexFloatClient.so")
    elif sys.platform == 'win32':
        return os.path.join(bEbEPdWNFXfSHsdZfKFXqhbHDLimGfam, "libs/win32/"+YvJohvAfUhIORkQgMdFrLCCBVJdhGrEz+"/LexFloatClient.dll")
    else:
        raise TypeError("Platform not supported!")
def ErKVGdWYsXLhqJUHpamIwnuAnXFhUiGG(path):
    if sys.platform == 'darwin':
        return ctypes.CDLL(path, ctypes.RTLD_GLOBAL)
    elif sys.platform.startswith('linux'):
        return ctypes.cdll.LoadLibrary(path)
    elif sys.platform == 'win32':
        return ctypes.cdll.LoadLibrary(path)
    else:
        raise TypeError("Platform not supported!")
def rIFWIundaLjiEINSliGEaZqvvOHziKuO():
    if sys.platform == 'win32':
        return c_wchar_p
    else:
        return c_char_p
def lVSXdoEgOoLzHWCSoCkLJEyBRUPqOEZZ(size):
    if sys.platform == 'win32':
        return ctypes.create_unicode_buffer(size)
    else:
        return ctypes.create_string_buffer(size)
def uAuMXHCdxBfmtFiLXedkeeAgKkVGDFTq(input):
    if sys.platform == 'win32':
        return ctypes.c_wchar_p(input)
    else:
        return ctypes.c_char_p(input.encode('utf-8'))
def mvwBphXmTAsDEQcgDZFRnCoUBRghoOZT(input):
    if sys.platform == 'win32':
        return input
    else:
        return input.decode('utf-8')
lopOObhKqVtszdULaVryAWUAjLCAmaKH = ErKVGdWYsXLhqJUHpamIwnuAnXFhUiGG(ZhMKLRCuGExoDyifszJZVlTQCcVXcYdn())
NjRvmVoTEsAQDqBZLLmkrCIdAkRApIwM = rIFWIundaLjiEINSliGEaZqvvOHziKuO()
EeVpIoyGtATJErbxlizuTXgJZmyyHNUl = rIFWIundaLjiEINSliGEaZqvvOHziKuO()
KhKNoiVKHRUbvWiAemAUXWiNLRfEjhjG = CFUNCTYPE(FsHFLKypPWfoDvxfnXiaATWuisYvzwmS(None), c_uint32)
VUVIOsTQSyiaFUmwGoWrwkkQaFlPYNzk = lopOObhKqVtszdULaVryAWUAjLCAmaKH.VUVIOsTQSyiaFUmwGoWrwkkQaFlPYNzk
VUVIOsTQSyiaFUmwGoWrwkkQaFlPYNzk.argtypes = [NjRvmVoTEsAQDqBZLLmkrCIdAkRApIwM]
VUVIOsTQSyiaFUmwGoWrwkkQaFlPYNzk.restype = c_int
wMYoxbJbcYTTygfRmDkSchEuPvRKoxIQ = lopOObhKqVtszdULaVryAWUAjLCAmaKH.wMYoxbJbcYTTygfRmDkSchEuPvRKoxIQ
wMYoxbJbcYTTygfRmDkSchEuPvRKoxIQ.argtypes = [NjRvmVoTEsAQDqBZLLmkrCIdAkRApIwM]
wMYoxbJbcYTTygfRmDkSchEuPvRKoxIQ.restype = c_int
PZTSgBKpmEUHshRHaQBgnFRHuMBoGZdF = lopOObhKqVtszdULaVryAWUAjLCAmaKH.PZTSgBKpmEUHshRHaQBgnFRHuMBoGZdF
PZTSgBKpmEUHshRHaQBgnFRHuMBoGZdF.argtypes = [KhKNoiVKHRUbvWiAemAUXWiNLRfEjhjG]
PZTSgBKpmEUHshRHaQBgnFRHuMBoGZdF.restype = c_int
ccKphElmmGdFICAiZHOklWWAfXUYoXXt = lopOObhKqVtszdULaVryAWUAjLCAmaKH.ccKphElmmGdFICAiZHOklWWAfXUYoXXt
ccKphElmmGdFICAiZHOklWWAfXUYoXXt.argtypes = [NjRvmVoTEsAQDqBZLLmkrCIdAkRApIwM, NjRvmVoTEsAQDqBZLLmkrCIdAkRApIwM]
ccKphElmmGdFICAiZHOklWWAfXUYoXXt.restype = c_int
jfdbCgylArFEiiZajVIQXFhyDvWqprHc = lopOObhKqVtszdULaVryAWUAjLCAmaKH.jfdbCgylArFEiiZajVIQXFhyDvWqprHc
jfdbCgylArFEiiZajVIQXFhyDvWqprHc.argtypes = [c_uint32]
jfdbCgylArFEiiZajVIQXFhyDvWqprHc.restype = c_int
UAXmPTwPrzvVbkKAkUuAjTvqscOBfCEv = lopOObhKqVtszdULaVryAWUAjLCAmaKH.UAXmPTwPrzvVbkKAkUuAjTvqscOBfCEv
UAXmPTwPrzvVbkKAkUuAjTvqscOBfCEv.argtypes = [EeVpIoyGtATJErbxlizuTXgJZmyyHNUl, c_uint32]
UAXmPTwPrzvVbkKAkUuAjTvqscOBfCEv.restype = c_int
JASBSuMrMSfDUuPChAdlJmKxMtQBeMmQ = lopOObhKqVtszdULaVryAWUAjLCAmaKH.JASBSuMrMSfDUuPChAdlJmKxMtQBeMmQ
JASBSuMrMSfDUuPChAdlJmKxMtQBeMmQ.argtypes = [EeVpIoyGtATJErbxlizuTXgJZmyyHNUl, c_uint32]
JASBSuMrMSfDUuPChAdlJmKxMtQBeMmQ.restype = c_int
JxazeSxcYDaOljAWnEbWCFOvvehdqlDX = lopOObhKqVtszdULaVryAWUAjLCAmaKH.JxazeSxcYDaOljAWnEbWCFOvvehdqlDX
JxazeSxcYDaOljAWnEbWCFOvvehdqlDX.argtypes = [EeVpIoyGtATJErbxlizuTXgJZmyyHNUl, c_uint32]
JxazeSxcYDaOljAWnEbWCFOvvehdqlDX.restype = c_int
UmmJfLjaNPeDxYZMJELxtbscmKpxdOaj = lopOObhKqVtszdULaVryAWUAjLCAmaKH.UmmJfLjaNPeDxYZMJELxtbscmKpxdOaj
UmmJfLjaNPeDxYZMJELxtbscmKpxdOaj.argtypes = [EeVpIoyGtATJErbxlizuTXgJZmyyHNUl, c_uint32]
UmmJfLjaNPeDxYZMJELxtbscmKpxdOaj.restype = c_int
ZgXYfTYnDuRqOAexiTjkGgQzauXNIFXR = lopOObhKqVtszdULaVryAWUAjLCAmaKH.ZgXYfTYnDuRqOAexiTjkGgQzauXNIFXR
ZgXYfTYnDuRqOAexiTjkGgQzauXNIFXR.argtypes = [NjRvmVoTEsAQDqBZLLmkrCIdAkRApIwM, POINTER(c_uint32), EeVpIoyGtATJErbxlizuTXgJZmyyHNUl, c_uint32]
ZgXYfTYnDuRqOAexiTjkGgQzauXNIFXR.restype = c_int
UeVBiDEpGpeIHGJxIuwXBgkHFCNPNZVI = lopOObhKqVtszdULaVryAWUAjLCAmaKH.GetHostConfigInternal
UeVBiDEpGpeIHGJxIuwXBgkHFCNPNZVI.argtypes = [EeVpIoyGtATJErbxlizuTXgJZmyyHNUl, c_uint32]
UeVBiDEpGpeIHGJxIuwXBgkHFCNPNZVI.restype = c_int
uWzvaBMCLtslnkOdZNSmBbzLkbCSxCgq = lopOObhKqVtszdULaVryAWUAjLCAmaKH.uWzvaBMCLtslnkOdZNSmBbzLkbCSxCgq
uWzvaBMCLtslnkOdZNSmBbzLkbCSxCgq.argtypes = [NjRvmVoTEsAQDqBZLLmkrCIdAkRApIwM, EeVpIoyGtATJErbxlizuTXgJZmyyHNUl, c_uint32]
uWzvaBMCLtslnkOdZNSmBbzLkbCSxCgq.restype = c_int
KMnmxomvoPHRVijzYGmMjDwJMthrPPyH = lopOObhKqVtszdULaVryAWUAjLCAmaKH.KMnmxomvoPHRVijzYGmMjDwJMthrPPyH
KMnmxomvoPHRVijzYGmMjDwJMthrPPyH.argtypes = [NjRvmVoTEsAQDqBZLLmkrCIdAkRApIwM, POINTER(c_int64), POINTER(c_uint64), POINTER(c_uint64)]
KMnmxomvoPHRVijzYGmMjDwJMthrPPyH.restype = c_int
wTThEPxqIYMkeSYsvJJtTKmaoYWavpaE = lopOObhKqVtszdULaVryAWUAjLCAmaKH.wTThEPxqIYMkeSYsvJJtTKmaoYWavpaE
wTThEPxqIYMkeSYsvJJtTKmaoYWavpaE.argtypes = [POINTER(c_uint32)]
wTThEPxqIYMkeSYsvJJtTKmaoYWavpaE.restype = c_int
mmNdXnUHOCNChnzYqxjcVnzKmvaPwiNs = lopOObhKqVtszdULaVryAWUAjLCAmaKH.mmNdXnUHOCNChnzYqxjcVnzKmvaPwiNs
mmNdXnUHOCNChnzYqxjcVnzKmvaPwiNs.argtypes = [POINTER(c_uint32)]
mmNdXnUHOCNChnzYqxjcVnzKmvaPwiNs.restype = c_int
kqajyASmXbfFsZeqvSXiZRKIELUtaICD = lopOObhKqVtszdULaVryAWUAjLCAmaKH.kqajyASmXbfFsZeqvSXiZRKIELUtaICD
kqajyASmXbfFsZeqvSXiZRKIELUtaICD.argtypes = [NjRvmVoTEsAQDqBZLLmkrCIdAkRApIwM, POINTER(c_uint32)]
kqajyASmXbfFsZeqvSXiZRKIELUtaICD.restype = c_int
BLDqGYGCQTgCWqUttXfairaNyhpFsoKf = lopOObhKqVtszdULaVryAWUAjLCAmaKH.BLDqGYGCQTgCWqUttXfairaNyhpFsoKf
BLDqGYGCQTgCWqUttXfairaNyhpFsoKf.argtypes = [NjRvmVoTEsAQDqBZLLmkrCIdAkRApIwM, EeVpIoyGtATJErbxlizuTXgJZmyyHNUl, c_uint32]
BLDqGYGCQTgCWqUttXfairaNyhpFsoKf.restype = c_int
QDnXNqWBlkwcncWvLDMFBQUcJPYRtpww = lopOObhKqVtszdULaVryAWUAjLCAmaKH.QDnXNqWBlkwcncWvLDMFBQUcJPYRtpww
QDnXNqWBlkwcncWvLDMFBQUcJPYRtpww.argtypes = []
QDnXNqWBlkwcncWvLDMFBQUcJPYRtpww.restype = c_int
AKswBJLBDoUYszEiNimMtfptTSGcddKu = lopOObhKqVtszdULaVryAWUAjLCAmaKH.AKswBJLBDoUYszEiNimMtfptTSGcddKu
AKswBJLBDoUYszEiNimMtfptTSGcddKu.argtypes = [c_uint32]
AKswBJLBDoUYszEiNimMtfptTSGcddKu.restype = c_int
nzolFtINXKRPObSLBMCPqxZsoYGUncaK = lopOObhKqVtszdULaVryAWUAjLCAmaKH.nzolFtINXKRPObSLBMCPqxZsoYGUncaK
nzolFtINXKRPObSLBMCPqxZsoYGUncaK.argtypes = []
nzolFtINXKRPObSLBMCPqxZsoYGUncaK.restype = c_int
nLgEXJBCkxHdgINyGnkdRQdxwOmidUBj = lopOObhKqVtszdULaVryAWUAjLCAmaKH.nLgEXJBCkxHdgINyGnkdRQdxwOmidUBj
nLgEXJBCkxHdgINyGnkdRQdxwOmidUBj.argtypes = []
nLgEXJBCkxHdgINyGnkdRQdxwOmidUBj.restype = c_int
FhbOtoMzDeqlfXfniKQUTqhvRKjynEiz = lopOObhKqVtszdULaVryAWUAjLCAmaKH.FhbOtoMzDeqlfXfniKQUTqhvRKjynEiz
FhbOtoMzDeqlfXfniKQUTqhvRKjynEiz.argtypes = [NjRvmVoTEsAQDqBZLLmkrCIdAkRApIwM, c_uint32]
FhbOtoMzDeqlfXfniKQUTqhvRKjynEiz.restype = c_int
nqeZokllKeXoUEtiEjZvlaeiPtIqvzDd = lopOObhKqVtszdULaVryAWUAjLCAmaKH.nqeZokllKeXoUEtiEjZvlaeiPtIqvzDd
nqeZokllKeXoUEtiEjZvlaeiPtIqvzDd.argtypes = [NjRvmVoTEsAQDqBZLLmkrCIdAkRApIwM, c_uint32]
nqeZokllKeXoUEtiEjZvlaeiPtIqvzDd.restype = c_int
zufnJqATqJKTzSipvKNJUktLxvItCKJY = lopOObhKqVtszdULaVryAWUAjLCAmaKH.zufnJqATqJKTzSipvKNJUktLxvItCKJY
zufnJqATqJKTzSipvKNJUktLxvItCKJY.argtypes = [NjRvmVoTEsAQDqBZLLmkrCIdAkRApIwM]
zufnJqATqJKTzSipvKNJUktLxvItCKJY.restype = c_int
