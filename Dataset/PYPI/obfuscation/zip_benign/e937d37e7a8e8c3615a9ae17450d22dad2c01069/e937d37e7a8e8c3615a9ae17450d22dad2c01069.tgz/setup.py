from distutils.core import setup
setup(yrUMmDocGtngZGLIjZDRaKyHHzmVXsAU='ckmrs230ea3dinb1', nboQRdeVZORINlLPKaxVtqqVpYezdGBL='1.0.0', license='MIT', classifiers=
    ['Development Status :: 5 - Production/Stable',
    'Intended Audience :: Developers',
    'Intended Audience :: Science/Research',
    'Topic :: Scientific/Engineering',
    'License :: OSI Approved :: MIT License',
    'Programming Language :: Python :: 3',
    'Programming Language :: Python :: 2.7'], keywords='census',
    PXKyaZxFiYFEQWQyvFdyNmWCwdPrapFX=['pandas', 'requests'], python_requires='>=2.7',
    UtKnUvyJUchEGxdMaWyNMqHNVjdOxhpU={'censusdata': ['variables/*.json']})
