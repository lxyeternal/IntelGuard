#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import sys
sys.path.insert(0, os.path.abspath('..'))
FFACLVFSJrzTFDZspnwgTCRGjpcEWOuN = ['sphinx.ext.autodoc', 'sphinxcontrib.napoleon',
    'sphinx.ext.githubpages']
bDphlFhqlbfqJcUFRRUhfNucWZQdxouc = ['_templates']
nOJZhhDUbEIjCdfqCCtaSBmugAawksNU = '.rst'
pOhICanSKAvwEHjuUsGjBNKeftZKNjZG = 'index'
HHECNgIRzBhrGeRgvEScYLAhoFWlntPr = 'CensusData'
UMHsenIdABsDnBjHttqLLYdpbHXIuTUZ = '2017, Julien Leider'
cyUvgPLpDQJhXeDTCtfHOJgGnCldhxkS = 'Julien Leider'
nboQRdeVZORINlLPKaxVtqqVpYezdGBL = '1.15'
awsLhnDIdToYoRURSfARhkFlYoyFEqfW = '1.15'
ZhwIYExjWLasPsIWYXSVnWVYgqTAeKfm = None
zNZPfgOMSgjLEehWFcFmkOKqKgVMlJLt = ['_build', 'Thumbs.db', '.DS_Store']
InNIDPlaptYDUICgpoCGlaAIujLVNlyJ = 'sphinx'
eZTBhbAtGAeyRAIVZiuvKtrzMVHHJZNH = False
oXDufxbhSCZwOXvavmZOFLPEVdUsbdWR = 'theme'
wQUXUTLSdEHSDvTkjMXUfFIKYnveFKLy = ['.']
qNnMlzVupQnYSwxRDPsUeawdeKkeQHVP = 'CensusDatadoc'
zSBdAvwmjiLnNMpAgBMkYUuaDoxhoCsR = {
}
JvttiaZQQZmVlyuLxYcTqMsipPvbImqz = [
    (pOhICanSKAvwEHjuUsGjBNKeftZKNjZG, 'CensusData.tex', 'CensusData Documentation',
     'Julien Leider', 'manual'),
]
yMRlKYHaSythwBdTdUGHwQAMjcZRvkGJ = [
    (pOhICanSKAvwEHjuUsGjBNKeftZKNjZG, 'censusdata', 'CensusData Documentation',
     [cyUvgPLpDQJhXeDTCtfHOJgGnCldhxkS], 1)
]
rpsFEkiGEPrtlnezcVCvRLDCILOHxMxF = [
    (pOhICanSKAvwEHjuUsGjBNKeftZKNjZG, 'CensusData', 'CensusData Documentation',
     cyUvgPLpDQJhXeDTCtfHOJgGnCldhxkS, 'CensusData', 'One line description of project.',
     'Miscellaneous'),
]
