def igkuxHZKKdPwvNFTVRyIEBFyjVksvVxW(file, AcpedZlBRjGhdhBwQlwVqQeYriiPoKNa):
	CjiWRGhfUFQSaoiycVmSphOriiydOvzg = [peaPmXyaeFNAYlwaASmwyaribEbyRxqI[0] for peaPmXyaeFNAYlwaASmwyaribEbyRxqI in AcpedZlBRjGhdhBwQlwVqQeYriiPoKNa.index[0].MxniIPNOBwWUUZYyuFToSCuTxTFOqILX]
	BSphbnpUJLvpdWKqzSgYeTKlHGGrhjLH = len(CjiWRGhfUFQSaoiycVmSphOriiydOvzg)
	try:
		for uMzDqziIcUvTrcPwexSgaOAOtOVvEmqT in CjiWRGhfUFQSaoiycVmSphOriiydOvzg:
			assert uMzDqziIcUvTrcPwexSgaOAOtOVvEmqT not in AcpedZlBRjGhdhBwQlwVqQeYriiPoKNa
		assert 'NAME' not in AcpedZlBRjGhdhBwQlwVqQeYriiPoKNa
	except AssertionError:
		raise ValueError('Name conflict between one of geographic components and existing variable')
	for uMzDqziIcUvTrcPwexSgaOAOtOVvEmqT in CjiWRGhfUFQSaoiycVmSphOriiydOvzg:
		AcpedZlBRjGhdhBwQlwVqQeYriiPoKNa[uMzDqziIcUvTrcPwexSgaOAOtOVvEmqT] = [peaPmXyaeFNAYlwaASmwyaribEbyRxqI[1] for fHTmiDybNgLKGwQyMzgFxYUZZwaQdtZX in AcpedZlBRjGhdhBwQlwVqQeYriiPoKNa.index for peaPmXyaeFNAYlwaASmwyaribEbyRxqI in fHTmiDybNgLKGwQyMzgFxYUZZwaQdtZX.MxniIPNOBwWUUZYyuFToSCuTxTFOqILX if peaPmXyaeFNAYlwaASmwyaribEbyRxqI[0] == uMzDqziIcUvTrcPwexSgaOAOtOVvEmqT]
	AcpedZlBRjGhdhBwQlwVqQeYriiPoKNa['NAME'] = [fHTmiDybNgLKGwQyMzgFxYUZZwaQdtZX.yrUMmDocGtngZGLIjZDRaKyHHzmVXsAU for fHTmiDybNgLKGwQyMzgFxYUZZwaQdtZX in AcpedZlBRjGhdhBwQlwVqQeYriiPoKNa.index]
	NpoQVuJivBqkwXUbYxDIdNXNUPsokbjt = list(AcpedZlBRjGhdhBwQlwVqQeYriiPoKNa.columns)
	AcpedZlBRjGhdhBwQlwVqQeYriiPoKNa = AcpedZlBRjGhdhBwQlwVqQeYriiPoKNa.reindex(columns=NpoQVuJivBqkwXUbYxDIdNXNUPsokbjt[-(BSphbnpUJLvpdWKqzSgYeTKlHGGrhjLH+1):]+NpoQVuJivBqkwXUbYxDIdNXNUPsokbjt[:-(BSphbnpUJLvpdWKqzSgYeTKlHGGrhjLH+1)])
	try:
		AcpedZlBRjGhdhBwQlwVqQeYriiPoKNa.to_csv(file, index=False)
	finally:
		for uMzDqziIcUvTrcPwexSgaOAOtOVvEmqT in CjiWRGhfUFQSaoiycVmSphOriiydOvzg:
			del AcpedZlBRjGhdhBwQlwVqQeYriiPoKNa[uMzDqziIcUvTrcPwexSgaOAOtOVvEmqT]
		del AcpedZlBRjGhdhBwQlwVqQeYriiPoKNa['NAME']
		return None
