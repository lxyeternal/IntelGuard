from __future__ import absolute_import, division, print_function, unicode_literals
import unittest
import os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import censusdata
class KgKSWpeGkQwisrwPQCElEVZbHbYmCiNs(unittest.TestCase):
	def taHcfiKqUjOEQpDUAooTvOtPshyjiXyc(self):
		self.countygeo = censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17'), ('county', '031')])
		self.placecountygeo = censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17'), ('place', '55555'), ('county (or part)', '*')])
		self.placegeo = censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06'), ('place', '53000')], 'Oakland city, California')
		self.blockg = censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17'), ('county', '031'), ('tract', '350100'), ('block group', '2')])
		self.msa = censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS((('metropolitan statistical area/micropolitan statistical area', '16980'),))
	def xRBrpVMPRBZBdeeQHmHvQLOSwPuctomG(self):
		self.assertEqual(self.countygeo.request()['for'], 'county:031')
		self.assertEqual(self.placecountygeo.request()['for'], 'county+(or+part):*')
		self.assertEqual(self.blockg.request()['for'], 'block+group:2')
		self.assertEqual(self.msa.request()['for'], 'metropolitan+statistical+area/micropolitan+statistical+area:16980')
	def aGULUqgJpOKpyRntfgvUJxIqEMZizMOI(self):
		self.assertEqual(self.countygeo.request()['in'], 'state:17')
		self.assertEqual(self.placecountygeo.request()['in'], 'state:17+place:55555')
		self.assertEqual(self.blockg.request()['in'], 'state:17+county:031+tract:350100')
		self.assertTrue('in' not in self.msa.request().keys())
	def GvFFONclfcrWvHjQyByVbYSNrNekvcga(self):
		self.assertEqual(self.countygeo.ehfUqAdkwdzhLvwkFuYjpEPaKbtgzjqT(), '050')
		self.assertEqual(self.placecountygeo.ehfUqAdkwdzhLvwkFuYjpEPaKbtgzjqT(), '155')
		self.assertEqual(self.blockg.ehfUqAdkwdzhLvwkFuYjpEPaKbtgzjqT(), '150')
		self.assertEqual(self.msa.ehfUqAdkwdzhLvwkFuYjpEPaKbtgzjqT(), '310')
	def nJmNDBMWJLKGoMKPzIoNWyJVeLhpbIeI(self):
		self.assertEqual(self.countygeo.PiqKcoslnZDRWDgcUqBtGvsiTkmeLObd(), (('state', '17'), ('county', '031')))
		self.assertEqual(self.placecountygeo.PiqKcoslnZDRWDgcUqBtGvsiTkmeLObd(), (('state', '17'), ('place', '55555'), ('county (or part)', '*')))
		self.assertEqual(self.placegeo.PiqKcoslnZDRWDgcUqBtGvsiTkmeLObd(), (('state', '06'), ('place', '53000')))
		self.assertEqual(self.blockg.PiqKcoslnZDRWDgcUqBtGvsiTkmeLObd(), (('state', '17'), ('county', '031'), ('tract', '350100'), ('block group', '2')))
		self.assertEqual(self.msa.PiqKcoslnZDRWDgcUqBtGvsiTkmeLObd(), (('metropolitan statistical area/micropolitan statistical area', '16980'),))
	def PrlcxcFuugrKYTvcsOqzItqoMuNRZcQE(self):
		self.assertEqual(self.countygeo.yFleqLsgzmzDhXgGiSNAVwlEsMBKOoIV(), 'state> county')
		self.assertEqual(self.placecountygeo.yFleqLsgzmzDhXgGiSNAVwlEsMBKOoIV(), 'state> place> county (or part)')
		self.assertEqual(self.blockg.yFleqLsgzmzDhXgGiSNAVwlEsMBKOoIV(), 'state> county> tract> block group')
		self.assertEqual(self.msa.yFleqLsgzmzDhXgGiSNAVwlEsMBKOoIV(), 'metropolitan statistical area/micropolitan statistical area')
	def FTgnNUKQtTfyGZfcGclFFcgRvfjpEucn(self):
		self.assertEqual(censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17'), ('county', '*')]), censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17'), ('county', '*')]))
	def YPZhUyBRMiIUQXpSsZvqHWdiVlOWBARj(self):
		self.assertEqual(repr(self.countygeo), str("censusgeo((({0[0]}, {0[1]}), ({0[2]}, {0[3]})))".format([repr(lScOxhnfhLuhIdnzAxZkxppBrrTSLytB) for lScOxhnfhLuhIdnzAxZkxppBrrTSLytB in ['state', '17', 'county', '031']])))
		self.assertEqual(repr(self.placecountygeo), str("censusgeo((({0[0]}, {0[1]}), ({0[2]}, {0[3]}), ({0[4]}, {0[5]})))".format([repr(lScOxhnfhLuhIdnzAxZkxppBrrTSLytB) for lScOxhnfhLuhIdnzAxZkxppBrrTSLytB in ['state', '17', 'place', '55555', 'county (or part)', '*']])))
		self.assertEqual(repr(self.placegeo), str("censusgeo((({0[0]}, {0[1]}), ({0[2]}, {0[3]})), {0[4]})".format([repr(lScOxhnfhLuhIdnzAxZkxppBrrTSLytB) for lScOxhnfhLuhIdnzAxZkxppBrrTSLytB in ['state', '06', 'place', '53000', 'Oakland city, California']])))
		self.assertEqual(repr(self.blockg), str("censusgeo((({0[0]}, {0[1]}), ({0[2]}, {0[3]}), ({0[4]}, {0[5]}), ({0[6]}, {0[7]})))".format([repr(lScOxhnfhLuhIdnzAxZkxppBrrTSLytB) for lScOxhnfhLuhIdnzAxZkxppBrrTSLytB in ['state', '17', 'county', '031', 'tract', '350100', 'block group', '2']])))
		self.assertEqual(repr(self.msa), str("censusgeo((({0[0]}, {0[1]}),))".format([repr(lScOxhnfhLuhIdnzAxZkxppBrrTSLytB) for lScOxhnfhLuhIdnzAxZkxppBrrTSLytB in ['metropolitan statistical area/micropolitan statistical area', '16980']])))
	def ZymNAiQajEhkhvjDwySOpBIcZNVkfVux(self):
		self.assertEqual(str(self.countygeo), 'Summary level: 050, state:17> county:031')
		self.assertEqual(str(self.placecountygeo), 'Summary level: 155, state:17> place:55555> county (or part):*')
		self.assertEqual(str(self.placegeo), 'Oakland city, California: Summary level: 160, state:06> place:53000')
		self.assertEqual(str(self.blockg), 'Summary level: 150, state:17> county:031> tract:350100> block group:2')
		self.assertEqual(str(self.msa), 'Summary level: 310, metropolitan statistical area/micropolitan statistical area:16980')
if __name__ == '__main__':
	unittest.main()
