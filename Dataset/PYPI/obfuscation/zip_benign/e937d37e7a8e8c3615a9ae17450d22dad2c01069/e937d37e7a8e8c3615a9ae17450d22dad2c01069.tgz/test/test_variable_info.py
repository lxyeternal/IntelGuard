from __future__ import absolute_import, division, print_function, unicode_literals
import os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import censusdata
import unittest
from collections import OrderedDict
import io
import textwrap
import re
class YdZXrtPcpOmxULjjsEbfQKFrlpfGxogV(unittest.TestCase):
	def hRZilCZnFBZBdbXOoxCRCyLeTLHhlret(self):
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz = {'B01001_001E': ['B01001.  Sex by Age', 'Total:', 'int'],
			'B01002_001E': ['B01002.  Median Age by Sex', 'Median age --!!Total:', 'int'],
			'B19013_001E': ['B19013.  Median Household Income',
				'Median household income in the past 12 months (in 2009 inflation-adjusted dollars)', 'int']}
		self.assertEqual(censusdata.tavbDPRkRTgrktGiFuuoeVonhiueEUeE('acs5', 2009, ['B01001_001E', 'B01002_001E', 'B19013_001E']), QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz)
		for vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm in range(2010, 2019+1):
			HjennHKKfbYSpiBSGOGFxbRJgFpgSYTT = ['SEX BY AGE', 'MEDIAN AGE BY SEX', 'MEDIAN HOUSEHOLD INCOME IN THE PAST 12 MONTHS (IN {0} INFLATION-ADJUSTED DOLLARS)'.format(vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm)]
			eXkkEszYccLyQBxZeugOAkZlRpIjlXLM = ['int', 'float', 'int']
			JnJYsDkguRrOwSwsDzOkTQNJBQkkrkkA = 'inflation'
			if vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm == 2014 or vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm == 2015: JnJYsDkguRrOwSwsDzOkTQNJBQkkrkkA = 'Inflation'
			boFcSLbPORHgJAvXSdUwIjQFiNfTOeiF = 'Estimate!!Median age!!Total'
			if vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm == 2017: boFcSLbPORHgJAvXSdUwIjQFiNfTOeiF = 'Estimate!!Median age --!!Total'
			if vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm == 2018: boFcSLbPORHgJAvXSdUwIjQFiNfTOeiF = 'Estimate!!Median age --!!Total'
			if vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm == 2019: boFcSLbPORHgJAvXSdUwIjQFiNfTOeiF = 'Estimate!!Median age --!!Total:'
			vsncCFXWYSnXhmIirvdBwDjMudCeMrEC = 'Estimate!!Total'
			if vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm == 2019: vsncCFXWYSnXhmIirvdBwDjMudCeMrEC = 'Estimate!!Total:'
			QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz = {'B01001_001E': [HjennHKKfbYSpiBSGOGFxbRJgFpgSYTT[0], vsncCFXWYSnXhmIirvdBwDjMudCeMrEC, eXkkEszYccLyQBxZeugOAkZlRpIjlXLM[0]],
				'B01002_001E': [HjennHKKfbYSpiBSGOGFxbRJgFpgSYTT[1], boFcSLbPORHgJAvXSdUwIjQFiNfTOeiF, eXkkEszYccLyQBxZeugOAkZlRpIjlXLM[1]],
				'B19013_001E': [HjennHKKfbYSpiBSGOGFxbRJgFpgSYTT[2],
					'Estimate!!Median household income in the past 12 months (in {0} {1}-adjusted dollars)'.format(vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm, JnJYsDkguRrOwSwsDzOkTQNJBQkkrkkA), eXkkEszYccLyQBxZeugOAkZlRpIjlXLM[2]]}
			self.assertEqual(censusdata.tavbDPRkRTgrktGiFuuoeVonhiueEUeE('acs5', vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm, ['B01001_001E', 'B01002_001E', 'B19013_001E']), QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz)
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz = {'C24010_001E': ['SEX BY OCCUPATION FOR THE CIVILIAN EMPLOYED POPULATION 16 YEARS AND OVER',
				'Estimate!!Total', 'int']}
		self.assertEqual(censusdata.tavbDPRkRTgrktGiFuuoeVonhiueEUeE('acs5', 2018, ['C24010_001E']), QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz)
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz = {'C24010_001E': ['SEX BY OCCUPATION FOR THE CIVILIAN EMPLOYED POPULATION 16 YEARS AND OVER',
				'Estimate!!Total:', 'int']}
		self.assertEqual(censusdata.tavbDPRkRTgrktGiFuuoeVonhiueEUeE('acs5', 2019, ['C24010_001E']), QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz)
	def irJxCyYrGRmTcQkEtkwBSJiMQRBlXpid(self):
		censusdata.tavbDPRkRTgrktGiFuuoeVonhiueEUeE('acs1', 2015, ['S0101_C02_001E', 'DP03_0021PE', 'CP02_2012_030E'])
		censusdata.tavbDPRkRTgrktGiFuuoeVonhiueEUeE('acs1', 2016, ['S0101_C02_001E', 'DP03_0021PE', 'CP02_2012_030E'])
		censusdata.tavbDPRkRTgrktGiFuuoeVonhiueEUeE('acs1', 2017, ['S0101_C02_001E', 'DP03_0021PE', 'CP02_2013_030E'])
		censusdata.tavbDPRkRTgrktGiFuuoeVonhiueEUeE('acs1', 2018, ['S0101_C02_001E', 'DP03_0021PE', 'CP02_2014_030E'])
		censusdata.tavbDPRkRTgrktGiFuuoeVonhiueEUeE('acs1', 2019, ['S0101_C02_001E', 'DP03_0021PE', 'CP02_2015_030E'])
	def WNUZBQigCKYBkDXzttkoWnRjjzTtzDjd(self):
		for vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm in range(2014, 2019+1):
			lboIQgKMyTDniFdVaCXnmGBpfqtuikxz = 'Estimate!!Total!!No computer'
			if vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm == 2019: lboIQgKMyTDniFdVaCXnmGBpfqtuikxz = 'Estimate!!Total:!!No computer'
			QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz = {'K202801_006E': ['PRESENCE OF A COMPUTER AND TYPE OF INTERNET SUBSCRIPTION IN HOUSEHOLD', lboIQgKMyTDniFdVaCXnmGBpfqtuikxz, 'int']}
			self.assertEqual(censusdata.tavbDPRkRTgrktGiFuuoeVonhiueEUeE('acsse', vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm, ['K202801_006E']), QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz)
	def KyksghGHMXAHWuecbSriNmeZrpcnbVYM(self):
		for vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm in range(2013, 2013+1):
			QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz = {'B19013_001E': ['MEDIAN HOUSEHOLD INCOME IN THE PAST 12 MONTHS (IN {0} INFLATION-ADJUSTED DOLLARS)'.format(vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm),
				'Estimate!!Median household income in the past 12 months (in {0} inflation-adjusted dollars)'.format(vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm), 'int']}
			self.assertEqual(censusdata.tavbDPRkRTgrktGiFuuoeVonhiueEUeE('acs3', vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm, ['B19013_001E']), QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz)
	def ZvLMytDPIRIYwUcolzlcBDtSVlwBSwZO(self):
		self.assertEqual(censusdata.tavbDPRkRTgrktGiFuuoeVonhiueEUeE('sf1', 2010, ['P001001']),
			{'P001001': ['TOTAL POPULATION', 'Total', '']})
	def IktLRRVBnwWilLNnBqdsAnAOVMGZsfZg(self):
		self.assertRaises(ValueError, censusdata.tavbDPRkRTgrktGiFuuoeVonhiueEUeE, 'acs5', 2015, ['B19013_010E'])
	def qmzLVFmtJtIQUNXRLMefprDtpqJbHpzE(self):
		for vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm in range(2012, 2019+1):
			censusdata.aDFNeTMDJsioUdtYsdPkkYGouLmfPhdF('acs1', vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm, 'B23025')
	def orvGFqvtatPlVLkrPowmoTVeIpEXviOg(self):
		censusdata.aDFNeTMDJsioUdtYsdPkkYGouLmfPhdF('acs5', 2015, 'B23025')
	def aybflSFdufgopTJfICmVJBPwytBUAwgb(self):
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz = OrderedDict()
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_001E'] = {'label': 'Estimate!!Total', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_002E'] = {'label': 'Estimate!!Total!!In labor force', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_003E'] = {'label': 'Estimate!!Total!!In labor force!!Civilian labor force', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_004E'] = {'label': 'Estimate!!Total!!In labor force!!Civilian labor force!!Employed', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_005E'] = {'label': 'Estimate!!Total!!In labor force!!Civilian labor force!!Unemployed', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_006E'] = {'label': 'Estimate!!Total!!In labor force!!Armed Forces', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_007E'] = {'label': 'Estimate!!Total!!Not in labor force', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		self.assertEqual(censusdata.aDFNeTMDJsioUdtYsdPkkYGouLmfPhdF('acs5', 2016, 'B23025'), QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz)
	def ZGzRVGZaGxxyEfXSBiKkJGoGThRIfuZg(self):
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz = OrderedDict()
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_001E'] = {'label': 'Estimate!!Total', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_002E'] = {'label': 'Estimate!!Total!!In labor force', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_003E'] = {'label': 'Estimate!!Total!!In labor force!!Civilian labor force', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_004E'] = {'label': 'Estimate!!Total!!In labor force!!Civilian labor force!!Employed', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_005E'] = {'label': 'Estimate!!Total!!In labor force!!Civilian labor force!!Unemployed', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_006E'] = {'label': 'Estimate!!Total!!In labor force!!Armed Forces', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_007E'] = {'label': 'Estimate!!Total!!Not in labor force', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		self.assertEqual(censusdata.aDFNeTMDJsioUdtYsdPkkYGouLmfPhdF('acs5', 2017, 'B23025'), QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz)
	def cqWwqfXfFcSJnCJhxDIRlKrzNTrSBwSA(self):
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz = OrderedDict()
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_001E'] = {'label': 'Estimate!!Total', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_002E'] = {'label': 'Estimate!!Total!!In labor force', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_003E'] = {'label': 'Estimate!!Total!!In labor force!!Civilian labor force', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_004E'] = {'label': 'Estimate!!Total!!In labor force!!Civilian labor force!!Employed', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_005E'] = {'label': 'Estimate!!Total!!In labor force!!Civilian labor force!!Unemployed', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_006E'] = {'label': 'Estimate!!Total!!In labor force!!Armed Forces', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_007E'] = {'label': 'Estimate!!Total!!Not in labor force', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		self.assertEqual(censusdata.aDFNeTMDJsioUdtYsdPkkYGouLmfPhdF('acs5', 2018, 'B23025'), QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz)
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz = OrderedDict()
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['C15010_001E'] = {'label': 'Estimate!!Total', 'concept': "FIELD OF BACHELOR'S DEGREE FOR FIRST MAJOR FOR THE POPULATION 25 YEARS AND OVER", 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['C15010_002E'] = {'label': 'Estimate!!Total!!Science and Engineering', 'concept': "FIELD OF BACHELOR'S DEGREE FOR FIRST MAJOR FOR THE POPULATION 25 YEARS AND OVER", 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['C15010_003E'] = {'label': 'Estimate!!Total!!Science and Engineering Related Fields', 'concept': "FIELD OF BACHELOR'S DEGREE FOR FIRST MAJOR FOR THE POPULATION 25 YEARS AND OVER", 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['C15010_004E'] = {'label': 'Estimate!!Total!!Business', 'concept': "FIELD OF BACHELOR'S DEGREE FOR FIRST MAJOR FOR THE POPULATION 25 YEARS AND OVER", 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['C15010_005E'] = {'label': 'Estimate!!Total!!Education', 'concept': "FIELD OF BACHELOR'S DEGREE FOR FIRST MAJOR FOR THE POPULATION 25 YEARS AND OVER", 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['C15010_006E'] = {'label': 'Estimate!!Total!!Arts, Humanities and Other', 'concept': "FIELD OF BACHELOR'S DEGREE FOR FIRST MAJOR FOR THE POPULATION 25 YEARS AND OVER", 'predicateType': 'int'}
		self.assertEqual(censusdata.aDFNeTMDJsioUdtYsdPkkYGouLmfPhdF('acs5', 2018, 'C15010'), QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz)
	def pXTSAcDChIKtiptSGhLJmOkGIkiTQtxS(self):
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz = OrderedDict()
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_001E'] = {'label': 'Estimate!!Total:', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_002E'] = {'label': 'Estimate!!Total:!!In labor force:', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_003E'] = {'label': 'Estimate!!Total:!!In labor force:!!Civilian labor force:', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_004E'] = {'label': 'Estimate!!Total:!!In labor force:!!Civilian labor force:!!Employed', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_005E'] = {'label': 'Estimate!!Total:!!In labor force:!!Civilian labor force:!!Unemployed', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_006E'] = {'label': 'Estimate!!Total:!!In labor force:!!Armed Forces', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['B23025_007E'] = {'label': 'Estimate!!Total:!!Not in labor force', 'concept': 'EMPLOYMENT STATUS FOR THE POPULATION 16 YEARS AND OVER', 'predicateType': 'int'}
		self.assertEqual(censusdata.aDFNeTMDJsioUdtYsdPkkYGouLmfPhdF('acs5', 2019, 'B23025'), QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz)
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz = OrderedDict()
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['C15010_001E'] = {'label': 'Estimate!!Total:', 'concept': "FIELD OF BACHELOR'S DEGREE FOR FIRST MAJOR FOR THE POPULATION 25 YEARS AND OVER", 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['C15010_002E'] = {'label': 'Estimate!!Total:!!Science and Engineering', 'concept': "FIELD OF BACHELOR'S DEGREE FOR FIRST MAJOR FOR THE POPULATION 25 YEARS AND OVER", 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['C15010_003E'] = {'label': 'Estimate!!Total:!!Science and Engineering Related Fields', 'concept': "FIELD OF BACHELOR'S DEGREE FOR FIRST MAJOR FOR THE POPULATION 25 YEARS AND OVER", 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['C15010_004E'] = {'label': 'Estimate!!Total:!!Business', 'concept': "FIELD OF BACHELOR'S DEGREE FOR FIRST MAJOR FOR THE POPULATION 25 YEARS AND OVER", 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['C15010_005E'] = {'label': 'Estimate!!Total:!!Education', 'concept': "FIELD OF BACHELOR'S DEGREE FOR FIRST MAJOR FOR THE POPULATION 25 YEARS AND OVER", 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['C15010_006E'] = {'label': 'Estimate!!Total:!!Arts, Humanities and Other', 'concept': "FIELD OF BACHELOR'S DEGREE FOR FIRST MAJOR FOR THE POPULATION 25 YEARS AND OVER", 'predicateType': 'int'}
		self.assertEqual(censusdata.aDFNeTMDJsioUdtYsdPkkYGouLmfPhdF('acs5', 2019, 'C15010'), QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz)
	def OguVuLlcrpBnWVfxhyPbtzWLYXCWxPdY(self):
		censusdata.aDFNeTMDJsioUdtYsdPkkYGouLmfPhdF('acs5', 2015, 'S0101_C02')
	def nFfJMbQDJhARHSyoKKyHFSIoAEXQLaKD(self):
		censusdata.aDFNeTMDJsioUdtYsdPkkYGouLmfPhdF('acs5', 2016, 'S0101_C02')
	def kRrnJnRLCKrbvyiclwhEAAumidhFdiAZ(self):
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz = OrderedDict()
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_001E'] = {'label': 'Estimate!!Percent!!Total population', 'concept': 'AGE AND SEX', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_002E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!Under 5 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_003E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!5 to 9 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_004E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!10 to 14 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_005E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!15 to 19 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_006E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!20 to 24 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_007E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!25 to 29 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_008E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!30 to 34 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_009E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!35 to 39 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_010E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!40 to 44 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_011E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!45 to 49 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_012E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!50 to 54 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_013E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!55 to 59 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_014E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!60 to 64 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_015E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!65 to 69 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_016E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!70 to 74 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_017E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!75 to 79 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_018E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!80 to 84 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_019E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!85 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_020E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!5 to 14 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_021E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!15 to 17 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_022E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!Under 18 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_023E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!18 to 24 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_024E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!15 to 44 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_025E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!16 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_026E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!18 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_027E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!21 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_028E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!60 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_029E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!62 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_030E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!65 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_031E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!75 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_032E'] = {'label': 'Estimate!!Percent!!Total population!!SUMMARY INDICATORS!!Median age (years)', 'concept': 'AGE AND SEX', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_033E'] = {'label': 'Estimate!!Percent!!Total population!!SUMMARY INDICATORS!!Sex ratio (males per 100 females)', 'concept': 'AGE AND SEX', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_034E'] = {'label': 'Estimate!!Percent!!Total population!!SUMMARY INDICATORS!!Age dependency ratio', 'concept': 'AGE AND SEX', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_035E'] = {'label': 'Estimate!!Percent!!Total population!!SUMMARY INDICATORS!!Old-age dependency ratio', 'concept': 'AGE AND SEX', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_036E'] = {'label': 'Estimate!!Percent!!Total population!!SUMMARY INDICATORS!!Child dependency ratio', 'concept': 'AGE AND SEX', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_037E'] = {'label': 'Estimate!!Percent!!PERCENT ALLOCATED!!Sex', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_038E'] = {'label': 'Estimate!!Percent!!PERCENT ALLOCATED!!Age', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		self.assertEqual(censusdata.aDFNeTMDJsioUdtYsdPkkYGouLmfPhdF('acs5', 2017, 'S0101_C02'), QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz)
	def gDejDtyWpCmQzoGiLNiHhyoHevgRWQEm(self):
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz = OrderedDict()
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_001E'] = {'label': 'Estimate!!Percent!!Total population', 'concept': 'AGE AND SEX', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_002E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!Under 5 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_003E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!5 to 9 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_004E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!10 to 14 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_005E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!15 to 19 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_006E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!20 to 24 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_007E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!25 to 29 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_008E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!30 to 34 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_009E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!35 to 39 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_010E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!40 to 44 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_011E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!45 to 49 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_012E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!50 to 54 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_013E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!55 to 59 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_014E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!60 to 64 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_015E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!65 to 69 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_016E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!70 to 74 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_017E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!75 to 79 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_018E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!80 to 84 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_019E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!85 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_020E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!5 to 14 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_021E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!15 to 17 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_022E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!Under 18 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_023E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!18 to 24 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_024E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!15 to 44 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_025E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!16 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_026E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!18 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_027E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!21 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_028E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!60 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_029E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!62 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_030E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!65 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_031E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!75 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_032E'] = {'label': 'Estimate!!Percent!!Total population!!SUMMARY INDICATORS!!Median age (years)', 'concept': 'AGE AND SEX', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_033E'] = {'label': 'Estimate!!Percent!!Total population!!SUMMARY INDICATORS!!Sex ratio (males per 100 females)', 'concept': 'AGE AND SEX', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_034E'] = {'label': 'Estimate!!Percent!!Total population!!SUMMARY INDICATORS!!Age dependency ratio', 'concept': 'AGE AND SEX', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_035E'] = {'label': 'Estimate!!Percent!!Total population!!SUMMARY INDICATORS!!Old-age dependency ratio', 'concept': 'AGE AND SEX', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_036E'] = {'label': 'Estimate!!Percent!!Total population!!SUMMARY INDICATORS!!Child dependency ratio', 'concept': 'AGE AND SEX', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_037E'] = {'label': 'Estimate!!Percent!!PERCENT ALLOCATED!!Sex', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_038E'] = {'label': 'Estimate!!Percent!!PERCENT ALLOCATED!!Age', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		self.assertEqual(censusdata.aDFNeTMDJsioUdtYsdPkkYGouLmfPhdF('acs5', 2018, 'S0101_C02'), QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz)
	def UvpNRNSQMFkKMdolawpKlDFNwyNxwIxF(self):
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz = OrderedDict()
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_001E'] = {'label': 'Estimate!!Percent!!Total population', 'concept': 'AGE AND SEX', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_002E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!Under 5 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_003E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!5 to 9 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_004E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!10 to 14 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_005E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!15 to 19 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_006E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!20 to 24 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_007E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!25 to 29 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_008E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!30 to 34 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_009E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!35 to 39 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_010E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!40 to 44 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_011E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!45 to 49 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_012E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!50 to 54 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_013E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!55 to 59 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_014E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!60 to 64 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_015E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!65 to 69 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_016E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!70 to 74 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_017E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!75 to 79 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_018E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!80 to 84 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_019E'] = {'label': 'Estimate!!Percent!!Total population!!AGE!!85 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_020E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!5 to 14 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_021E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!15 to 17 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_022E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!Under 18 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_023E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!18 to 24 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_024E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!15 to 44 years', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_025E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!16 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_026E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!18 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_027E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!21 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_028E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!60 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_029E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!62 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_030E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!65 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_031E'] = {'label': 'Estimate!!Percent!!Total population!!SELECTED AGE CATEGORIES!!75 years and over', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_032E'] = {'label': 'Estimate!!Percent!!Total population!!SUMMARY INDICATORS!!Median age (years)', 'concept': 'AGE AND SEX', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_033E'] = {'label': 'Estimate!!Percent!!Total population!!SUMMARY INDICATORS!!Sex ratio (males per 100 females)', 'concept': 'AGE AND SEX', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_034E'] = {'label': 'Estimate!!Percent!!Total population!!SUMMARY INDICATORS!!Age dependency ratio', 'concept': 'AGE AND SEX', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_035E'] = {'label': 'Estimate!!Percent!!Total population!!SUMMARY INDICATORS!!Old-age dependency ratio', 'concept': 'AGE AND SEX', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_036E'] = {'label': 'Estimate!!Percent!!Total population!!SUMMARY INDICATORS!!Child dependency ratio', 'concept': 'AGE AND SEX', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_037E'] = {'label': 'Estimate!!Percent!!Total population!!PERCENT ALLOCATED!!Sex', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['S0101_C02_038E'] = {'label': 'Estimate!!Percent!!Total population!!PERCENT ALLOCATED!!Age', 'concept': 'AGE AND SEX', 'predicateType': 'float'}
		self.assertEqual(censusdata.aDFNeTMDJsioUdtYsdPkkYGouLmfPhdF('acs5', 2019, 'S0101_C02'), QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz)
	def NilFMLsEliBSjLmnIfALfNioqohoQKxo(self):
		censusdata.aDFNeTMDJsioUdtYsdPkkYGouLmfPhdF('acs5', 2018, 'S1810')
	def JNEWSUHPpmcxVcUgyDdzHVtHzMdAxiaw(self):
		for vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm in range(2014, 2015+1):
			censusdata.aDFNeTMDJsioUdtYsdPkkYGouLmfPhdF('acsse', vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm, 'K201601')
		for vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm in range(2016, 2018+1):
			censusdata.aDFNeTMDJsioUdtYsdPkkYGouLmfPhdF('acsse', vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm, 'K201601')
		censusdata.aDFNeTMDJsioUdtYsdPkkYGouLmfPhdF('acsse', 2019, 'K201601')
	def ZPGqqbPYMvbnRAQGAzlTxoMpdSHRTdER(self):
		for vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm in range(2012, 2013+1):
			censusdata.aDFNeTMDJsioUdtYsdPkkYGouLmfPhdF('acs3', vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm, 'B23025')
	def UeEcOZpJcIiRycCGkRTbNQmskzfROKBH(self):
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz = OrderedDict()
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['P002001'] = {'label': 'Total', 'concept': 'URBAN AND RURAL', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['P002002'] = {'label': 'Total!!Urban', 'concept': 'URBAN AND RURAL', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['P002003'] = {'label': 'Total!!Urban!!Inside urbanized areas', 'concept': 'URBAN AND RURAL', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['P002004'] = {'label': 'Total!!Urban!!Inside urban clusters', 'concept': 'URBAN AND RURAL', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['P002005'] = {'label': 'Total!!Rural', 'concept': 'URBAN AND RURAL', 'predicateType': 'int'}
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz['P002006'] = {'label': 'Total!!Not defined for this file', 'concept': 'URBAN AND RURAL', 'predicateType': 'int'}
		self.assertEqual(censusdata.aDFNeTMDJsioUdtYsdPkkYGouLmfPhdF('sf1', 2010, 'P002'), QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz)
	def EdJFdxlNKYiaEmLzbrPPnTcWEOCcQEBo(self):
		self.assertRaises(ValueError, censusdata.aDFNeTMDJsioUdtYsdPkkYGouLmfPhdF, 'acs5', 2015, 'B24444')
	def AjKPKyIYhYuDLAreoAUBUQaONPflTJLL(self):
		censusdata.oovEHmiQNRFpfSBorBdkdNowbSVrhKid('acs5', 2015, 'concept', 'unweighted sample')
		censusdata.oovEHmiQNRFpfSBorBdkdNowbSVrhKid('acs5', 2018, 'concept', 'SEX BY AGE')
		censusdata.oovEHmiQNRFpfSBorBdkdNowbSVrhKid('acs5', 2015, 'concept',
		lambda value: re.oovEHmiQNRFpfSBorBdkdNowbSVrhKid('unweighted sample', value, re.IGNORECASE) and re.oovEHmiQNRFpfSBorBdkdNowbSVrhKid('housing', value, re.IGNORECASE))
		censusdata.oovEHmiQNRFpfSBorBdkdNowbSVrhKid('sf1', 2010, 'concept', 'JUVENILE FACILITIES')
		censusdata.oovEHmiQNRFpfSBorBdkdNowbSVrhKid('acsse', 2019, 'concept', 'SEX BY AGE')
	def RBPZUaADlSrwhVaYMSYkffEKBfLPCwTO(self):
		mxcjpsoZmlGcTtLCAYOWpykQmgGtVnOS = censusdata.aDFNeTMDJsioUdtYsdPkkYGouLmfPhdF('acs5', 2015, 'B19013')
		fvPgNIpTGtvNPoJePChDqdIswuVSAMKd = io.StringIO()
		sys.stdout = fvPgNIpTGtvNPoJePChDqdIswuVSAMKd
		censusdata.oWiCDdbGaPuBqgTeHOsWyYzZtyHdecCk(mxcjpsoZmlGcTtLCAYOWpykQmgGtVnOS)
		sys.stdout = sys.__stdout__
		self.assertEqual(fvPgNIpTGtvNPoJePChDqdIswuVSAMKd.getvalue(), textwrap.dedent(
		fvPgNIpTGtvNPoJePChDqdIswuVSAMKd.close()
		fvPgNIpTGtvNPoJePChDqdIswuVSAMKd = io.StringIO()
		sys.stdout = fvPgNIpTGtvNPoJePChDqdIswuVSAMKd
		censusdata.oWiCDdbGaPuBqgTeHOsWyYzZtyHdecCk(mxcjpsoZmlGcTtLCAYOWpykQmgGtVnOS, moe=True)
		sys.stdout = sys.__stdout__
		self.assertEqual(fvPgNIpTGtvNPoJePChDqdIswuVSAMKd.getvalue(), textwrap.dedent(
		fvPgNIpTGtvNPoJePChDqdIswuVSAMKd.close()
	def uVLnNwOHYbDrNrVOAbuMLPKoIpHFmkEC(self):
		self.assertRaises(ValueError, censusdata.tavbDPRkRTgrktGiFuuoeVonhiueEUeE, 'acs5', 2015, ['B19013_001E', 'D19013_002E'])
		self.assertRaises(ValueError, censusdata.aDFNeTMDJsioUdtYsdPkkYGouLmfPhdF, 'acs5', 2015, 'C19013')
		self.assertRaises(ValueError, censusdata.oovEHmiQNRFpfSBorBdkdNowbSVrhKid, 'acs5', 2015, 'concept', 'unweighted sample', MixRaUOIuuCbUmmGzTNYGwhSDrGjqxpN='cdetail')
if __name__ == '__main__':
	unittest.main()
