from __future__ import absolute_import, division, print_function, unicode_literals
import os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import censusdata
import unittest
import pandas as pd
from pandas.util.testing import assert_frame_equal
class vWMFnhhPMNVABbueRsFWfameomwnHUeo(unittest.TestCase):
	def uhlEAczrqHqJTtXjlxbKtFScqiNZKkpL(self):
		self.assertEqual(censusdata.eXjKDyfVlWEHIkFRMmtszaDgqbaZACFx('acs5', 2015, {'get': 'NAME,B01001_001E', 'for': 'state:17'}),
			{'NAME': ['Illinois'], 'B01001_001E': ['12873761'], 'state': ['17']})
	def rVjGLrdAcQMxRwBhbmtFCoGlnNNgGAwh(self):
		self.assertEqual(censusdata.eXjKDyfVlWEHIkFRMmtszaDgqbaZACFx('acs5', 2015, {'get': 'NAME,B01001_001E', 'for': 'place:53000', 'in': 'state:06'}),
			{'NAME': ['Oakland city, California'], 'B01001_001E': ['408073'], 'state': ['06'], 'place': ['53000']})
	def NVSDggxRULEkidGVMvJBYKXgYrtjexxo(self):
		for vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm in range(2009, 2019+1):
			self.assertEqual(censusdata.YbOoDnmwqNZZqhtTaHRfDQKDfnsnDLUM(censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '*')]), 'acs5', vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm),
				{
				'Alaska': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '02')]),
				'Alabama': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '01')]),
				'Arkansas': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '05')]),
				'Arizona': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '04')]),
				'California': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06')]),
				'Colorado': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '08')]),
				'Connecticut': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '09')]),
				'District of Columbia': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '11')]),
				'Delaware': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '10')]),
				'Florida': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '12')]),
				'Georgia': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '13')]),
				'Hawaii': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15')]),
				'Iowa': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '19')]),
				'Idaho': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '16')]),
				'Illinois': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17')]),
				'Indiana': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '18')]),
				'Kansas': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '20')]),
				'Kentucky': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '21')]),
				'Louisiana': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '22')]),
				'Massachusetts': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '25')]),
				'Maryland': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '24')]),
				'Maine': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '23')]),
				'Michigan': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '26')]),
				'Minnesota': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '27')]),
				'Missouri': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '29')]),
				'Mississippi': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '28')]),
				'Montana': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '30')]),
				'North Carolina': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '37')]),
				'North Dakota': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '38')]),
				'Nebraska': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '31')]),
				'New Hampshire': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '33')]),
				'New Jersey': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '34')]),
				'New Mexico': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '35')]),
				'Nevada': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '32')]),
				'New York': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '36')]),
				'Ohio': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '39')]),
				'Oklahoma': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '40')]),
				'Oregon': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '41')]),
				'Pennsylvania': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '42')]),
				'Puerto Rico': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '72')]),
				'Rhode Island': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '44')]),
				'South Carolina': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '45')]),
				'South Dakota': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '46')]),
				'Tennessee': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '47')]),
				'Texas': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '48')]),
				'Utah': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '49')]),
				'Virginia': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '51')]),
				'Vermont': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '50')]),
				'Washington': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '53')]),
				'Wisconsin': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '55')]),
				'West Virginia': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '54')]),
				'Wyoming': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '56')]),
				})
	def zSuvyRDDNnuEKopazqReGZqrlLLbZLnD(self):
		self.assertEqual(censusdata.YbOoDnmwqNZZqhtTaHRfDQKDfnsnDLUM(censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '*')]), 'acs5', 2015), 
			{'Hawaii County, Hawaii': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '001')]),
			'Honolulu County, Hawaii': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '003')]),
			'Kalawao County, Hawaii': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '005')]),
			'Kauai County, Hawaii': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '007')]),
			'Maui County, Hawaii': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '009')]),})
		self.assertEqual(censusdata.YbOoDnmwqNZZqhtTaHRfDQKDfnsnDLUM(censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '*')]), 'acs1', 2015), 
			{'Hawaii County, Hawaii': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '001')]),
			'Honolulu County, Hawaii': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '003')]),
			'Kauai County, Hawaii': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '007')]),
			'Maui County, Hawaii': censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '009')]),})
	def ESmWXhvXjHRcEgWcrerJdOcYFdKcijap(self):
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2019, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06'), ('place', '53000')]), ['B01001_001E', 'B01002_001E', 'B19013_001E']),
			pd.DataFrame({'B01001_001E': 425097, 'B01002_001E': 36.5, 'B19013_001E': 73692}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06'), ('place', '53000')], 'Oakland city, California')]))
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2019, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '*')]), ['B01001_001E', 'B01002_001E', 'B19013_001E']),
			pd.DataFrame({'B01001_001E': [199459, 984821, 71769, 66, 165979,], 'B01002_001E': [42.7, 37.9, 42.6, 57.4, 41.2], 'B19013_001E': [62409, 85857, 83554, 69375, 80948]}, 
				[censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '001')], 'Hawaii County, Hawaii'),
				censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '003')], 'Honolulu County, Hawaii'),
				censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '007')], 'Kauai County, Hawaii'),
				censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '005')], 'Kalawao County, Hawaii'),
				censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '009')], 'Maui County, Hawaii'),
				]))
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2019, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17'), ('county', '031'), ('tract', '350100'), ('block group', '2')]), ['B01001_001E', 'B19013_001E']),
			pd.DataFrame({'B01001_001E': 1586, 'B19013_001E': 45313}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17'), ('county', '031'), ('tract', '350100'), ('block group', '2')], 'Block Group 2, Census Tract 3501, Cook County, Illinois')]))
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2019, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('metropolitan statistical area/micropolitan statistical area', '16980')]), ['B01001_001E', 'B19013_001E']),
			pd.DataFrame({'B01001_001E': 9508605, 'B19013_001E': 71770}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('metropolitan statistical area/micropolitan statistical area', '16980')], 'Chicago-Naperville-Elgin, IL-IN-WI Metro Area')]))
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2019, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06')]), ['DP03_0021PE'], MixRaUOIuuCbUmmGzTNYGwhSDrGjqxpN='profile'),
			pd.DataFrame({'DP03_0021PE': 5.1}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06')], 'California')]))
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2019, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06')]), ['C24010_001E'], MixRaUOIuuCbUmmGzTNYGwhSDrGjqxpN='detail'),
			pd.DataFrame({'C24010_001E': 18591241}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06')], 'California')]))
	def zUaJXAqsnaZrkfwepsecHMalcxBdsqjh(self):
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2018, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06'), ('place', '53000')]), ['B01001_001E', 'B01002_001E', 'B19013_001E']),
			pd.DataFrame({'B01001_001E': 421042, 'B01002_001E': 36.5, 'B19013_001E': 68442}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06'), ('place', '53000')], 'Oakland city, California')]))
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2018, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '*')]), ['B01001_001E', 'B01002_001E', 'B19013_001E']),
			pd.DataFrame({'B01001_001E': [197658, 987638, 71377, 75, 165281], 'B01002_001E': [42.3, 37.6, 42.4, 57.1, 41.1], 'B19013_001E': [59297, 82906, 78482, 61875, 77117]}, 
				[censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '001')], 'Hawaii County, Hawaii'),
				censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '003')], 'Honolulu County, Hawaii'),
				censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '007')], 'Kauai County, Hawaii'),
				censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '005')], 'Kalawao County, Hawaii'),
				censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '009')], 'Maui County, Hawaii'),]))
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2018, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17'), ('county', '031'), ('tract', '350100'), ('block group', '2')]), ['B01001_001E', 'B19013_001E']),
			pd.DataFrame({'B01001_001E': 1433, 'B19013_001E': 33750}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17'), ('county', '031'), ('tract', '350100'), ('block group', '2')], 'Block Group 2, Census Tract 3501, Cook County, Illinois')]))
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2018, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('metropolitan statistical area/micropolitan statistical area', '16980')]), ['B01001_001E', 'B19013_001E']),
			pd.DataFrame({'B01001_001E': 9536428, 'B19013_001E': 68715}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('metropolitan statistical area/micropolitan statistical area', '16980')], 'Chicago-Naperville-Elgin, IL-IN-WI Metro Area')]))
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2018, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06')]), ['DP03_0021PE'], MixRaUOIuuCbUmmGzTNYGwhSDrGjqxpN='profile'),
			pd.DataFrame({'DP03_0021PE': 5.1}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06')], 'California')]))
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2018, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06')]), ['C24010_001E'], MixRaUOIuuCbUmmGzTNYGwhSDrGjqxpN='detail'),
			pd.DataFrame({'C24010_001E': 18309012}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06')], 'California')]))
	def tTnjVJLBOwkCmffnQvGLcowMioIgbkMB(self):
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2017, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06'), ('place', '53000')]), ['B01001_001E', 'B01002_001E', 'B19013_001E']),
			pd.DataFrame({'B01001_001E': 417442, 'B01002_001E': 36.4, 'B19013_001E': 63251}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06'), ('place', '53000')], 'Oakland city, California')]))
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2017, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '*')]), ['B01001_001E', 'B01002_001E', 'B19013_001E']),
			pd.DataFrame({'B01001_001E': [196325, 990060, 164094, 71093, 86], 'B01002_001E': [42.1, 37.6, 40.9, 42.1, 57.6], 'B19013_001E': [56395, 80078, 72762, 72330, 61750]}, 
				[censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '001')], 'Hawaii County, Hawaii'), censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '003')], 'Honolulu County, Hawaii'),
				censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '009')], 'Maui County, Hawaii'), censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '007')], 'Kauai County, Hawaii'),
				censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '005')], 'Kalawao County, Hawaii'),]))
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2017, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17'), ('county', '031'), ('tract', '350100'), ('block group', '2')]), ['B01001_001E', 'B19013_001E']),
			pd.DataFrame({'B01001_001E': 1476, 'B19013_001E': 41638}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17'), ('county', '031'), ('tract', '350100'), ('block group', '2')], 'Block Group 2, Census Tract 3501, Cook County, Illinois')]))
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2017, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('metropolitan statistical area/micropolitan statistical area', '16980')]), ['B01001_001E', 'B19013_001E']),
			pd.DataFrame({'B01001_001E': 9549229, 'B19013_001E': 65757}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('metropolitan statistical area/micropolitan statistical area', '16980')], 'Chicago-Naperville-Elgin, IL-IN-WI Metro Area')]))
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2017, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06')]), ['DP03_0021PE'], MixRaUOIuuCbUmmGzTNYGwhSDrGjqxpN='profile'),
			pd.DataFrame({'DP03_0021PE': 5.2}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06')], 'California')]))
	def RDlFrQKZlcJrMoBarPetPfFjGpZHRqdC(self):
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2016, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06'), ('place', '53000')]), ['B01001_001E', 'B01002_001E', 'B19013_001E']),
			pd.DataFrame({'B01001_001E': 412040, 'B01002_001E': 36.2, 'B19013_001E': 57778}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06'), ('place', '53000')], 'Oakland city, California')]))
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2016, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '*')]), ['B01001_001E', 'B01002_001E', 'B19013_001E']),
			pd.DataFrame({'B01001_001E': [986999, 162456, 91, 193680, 70447], 'B01002_001E': [37.4, 40.5, 56.5, 41.8, 42.0], 'B19013_001E': [77161, 68777, 65625, 53936, 68224]}, 
				[
				censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '003')], 'Honolulu County, Hawaii'),
				censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '009')], 'Maui County, Hawaii'),
				censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '005')], 'Kalawao County, Hawaii'),
				censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '001')], 'Hawaii County, Hawaii'),
				censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '007')], 'Kauai County, Hawaii'),
				]))
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2016, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17'), ('county', '031'), ('tract', '350100'), ('block group', '2')]), ['B01001_001E', 'B19013_001E']),
			pd.DataFrame({'B01001_001E': 1374, 'B19013_001E': 44044}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17'), ('county', '031'), ('tract', '350100'), ('block group', '2')], 'Block Group 2, Census Tract 3501, Cook County, Illinois')]))
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2016, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('metropolitan statistical area/micropolitan statistical area', '16980')]), ['B01001_001E', 'B19013_001E']),
			pd.DataFrame({'B01001_001E': 9528396, 'B19013_001E': 63327}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('metropolitan statistical area/micropolitan statistical area', '16980')], 'Chicago-Naperville-Elgin, IL-IN-WI Metro Area')]))
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2016, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06')]), ['DP03_0021PE'], MixRaUOIuuCbUmmGzTNYGwhSDrGjqxpN='profile'),
			pd.DataFrame({'DP03_0021PE': 5.2}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06')], 'California')]))
	def rXERyMDIydfYTRKbKCLQZyHWYIgfuKbu(self):
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2015, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06'), ('place', '53000')]), ['B01001_001E', 'B01002_001E', 'B19013_001E']),
			pd.DataFrame({'B01001_001E': 408073, 'B01002_001E': 36.3, 'B19013_001E': 54618}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06'), ('place', '53000')], 'Oakland city, California')]))
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2015, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '*')]), ['B01001_001E', 'B01002_001E', 'B19013_001E']),
			pd.DataFrame({'B01001_001E': [191482, 69691, 984178, 160863, 85], 'B01002_001E': [41.1, 41.6, 36.9, 40, 51.9], 'B19013_001E': [52108, 65101, 74460, 66476, 66250]}, 
				[censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '001')], 'Hawaii County, Hawaii'),
				censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '007')], 'Kauai County, Hawaii'),
				censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '003')], 'Honolulu County, Hawaii'),
				censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '009')], 'Maui County, Hawaii'),
				censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '15'), ('county', '005')], 'Kalawao County, Hawaii'),]))
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2015, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17'), ('county', '031'), ('tract', '350100'), ('block group', '2')]), ['B01001_001E', 'B19013_001E']),
			pd.DataFrame({'B01001_001E': 1293, 'B19013_001E': 49375}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17'), ('county', '031'), ('tract', '350100'), ('block group', '2')], 'Block Group 2, Census Tract 3501, Cook County, Illinois')]))
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2015, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('metropolitan statistical area/micropolitan statistical area', '16980')]), ['B01001_001E', 'B19013_001E']),
			pd.DataFrame({'B01001_001E': 9534008, 'B19013_001E': 61828}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('metropolitan statistical area/micropolitan statistical area', '16980')], 'Chicago-Naperville-Elgin, IL-IN-WI Metro Area')]))
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2015, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06')]), ['DP03_0021PE'], MixRaUOIuuCbUmmGzTNYGwhSDrGjqxpN='profile'),
			pd.DataFrame({'DP03_0021PE': 5.2}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06')], 'California')]))
	def aXYuQwnnJbwDLJIpaMwtJvmwcDYVeVES(self):
		XrCkZRswwtXjJiaINsavFOGOShAcTFzQ = {2009: 55222, 2010: 55735, 2011: 56576, 2012: 56853, 2013: 56797, 2014: 57166}
		for vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm in range(2009, 2014+1):
			assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17')]), ['B19013_001E']),
				pd.DataFrame({'B19013_001E': XrCkZRswwtXjJiaINsavFOGOShAcTFzQ[vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm]}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17')], 'Illinois')]))
	def wvpcHmiUkVcaiWGQBtysBHCAKZcppbZt(self):
		str(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2019, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('zip code tabulation area','*')]), ['B19013_001E']))
	def GOjnnwyGDlCmbuERHkTZPzkVdYoODSAn(self):
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs1', 2019, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17')]), ['B19013_001E']),
			pd.DataFrame({'B19013_001E': 69187}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17')], 'Illinois')]))
	def aLfLZjzKiRhHEeGorVfTetgnAwUZSjip(self):
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs1', 2018, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17')]), ['B19013_001E']),
			pd.DataFrame({'B19013_001E': 65030}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17')], 'Illinois')]))
	def rxxcMWgEyTulzToIGhTqSZZClnOReHLe(self):
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs1', 2017, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17')]), ['B19013_001E']),
			pd.DataFrame({'B19013_001E': 62992}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17')], 'Illinois')]))
	def NwZstHCQPJLOauTqhDOcfTzliIEdlxtO(self):
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs1', 2016, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17')]), ['B19013_001E']),
			pd.DataFrame({'B19013_001E': 60960}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17')], 'Illinois')]))
	def JAOjtSnhqJcdDexpqHRwaPBQGpsqsyWB(self):
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs1', 2015, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17')]), ['B19013_001E']),
			pd.DataFrame({'B19013_001E': 59588}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17')], 'Illinois')]))
	def HssoxDLjSgQEHluInoudRsPxZFZghgHb(self):
		XrCkZRswwtXjJiaINsavFOGOShAcTFzQ = {2012: 55137, 2013: 56210, 2014: 57444}
		for vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm in range(2012, 2014+1):
			assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs1', vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17')]), ['B19013_001E']),
				pd.DataFrame({'B19013_001E': XrCkZRswwtXjJiaINsavFOGOShAcTFzQ[vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm]}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17')], 'Illinois')]))
	def HfirgQUvVrTbPVzweVlXiTcPzTnEFeUw(self):
		akCtZqMwdfFqlPydkIVkMmiIyBxxxCvt = {2014: 731135, 2015: 658047, 2016: 522736, 2017: 464053, 2018: 414688, 2019: 378926}
		for vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm in range(2014, 2019+1):
			assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acsse', vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17')]), ['K202801_006E']),
				pd.DataFrame({'K202801_006E': akCtZqMwdfFqlPydkIVkMmiIyBxxxCvt[vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm]}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17')], 'Illinois')]))
	def iEXjDWecSBVDyqzvGOnVNfXySuhyDklb(self):
		XrCkZRswwtXjJiaINsavFOGOShAcTFzQ = {2012: 55231, 2013: 55799}
		for vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm in XrCkZRswwtXjJiaINsavFOGOShAcTFzQ:
			assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs3', vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17')]), ['B19013_001E']),
				pd.DataFrame({'B19013_001E': XrCkZRswwtXjJiaINsavFOGOShAcTFzQ[vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm]}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17')], 'Illinois')]))
	def NbyOHUeGBAeMLxQIZgTScbUXtmokhAgM(self):
		pkDyQWOOCpBTuIAyFhmYKReSduaTbyPM = {2012: 78.3, 2013: 78.5}
		for vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm in pkDyQWOOCpBTuIAyFhmYKReSduaTbyPM:
			assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs3', vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17')]), ['DP03_0115PE'], MixRaUOIuuCbUmmGzTNYGwhSDrGjqxpN='profile'),
				pd.DataFrame({'DP03_0115PE': pkDyQWOOCpBTuIAyFhmYKReSduaTbyPM[vLLLbBjhKiPVHtbzKxgLZHHHShSBAAEm]}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17')], 'Illinois')]))
	def FyaGOXZwCRkolFABXQqwXJQaXxoahvMI(self):
		assert_frame_equal(censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('sf1', 2010, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17'), ('place', '14000')]), ['P001001']),
			pd.DataFrame({'P001001': 2695598}, [censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '17'), ('place', '14000')])]))
	def ZWCgKQBDwRcEEpWZLcGcUqYEAxHVInuS(self):
		self.assertRaises(ValueError, censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT, 'acs5', 2015, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06'), ('place', '53000')]), ['B19013_010E'])
	def utYgoqgNOKcGzFmrWMbDfhuiGRvPAtSS(self):
		self.assertRaises(ValueError, censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT, 'acs5', 2015, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06')]), ['B19013_001E'], MixRaUOIuuCbUmmGzTNYGwhSDrGjqxpN='cdetail')
	def soSngIuuWIZAaOsuxBSmsGQUvQRWbgVt(self):
		vars = ['DP05_{:04}PE'.format(fHTmiDybNgLKGwQyMzgFxYUZZwaQdtZX) for fHTmiDybNgLKGwQyMzgFxYUZZwaQdtZX in range(1, 84+1)]
		AcpedZlBRjGhdhBwQlwVqQeYriiPoKNa = censusdata.iaLceksReKZzSkeYwuKtXEpZSPEVQUsT('acs5', 2015, censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06')]), vars, MixRaUOIuuCbUmmGzTNYGwhSDrGjqxpN='profile')
		QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz = pd.DataFrame({'DP05_0001PE': 38421464, 'DP05_0002PE': 49.7, 'DP05_0003PE': 50.3, 'DP05_0004PE': 6.5, 'DP05_0005PE': 6.6,
			'DP05_0006PE': 6.6, 'DP05_0007PE': 6.9, 'DP05_0008PE': 7.6, 'DP05_0009PE': 14.6, 'DP05_0010PE': 13.5, 'DP05_0011PE': 13.7,
			'DP05_0012PE': 6.2, 'DP05_0013PE': 5.3, 'DP05_0014PE': 7.0, 'DP05_0015PE': 3.8, 'DP05_0016PE': 1.7, 'DP05_0017PE': -888888888,
			'DP05_0018PE': 76.1, 'DP05_0019PE': 71.7, 'DP05_0020PE': 15.5, 'DP05_0021PE': 12.5, 'DP05_0022PE': 29247121, 'DP05_0023PE': 49.2,
			'DP05_0024PE': 50.8, 'DP05_0025PE': 4797320, 'DP05_0026PE': 44.0, 'DP05_0027PE': 56.0, 'DP05_0028PE': 38421464, 'DP05_0029PE': 95.5,
			'DP05_0030PE': 4.5, 'DP05_0031PE': 95.5, 'DP05_0032PE': 61.8, 'DP05_0033PE': 5.9, 'DP05_0034PE': 0.7, 'DP05_0035PE': 0.1, 'DP05_0036PE': 0.0,
			'DP05_0037PE': 0.0, 'DP05_0038PE': 0.0, 'DP05_0039PE': 13.7, 'DP05_0040PE': 1.7, 'DP05_0041PE': 3.6, 'DP05_0042PE': 3.2,
			'DP05_0043PE': 0.7, 'DP05_0044PE': 1.2, 'DP05_0045PE': 1.6, 'DP05_0046PE': 1.6, 'DP05_0047PE': 0.4, 'DP05_0048PE': 0.1, 'DP05_0049PE': 0.1,
			'DP05_0050PE': 0.1, 'DP05_0051PE': 0.2, 'DP05_0052PE': 12.9, 'DP05_0053PE': 4.5, 'DP05_0054PE': 0.6, 'DP05_0055PE': 0.7, 'DP05_0056PE': 1.3,
			'DP05_0057PE': 0.1, 'DP05_0058PE': 38421464, 'DP05_0059PE': 65.5, 'DP05_0060PE': 7.1, 'DP05_0061PE': 1.9, 'DP05_0062PE': 15.6,
			'DP05_0063PE': 0.8, 'DP05_0064PE': 14.1, 'DP05_0065PE': 38421464, 'DP05_0066PE': 38.4, 'DP05_0067PE': 31.9, 'DP05_0068PE': 0.5,
			'DP05_0069PE': 0.2, 'DP05_0070PE': 5.7, 'DP05_0071PE': 61.6, 'DP05_0072PE': 38.7, 'DP05_0073PE': 5.6, 'DP05_0074PE': 0.4,
			'DP05_0075PE': 13.5, 'DP05_0076PE': 0.4, 'DP05_0077PE': 0.2, 'DP05_0078PE': 2.8, 'DP05_0079PE': 0.1, 'DP05_0080PE': 2.7,
			'DP05_0081PE': -888888888, 'DP05_0082PE': 24280349, 'DP05_0083PE': 49.0, 'DP05_0084PE': 51.0},
			[censusdata.ZLnCyTSweNgEXfMJXPhHtuAeMOfNrRwS([('state', '06')])])
		assert_frame_equal(AcpedZlBRjGhdhBwQlwVqQeYriiPoKNa, QBgRKhNsfpWSSJGfFjbRgqpAujxdCrNz)
if __name__ == '__main__':
	unittest.main()
