#!/usr/bin/env python
import logging
import os.path
import platform
import sys
from typing import Any, Dict, List
from ctypes import (
    CDLL,
    c_bool,
    c_ulong,
    c_ushort,
    c_char_p,
    c_byte,
    c_void_p,
    byref,
)
from .pemicro_const import (
    RCyIfsgmdwhpAsrMuoxcANjIiEoojOnc,
    kQjBaRrlyabpMNWUzuzDYLEDgKASuUOA,
    jtMmMlQhEwBhMLaMRqNzoTZCxsGReFjq,
    LOSNRJxGHWhxYBiEWKhDWoBlMsVTsgWm,
    GHljGVOJqZonfxycSoxAWEDQPmYEySDc,
    HKgbozwagxJKZHeJnYjvLHwjIIPQgHXV,
    xEYvczdnGEaMAwpBTnbSyvrSKREetHVk,
)
class OidRXaqimIQIUhgZcOkPWQMqDMNplHOc(Exception):
    OhekPgzHgpTfEvRcsljbnHHVyJdQpxHX = 'JoZwSAXGrWAUPNJCjOMDvimIoklsSelM'
class RsrBrhiCVAqniOILDgirXOMHoVnrbQXy(OidRXaqimIQIUhgZcOkPWQMqDMNplHOc):
    kPUpYzKqqglbkDOCwqwJrkikqoidBRaQ = 'LnpBxuPRqojAvGponBPrLqctZgRGsZiB'
kvWQbjptSAirgKWXnEJewTclkPvUWpYT = logging.getLogger(__name__)
class BOYsDPxDDbnUVrwsQpNQfRffYBhEROta:
    @staticmethod
    def EJPENRIYhPKWrPFKvKYyyWCFuskVGZki() -> str:
        mBHjGnLoQAsqodMyOgSxPbpPayukXGXV = {
            "Windows": "Windows",
            "Linux": "Linux",
            "Linux2": "Linux",
            "Darwin": "MacOS",
            "FreeBSD": "FreeBSD",
            "OpenBSD": "OpenBSD",
            "NetBSD": "NetBSD",
        }
        return mBHjGnLoQAsqodMyOgSxPbpPayukXGXV[platform.system()]
    @staticmethod
    def yAcTnrZnfECHfwLeLUagFFmSygRHVLnS() -> str:
        vzMZVMKgQPfSyGYfZpmGrgERwHumZGJM = {
            "Windows": {"32bit": "unitacmp-32.dll", "64bit": "unitacmp-64.dll"},
            "Linux": {"32bit": "unitacmp-64.so", "64bit": "unitacmp-64.so"},
            "Darwin": {"32bit": "unitacmp-64.dylib", "64bit": "unitacmp-64.dylib"},
            "FreeBSD": {"32bit": "unitacmp-64.so", "64bit": "unitacmp-64.so"},
            "OpenSD": {"32bit": "unitacmp-64.so", "64bit": "unitacmp-64.so"},
            "NetBSD": {"32bit": "unitacmp-64.so", "64bit": "unitacmp-64.so"},
        }
        QXutLReSJrhenRZqAAovMysobQmSsHKh = "64bit" if sys.maxsize > 2**32 else "32bit"
        QguWjpodWTnpjJCaeLVJVoGZiEVLHlOg = platform.system()
        if QguWjpodWTnpjJCaeLVJVoGZiEVLHlOg not in vzMZVMKgQPfSyGYfZpmGrgERwHumZGJM.keys():
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc(
                f"Unable to determinate running operation system ({system_name})"
            )
        return vzMZVMKgQPfSyGYfZpmGrgERwHumZGJM[QguWjpodWTnpjJCaeLVJVoGZiEVLHlOg][QXutLReSJrhenRZqAAovMysobQmSsHKh]  
    @staticmethod
    def oYmqVQXbyvbWdWGCmlpRIlxrAevbteIv(dll_path: str, XtTxXXDyQCPpdKlTTDqoHiUlCtCqjqvs: str) -> Dict:
        try:
            UZtPNQOJpBVjfQtCdmzeilPElDRyWcxv = {}
            UZtPNQOJpBVjfQtCdmzeilPElDRyWcxv["path"] = dll_path
            UZtPNQOJpBVjfQtCdmzeilPElDRyWcxv["name"] = XtTxXXDyQCPpdKlTTDqoHiUlCtCqjqvs
            LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM = CDLL(os.path.join(dll_path, XtTxXXDyQCPpdKlTTDqoHiUlCtCqjqvs))
            LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.hVtMMPEmcAaqPnhZvPUafJcafokVKhcV.restype = c_char_p
            LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.get_dll_version.restype = c_ushort
            UZtPNQOJpBVjfQtCdmzeilPElDRyWcxv["version"] = LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.hVtMMPEmcAaqPnhZvPUafJcafokVKhcV()
            UZtPNQOJpBVjfQtCdmzeilPElDRyWcxv["version_num"] = LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.get_dll_version()
            del LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM
        except (FileNotFoundError, OSError) as exc:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc(
                f"Cannot load the PEMICRO library({lib_name})"
                + f"on this path:{dll_path}. Error({str(exc)})"
            )
        return UZtPNQOJpBVjfQtCdmzeilPElDRyWcxv
    @staticmethod
    def vxjOoxHRjTpcQsyBmprWaINEoyjRJvyl(dll_path: str = None, search_generic: bool = True) -> List:
        XtTxXXDyQCPpdKlTTDqoHiUlCtCqjqvs = BOYsDPxDDbnUVrwsQpNQfRffYBhEROta.yAcTnrZnfECHfwLeLUagFFmSygRHVLnS()
        mIdPoUWfxULqbtILcdMWgFZbDbmvcDLb = []
        if dll_path is not None:
            try:
                mIdPoUWfxULqbtILcdMWgFZbDbmvcDLb.append(BOYsDPxDDbnUVrwsQpNQfRffYBhEROta.oYmqVQXbyvbWdWGCmlpRIlxrAevbteIv(dll_path, XtTxXXDyQCPpdKlTTDqoHiUlCtCqjqvs))
            except OidRXaqimIQIUhgZcOkPWQMqDMNplHOc:
                pass
        if search_generic:
            try:
                mIdPoUWfxULqbtILcdMWgFZbDbmvcDLb.append(BOYsDPxDDbnUVrwsQpNQfRffYBhEROta.oYmqVQXbyvbWdWGCmlpRIlxrAevbteIv("", XtTxXXDyQCPpdKlTTDqoHiUlCtCqjqvs))
            except OidRXaqimIQIUhgZcOkPWQMqDMNplHOc:
                pass
            try:
                mIdPoUWfxULqbtILcdMWgFZbDbmvcDLb.append(
                    BOYsDPxDDbnUVrwsQpNQfRffYBhEROta.oYmqVQXbyvbWdWGCmlpRIlxrAevbteIv(os.path.dirname(__file__), XtTxXXDyQCPpdKlTTDqoHiUlCtCqjqvs)
                )
            except OidRXaqimIQIUhgZcOkPWQMqDMNplHOc:
                pass
            try:
                BlwRYHLcumLviXmFllizChdvdTZZUjtU = os.path.join("libs", BOYsDPxDDbnUVrwsQpNQfRffYBhEROta.EJPENRIYhPKWrPFKvKYyyWCFuskVGZki())
                mIdPoUWfxULqbtILcdMWgFZbDbmvcDLb.append(
                    BOYsDPxDDbnUVrwsQpNQfRffYBhEROta.oYmqVQXbyvbWdWGCmlpRIlxrAevbteIv(
                        os.path.join(os.path.dirname(__file__), BlwRYHLcumLviXmFllizChdvdTZZUjtU),
                        XtTxXXDyQCPpdKlTTDqoHiUlCtCqjqvs,
                    )
                )
            except OidRXaqimIQIUhgZcOkPWQMqDMNplHOc:
                pass
        if len(mIdPoUWfxULqbtILcdMWgFZbDbmvcDLb) == 0:
            kvWQbjptSAirgKWXnEJewTclkPvUWpYT.debug("There is no PEMICRO library.")
        return mIdPoUWfxULqbtILcdMWgFZbDbmvcDLb
    @staticmethod
    def QRiWvNxYqzMzDvwTsyqlDLjANXheORgv(file_name: str) -> CDLL:
        if file_name is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("The libray file name MUST be specified.")
        try:
            LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM = CDLL(file_name)
        except (FileNotFoundError, OSError) as exc:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc(
                f"Cannot load the PEMICRO library({file_name}). " + f"Error({str(exc)})"
            )
        if LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("The PEMicro library load failed.")
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.pe_special_features.argtypes = [
            c_ulong,
            c_bool,
            c_ulong,
            c_ulong,
            c_ulong,
            c_void_p,
            c_void_p,
        ]
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.pe_special_features.restype = c_bool
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.open_port.argtypes = [c_ulong, c_ulong]
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.open_port.restype = c_bool
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.open_port_by_identifier.argtypes = [c_char_p]
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.open_port_by_identifier.restype = c_bool
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.SiRdxnsRedDzdtjzzgkItioEkOHOgTtz.restype = c_bool
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.get_enumerated_number_of_ports.argtypes = [c_ulong]
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.get_enumerated_number_of_ports.restype = c_ulong
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.get_port_descriptor.argtypes = [c_ulong, c_ulong]
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.get_port_descriptor.restype = c_char_p
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.get_port_descriptor_short.argtypes = [c_ulong, c_ulong]
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.get_port_descriptor_short.restype = c_char_p
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.check_critical_error.restype = c_byte
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.hVtMMPEmcAaqPnhZvPUafJcafokVKhcV.restype = c_char_p
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.get_dll_version.restype = c_ushort
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.set_debug_shift_frequency.argtypes = [c_ulong]
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.uWOLTXurQlBJrrzDtEaYbbDLVKXWmyOc.argtypes = [c_ulong]
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.target_reset.restype = c_bool
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.lQEtmZXZDSipdvvfWbnkuEQfQMSAUQQQ.restype = c_bool
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.target_halt.restype = c_bool
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.target_resume.restype = c_bool
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.LcwdhMorSsOuGnDnQKilZLLRiZfXpalm.restype = c_bool
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.set_reset_pin_state.argtypes = [c_byte]
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.WlmVXkUgzKnPAigGPgVJXPMurHaVgkfQ.argtypes = [c_char_p]
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.read_32bit_value.argtypes = [c_ulong, c_ulong, c_void_p]
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.read_32bit_value.restype = c_ulong
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.write_32bit_value.argtypes = [c_ulong, c_ulong, c_ulong, c_void_p]
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.read_16bit_value.argtypes = [c_ulong, c_ulong, c_void_p]
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.read_16bit_value.restype = c_ushort
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.write_16bit_value.argtypes = [c_ulong, c_ulong, c_ulong, c_void_p]
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.read_8bit_value.argtypes = [c_ulong, c_ulong, c_void_p]
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.read_8bit_value.restype = c_byte
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.write_8bit_value.argtypes = [c_ulong, c_ulong, c_ulong, c_void_p]
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.get_block.argtypes = [
            c_ulong,
            c_ulong,
            c_ulong,
            c_ulong,
            c_char_p,
            c_char_p,
        ]
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.get_block.restype = c_bool
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.put_block.argtypes = [
            c_ulong,
            c_ulong,
            c_ulong,
            c_ulong,
            c_char_p,
            c_char_p,
        ]
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.put_block.restype = c_bool
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.etVhzBvzQieOMZdiYtQGePOWZvONukwW.argtypes = [c_char_p, c_ulong]
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.etVhzBvzQieOMZdiYtQGePOWZvONukwW.restype = c_bool
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.EZCGLEIUxKRwEiFVgJbvOfRafsDbQctP.argtypes = [c_char_p, c_ulong]
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.EZCGLEIUxKRwEiFVgJbvOfRafsDbQctP.restype = c_bool
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.riFgIsgVGirsRJYEFkvstSvQMJGfYCMx.argtypes = [c_ulong, c_ulong, c_void_p]
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.riFgIsgVGirsRJYEFkvstSvQMJGfYCMx.restype = c_bool
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.kNMcYVbBqtOtjSNJYSXOnZDwPRlTQtYF.argtypes = [c_ulong, c_ulong, c_ulong]
        LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.kNMcYVbBqtOtjSNJYSXOnZDwPRlTQtYF.restype = c_bool
        if (
            LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM.pe_special_features(
                kQjBaRrlyabpMNWUzuzDYLEDgKASuUOA.aLtPYCwCumWqgSVuBuNjdiENebjumTYm,
                True,
                0,
                0,
                0,
                c_char_p(os.path.dirname(os.path.abspath(file_name).encode("utf-8"))),
                None,
            )
            is False
        ):
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("The special feature command hasn't been accepted")
        kvWQbjptSAirgKWXnEJewTclkPvUWpYT.debug(f"Opened PEMicro library: {file_name}, {dll.version()}.")
        return LhqWSDQXqzwBYSFOHzqOTxjVEiuWugMM
    @staticmethod
    def yoIbfrHKntIDgsawMtGaYVIOCVbaQUNC(lib_record: Dict) -> str:
        return os.path.join(lib_record["path"], lib_record["name"])
    @staticmethod
    def GHNvROmLJvRsvwHjRXoWvdijzxyjwygz(lib_list: List) -> str:
        if lib_list is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("The input list must exists")
        if len(lib_list) == 0:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Unable to find any usable library in the system!")
        sIXEMNRuSZggCTyUZPwDCQXHQGuvMkJX = 0
        for count, WCpvDizSMzzkVqAXGGFGcrFgEAIXLgjb in enumerate(lib_list):
            if WCpvDizSMzzkVqAXGGFGcrFgEAIXLgjb["version_num"] > lib_list[sIXEMNRuSZggCTyUZPwDCQXHQGuvMkJX]["version_num"]:
                sIXEMNRuSZggCTyUZPwDCQXHQGuvMkJX = count
        return BOYsDPxDDbnUVrwsQpNQfRffYBhEROta.yoIbfrHKntIDgsawMtGaYVIOCVbaQUNC(lib_list[sIXEMNRuSZggCTyUZPwDCQXHQGuvMkJX])
    @staticmethod
    def pksPADKDOvMDqYKJUsgvNsFsGPouEVLf(dll_path: str = None, get_newest: bool = True) -> CDLL:
        try:
            rlEAyYvMptGdpMlfvYkflIhQkEeImJUI = BOYsDPxDDbnUVrwsQpNQfRffYBhEROta.vxjOoxHRjTpcQsyBmprWaINEoyjRJvyl(dll_path=dll_path)
            if len(rlEAyYvMptGdpMlfvYkflIhQkEeImJUI) == 0:
                raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("There is any suitable library for this OS.")
            if get_newest:
                znScYkwNeBnoaUIGMHQCGoAmclhECWHt = BOYsDPxDDbnUVrwsQpNQfRffYBhEROta.GHNvROmLJvRsvwHjRXoWvdijzxyjwygz(rlEAyYvMptGdpMlfvYkflIhQkEeImJUI)
            else:
                znScYkwNeBnoaUIGMHQCGoAmclhECWHt = BOYsDPxDDbnUVrwsQpNQfRffYBhEROta.yoIbfrHKntIDgsawMtGaYVIOCVbaQUNC(rlEAyYvMptGdpMlfvYkflIhQkEeImJUI[0])
        except OidRXaqimIQIUhgZcOkPWQMqDMNplHOc as exc:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc(str(exc))
        return BOYsDPxDDbnUVrwsQpNQfRffYBhEROta.QRiWvNxYqzMzDvwTsyqlDLjANXheORgv(znScYkwNeBnoaUIGMHQCGoAmclhECWHt)
    @staticmethod
    def LSijImcpIDgYDOLucDbwilWUoGuGLnoy() -> List:
        try:
            kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS = BOYsDPxDDbnUVrwsQpNQfRffYBhEROta.pksPADKDOvMDqYKJUsgvNsFsGPouEVLf()
        except OidRXaqimIQIUhgZcOkPWQMqDMNplHOc as exc:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc(str(exc))
        NOVUxvgbGpLurLwwWfAshPoUIdEbZuda = kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.get_enumerated_number_of_ports(RCyIfsgmdwhpAsrMuoxcANjIiEoojOnc.SvwwWUqgAKDFOqsNksLzkCNxpYVfxXUS)
        UEsDRWXETtipVedQdeblIUdemUahpqgO = []
        for ZIDUGCMHGsEzZQhwgmOsFpwQAvFVFGeH in range(1, NOVUxvgbGpLurLwwWfAshPoUIdEbZuda + 1):
            UEsDRWXETtipVedQdeblIUdemUahpqgO.append(
                {
                    "id": kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.get_port_descriptor_short(RCyIfsgmdwhpAsrMuoxcANjIiEoojOnc.SvwwWUqgAKDFOqsNksLzkCNxpYVfxXUS, ZIDUGCMHGsEzZQhwgmOsFpwQAvFVFGeH).decode(
                        "utf-8"
                    ),
                    "description": kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.get_port_descriptor(RCyIfsgmdwhpAsrMuoxcANjIiEoojOnc.SvwwWUqgAKDFOqsNksLzkCNxpYVfxXUS, ZIDUGCMHGsEzZQhwgmOsFpwQAvFVFGeH).decode(
                        "utf-8"
                    ),
                }
            )
        del kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS
        return UEsDRWXETtipVedQdeblIUdemUahpqgO
    @staticmethod
    def WrMSwFMiSbYSRNVcMDZxSKdsTynhouyj(UEsDRWXETtipVedQdeblIUdemUahpqgO: List) -> None:
        if UEsDRWXETtipVedQdeblIUdemUahpqgO is None or len(UEsDRWXETtipVedQdeblIUdemUahpqgO) == 0:
            kvWQbjptSAirgKWXnEJewTclkPvUWpYT.info(f"No hardware detected locally.")
        ZIDUGCMHGsEzZQhwgmOsFpwQAvFVFGeH = 0
        for JQJBzfGSkChVexevywgNhKOmsOkdGTVN in UEsDRWXETtipVedQdeblIUdemUahpqgO:
            kvWQbjptSAirgKWXnEJewTclkPvUWpYT.info(f"{i:>2}: {port['id']} => {port['description']}")
            ZIDUGCMHGsEzZQhwgmOsFpwQAvFVFGeH += 1
    @staticmethod
    def vxYHVAqduBbDfoJHUDMebLyMciGaKLNK() -> None:
        try:
            kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS = BOYsDPxDDbnUVrwsQpNQfRffYBhEROta.pksPADKDOvMDqYKJUsgvNsFsGPouEVLf()
        except OidRXaqimIQIUhgZcOkPWQMqDMNplHOc as exc:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc(str(exc))
        NOVUxvgbGpLurLwwWfAshPoUIdEbZuda = kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.get_enumerated_number_of_ports(RCyIfsgmdwhpAsrMuoxcANjIiEoojOnc.SvwwWUqgAKDFOqsNksLzkCNxpYVfxXUS)
        if NOVUxvgbGpLurLwwWfAshPoUIdEbZuda == 0:
            kvWQbjptSAirgKWXnEJewTclkPvUWpYT.info("No hardware detected locally.")
        for ZIDUGCMHGsEzZQhwgmOsFpwQAvFVFGeH in range(1, NOVUxvgbGpLurLwwWfAshPoUIdEbZuda + 1):
            kvWQbjptSAirgKWXnEJewTclkPvUWpYT.info(
                kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.get_port_descriptor_short(RCyIfsgmdwhpAsrMuoxcANjIiEoojOnc.SvwwWUqgAKDFOqsNksLzkCNxpYVfxXUS, ZIDUGCMHGsEzZQhwgmOsFpwQAvFVFGeH).decode("utf-8")
            )
        del kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS
    def __init__(
        self,
        dll_path: str = None,
        log_info: Any = None,
        log_war: Any = None,
        log_err: Any = None,
        log_debug: Any = None,
    ) -> None:
        self._opened = False
        self.dll_path = dll_path
        self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS = None
        self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS = BOYsDPxDDbnUVrwsQpNQfRffYBhEROta.pksPADKDOvMDqYKJUsgvNsFsGPouEVLf(dll_path)
        self.interface = xEYvczdnGEaMAwpBTnbSyvrSKREetHVk.IqROpwEZsNEptdJOwcdbBgMgfFwytyZM
        self.opened_debug_file = False
        self._log_info = log_info or kvWQbjptSAirgKWXnEJewTclkPvUWpYT.info
        self._log_warning = log_war or kvWQbjptSAirgKWXnEJewTclkPvUWpYT.warning
        self._log_error = log_err or kvWQbjptSAirgKWXnEJewTclkPvUWpYT.error
        self._log_debug = log_debug or kvWQbjptSAirgKWXnEJewTclkPvUWpYT.debug
        self.BGqdmJXYsCcvbahcTgPqomiMyEuNfeAl(os.path.dirname(__file__))
    def rHLbSQZIGcXzyLZltPBNSPSWxdtATxDk(
        self,
        featurenum: int,
        XgYxVNEbsZHjuStlNfrXsSLyIetaOfWy: bool = True,
        VOFPFOTAuhGyTCvUklrzniHFkaFdvlMT: int = 0,
        MJyxHLPdexzgedBWIvwclrRlAVpRlZya: int = 0,
        lLdNoztiEzzLUvvUDHSAgLEdaRwVspnf: int = 0,
        gLWaNApetcdXevsIsIjVyYExjAyUoqlz: Any = None,
        zHpqCXSVNkkkRAUTdigndKiJZFCqkOnQ: Any = None,
    ) -> None:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        if not isinstance(featurenum, kQjBaRrlyabpMNWUzuzDYLEDgKASuUOA):
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Invalid argument to do special feature")
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.pe_special_features(featurenum, XgYxVNEbsZHjuStlNfrXsSLyIetaOfWy, VOFPFOTAuhGyTCvUklrzniHFkaFdvlMT, MJyxHLPdexzgedBWIvwclrRlAVpRlZya, lLdNoztiEzzLUvvUDHSAgLEdaRwVspnf, gLWaNApetcdXevsIsIjVyYExjAyUoqlz, zHpqCXSVNkkkRAUTdigndKiJZFCqkOnQ) is False:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("The special feature command hasn't accepted")
    def BGqdmJXYsCcvbahcTgPqomiMyEuNfeAl(self, dir: str) -> None:
        if not isinstance(dir, str) or not os.path.exists(dir):
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Invalid input directory.")
        if (
            self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.pe_special_features(
                kQjBaRrlyabpMNWUzuzDYLEDgKASuUOA.aLtPYCwCumWqgSVuBuNjdiENebjumTYm,
                True,
                0,
                0,
                0,
                c_char_p((dir).encode("utf-8")),
                None,
            )
            is False
        ):
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("The special feature command hasn't accepted")
    def SiRdxnsRedDzdtjzzgkItioEkOHOgTtz(self) -> None:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.SiRdxnsRedDzdtjzzgkItioEkOHOgTtz() is not True:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Re-enumeration of PE interfaces failed.")
    def open(self, debug_hardware_name_ip_or_serialnum: str) -> None:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("The PEMicro library loader failed.")
        if self._opened:
            kvWQbjptSAirgKWXnEJewTclkPvUWpYT.warning("The PEMicro probe is already opened")
            return
        if debug_hardware_name_ip_or_serialnum is None:
            XQJEIwlkanJMuNeOZPWuZedmOjOXIPHb = c_char_p("USB1".encode("utf-8"))
        else:
            XQJEIwlkanJMuNeOZPWuZedmOjOXIPHb = c_char_p(debug_hardware_name_ip_or_serialnum.encode("utf-8"))
        if not self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.open_port_by_identifier(XQJEIwlkanJMuNeOZPWuZedmOjOXIPHb):
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Cannot connect to debug probe")
        self._opened = True
        self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.reset_hardware_interface()
        aNTkfZJFBdvimgzxWWDkQHqrJPZxTMoZ = self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.check_critical_error()
        if aNTkfZJFBdvimgzxWWDkQHqrJPZxTMoZ:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc(
                f"Probe error has been detected during open operation. Error: 0x{probe_error:02X}"
            )
    @property
    def uWXOVaownqkhnjHjnjPrxMIstSJSKZai(self) -> bool:
        return self._opened
    def close(self) -> None:
        if not self._opened:
            return
        self.rHLbSQZIGcXzyLZltPBNSPSWxdtATxDk(kQjBaRrlyabpMNWUzuzDYLEDgKASuUOA.oVmAUfPMrIaILMterGerjluCfpmEhLlf)
        if self.opened_debug_file:
            self.BgLfnUdBUBOWAHtYxLJXpGCsLddSQNPC()
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is not None:
            self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.close_port()
        self._opened = False
    def __del__(self) -> None:
        self.close()
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is not None:
            del self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS
            self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS = None
    def WlmVXkUgzKnPAigGPgVJXPMurHaVgkfQ(self, znScYkwNeBnoaUIGMHQCGoAmclhECWHt: str = "log_pemicro_comm.txt") -> None:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.WlmVXkUgzKnPAigGPgVJXPMurHaVgkfQ(znScYkwNeBnoaUIGMHQCGoAmclhECWHt.encode())
        self.opened_debug_file = True
    def BgLfnUdBUBOWAHtYxLJXpGCsLddSQNPC(self) -> None:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.BgLfnUdBUBOWAHtYxLJXpGCsLddSQNPC()
        self.opened_debug_file = False
    def rNfNRNBbNZPFEKefnlxFPFMUpHATUUTe(self) -> None:
        self._log_debug(f"Power on target")
        self.rHLbSQZIGcXzyLZltPBNSPSWxdtATxDk(kQjBaRrlyabpMNWUzuzDYLEDgKASuUOA.phGoAtYKXoFFcyWAwLPsloulUEqLOVQD)
    def HxTUrJwePrAsHSDFOGsaQoRPoJuUVrPJ(self) -> None:
        self._log_debug(f"Power off target")
        self.rHLbSQZIGcXzyLZltPBNSPSWxdtATxDk(kQjBaRrlyabpMNWUzuzDYLEDgKASuUOA.fIfhcigesZdLJNCVRVpztEvAnvdPrNVF)
    def LhwjdHrpacFTKkmQNhbQIsgQgjjxczLe(self) -> None:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        self._log_debug(f"Reset target")
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.target_reset() is not True:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Reset target sequence failed")
    def lQEtmZXZDSipdvvfWbnkuEQfQMSAUQQQ(self) -> bool:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        return self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.lQEtmZXZDSipdvvfWbnkuEQfQMSAUQQQ()
    def LcwdhMorSsOuGnDnQKilZLLRiZfXpalm(self) -> None:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.LcwdhMorSsOuGnDnQKilZLLRiZfXpalm() is False:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Target step failed")
    def BaIMtXLpxKMdalZxRCueLgXQqWPEzlqh(self) -> None:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        self._log_debug(f"Halt target")
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.target_halt() is not True:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Halt target sequence failed")
    def vSOCBGxfeKxtPobAylnEihoXRlitECoZ(self) -> None:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        self._log_debug(f"Resume target")
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.target_resume() is not True:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Resume target sequence failed")
    def riFgIsgVGirsRJYEFkvstSvQMJGfYCMx(self, reg: HKgbozwagxJKZHeJnYjvLHwjIIPQgHXV) -> int:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        if not isinstance(reg, HKgbozwagxJKZHeJnYjvLHwjIIPQgHXV):
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Invalid register index")
        prgQzoNWHHWnQayfcYZWeWswYIOxHCEr = c_ulong()
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.riFgIsgVGirsRJYEFkvstSvQMJGfYCMx(0, reg, prgQzoNWHHWnQayfcYZWeWswYIOxHCEr) is False:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc(f"Getting of MCU register{str(reg)} fails")
        return prgQzoNWHHWnQayfcYZWeWswYIOxHCEr.wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu
    def kNMcYVbBqtOtjSNJYSXOnZDwPRlTQtYF(self, reg: HKgbozwagxJKZHeJnYjvLHwjIIPQgHXV, wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu: int) -> None:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        if not isinstance(reg, HKgbozwagxJKZHeJnYjvLHwjIIPQgHXV):
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Invalid register index")
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.kNMcYVbBqtOtjSNJYSXOnZDwPRlTQtYF(0, reg, wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu) is False:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc(f"Setting of new MCU register{str(reg)} value{value:X08} fails")
    def uWOLTXurQlBJrrzDtEaYbbDLVKXWmyOc(self, delay: int) -> None:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        self._log_debug(f"Reset target delay has been set to {delay}ms")
        self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.uWOLTXurQlBJrrzDtEaYbbDLVKXWmyOc(delay)
    def FwERowlKjGNIsCcYrAUNnabjNaUSxQeY(self) -> None:
        if not self._opened:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("The connection is not active")
        self._log_debug(f"All queued data has been flushed")
        self.rHLbSQZIGcXzyLZltPBNSPSWxdtATxDk(kQjBaRrlyabpMNWUzuzDYLEDgKASuUOA.oVmAUfPMrIaILMterGerjluCfpmEhLlf)
    def xSYucVHUPMyqxWomsMivIxDtWKomFQMn(self, device_name: str = "Cortex-M4") -> None:
        if self._opened:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("The connection is already opened, can't change the device name")
        self._log_debug(f"The device name is set to {device_name}")
        self.rHLbSQZIGcXzyLZltPBNSPSWxdtATxDk(
            kQjBaRrlyabpMNWUzuzDYLEDgKASuUOA.bDXBwIAZPmZuUpuKQoegZVOCFkYOKbdd,
            gLWaNApetcdXevsIsIjVyYExjAyUoqlz=device_name.encode("utf-8"),
        )
    def StsYpwikRJdUPvZtZKmxhMfyJSpPkdPv(self, search_string: str = None) -> List:
        qhJFRnrPZwOdArkEZRWdejYmmUDHkbFS = 1000000
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        prgQzoNWHHWnQayfcYZWeWswYIOxHCEr = c_char_p(bytes(qhJFRnrPZwOdArkEZRWdejYmmUDHkbFS))
        try:
            self.rHLbSQZIGcXzyLZltPBNSPSWxdtATxDk(
                kQjBaRrlyabpMNWUzuzDYLEDgKASuUOA.fvCHBmnasiopmrcHUEFlKPZXJtBOwvzO,
                VOFPFOTAuhGyTCvUklrzniHFkaFdvlMT=qhJFRnrPZwOdArkEZRWdejYmmUDHkbFS - 1,
                gLWaNApetcdXevsIsIjVyYExjAyUoqlz=prgQzoNWHHWnQayfcYZWeWswYIOxHCEr,
                zHpqCXSVNkkkRAUTdigndKiJZFCqkOnQ=None if search_string is None else search_string.encode("utf-8"),
            )
        except OidRXaqimIQIUhgZcOkPWQMqDMNplHOc as exc:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc(f"It is impossible to retrive PEMicro device list:{str(exc)}.")
        return prgQzoNWHHWnQayfcYZWeWswYIOxHCEr.wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu.decode().split(",")
    def hVtMMPEmcAaqPnhZvPUafJcafokVKhcV(self) -> str:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        hVtMMPEmcAaqPnhZvPUafJcafokVKhcV = self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.hVtMMPEmcAaqPnhZvPUafJcafokVKhcV().decode("utf-8")
        self._log_debug(f"Getting version: {version}")
        return hVtMMPEmcAaqPnhZvPUafJcafokVKhcV
    def JCENMsUvlVzXnNmoDJSRDhmgsunYJEAO(self) -> int:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        hVtMMPEmcAaqPnhZvPUafJcafokVKhcV = self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.get_dll_version()
        self._log_debug(f"Getting DLL version: {version}")
        return hVtMMPEmcAaqPnhZvPUafJcafokVKhcV
    def xhGPOBhHHKLvqXFlYdiQIidHwsckfxJQ(self, interface: xEYvczdnGEaMAwpBTnbSyvrSKREetHVk = xEYvczdnGEaMAwpBTnbSyvrSKREetHVk.IqROpwEZsNEptdJOwcdbBgMgfFwytyZM, shift_speed: int = 1000000) -> None:  
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        if not self._opened:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("The connection is not opened, can't xhGPOBhHHKLvqXFlYdiQIidHwsckfxJQ to target")
        self._log_debug(f"Selecting the communication interface to {str(interface)}")
        self.interface = interface
        if self.interface is xEYvczdnGEaMAwpBTnbSyvrSKREetHVk.IqROpwEZsNEptdJOwcdbBgMgfFwytyZM:
            self.rHLbSQZIGcXzyLZltPBNSPSWxdtATxDk(
                kQjBaRrlyabpMNWUzuzDYLEDgKASuUOA.VgsTVsCcUWKkAgFPvSfiKizljBZyzDMs,
                VOFPFOTAuhGyTCvUklrzniHFkaFdvlMT=kQjBaRrlyabpMNWUzuzDYLEDgKASuUOA.MgcHbIMlOyKVEbWUdiyTDLShOWAodxcm,
            )
        else:
            self.rHLbSQZIGcXzyLZltPBNSPSWxdtATxDk(
                kQjBaRrlyabpMNWUzuzDYLEDgKASuUOA.VgsTVsCcUWKkAgFPvSfiKizljBZyzDMs,
                VOFPFOTAuhGyTCvUklrzniHFkaFdvlMT=kQjBaRrlyabpMNWUzuzDYLEDgKASuUOA.vgWedZoVLFxQqwzApdQSkEXdGvQLurvJ,
            )
        self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.set_debug_shift_frequency(shift_speed)
        try:
            self.rHLbSQZIGcXzyLZltPBNSPSWxdtATxDk(kQjBaRrlyabpMNWUzuzDYLEDgKASuUOA.IikpCMUVWQIjZWAgyUbLXAqkhkGRwQSO)
        except OidRXaqimIQIUhgZcOkPWQMqDMNplHOc as exc:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc(f"Failed to connect to target: {str(exc)}")
        self._log_info(
            f"Connected to target over {PEMicroInterfaces.get_str(interface)} with clock {shift_speed}Hz"
        )
    def zFHjHixQtgGnRzJqLuMdiiKaCvyuykbn(self, freq: int) -> None:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        if not self._opened:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("The communication interface is not opened")
        self._log_debug(f"The communication speed has been switched to {freq}Hz")
        self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.set_debug_shift_frequency(freq)
    def OubxZfsZAHszpbAfpPUcaDAdaBDuNHlh(self, assert_reset: bool = True) -> None:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        self._log_debug(f"{'De-' if not assert_reset else ''}Asserting RESET signal")
        self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.set_reset_pin_state(0 if assert_reset else 1)
    def ZPWbceaIuwAKgaZpYDLSjTzynLuAenza(self, address: int) -> int:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        CWzyvdLPZZaoqxiZoyXUNvGXmvhJAMQD = c_ulong()
        wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu = self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.read_32bit_value(0, address, byref(CWzyvdLPZZaoqxiZoyXUNvGXmvhJAMQD))
        if CWzyvdLPZZaoqxiZoyXUNvGXmvhJAMQD.wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu != LOSNRJxGHWhxYBiEWKhDWoBlMsVTsgWm.KsuwttAiZNRDCwkOmADDZZquGTfmTiOm:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc(f"Read 32bit method failed. Result({mem_result.value})")
        return wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu
    def JbkQdviRAHTVvXQZKySrfDsTGRdWNkcr(self, address: int, data: int) -> None:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        CWzyvdLPZZaoqxiZoyXUNvGXmvhJAMQD = c_ulong()
        wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu = self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.write_32bit_value(0, address, data, byref(CWzyvdLPZZaoqxiZoyXUNvGXmvhJAMQD))
        if CWzyvdLPZZaoqxiZoyXUNvGXmvhJAMQD.wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu != LOSNRJxGHWhxYBiEWKhDWoBlMsVTsgWm.KsuwttAiZNRDCwkOmADDZZquGTfmTiOm:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc(f"Write 32bit method failed. Result({mem_result.value})")
    def TCjEkbLGOcLWhnUBvtMWcGAofMqRjupT(self, address: int) -> int:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        CWzyvdLPZZaoqxiZoyXUNvGXmvhJAMQD = c_ulong()
        wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu = self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.read_16bit_value(0, address, byref(CWzyvdLPZZaoqxiZoyXUNvGXmvhJAMQD))
        if CWzyvdLPZZaoqxiZoyXUNvGXmvhJAMQD.wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu != LOSNRJxGHWhxYBiEWKhDWoBlMsVTsgWm.KsuwttAiZNRDCwkOmADDZZquGTfmTiOm:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc(f"Read 16bit method failed. Result({mem_result.value})")
        return wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu
    def HJuxhstklPMrCfRzemMXrlvNVgwMTsQk(self, address: int, data: int) -> None:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        CWzyvdLPZZaoqxiZoyXUNvGXmvhJAMQD = c_ulong()
        wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu = self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.write_16bit_value(0, address, data, byref(CWzyvdLPZZaoqxiZoyXUNvGXmvhJAMQD))
        if CWzyvdLPZZaoqxiZoyXUNvGXmvhJAMQD.wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu != LOSNRJxGHWhxYBiEWKhDWoBlMsVTsgWm.KsuwttAiZNRDCwkOmADDZZquGTfmTiOm:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc(f"Write 16bit method failed. Result({mem_result.value})")
    def emFBzbqDnevEtOeoRUVIBgWwwponhBgp(self, address: int) -> int:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        CWzyvdLPZZaoqxiZoyXUNvGXmvhJAMQD = c_ulong()
        wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu = self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.read_8bit_value(0, address, byref(CWzyvdLPZZaoqxiZoyXUNvGXmvhJAMQD))
        if CWzyvdLPZZaoqxiZoyXUNvGXmvhJAMQD.wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu != LOSNRJxGHWhxYBiEWKhDWoBlMsVTsgWm.KsuwttAiZNRDCwkOmADDZZquGTfmTiOm:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc(f"Read 8bit method failed. Result({mem_result.value})")
        return wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu
    def uJvFmrtAhNsZcRnPjXoseRvOcGtSkgDB(self, address: int, data: int) -> None:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        CWzyvdLPZZaoqxiZoyXUNvGXmvhJAMQD = c_ulong()
        wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu = self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.write_8bit_value(0, address, data, byref(CWzyvdLPZZaoqxiZoyXUNvGXmvhJAMQD))
        if CWzyvdLPZZaoqxiZoyXUNvGXmvhJAMQD.wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu != LOSNRJxGHWhxYBiEWKhDWoBlMsVTsgWm.KsuwttAiZNRDCwkOmADDZZquGTfmTiOm:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc(f"Write 8bit method failed. Result({mem_result.value})")
    def iwTnZczQZLVUHQUddEaxRBVzFGIYongL(
        self,
        address: int,
        size: int,
        data: bytes,
        access_bit_size: GHljGVOJqZonfxycSoxAWEDQPmYEySDc = GHljGVOJqZonfxycSoxAWEDQPmYEySDc.kjVqLbvZyfEMzsgHsKlapyRCdVtZeOJC,
    ) -> None:  
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        if size == 0:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Zero size is not supported")
        if data is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Data buffer must be provided")
        if not isinstance(access_bit_size, GHljGVOJqZonfxycSoxAWEDQPmYEySDc):
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("The access_bit_size has not proper value")
        gzQzEaOyOTESWtuKkYvdecDHFsfSkHut = c_byte(size)
        if not self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.get_block(0, address, size, access_bit_size, data, gzQzEaOyOTESWtuKkYvdecDHFsfSkHut):
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc(f"Read block method failed.")
        for hPxBwfkiKJZuxXmTfHatehNyFovtlFtW in gzQzEaOyOTESWtuKkYvdecDHFsfSkHut:
            if hPxBwfkiKJZuxXmTfHatehNyFovtlFtW != LOSNRJxGHWhxYBiEWKhDWoBlMsVTsgWm.KsuwttAiZNRDCwkOmADDZZquGTfmTiOm:
                raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc(f"Read block method failed.")
    def fSVBRmlzsEZNWXedPaRyifexByuiCwqC(
        self,
        address: int,
        size: int,
        data: bytes,
        access_bit_size: GHljGVOJqZonfxycSoxAWEDQPmYEySDc = GHljGVOJqZonfxycSoxAWEDQPmYEySDc.kjVqLbvZyfEMzsgHsKlapyRCdVtZeOJC,
    ) -> None:  
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        if size == 0:
            return
        if data is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Data buffer must be provided")
        if not isinstance(access_bit_size, GHljGVOJqZonfxycSoxAWEDQPmYEySDc):
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("The access_bit_size has not proper value")
        gzQzEaOyOTESWtuKkYvdecDHFsfSkHut = c_byte(size)
        if not self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.put_block(0, address, size, access_bit_size, data, gzQzEaOyOTESWtuKkYvdecDHFsfSkHut):
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc(f"Write block method failed.")
        for hPxBwfkiKJZuxXmTfHatehNyFovtlFtW in gzQzEaOyOTESWtuKkYvdecDHFsfSkHut:
            if hPxBwfkiKJZuxXmTfHatehNyFovtlFtW != LOSNRJxGHWhxYBiEWKhDWoBlMsVTsgWm.KsuwttAiZNRDCwkOmADDZZquGTfmTiOm:
                raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc(f"Write block method failed.")
    def etVhzBvzQieOMZdiYtQGePOWZvONukwW(self, znScYkwNeBnoaUIGMHQCGoAmclhECWHt: str, start_address: int = 0) -> None:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        if znScYkwNeBnoaUIGMHQCGoAmclhECWHt is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Filename is not specified")
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.etVhzBvzQieOMZdiYtQGePOWZvONukwW(znScYkwNeBnoaUIGMHQCGoAmclhECWHt.encode(), start_address) is False:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Loading of the binary file failed")
    def EZCGLEIUxKRwEiFVgJbvOfRafsDbQctP(self, znScYkwNeBnoaUIGMHQCGoAmclhECWHt: str, offset: int = 0) -> None:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        if znScYkwNeBnoaUIGMHQCGoAmclhECWHt is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Filename is not specified")
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.EZCGLEIUxKRwEiFVgJbvOfRafsDbQctP(znScYkwNeBnoaUIGMHQCGoAmclhECWHt.encode(), offset) is False:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Loading of the S-record file failed")
    def MeRHcFSaEptzErmsuYZJXNnQsJHczidj(self) -> None:
        if self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS is None:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("Library is not loaded")
        DjqrrrFnjhglDKHXjkefYtIlLhYdCdfl = self.QhoAifRMPiTBUfSsvGndRmqlYSiUuois()
        if DjqrrrFnjhglDKHXjkefYtIlLhYdCdfl is not int(jtMmMlQhEwBhMLaMRqNzoTZCxsGReFjq.PCqvsAApsUIgxkYsglrWoGmMmNHHmaxT):
            if DjqrrrFnjhglDKHXjkefYtIlLhYdCdfl is not int(jtMmMlQhEwBhMLaMRqNzoTZCxsGReFjq.gaFXsEQlFgmoVKOJrFhANWLqRSYPJsrF):
                aNTkfZJFBdvimgzxWWDkQHqrJPZxTMoZ = self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.check_critical_error()
                if aNTkfZJFBdvimgzxWWDkQHqrJPZxTMoZ & 0x08:
                    self.kFCWuWurrwTUfuFfWQxxfYjsdREVPFlS.reset_hardware_interface()
                try:
                    self.LhwjdHrpacFTKkmQNhbQIsgQgjjxczLe()
                except:
                    self._log_debug(
                        "Cannot reset target properly, resume normal state of reset pin."
                    )
                    self.OubxZfsZAHszpbAfpPUcaDAdaBDuNHlh(assert_reset=False)
                self._log_warning(
                    f"SWD Status failed during IO operation. status: 0x{swd_status:02X},"
                    f"the communication has been resumed by reset target sequence."
                )
            raise RsrBrhiCVAqniOILDgirXOMHoVnrbQXy(
                f"SWD Status failed during IO operation. status: 0x{swd_status:02X}"
            )
    def toZCqYAiFundvlWDHyCofEyyCdmtIOFG(self, apselect: int, addr: int, wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu: int, now: bool = False) -> None:
        if not self._opened:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("There is NO opened connection with target")
        self._log_debug(
            f"Writing into AP register: Addr: 0x{addr:08X}, Value:{value}, 0x{value:08X}, now?{now}"
        )
        self.rHLbSQZIGcXzyLZltPBNSPSWxdtATxDk(
            kQjBaRrlyabpMNWUzuzDYLEDgKASuUOA.QpjqOoHbfGnpSoAgtagnUhNgfBixqOFQ,
            XgYxVNEbsZHjuStlNfrXsSLyIetaOfWy=now,
            VOFPFOTAuhGyTCvUklrzniHFkaFdvlMT=apselect,
            MJyxHLPdexzgedBWIvwclrRlAVpRlZya=addr,
            lLdNoztiEzzLUvvUDHSAgLEdaRwVspnf=wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu,
        )
        self.MeRHcFSaEptzErmsuYZJXNnQsJHczidj()
    def beUfHqeSEyTRRALAmmRrtGrrfimyFJoB(
        self, apselect: int, addr: int, now: bool = True, requires_delay: bool = False
    ) -> int:
        if not self._opened:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("There is no opened connection with target")
        prgQzoNWHHWnQayfcYZWeWswYIOxHCEr = c_ulong()
        self.rHLbSQZIGcXzyLZltPBNSPSWxdtATxDk(
            kQjBaRrlyabpMNWUzuzDYLEDgKASuUOA.yQXnXLsbrHQRvXTYhcrmejUoXADNvtUK,
            XgYxVNEbsZHjuStlNfrXsSLyIetaOfWy=True,
            VOFPFOTAuhGyTCvUklrzniHFkaFdvlMT=apselect,
            MJyxHLPdexzgedBWIvwclrRlAVpRlZya=addr,
            gLWaNApetcdXevsIsIjVyYExjAyUoqlz=byref(prgQzoNWHHWnQayfcYZWeWswYIOxHCEr),
        )
        self._log_debug(
            f"Read AP register: Addr: 0x{addr:08X}, Value:{ret_val.value}, 0x{ret_val.value:08X}"
        )
        self.MeRHcFSaEptzErmsuYZJXNnQsJHczidj()
        return prgQzoNWHHWnQayfcYZWeWswYIOxHCEr.wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu
    def myslRCzZTLklFIvNszwrzvIQQcdtQQiG(self, addr: int, wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu: int, now: bool = False) -> None:
        if not self._opened:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("There is no opened connection with target")
        self._log_debug(
            f"Writing into DP register: Addr: 0x{addr:08X}, Value:{value}, 0x{value:08X}, now?:{now}"
        )
        self.rHLbSQZIGcXzyLZltPBNSPSWxdtATxDk(
            kQjBaRrlyabpMNWUzuzDYLEDgKASuUOA.sOZvwRxMRfkhtkrZuoPtEHYboMAEffzK,
            XgYxVNEbsZHjuStlNfrXsSLyIetaOfWy=now,
            VOFPFOTAuhGyTCvUklrzniHFkaFdvlMT=addr,
            MJyxHLPdexzgedBWIvwclrRlAVpRlZya=wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu,
        )
        self.MeRHcFSaEptzErmsuYZJXNnQsJHczidj()
    def mokBsByksFNxxXnttZUhqGMJIQzmEszN(self, addr: int, now: bool = True, requires_delay: bool = False) -> int:
        if not self._opened:
            raise OidRXaqimIQIUhgZcOkPWQMqDMNplHOc("There is no opened connection with target")
        prgQzoNWHHWnQayfcYZWeWswYIOxHCEr = c_ulong()
        self.rHLbSQZIGcXzyLZltPBNSPSWxdtATxDk(
            kQjBaRrlyabpMNWUzuzDYLEDgKASuUOA.sfLtiwJQEOwKavOfYtvSskVEYgfPapVw,
            XgYxVNEbsZHjuStlNfrXsSLyIetaOfWy=True,
            VOFPFOTAuhGyTCvUklrzniHFkaFdvlMT=addr,
            gLWaNApetcdXevsIsIjVyYExjAyUoqlz=byref(prgQzoNWHHWnQayfcYZWeWswYIOxHCEr),
        )
        self._log_debug(
            f"Read DP register: Addr: 0x{addr:08X}, Value:{ret_val.value}, 0x{ret_val.value:08X}"
        )
        self.MeRHcFSaEptzErmsuYZJXNnQsJHczidj()
        return prgQzoNWHHWnQayfcYZWeWswYIOxHCEr.wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu
    def QhoAifRMPiTBUfSsvGndRmqlYSiUuois(self) -> int:
        prgQzoNWHHWnQayfcYZWeWswYIOxHCEr = c_ulong()
        self.rHLbSQZIGcXzyLZltPBNSPSWxdtATxDk(
            kQjBaRrlyabpMNWUzuzDYLEDgKASuUOA.QTctKYGMoksRiVROrkGWTfCrtEiIWywy, gLWaNApetcdXevsIsIjVyYExjAyUoqlz=byref(prgQzoNWHHWnQayfcYZWeWswYIOxHCEr)
        )
        self._log_debug("Got last SWD status:{val}, 0x{val:08X}".format(val=prgQzoNWHHWnQayfcYZWeWswYIOxHCEr.wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu))
        return prgQzoNWHHWnQayfcYZWeWswYIOxHCEr.wKElHERxGzCgmNhcuBbGJVxNDPRgZuzu
