#!/usr/bin/env python
from enum import IntEnum
class RCyIfsgmdwhpAsrMuoxcANjIiEoojOnc(IntEnum):
    SvwwWUqgAKDFOqsNksLzkCNxpYVfxXUS = 99
    nWkHipIKYaihQMikGYLiMlSRcUszkUnt = 1
    tzdwYdjyyoDvWAlWwYIqxYMsFEqGbbuH = 2
    BSQCEtbFESJBHSxenWnrtPBTvnxFhCwT = 3
    xiPRSKVTJOnqqHUlMxgUlGWPCfkGnfsO = 4
    nOKwOccTxpgQvmlCRSXSDKpJqVomSqRt = 5
    hDkDwNrppjSlHuXjdxXsidJauyoxxykY = 6
    aRFWLZxXmwDtILupKorGZAMJslQoIsKh = 9
class kQjBaRrlyabpMNWUzuzDYLEDgKASuUOA(IntEnum):
    ggGJBCVucDaBfaJJVZYoWFSdxdiAJnBY = 0x38000001
    phGoAtYKXoFFcyWAwLPsloulUEqLOVQD = 0x38000011
    fIfhcigesZdLJNCVRVpztEvAnvdPrNVF = 0x38000012
    VgsTVsCcUWKkAgFPvSfiKizljBZyzDMs = 0x44000001
    MgcHbIMlOyKVEbWUdiyTDLShOWAodxcm = 0x00000000
    vgWedZoVLFxQqwzApdQSkEXdGvQLurvJ = 0x00000001
    IikpCMUVWQIjZWAgyUbLXAqkhkGRwQSO = 0x44000002
    QpjqOoHbfGnpSoAgtagnUhNgfBixqOFQ = 0x44000003
    yQXnXLsbrHQRvXTYhcrmejUoXADNvtUK = 0x44000004
    sOZvwRxMRfkhtkrZuoPtEHYboMAEffzK = 0x44000007
    sfLtiwJQEOwKavOfYtvSskVEYgfPapVw = 0x44000008
    oVmAUfPMrIaILMterGerjluCfpmEhLlf = 0x44000005
    QTctKYGMoksRiVROrkGWTfCrtEiIWywy = 0x44000006
    fvCHBmnasiopmrcHUEFlKPZXJtBOwvzO = 0x58004000
    bDXBwIAZPmZuUpuKQoegZVOCFkYOKbdd = 0x58004001
    ooBVMlXrxDsGpodsBYycSKdBTeLjWwHU = 0x58004002
    UALcynPTLtZnVdxElKgERPCELTbWVFvO = 0x58004003
    aLtPYCwCumWqgSVuBuNjdiENebjumTYm = 0x58006000
class jtMmMlQhEwBhMLaMRqNzoTZCxsGReFjq(IntEnum):
    PCqvsAApsUIgxkYsglrWoGmMmNHHmaxT = 0x04
    gaFXsEQlFgmoVKOJrFhANWLqRSYPJsrF = 0x02
    hmIUflYTgQdqyDmhONEwbXQFnMExkQOZ = 0x01
class LOSNRJxGHWhxYBiEWKhDWoBlMsVTsgWm(IntEnum):
    KsuwttAiZNRDCwkOmADDZZquGTfmTiOm = 0
    clcZXlPzVHgOGciMNlIRdDZsFHfdLTrp = 1
    rFJHjyANfgKKCqqciSTbIzXICvoOuNTb = 2
    ZNdPQluINVqGtnIdgcmsvkZRWFKDZPnQ = 3
    icGywWypSbvVqiAgMvLOJscsuiGaEnZp = 4
    cdSRwJRXrGmZoyJvAVYDhlMMistsvyMi = 5
class GHljGVOJqZonfxycSoxAWEDQPmYEySDc(IntEnum):
    rCyPDnyiofYxjVozkrbqESIKtXpisVJB = 1
    mvVhcCMhwtJBYCMAtCcKlZzMwsNgqvZj = 2
    kjVqLbvZyfEMzsgHsKlapyRCdVtZeOJC = 4
class HKgbozwagxJKZHeJnYjvLHwjIIPQgHXV(IntEnum):
    sUnIrJgnUmrEqpZTUEQPSljLMtlOZOhB = 0
    IDvuZvKMCnXJvdcCEFWsQDpgXxuBoOWK = 1
    RViuOplEPOqDHuHJOALEQLBPMbGnWibQ = 2
    XfpMtAiTFbcUCprZNoISiKKrmvuTXctT = 3
    hUAuiDxHlAVRHcmDHrkPQrPezzXPYjeB = 4
    lWLstKEYAhTiZKFhgyOnLbfPJqQjnEFG = 5
    jHCnfJspzKGyzqUyVlexCFKFbnAiNCwH = 6
    MdoSbOGEBcsszDxcnbDFzCdpnjduSuzY = 7
    gFAsCViygFrAhigqewZtAInGqAloehXD = 8
    CXjsWozpyvVIPOMegokyRehIhYlRKhnX = 9
    HWdpHYxWeCjYebEeKTDxkuGNEfvyOJFr = 10
    TGTbSQNzdhLdzvkRooxTOglVtfmjPQFi = 11
    YKiwXVnDDbvhbMspNUfQyAcinmagDciU = 12
    tAWZQxbqgnAptXvEhhGpXAsOkgbZhcIW = 13
    ULZLhKIZRDYBHxqHHXuGiwRsoxpteRHq = 14
    ACWVfyzbjDvDBFZHwfYyxCMlXByIWdof = 15
    aedaWLevgTfVEyvTllbDfsFSkkmKQmFi = tAWZQxbqgnAptXvEhhGpXAsOkgbZhcIW
    fRkuvMvdyHrhKDHWZVFFTOLSLjpEGNav = ULZLhKIZRDYBHxqHHXuGiwRsoxpteRHq
    kSsHMtZqgQPpbEfMwnMwhApeKJNndNvj = ACWVfyzbjDvDBFZHwfYyxCMlXByIWdof
    ZZwilVCcUDetqGuAEpEDoIeEhAFSqvgV = 16
    TkeJDAARkADCYDcztZOCSwmQCRCeefPw = 17  
    vidQlRmqWJdMNzQdHByVXdqjbzIMRyyF = 18  
    lejfeTANrzUvmVGUgJvfzDOYnGUAuXcx = 20
    TlkEtsTxsXOmndYvCvnMBsJGxCVWPmOm = 33
    UQYNNmbbjnMCfLpwRzUFRIGzrItqYYfU = 64
    OqDHTGFzNMbRNndZllVQQSeJdpgMbYNT = 65
    vziNnKPlGzXqfHPzIlLAoYKXyJXwKfGS = 66
    QiwTCbaNpHGGiBoVcOlpyEQUbDEWpdzm = 67
    TcMsdiTDDVUuNxrKbugppkDXZJndVnFv = 68
    CrMpBxFwLcUcNCZTABSwldkjjqxhgOUW = 69
    wJrPahfUbEawkyKREoSvRZBYsmjFRdfU = 70
    nzyormvlajqZNfZUmvAiFgXKlVAdLFXA = 71
    gyMKXwxmWuLzbSCrahlwQmdmhdKgjojH = 72
    TKrVfshPoVNexlEwPipEwXAIirhCcabP = 73
    dONvDxYfUpsqEOXCDaZBaeOJnlpnnuzr = 74
    DHGoXXMWxHdtfrceNTIPmWrtcSBgopNW = 75
    lGxKTrjRGbNvqDOELZWTeVZQWiLEsQpZ = 76
    jYWEGsUgcvXYbSradWXKRUENJasxzSHz = 77
    GRILupbFFChHtrerDkMxFhBYTRKIBqRG = 78
    mTHLlfuAVUmcPuMYFukhpzEghniBpdEi = 79
    eZvqsjhZGretgeXsHwrCtLuuFgUDYQWI = 80
    AwYOiglyJsPhNSrFGakdZbqkGaABHcgv = 81
    HJzCmjkTAFNILnkIVyghxttKIsvMIcGW = 82
    vyWMpiBHvTmUDqTRZdbinOSzTGOyDQnu = 83
    RubihceuOaopdlBoWBPoJOAZrBguvijH = 84
    KeogBkdJxvFshaHaMsQIBmXVcJDeebQj = 85
    VoCjZhEmdVRQyTsOaxkOUNksKVnqdBEk = 86
    EArSQplQksHJZSSgujrxVkPGioEMvTtj = 87
    jBfAGNdqDmwqNFcbSVOBeslhxYwBqKQS = 88
    SDpOFGbMYIfEfKCaLsqyvvbodXcOFaXa = 89
    MUzDIJLBIJyQCUjKAopEjWLyefekNBrq = 90
    jrUBRYSHzIkxiHcrofrPJzcJGxXQXZKn = 91
    mViVxycbXLIivLfUwoDBMgvmLffIpAuC = 92
    iiyGaZqeYRFHkIQLWKaFVffsMJRXgCcn = 93
    lndSxqGJhSvUnngwesUeTokjCewJlBTC = 94
    baLzBrdePZvfGqgemZmRDoJNgwUKJiGV = 95
    VENjFCgxZgCwxcVpXIgZqrRpIhGpBXqd = 1000
class xEYvczdnGEaMAwpBTnbSyvrSKREetHVk(IntEnum):
    decOMpdRNbJWAharxozMYUSAScbeOIJM = 0
    IqROpwEZsNEptdJOwcdbBgMgfFwytyZM = 1
    @classmethod
    def BndwtcaAWgSrHTnfzTYvtuVlIDNdTgwn(cls, interface: "PEMicroInterfaces") -> str:
        if not isinstance(interface, cls):
            return "Not selected"
        else:
            return "SWD" if interface is cls.IqROpwEZsNEptdJOwcdbBgMgfFwytyZM else "JTAG"
