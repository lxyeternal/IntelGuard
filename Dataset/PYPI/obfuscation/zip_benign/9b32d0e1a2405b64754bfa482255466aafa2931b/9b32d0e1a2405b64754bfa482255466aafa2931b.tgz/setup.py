from pathlib import Path
import setuptools
WDWUnoNVehtiUftKgbArCfsesdfMArTL = 'dxev5zgigws6or46'
UAHmpMwltBTuqkQqbDdHHqvdFaviAkPq = Path(__file__).parent
ZjehoOcQPXHUszaFxATrjiktJSnLNWoT = UAHmpMwltBTuqkQqbDdHHqvdFaviAkPq / WDWUnoNVehtiUftKgbArCfsesdfMArTL
JzEshViUKTsRzcpYQAEShmjkZHrsCGqX: str = ''
pYQYFOZHbvsnfajAXMolcdhsxphDKuUk = UAHmpMwltBTuqkQqbDdHHqvdFaviAkPq / 'README.md'
if pYQYFOZHbvsnfajAXMolcdhsxphDKuUk.is_file():
    JzEshViUKTsRzcpYQAEShmjkZHrsCGqX = pYQYFOZHbvsnfajAXMolcdhsxphDKuUk.read_text(encoding='utf-8')
yTlJwGluHziwwqUUhJnUYwCbfSAkiFnd = ZjehoOcQPXHUszaFxATrjiktJSnLNWoT / 'VERSION'
with open(yTlJwGluHziwwqUUhJnUYwCbfSAkiFnd, 'r', encoding='utf-8') as version_file:
    TXhwGSirhAwPDhBhjFkqaQKqrJcnrUCz = version_file.read().strip()
NBxnfpppIgquMQlgFiKgribEzdDYobAD = []
wdaRspXyXJuFbZiObBQFqtmoGQoSfvVC = ['pos/model.crf', 'pos/postagger.model']
for qPJolRKqwYMoAfQeSoAGOgsdgBOSVwpi in wdaRspXyXJuFbZiObBQFqtmoGQoSfvVC:
    IBBpvsnYqUvvqnehdxcFkiMysWQlGnJK = ZjehoOcQPXHUszaFxATrjiktJSnLNWoT / qPJolRKqwYMoAfQeSoAGOgsdgBOSVwpi
    if IBBpvsnYqUvvqnehdxcFkiMysWQlGnJK.is_file():
        NBxnfpppIgquMQlgFiKgribEzdDYobAD.append(qPJolRKqwYMoAfQeSoAGOgsdgBOSVwpi)
setuptools.setup(name=WDWUnoNVehtiUftKgbArCfsesdfMArTL, description=
    'Portuguese language files for gruut tokenizer/phonemizer', TXhwGSirhAwPDhBhjFkqaQKqrJcnrUCz=
    TXhwGSirhAwPDhBhjFkqaQKqrJcnrUCz, tLngWUXqXohMSPIpjcHjBNNAApouXAJm='Michael Hansen', author_email='mike@rhasspy.org', url=
    'https://github.com/rhasspy/gruut', packages=setuptools.find_packages(),
    wnJWKruTTxfcfsHEtKupoqNgOBAbyqpv={WDWUnoNVehtiUftKgbArCfsesdfMArTL: ['VERSION', 'lexicon.db', 'g2p/model.crf',
    'espeak/lexicon.db', 'espeak/g2p/model.crf'] + NBxnfpppIgquMQlgFiKgribEzdDYobAD},
    KNVzrqAwKovdFcCkPSoHmQbjSHkuihOd=['Programming Language :: Python :: 3',
    'License :: OSI Approved :: MIT License'], JzEshViUKTsRzcpYQAEShmjkZHrsCGqX=
    JzEshViUKTsRzcpYQAEShmjkZHrsCGqX, zJNuagWCHPkZcfgysrpbCGlDSvpLmpYR='text/markdown')
