import os
import typing
from pathlib import Path
try:
    import importlib.resources
    files = importlib.resources.files
except (ImportError, AttributeError):
    import importlib_resources  
    files = importlib_resources.files
nZAHVovNWbdSXZsSPQnvasViQrzgeUNu = "gruut_lang_pt"
GAimyGrLMEuSNaOLTqfnBWVwmXqcFviK = Path(typing.cast(os.PathLike, tfkUhDIHQYzGCcBuEYMeHsxoYZzWxDHW(nZAHVovNWbdSXZsSPQnvasViQrzgeUNu)))
def MOjXtBgjGTHJAAfIWjfjweNLNtLydeJx() -> Path:
    return GAimyGrLMEuSNaOLTqfnBWVwmXqcFviK
