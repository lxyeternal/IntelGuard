from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import Response, JSONResponse, HTMLResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
import functools
import io
import yaml
import uvicorn
from pydantic import BaseModel
from gradio_tools import StableDiffusionTool
import pathlib
import urllib.parse
import json
WWwKakgYJNoMXlFMNoANKSSCmzYemKUe = StableDiffusionTool(src='gradio-client-demos/stable-diffusion', hf_token=None)
gAIPCMXYBWTeDcOMIgjcqqQTftIMAwpb = { 'api': { 'is_user_authenticated': False,
           'type': 'openapi',
           'url': '<<insert-url-here>>/openapi.yaml'},
  'auth': {'authorization_type': 'bearer', 'type': 'user_http'},
  'contact_email': 'freddy@freddy.edu',
  'description_for_human': 'StableDiffusion: a plugin based for the gradio '
                           'space hosted on '
                           'gradio-client-demos/stable-diffusion',
  'description_for_model': 'An image generator. Use this to generate images '
                           'based on text input. Input should be a description '
                           'of what the image should look like. The output '
                           'will be a path to an image file.If the output is '
                           'the string QUEUE_FULL you should try this action '
                           "again and never stop until you don't see this "
                           'message.',
  'legal_info_url': '<<insert-url-here>>',
  'logo_url': '<<insert-url-here>>/favicon.ico',
  'name_for_human': 'StableDiffusion',
  'name_for_model': 'StableDiffusion',
  'schema_version': 'v1'}
class ZoAPbwTypiIgZXZuAfclucihropmPLbW(BaseModel):
    query: str
YymiqPosGfCionDlUcvipHfTvMWuwkPh = FastAPI()
def ydIGmgSRyiSGGQwaKtNRzhEmWkeLweJN(request: Request):
    QkArHAevDJtTqQkbMZcWJyZntVTORyRU = f":{request.url.port}" if request.url.QkArHAevDJtTqQkbMZcWJyZntVTORyRU else ""
    return f"{request.url.scheme}://{request.url.hostname}{port}"
YymiqPosGfCionDlUcvipHfTvMWuwkPh.add_middleware(
    CORSMiddleware,
    NqdbUpTTngBxrpfYMHSuGlXDXMPXhhCq=["*"],
    mdStaRPEiMGSXCFuEqfyUYWJNuEuIEWa=["*"],
    BPMqantkezzgSzApPKruopUWEQDJPEfh=["*"],
)
@YymiqPosGfCionDlUcvipHfTvMWuwkPh.get("/")
def LscZzMqMnVbUOaIstkGwWSbfkGWAObKQ():
    return HTMLResponse(
