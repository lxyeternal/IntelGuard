===========================
NEWS for lazr.restfulclient
===========================

0.14.6 (2024-01-03)
===================

  - Add ``Read the Docs`` configuration
  - Add Python 3.12 compatibility

0.14.5 (2022-10-15)
===================

  - Add ``pre-commit`` configuration.
  - Publish documentation on Read the Docs.
  - Apply black code formatter.
  - Apply inclusive naming via the woke pre-commit hook.
  - Fix ``HostedFile.open(mode="w")`` on Python 3.

0.14.4 (2021-09-13)
===================

  - Drop support for Python < 2.6.
  - Adjust versioning strategy to avoid importing pkg_resources, which is
    slow in large environments.

0.14.3 (2020-01-27)
===================

  - Restore from_string, to_string, and __str__ methods of
    lazr.restfulclient.authorize.oauth.AccessToken, unintentionally removed
    in 0.14.0.

0.14.2 (2018-11-17)
===================

  - Fix compatibility with httplib2 0.12.0 for Python 3.  [bug=1803754]
  - Really fix compatibility with httplib2 < 0.9.
  - Fix compatibility with httplib2 0.9 for Python 3.
  - Require httplib2 >= 0.7.7 for Python 3.

0.14.1 (2018-11-16)
===================

  - Add compatibility with httplib2 0.12.0.  [bug=1803558]

0.14.0 (2018-05-08)
===================

  - Switch from buildout to tox.
  - Port from oauth to oauthlib.  Some tests still need to use oauth until
    lazr.authentication is ported.  [bug=1672458]
  - Use the distro module rather than platform.linux_distribution, since the
    latter is deprecated in Python 3.5 and will be removed in 3.7.
    [bug=1473577]

0.13.5 (2017-09-04)
===================

  - Fix bytes vs. unicode in json.loads calls.  [bug=1403524]
  - Decode header before comparison.  [bug=1414075]
  - Fix urllib unquote imports.  [bug=1414055]
  - Fix urllib urlencode imports.  [bug=1425609]
  - Tolerate httplib2 versions earlier than 0.9 again.
  - Fix handling of 304 responses with an empty body on Python 3.
    [bug=1714960]

0.13.4 (2014-12-05)
===================

  - Port to python3.
  - Support proxy settings from environment by default.

0.13.3 (2013-03-22)
===================

  - Fall back to httplib2's default certificate path if the
    Debian/Ubuntu one doesn't exist. The default bundle might work,
    but a path that doesn't exist is never going to. New httplib2
    bundles contain the required CA certs.

0.13.2 (2012-12-06)
===================

  - lazr.restfulclient is almost exclusively used with launchpad.net,
    but httplib2's cert bundle doesn't include launchpad's CA. Therefore
    with the default setup launchpadlib doesn't work unless cert checking
    is disabled. This is mitigated by the fact that Ubuntu carries a patch
    to httplib2 to make it use the system CA certs. This release makes that
    the default approach in lazr.restfulclient so that launchpad.net can be
    used by anyone with the Debian/Ubuntu CA certs path
    (/etc/ssl/certs/ca-certificates.crt), regardless of whether they are
    using Ubuntu's patched version of httplib2. Any platforms that don't have
    that path remain broken.

0.13.1 (2012-09-26)
===================

  - Named POST operations may result in a resource moving to a new location.
    Detect the redirect and reload the resource from its new URL.

0.13.0 (2012-06-19)
===================

  - Add environment variable, LP_DISABLE_SSL_CERTIFICATE_VALIDATION, to
    disable SSL certificate checks.  Most useful when testing against
    development servers.

0.12.3 (2012-05-17)
===================

  - Implement the mocked out authorizeRequest for the BasicHttpAuthorizer
    object.

0.12.2 (2012-04-16)
===================

  - Fix ServiceRoot.load() so that it properly handles relative URLs
    in a way that doesn't break subsequent API calls (bug 681767).

0.12.1 (2012-03-28)
===================

  - Made the cache safe for use by concurrent threads and processes.

0.12.0 (2011-06-30)
===================

  - Give a more useful AttributeError

0.11.2 (2011-02-03)
===================

 - The 'web_link' parameter now shows up in lp_attributes, not
   lp_entries.

0.11.1 (2010-11-04)
===================

 - Restored compatibility with Python 2.4.

0.11.0 (2010-10-28)
===================

 - Make it possibly to specify an "application name" separate from the
   OAuth consumer key. If present, the application name is used in the
   User-Agent header; otherwise, the OAuth consumer key is used.

 - Add a "system-wide consumer" which can be used to authorize a
   user's entire account to use a web service, rather than doing it
   one application at a time.

0.10.0 (2010-08-12)
===================

 - Add compatibility with lazr.restful 0.11.0

0.9.21 (2010-07-19)
===================

 - Ensure that all JSON representations are converted to Unicode.

 - Restore the old behavior of CollectionWithKeyBasedLookup, which is
   less efficient but easier to understand. That is, the following
   code will work as it did in 0.9.17, performing the lookup
   immediately and raising a KeyError if the object doesn't exist on
   the server side.

    service.collection['key']

   The more efficient behavior (which doesn't perform the lookup until
   you actually need the object) is still available, but you have to
   write this code instead:

    service.collection('key')

 - Exceptional conditions will now raise an appropriate subclass of
   HTTPError instead of always raising HTTPError.

 - Credential files are now created as being user-readable only. (In
   launchpadlib, they were created using the default umask and then
   made user-readable with chmod.)

0.9.20 (2010-06-25)
===================

 - It's now possible to pass a relative URL (relative to the versioned
   service root) into load().

0.9.19 (2010-06-21)
===================

 - When the representation of a resource, as retrieved from the
   server, is of a different type than expected, the server value now
   takes precedence. This means that, in rare situations, a resource
   may start out presumed to be of one type, and change its
   capabilities once its representation is fetched from the server.

0.9.18 (2010-06-16)
===================

 - Made it possible to avoid fetching a representation of every single
   object looked up from a CollectionWithKeyBasedLookup (by defining
   .collection_of on the class), potentially improving script
   performance.

0.9.17 (2010-05-10)
===================

 - Switched back to asking for compression using the standard
   Accept-Encoding header. Using the TE header has never worked in a
   real situation due to HTTP intermediaries.

0.9.16 (2010-05-03)
===================

 - If a server returns a 502 or 503 error code, lazr.restfulclient
   will retry its request a configurable number of times in hopes that
   the error is transient.

 - It's now possible to invoke lazr.restful destructor methods, with
   the lp_delete() method.

0.9.15 (2010-04-27)
====================

 - Clients will no longer fetch a representation of a collection
   before invoking a named operation on the collection.

0.9.14 (2010-04-15)
===================

 - Clients now send a useful and somewhat customizable User-Agent
   string.

 - Added a workaround for a bug in httplib2.

 - Removed the software dependency on lazr.restful except when running
   the full test suite. (The standalone_test test suite tests basic
   functionality of lazr.restfulclient to make sure the code base
   doesn't fundamentally depend on lazr.restful.)

0.9.13 (2010-03-24)
===================

- Removed some no-longer-needed compatibility code for buggy
  servers, and fixed the tests to work with the new release of simplejson.

- The fix in 0.9.11 to avoid errors on eCryptfs filesystems wasn't
  strict enough. The maximum filename length is now 143 characters.

0.9.12 (2010-03-09)
===================

- Fixed a bug that prevented a unicode string from being used as a
  cache filename.

0.9.11 (2010-02-11)
===================

- If a lazr.restful web service publishes multiple versions, you can
  now specify which version to use in a separate constructor argument,
  rather than sticking it on to the end of the service root.
- Filenames in the cache will never be longer than 150 characters,
  to avoid errors on eCryptfs filesystems.
- Added a proof-of-concept test for OAuth-signed anonymous access.
- Fixed comparisons of entries and hosted files with None.

0.9.10 (2009-10-23)
===================

- lazr.restfulclient now requests the correct WADL media type.
- Made HTTPError strings more verbose.
- Implemented the equality operator for entry and hosted-file resources.
- Resume setting the 'credentials' attribute on ServerRoot to avoid
  breaking compatibility with launchpadlib.

0.9.9 (2009-10-07)
==================

- The WSGI authentication middleware has been moved from lazr.restful
  to the new lazr.authentication library, and lazr.restfulclient now
  uses the new library.

0.9.8 (2009-10-06)
==================

- Added support for OAuth.

0.9.7 (2009-09-30)
==================

- Added support for HTTP Basic Auth.

0.9.6 (2009-09-16)
==================

- Made compatible with lazr.restful 0.9.6.

0.9.5 (2009-08-28)
==================

- Removed debugging code.

0.9.4 (2009-08-26)
==================

- Removed unnecessary build dependencies.

- Updated tests for newer version of simplejson.

- Made tests less fragile by cleaning up lazr.restful example filemanager
  between tests.

- normalized output of simplejson to unicode.

0.9.3 (2009-08-05)
==================

Removed a sys.path hack from setup.py.

0.9.2 (2009-07-16)
==================

- Fields that can contain binary data are no longer run through
  simplejson.dumps().

- For fields that can take on a limited set of values, you can now get
  a list of possible values.

0.9.1 (2009-07-13)
==================

- The client now knows to look for multipart/form-data representations
  and will create them as appropriate. The upshot of this is that you
  can now send binary data when invoking named operations that will
  accept binary data.


0.9 (2009-04-29)
================

- Initial public release
