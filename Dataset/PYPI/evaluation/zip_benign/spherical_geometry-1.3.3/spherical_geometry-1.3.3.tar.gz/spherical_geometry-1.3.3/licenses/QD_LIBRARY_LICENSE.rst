This work was supported by the Director, Office of Science, Division
of Mathematical, Information, and Computational Sciences of the
U.S. Department of Energy under contract numbers DE-AC03-76SF00098 and
DE-AC02-05CH11231.

Copyright (c) 2003-2009, The Regents of the University of California,
through Lawrence Berkeley National Laboratory (subject to receipt of
any required approvals from U.S. Dept. of Energy) All rights reserved.

By downloading or using this software you are agreeing to the modified
BSD license that is in file "BSD-LBNL-License.doc" in the main ARPREC
directory. If you wish to use the software for commercial purposes
please contact the Technology Transfer Department at TTD@lbl.gov or
call 510-286-6457."


1. Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

(1) Redistributions of source code must retain the copyright notice,
    this list of conditions and the following disclaimer.

(2) Redistributions in binary form must reproduce the copyright
    notice, this list of conditions and the following disclaimer in
    the documentation and/or other materials provided with the
    distribution.

(3) Neither the name of the University of California, Lawrence
    Berkeley National Laboratory, U.S. Dept. of Energy nor the names
    of its contributors may be used to endorse or promote products
    derived from this software without specific prior written
    permission.

2. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
   FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
   COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
   INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
   (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
   SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
   HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
   STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
   ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
   OF THE POSSIBILITY OF SUCH DAMAGE.

3. You are under no obligation whatsoever to provide any bug fixes,
   patches, or upgrades to the features, functionality or performance
   of the source code ("Enhancements") to anyone; however, if you
   choose to make your Enhancements available either publicly, or
   directly to Lawrence Berkeley National Laboratory, without imposing
   a separate written license agreement for such Enhancements, then
   you hereby grant the following license: a non-exclusive,
   royalty-free perpetual license to install, use, modify, prepare
   derivative works, incorporate into other computer software,
   distribute, and sublicense such enhancements or derivative works
   thereof, in binary and source code form.
