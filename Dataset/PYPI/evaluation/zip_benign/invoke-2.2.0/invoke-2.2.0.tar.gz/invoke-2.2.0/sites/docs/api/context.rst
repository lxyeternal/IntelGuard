===========
``context``
===========

.. automodule:: invoke.context
