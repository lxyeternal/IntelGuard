/*
  This file contains docstrings for use in the Python bindings.
  Do not edit! They were automatically extracted by pybind11_mkdoc.
 */

#define __EXPAND(x)                                      x
#define __COUNT(_1, _2, _3, _4, _5, _6, _7, COUNT, ...)  COUNT
#define __VA_SIZE(...)                                   __EXPAND(__COUNT(__VA_ARGS__, 7, 6, 5, 4, 3, 2, 1))
#define __CAT1(a, b)                                     a ## b
#define __CAT2(a, b)                                     __CAT1(a, b)
#define __DOC1(n1)                                       __doc_##n1
#define __DOC2(n1, n2)                                   __doc_##n1##_##n2
#define __DOC3(n1, n2, n3)                               __doc_##n1##_##n2##_##n3
#define __DOC4(n1, n2, n3, n4)                           __doc_##n1##_##n2##_##n3##_##n4
#define __DOC5(n1, n2, n3, n4, n5)                       __doc_##n1##_##n2##_##n3##_##n4##_##n5
#define __DOC6(n1, n2, n3, n4, n5, n6)                   __doc_##n1##_##n2##_##n3##_##n4##_##n5##_##n6
#define __DOC7(n1, n2, n3, n4, n5, n6, n7)               __doc_##n1##_##n2##_##n3##_##n4##_##n5##_##n6##_##n7
#define DOC(...)                                         __EXPAND(__EXPAND(__CAT2(__DOC, __VA_SIZE(__VA_ARGS__)))(__VA_ARGS__))

#if defined(__GNUG__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-variable"
#endif


static const char *__doc_low_index_SimsNode =
R"doc(A non-abstract SimsNode.

It has value semantics (except that operator= has not been implemented
yet since it was needed yet). It can be created with "SimsNode
myNode(...);" or "new SimsNode(...)" and can be copied or moved and
thus be used in an STL container or from python.

Creation of a SimsNode requires a heap allocation and is thus slower
than StackedSimsNode.)doc";

static const char *__doc_low_index_SimsNode_SimsNode =
R"doc(Create SimsNode for a covering graph that can have up to max_degree
vertices with edges labeled by rank many letters. num_relators is the
number of "short relators" that can be checked relator_may_lift.)doc";

static const char *__doc_low_index_SimsNode_SimsNode_2 = R"doc(Copy a different subclass of SimsNode.)doc";

static const char *__doc_low_index_SimsNode_SimsNode_3 = R"doc(Copy a SimsNode.)doc";

static const char *__doc_low_index_SimsNode_SimsNode_4 =
R"doc(Move this SimsNode. Calling methods on the SimsNode we copied from
will be unsafe.)doc";

static const char *__doc_low_index_SimsNode_allocate_memory = R"doc()doc";

static const char *__doc_low_index_SimsNode_memory = R"doc()doc";

#if defined(__GNUG__)
#pragma GCC diagnostic pop
#endif

