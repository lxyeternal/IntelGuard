from typing import Any, Dict, List, Type, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="AuthenticationResponse")


@_attrs_define
class AuthenticationResponse:
    """
    Attributes:
        auth_token (str):
    """

    auth_token: str
    additional_properties: Dict[str, Any] = _attrs_field(
        init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        auth_token = self.auth_token

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "authToken": auth_token,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        auth_token = d.pop("authToken")

        authentication_response = cls(
            auth_token=auth_token,
        )

        authentication_response.additional_properties = d
        return authentication_response

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
