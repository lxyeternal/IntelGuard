::: evalica.elo
::: evalica.EloResult
