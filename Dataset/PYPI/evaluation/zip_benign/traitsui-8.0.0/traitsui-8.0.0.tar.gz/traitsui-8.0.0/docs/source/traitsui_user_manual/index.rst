.. TraitsUI documentation master file, created by sphinx-quickstart on Mon Aug 18 11:27:34 2008.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

===============================
TraitsUI |version| User Manual
===============================

:Authors: Lyn Pierce, Janet Swisher, and Enthought Developers
:Version: Document Version 4
:Copyright: 2005-2023 Enthought, Inc. All Rights Reserved.

Contents
========

.. toctree::
   :maxdepth: 3

   intro.rst
   view.rst
   custom_view.rst
   advanced_view.rst
   handler.rst
   factory_intro.rst
   factories_basic.rst
   factories_advanced_extra.rst
   adapters.rst
   testing.rst
   tips.rst
   glossary.rst
   predefined_traits.rst


License
=======

Redistribution and use of this document in source and derived forms, with or
without modification, are permitted provided that the following conditions are
met:

* Redistributions of source or derived format (for example, Portable Document
  Format or Hypertext Markup Language) must retain the above copyright notice,
  this list of conditions and the following disclaimer.

* Neither the name of Enthought, Inc., nor the names of contributors may be used
  to endorse or promote products derived from this document without specific
  prior written permission.

THIS DOCUMENT IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS DOCUMENT, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

All trademarks and registered trademarks are the property of their respective
owners.

| Enthought, Inc.
| 200 W Cesar Chavez, Suite 202
| Austin, TX 78701
| United States
| 1.512.536.1057 (voice)
| http://www.enthought.com
| info@enthought.com
