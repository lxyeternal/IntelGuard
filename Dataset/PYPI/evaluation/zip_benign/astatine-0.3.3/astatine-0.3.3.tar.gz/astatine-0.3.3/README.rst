#########
astatine
#########

.. start short_desc

**Some handy helper functions for Python's AST module.**

.. end short_desc


`Astatine <https://en.wikipedia.org/wiki/Astatine>`_ is a chemical element with the symbol At and atomic number 85.
Its name comes from the Greek astatos (ἄστατος), meaning "unstable".
It's a fitting name for Python's ``ast`` module, which has been unstable between releases.


.. start shields

.. list-table::
	:stub-columns: 1
	:widths: 10 90

	* - Docs
	  - |docs| |docs_check|
	* - Tests
	  - |actions_linux| |actions_windows| |actions_macos| |coveralls|
	* - PyPI
	  - |pypi-version| |supported-versions| |supported-implementations| |wheel|
	* - Anaconda
	  - |conda-version| |conda-platform|
	* - Activity
	  - |commits-latest| |commits-since| |maintained| |pypi-downloads|
	* - QA
	  - |codefactor| |actions_flake8| |actions_mypy|
	* - Other
	  - |license| |language| |requires|

.. |docs| image:: https://img.shields.io/readthedocs/astatine/latest?logo=read-the-docs
	:target: https://astatine.readthedocs.io/en/latest
	:alt: Documentation Build Status

.. |docs_check| image:: https://github.com/python-formate/astatine/workflows/Docs%20Check/badge.svg
	:target: https://github.com/python-formate/astatine/actions?query=workflow%3A%22Docs+Check%22
	:alt: Docs Check Status

.. |actions_linux| image:: https://github.com/python-formate/astatine/workflows/Linux/badge.svg
	:target: https://github.com/python-formate/astatine/actions?query=workflow%3A%22Linux%22
	:alt: Linux Test Status

.. |actions_windows| image:: https://github.com/python-formate/astatine/workflows/Windows/badge.svg
	:target: https://github.com/python-formate/astatine/actions?query=workflow%3A%22Windows%22
	:alt: Windows Test Status

.. |actions_macos| image:: https://github.com/python-formate/astatine/workflows/macOS/badge.svg
	:target: https://github.com/python-formate/astatine/actions?query=workflow%3A%22macOS%22
	:alt: macOS Test Status

.. |actions_flake8| image:: https://github.com/python-formate/astatine/workflows/Flake8/badge.svg
	:target: https://github.com/python-formate/astatine/actions?query=workflow%3A%22Flake8%22
	:alt: Flake8 Status

.. |actions_mypy| image:: https://github.com/python-formate/astatine/workflows/mypy/badge.svg
	:target: https://github.com/python-formate/astatine/actions?query=workflow%3A%22mypy%22
	:alt: mypy status

.. |requires| image:: https://dependency-dash.repo-helper.uk/github/python-formate/astatine/badge.svg
	:target: https://dependency-dash.repo-helper.uk/github/python-formate/astatine/
	:alt: Requirements Status

.. |coveralls| image:: https://img.shields.io/coveralls/github/python-formate/astatine/master?logo=coveralls
	:target: https://coveralls.io/github/python-formate/astatine?branch=master
	:alt: Coverage

.. |codefactor| image:: https://img.shields.io/codefactor/grade/github/python-formate/astatine?logo=codefactor
	:target: https://www.codefactor.io/repository/github/python-formate/astatine
	:alt: CodeFactor Grade

.. |pypi-version| image:: https://img.shields.io/pypi/v/astatine
	:target: https://pypi.org/project/astatine/
	:alt: PyPI - Package Version

.. |supported-versions| image:: https://img.shields.io/pypi/pyversions/astatine?logo=python&logoColor=white
	:target: https://pypi.org/project/astatine/
	:alt: PyPI - Supported Python Versions

.. |supported-implementations| image:: https://img.shields.io/pypi/implementation/astatine
	:target: https://pypi.org/project/astatine/
	:alt: PyPI - Supported Implementations

.. |wheel| image:: https://img.shields.io/pypi/wheel/astatine
	:target: https://pypi.org/project/astatine/
	:alt: PyPI - Wheel

.. |conda-version| image:: https://img.shields.io/conda/v/domdfcoding/astatine?logo=anaconda
	:target: https://anaconda.org/domdfcoding/astatine
	:alt: Conda - Package Version

.. |conda-platform| image:: https://img.shields.io/conda/pn/domdfcoding/astatine?label=conda%7Cplatform
	:target: https://anaconda.org/domdfcoding/astatine
	:alt: Conda - Platform

.. |license| image:: https://img.shields.io/github/license/python-formate/astatine
	:target: https://github.com/python-formate/astatine/blob/master/LICENSE
	:alt: License

.. |language| image:: https://img.shields.io/github/languages/top/python-formate/astatine
	:alt: GitHub top language

.. |commits-since| image:: https://img.shields.io/github/commits-since/python-formate/astatine/v0.3.3
	:target: https://github.com/python-formate/astatine/pulse
	:alt: GitHub commits since tagged version

.. |commits-latest| image:: https://img.shields.io/github/last-commit/python-formate/astatine
	:target: https://github.com/python-formate/astatine/commit/master
	:alt: GitHub last commit

.. |maintained| image:: https://img.shields.io/maintenance/yes/2023
	:alt: Maintenance

.. |pypi-downloads| image:: https://img.shields.io/pypi/dm/astatine
	:target: https://pypi.org/project/astatine/
	:alt: PyPI - Downloads

.. end shields

Installation
--------------

.. start installation

``astatine`` can be installed from PyPI or Anaconda.

To install with ``pip``:

.. code-block:: bash

	$ python -m pip install astatine

To install with ``conda``:

	* First add the required channels

	.. code-block:: bash

		$ conda config --add channels https://conda.anaconda.org/conda-forge
		$ conda config --add channels https://conda.anaconda.org/domdfcoding

	* Then install

	.. code-block:: bash

		$ conda install astatine

.. end installation
