Adafruit CircuitPython BusDevice
================================

.. image:: https://readthedocs.org/projects/adafruit-circuitpython-busdevice/badge/?version=latest
    :target: https://docs.circuitpython.org/projects/busdevice/en/latest/
    :alt: Documentation Status

.. image:: https://raw.githubusercontent.com/adafruit/Adafruit_CircuitPython_Bundle/main/badges/adafruit_discord.svg
    :target: https://adafru.it/discord
    :alt: Discord

.. image:: https://github.com/adafruit/Adafruit_CircuitPython_BusDevice/workflows/Build%20CI/badge.svg
    :target: https://github.com/adafruit/Adafruit_CircuitPython_BusDevice/actions/
    :alt: Build Status

.. image:: https://img.shields.io/badge/code%20style-black-000000.svg
    :target: https://github.com/psf/black
    :alt: Code Style: Black

The ``I2CDevice`` and ``SPIDevice`` helper classes make managing transaction state
on a bus easy. For example, they manage locking the bus to prevent other
concurrent access. For SPI devices, it manages the chip select and protocol
changes such as mode. For I2C, it manages the device address.

.. _bus_device_installation:

.. note:: On microcontroller boards using CircuitPython v6.3.0 or newer, the firmware
    may already have the ``adafruit_bus_device`` package builtin, thus there may be no
    need to add this package to your CIRCUITPY drive's "lib" directory. If both the
    builtin and add-on ``adafruit_bus_device`` packages are present, then some
    libraries that require this package *might* have problems importing it.

    Please check the `CircuitPython documentation's "module support matrix"
    <https://docs.circuitpython.org/en/latest/shared-bindings/support_matrix.html>`_
    to make sure that your board's firmware does include the builtin ``adafruit_bus_device``
    package.

On supported GNU/Linux systems like the Raspberry Pi, you can install the driver locally `from
PyPI <https://pypi.org/project/adafruit-circuitpython-busdevice/>`_. To install for current user:

.. code-block:: shell

    pip3 install adafruit-circuitpython-busdevice

To install system-wide (this may be required in some cases):

.. code-block:: shell

    sudo pip3 install adafruit-circuitpython-busdevice

To install in a virtual environment in your current project:

.. code-block:: shell

    mkdir project-name && cd project-name
    python3 -m venv .venv
    source .venv/bin/activate
    pip3 install adafruit-circuitpython-busdevice

Usage Example
=============

See examples/read_register_i2c.py and examples/read_register_spi.py for examples of the module's usage.

Documentation
=============

API documentation for this library can be found on `Read the Docs <https://docs.circuitpython.org/projects/busdevice/en/latest/>`_.

For information on building library documentation, please check out `this guide <https://learn.adafruit.com/creating-and-sharing-a-circuitpython-library/sharing-our-docs-on-readthedocs#sphinx-5-1>`_.

Contributing
============

Contributions are welcome! Please read our `Code of Conduct
<https://github.com/adafruit/Adafruit_CircuitPython_BusDevice/blob/main/CODE_OF_CONDUCT.md>`_
before contributing to help this project stay welcoming.
