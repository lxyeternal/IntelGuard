import{b as e,n as s,s as l,x as o}from"./index-enlvTT7f.js";import"./c.B_RWjdvK.js";import"./c.C2ITiWVK.js";let d=class extends l{render(){return o`
      <esphome-process-dialog
        heading="Update All"
        .type=${"update-all"}
        @closed=${this._handleClose}
      ></esphome-process-dialog>
    `}_handleClose(){this.parentNode.removeChild(this)}};d=e([s("esphome-update-all-dialog")],d);
//# sourceMappingURL=c.BI0_3vTY.js.map
