import{Z as s,$ as a}from"./index-enlvTT7f.js";const i="wifi_ssid",n="wifi_password",o=async()=>{const s=await a();return s.includes(i)&&s.includes(n)},r=async(a,o)=>s({[i]:a,[n]:o},"Your Wi-Fi SSID and password");export{n as S,i as a,o as c,r as s};
//# sourceMappingURL=c.RrddT4I5.js.map
