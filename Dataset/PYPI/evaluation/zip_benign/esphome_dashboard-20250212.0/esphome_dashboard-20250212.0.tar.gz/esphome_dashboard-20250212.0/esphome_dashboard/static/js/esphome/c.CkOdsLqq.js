const e=(e,o)=>{import("./c.CGh-qXyO.js");const t=document.createElement("esphome-install-server-dialog");t.configuration=e,t.target=o,document.body.append(t)};export{e as o};
//# sourceMappingURL=c.CkOdsLqq.js.map
