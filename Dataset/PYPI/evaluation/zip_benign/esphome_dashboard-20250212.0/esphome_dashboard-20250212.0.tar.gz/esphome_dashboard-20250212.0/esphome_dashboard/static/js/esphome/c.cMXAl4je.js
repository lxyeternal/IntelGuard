import{v as r}from"./index-enlvTT7f.js";const t=()=>r("./serial-ports").then((r=>r.filter((r=>"OTA"!==r.port))));export{t as g};
//# sourceMappingURL=c.cMXAl4je.js.map
