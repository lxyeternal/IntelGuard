import{X as e}from"./index-enlvTT7f.js";const i="serial"in navigator,s=window.isSecureContext,l={ESP32:{label:"ESP32",showInPickerTitle:!0,showInDeviceTypePicker:!0,defaultBoard:"esp32dev"},ESP32S2:{label:"ESP32-S2",showInPickerTitle:!0,showInDeviceTypePicker:!0,defaultBoard:"esp32-s2-saola-1"},ESP32S3:{label:"ESP32-S3",showInPickerTitle:!0,showInDeviceTypePicker:!0,defaultBoard:"esp32-s3-devkitc-1"},ESP32C3:{label:"ESP32-C3",showInPickerTitle:!0,showInDeviceTypePicker:!0,defaultBoard:"esp32-c3-devkitm-1"},ESP32C6:{label:"ESP32-C6",showInPickerTitle:!0,showInDeviceTypePicker:!1,defaultBoard:"esp32-c6-devkitc-1"},ESP8266:{label:"ESP8266",showInPickerTitle:!0,showInDeviceTypePicker:!0,defaultBoard:"esp01_1m"},RP2040:{label:"Raspberry Pi Pico W",showInPickerTitle:!1,showInDeviceTypePicker:!0,defaultBoard:"rpipicow"},BK72XX:{label:"BK72xx",showInPickerTitle:!0,showInDeviceTypePicker:!0,defaultBoard:null},RTL87XX:{label:"RTL87xx",showInPickerTitle:!0,showInDeviceTypePicker:!0,defaultBoard:null}},a={ESP32:"ESP32","ESP32-S2":"ESP32S2","ESP32-S3":"ESP32S3","ESP32-C3":"ESP32C3","ESP32-C6":"ESP32C6",ESP8266:"ESP8266"},P=e`
  <svg class="svg-fill-primary" width="24" height="24" viewBox="0 0 24 24" slot="meta">
    <path d="M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z" />
  </svg>
`;e`
  <svg class="svg-fill-primary" width="24" height="24" viewBox="0 0 24 24" slot="meta">
    <path d="M11,18H13V16H11V18M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,6A4,4 0 0,0 8,10H10A2,2 0 0,1 12,8A2,2 0 0,1 14,10C14,12 11,11.75 11,15H13C13,12.75 16,12.5 16,10A4,4 0 0,0 12,6Z" />
  </svg>
`;export{l as a,s as b,a as c,P as m,i as s};
//# sourceMappingURL=c.L7vpoWlH.js.map
