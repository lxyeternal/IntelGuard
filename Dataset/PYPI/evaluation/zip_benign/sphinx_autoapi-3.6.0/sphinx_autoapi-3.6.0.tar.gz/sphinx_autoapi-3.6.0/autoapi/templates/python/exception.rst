{% extends "python/class.rst" %}
