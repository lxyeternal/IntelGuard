"""The scripts main functions."""
