class Foo(object):
    pass
