def f():
    return 'b'
