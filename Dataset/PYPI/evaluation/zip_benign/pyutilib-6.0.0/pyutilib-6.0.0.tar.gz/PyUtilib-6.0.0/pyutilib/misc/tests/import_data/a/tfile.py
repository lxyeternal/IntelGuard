def f():
    return 'a'
