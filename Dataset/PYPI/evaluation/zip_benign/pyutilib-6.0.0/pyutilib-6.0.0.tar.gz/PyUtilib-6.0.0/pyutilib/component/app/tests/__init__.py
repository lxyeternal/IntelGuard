"""Test plugin applications"""
