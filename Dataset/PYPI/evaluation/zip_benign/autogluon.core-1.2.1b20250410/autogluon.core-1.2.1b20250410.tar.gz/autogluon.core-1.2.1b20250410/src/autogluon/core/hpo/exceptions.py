class EmptySearchSpace(Exception):
    pass
