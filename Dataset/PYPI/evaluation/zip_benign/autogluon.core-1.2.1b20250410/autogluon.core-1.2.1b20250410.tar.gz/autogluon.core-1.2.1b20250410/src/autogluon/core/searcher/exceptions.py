class ExhaustedSearchSpaceError(Exception):
    pass
