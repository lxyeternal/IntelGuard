# 32 bit libraries

