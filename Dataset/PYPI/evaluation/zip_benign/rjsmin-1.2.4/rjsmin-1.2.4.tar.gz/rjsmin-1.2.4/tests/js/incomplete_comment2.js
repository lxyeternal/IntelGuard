foo /* huh.

Yo. "string     "?

**************
