aliases: dict[str, str]
