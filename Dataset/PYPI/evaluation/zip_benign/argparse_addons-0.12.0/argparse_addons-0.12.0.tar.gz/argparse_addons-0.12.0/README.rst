About
=====

Additional Python argparse types and actions.

Project homepage: https://github.com/eerimoq/argparse_addons

Installation
============

.. code-block:: text

    $ pip install argparse_addons

Examples
========

Integer type
------------

The script. See `examples/integer.py`_ for the complete script.

.. code-block:: python

   parser.add_argument('--min-max',
                       type=argparse_addons.Integer(0, 255))
   parser.add_argument('--min',
                       type=argparse_addons.Integer(0, None))
   parser.add_argument('--max',
                       type=argparse_addons.Integer(None, 255))
   parser.add_argument('--any',
                       type=argparse_addons.Integer())

Error message for the ``--min-max`` argument.

.. code-block:: text

   $ python3 examples/integer.py --min-max -1
   usage: integer.py [-h] [--min-max MIN_MAX] [--min MIN] [--max MAX] [--any ANY]
   integer.py: error: argument --min-max: -1 is not in the range 0..255

Error message for the ``--min`` argument.

.. code-block:: text

   $ python3 examples/integer.py --min -1
   usage: integer.py [-h] [--min-max MIN_MAX] [--min MIN] [--max MAX] [--any ANY]
   integer.py: error: argument --min: -1 is not in the range 0..inf

Error message for the ``--max`` argument.

.. code-block:: text

   $ python3 examples/integer.py --max 1000
   usage: integer.py [-h] [--min-max MIN_MAX] [--min MIN] [--max MAX] [--any ANY]
   integer.py: error: argument --max: 1000 is not in the range -inf..255

Error message for the ``--any`` argument.

.. code-block:: text

   $ python3 examples/integer.py --any a
   usage: integer.py [-h] [--min-max MIN_MAX] [--min MIN] [--max MAX] [--any ANY]
   integer.py: error: argument --any: invalid integer value: 'a'

All values within allowed ranges.

.. code-block:: text

   $ python3 examples/integer.py --min-max 47 --min 1000 --max -5 --any 1
   --min-max: 47
   --min:     1000
   --max:     -5
   --any:     1

Contributing
============

#. Fork the repository.

#. Install prerequisites.

   .. code-block:: text

      pip install -r requirements.txt

#. Implement the new feature or bug fix.

#. Implement test case(s) to ensure that future changes do not break
   legacy.

#. Run the tests.

   .. code-block:: text

      make test

#. Create a pull request.

.. _examples/integer.py: https://github.com/eerimoq/argparse_addons/blob/master/examples/integer.py
