# VMware vCloud Director Python SDK
# Copyright (c) 2017-2018 VMware, Inc. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


class VAppConstants(object):
    name = "test_vapp_zxcvb12345"
    network1_name = "vappnetwork"
    network1_cidr = '90.80.70.1/24'
    network1_ip_ranges = ['90.80.70.2-90.80.70.20']
    vm1_name = 'testvm1'
