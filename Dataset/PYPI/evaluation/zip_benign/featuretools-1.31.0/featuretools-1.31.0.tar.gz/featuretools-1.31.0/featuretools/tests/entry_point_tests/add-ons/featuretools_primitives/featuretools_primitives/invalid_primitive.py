raise NotImplementedError("invalid primitive")
