.. _how-to:

=============
How-to Guides
=============

How-to guides are recipes that take the user through steps in key subjects.
They are more advanced than tutorials and assume a lot more about what the user
already knows than tutorials do, and unlike documents in the tutorial they can
stand alone.

.. toctree::
   :maxdepth: 2
   :glob:

   get-started
   type-mapping
   memory-management
   protocols
   async
   c-functions
   contribute-code
   contribute-docs
   internal/index
