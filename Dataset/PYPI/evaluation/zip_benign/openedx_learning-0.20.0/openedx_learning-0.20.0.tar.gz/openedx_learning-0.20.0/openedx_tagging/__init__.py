"""
Open edX Tagging app.
"""
