class ObMissingEnvironmentVariable(Exception):
    pass
