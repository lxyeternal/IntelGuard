class EmptyClass:
    pass
