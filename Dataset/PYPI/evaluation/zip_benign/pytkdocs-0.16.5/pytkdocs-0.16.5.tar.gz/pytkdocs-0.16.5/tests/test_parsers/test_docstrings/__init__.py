"""Test the docstrings parsers."""
