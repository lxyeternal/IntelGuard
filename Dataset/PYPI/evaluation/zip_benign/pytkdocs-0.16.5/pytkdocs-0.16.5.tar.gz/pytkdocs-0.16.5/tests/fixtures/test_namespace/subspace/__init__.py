"The subspace package docstring."
