.. _examples:

Examples
========
