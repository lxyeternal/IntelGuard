def baz():
    pass
