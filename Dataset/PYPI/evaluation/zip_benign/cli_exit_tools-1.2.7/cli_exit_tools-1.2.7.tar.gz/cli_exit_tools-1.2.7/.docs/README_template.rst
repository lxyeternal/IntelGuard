cli_exit_tools
==============


Version v1.2.7 as of 2024-10-02 see `Changelog`_


.. include:: ./badges.rst

.. include:: ./description.rst

----

automated tests, Github Actions, Documentation, Badges, etc. are managed with `PizzaCutter <https://github
.com/bitranox/PizzaCutter>`_ (cookiecutter on steroids)

Python version required: 3.8.0 or newer

.. include:: ./tested_under.rst

----

.. include:: ./index.rst

----

.. include:: ./try_in_jupyter.rst

Usage
-----------
.. include:: ./usage.rst

Usage from Commandline
------------------------
.. include:: ./commandline_help.rst

Installation and Upgrade
------------------------
.. include:: ./installation.rst

Requirements
------------
following modules will be automatically installed :

.. include:: ../requirements.txt
        :code: bash

Acknowledgements
----------------
.. include:: ./acknowledgment.rst

Contribute
----------
.. include:: ./contribute.rst

License
-------
.. include:: ./licence_mit.rst

---

.. include:: ../CHANGES.rst
