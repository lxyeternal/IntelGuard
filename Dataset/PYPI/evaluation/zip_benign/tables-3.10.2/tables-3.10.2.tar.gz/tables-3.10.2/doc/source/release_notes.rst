======================
PyTables Release Notes
======================

Migration
----------

.. toctree::
    :maxdepth: 1

    Migrating from 2.x to 3.x <MIGRATING_TO_3.x>
    Migrating from 1.x to 2.x <MIGRATING_TO_2.x>

PyTables
--------

.. toctree::
    :maxdepth: 1

    release-notes/RELEASE_NOTES_v3.10.x
    release-notes/RELEASE_NOTES_v3.9.x
    release-notes/RELEASE_NOTES_v3.8.x
    release-notes/RELEASE_NOTES_v3.7.x
    release-notes/RELEASE_NOTES_v3.6.x
    release-notes/RELEASE_NOTES_v3.5.x
    release-notes/RELEASE_NOTES_v3.4.x
    release-notes/RELEASE_NOTES_v3.3.x
    release-notes/RELEASE_NOTES_v3.2.x
    release-notes/RELEASE_NOTES_v3.1.x
    release-notes/RELEASE_NOTES_v3.0.x
    release-notes/RELEASE_NOTES_v2.4.x
    release-notes/RELEASE_NOTES_v2.3.x
    release-notes/RELEASE_NOTES_v2.2.x
    release-notes/RELEASE_NOTES_v2.1.x
    release-notes/RELEASE_NOTES_v2.0.x
    release-notes/RELEASE_NOTES_v1.4
    release-notes/RELEASE_NOTES_v1.3.3
    release-notes/RELEASE_NOTES_v1.3.2
    release-notes/RELEASE_NOTES_v1.3.1
    release-notes/RELEASE_NOTES_v1.3
    release-notes/RELEASE_NOTES_v1.2.3
    release-notes/RELEASE_NOTES_v1.2.2
    release-notes/RELEASE_NOTES_v1.2.1
    release-notes/RELEASE_NOTES_v1.2
    release-notes/RELEASE_NOTES_v1.1.1
    release-notes/RELEASE_NOTES_v1.1
    release-notes/RELEASE_NOTES_v1.0
    release-notes/RELEASE_NOTES_v0.9.1
    release-notes/RELEASE_NOTES_v0.9
    release-notes/RELEASE_NOTES_v0.8
    release-notes/RELEASE_NOTES_v0.7.2
    release-notes/RELEASE_NOTES_v0.7.1


PyTables Pro
------------

.. toctree::
    :maxdepth: 1

    release-notes/RELEASE_NOTES_v2.2.x-pro
    release-notes/RELEASE_NOTES_v2.1.x-pro
    release-notes/RELEASE_NOTES_v2.0.x-pro


Release timeline
----------------

=============== =========== ==========
PyTables        3.10.1      2024-08-17
PyTables        3.10.0      2024-08-13
PyTables        3.9.2       2023-11-27
PyTables        3.9.1       2023-10-06
PyTables        3.9.0       2023-10-05
PyTables        3.8.0       2022-12-23
PyTables        3.7.0       2021-12-28
PyTables        3.6.1       2019-10-28
PyTables        3.6.0       2019-10-14
PyTables        3.5.2       2019-05-31
PyTables        3.5.1       2019-03-14
PyTables        3.5.0       2019-03-13
PyTables        3.4.4       2018-06-11
PyTables        3.4.3       2018-04-17
PyTables        3.4.2       2017-04-19
PyTables        3.4.1       2017-04-12
PyTables        3.4.0       2017-04-11
PyTables        3.3.0       2016-09-12
PyTables        3.2.3.1     2016-07-05
PyTables        3.2.3       2016-07-04
PyTables        3.2.2       2015-09-22
PyTables        3.2.1.1     2015-08-31
PyTables        3.2.1       2015-08-04
PyTables        3.2.0       2015-05-06
PyTables        3.2.0rc2    2015-05-01
PyTables        3.2.0rc1    2015-04-21
PyTables        3.1.1       2014-03-25
PyTables        3.1.0       2014-02-05
PyTables        3.1.0rc2    2014-01-22
PyTables        3.1.0rc1    2014-01-17
PyTables        3.0         2013-06-01
PyTables        3.0rc3      2013-05-29
PyTables        3.0rc2      2013-05-17
PyTables        3.0rc1      2013-05-10
PyTables        3.0b1       2013-04-27
PyTables        2.4         2012-07-20
PyTables        2.4rc1      2012-07-16
PyTables        2.4b1       2012-07-07
PyTables        2.3.1       2011-10-28
PyTables        2.3         2011-09-23
PyTables        2.3rc1      2011-09-11
PyTables        2.2.1       2010-11-05
PyTables        2.2.1rc1    2010-11-03
Pytables        2.2         2010-07-01
PyTables        2.2rc2      2010-06-17
PyTables        2.2rc1      2010-05-20
PyTables        2.1.2       2009-09-14
PyTables        2.1.1       2009-03-13
PyTables Pro    2.1.1       2009-03-13
PyTables        2.1         2008-12-19
PyTables        2.1rc2      2008-11-18
PyTables        2.1rc1      2008-10-31
PyTables        2.0.4       2008-07-05
PyTables Pro    2.0.4       2008-07-05
PyTables        2.0.3       2008-03-07
PyTables Pro    2.0.2.1     2007-12-24
PyTables Pro    2.0.1       2007-09-20
PyTables        2.0.1       2007-09-20
PyTables Pro    2.0         2007-07-12
PyTables        2.0         2007-07-12
PyTables        2.0rc2      2007-05-28
PyTables        2.0rc1      2007-04-26
PyTables        1.4         2006-12-21
PyTables        1.3.3       2006-08-24
PyTables        1.3.2       2006-06-20
PyTables        1.3.1       2006-05-02
PyTables        1.3         2006-04-01
PyTables        1.2.3       2006-02-23
PyTables        1.2.2       2006-02-16
PyTables        1.2.1       2005-12-21
PyTables        1.2         2005-11-22
PyTables        1.1.1       2005-09-13
PyTables        1.1         2005-07-14
PyTables        1.0         2005-05-12
PyTables        0.9.1       2004-12-02
PyTables        0.9         2004-11-08
PyTables        0.8.1       2004-07-13
PyTables        0.8         2004-03-03
PyTables        0.7.2       2003-09-22
PyTables        0.7         2003-07-31
PyTables        0.5.1       2003-05-14
PyTables        0.5         2003-05-10
Pytables        0.4         2003-03-19
=============== =========== ==========
