"""
Wrappers for the "CoreMediaIO" framework on macOS.

These wrappers don't include documentation, please check Apple's documentation
for information on how to use this framework and PyObjC's documentation
for general tips and tricks regarding the translation between Python
and (Objective-)C frameworks
"""

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))


from pyobjc_setup import Extension, setup  # noqa: E402

VERSION = "11.0"

setup(
    name="pyobjc-framework-CoreMediaIO",
    description="Wrappers for the framework CoreMediaIO on macOS",
    min_os_level="10.7",
    packages=["CoreMediaIO"],
    ext_modules=[
        Extension(
            "CoreMediaIO._CoreMediaIO",
            ["Modules/_CoreMediaIO.m"],
            extra_link_args=["-framework", "CoreMediaIO"],
        )
    ],
    version=VERSION,
    install_requires=["pyobjc-core>=" + VERSION, "pyobjc-framework-Cocoa>=" + VERSION],
    long_description=__doc__,
)
