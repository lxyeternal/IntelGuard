# Changelog

## [integrations/opensearch-v3.1.1] - 2025-03-21

### 🐛 Bug Fixes

- OpenSearch custom_query use without filters (#1554)

### 📚 Documentation

- Update changelog for integrations/opensearch (#1531)

### ⚙️ CI

- Review testing workflows (#1541)

## [integrations/opensearch-v3.1.0] - 2025-03-12

### 🚀 Features

- AWS IAM Auth support for OpenSearch async (#1527)

### 🐛 Bug Fixes

- OpenSearch - call _ensure_index_exists only at initialization (#1522)

### 📚 Documentation

- Update changelog for integrations/opensearch (#1515)

## [integrations/opensearch-v3.0.0] - 2025-03-11

### 🐛 Bug Fixes

- OpenSearchDocumentStore depends on async opensearch-py (#1438)

### 📚 Documentation

- Update changelog for integrations/opensearch (#1415)
- Add docstore description to docstring (#1446)
- Update changelog for integrations/opensearch (#1488)

### 🧹 Chores

- Remove Python 3.8 support (#1421)

### 🌀 Miscellaneous

- Chore: OpenSearch - pin haystack and remove dataframe checks (#1513)

## [integrations/opensearch-v2.1.0] - 2025-02-18

### 🚀 Features

- OpenSearch - async support (#1414)

### 📚 Documentation

- Update changelog for integrations/opensearch (#1402)

## [integrations/opensearch-v2.0.0] - 2025-02-14

### 🚀 Features

- Add Secret handling in OpenSearchDocumentStore (#1288)

### 🧹 Chores

- Inherit from `FilterDocumentsTestWithDataframe` in Document Stores (#1290)
- [**breaking**] OpenSearch - remove dataframe support (#1378)

### 🌀 Miscellaneous

- Chore: OpenSearch - manually fix changelog (#1299)

## [integrations/opensearch-v1.2.0] - 2024-12-12

### 🧹 Chores

- Update docstring and type of fuzziness (#1243)


## [integrations/opensearch-v1.1.0] - 2024-10-29

### 🚀 Features

- Efficient knn filtering support for OpenSearch (#1134)

### 📚 Documentation

- Update opensearch retriever docstrings (#1035)

### 🧪 Testing

- Do not retry tests in `hatch run test` command (#954)

### ⚙️ CI

- Adopt uv as installer (#1142)

### 🧹 Chores

- OpenSearch - remove legacy filter support (#1067)
- Update changelog after removing legacy filters (#1083)
- Update ruff linting scripts and settings (#1105)

### 🌀 Miscellaneous

- Docs: Update OpenSearchEmbeddingRetriever docstrings (#947)
- Update BM25 docstrings (#945)
- Chore: opensearch - ruff update, don't ruff tests (#988)

## [integrations/opensearch-v0.9.0] - 2024-08-01

### 🚀 Features

- Support aws authentication with OpenSearchDocumentStore (#920)


## [integrations/opensearch-v0.8.1] - 2024-07-15

### 🚀 Features

- Add raise_on_failure param to OpenSearch retrievers (#852)
- Add filter_policy to opensearch integration (#822)

### 🐛 Bug Fixes

- `OpenSearch` - Fallback to default filter policy when deserializing retrievers without the init parameter (#895)

### 🧹 Chores

- Update ruff invocation to include check parameter (#853)

### 🌀 Miscellaneous

- Chore: Minor retriever pydoc fix (#884)

## [integrations/opensearch-v0.7.1] - 2024-06-27

### 🐛 Bug Fixes

- Serialization for custom_query in OpenSearch retrievers (#851)
- Support legacy filters with OpenSearchDocumentStore (#850)


## [integrations/opensearch-v0.7.0] - 2024-06-25

### 🚀 Features

- Defer the database connection to when it's needed (#753)
- Improve `OpenSearchDocumentStore.__init__` arguments (#739)
- Return_embeddings flag for opensearch (#784)
- Add create_index option to OpenSearchDocumentStore (#840)
- Add custom_query param to OpenSearch retrievers (#841)

### 🐛 Bug Fixes

- Fix order of API docs (#447)

### 📚 Documentation

- Update category slug (#442)
- Fixing opensearch docstrings (#521)
- Small consistency improvements (#536)
- Disable-class-def (#556)

### ⚙️ CI

- Retry tests to reduce flakyness (#836)

### 🌀 Miscellaneous

- Generate API docs (#324)
- Make tests show coverage (#566)
- Refactor tests (#574)
- Fix opensearch errors bulk write (#594)
- Remove references to Python 3.7 (#601)
- [Elasticsearch] fix: Filters not working with metadata that contain a space or capitalization (#639)
- Chore: add license classifiers (#680)
- Chore: change the pydoc renderer class (#718)
- Ci: install `pytest-rerunfailures` where needed; add retry config to `test-cov` script (#845)

## [integrations/opensearch-v0.2.0] - 2024-01-17

### 🐛 Bug Fixes

- Fix links in docstrings (#188)

### 🚜 Refactor

- Use `hatch_vcs` to manage integrations versioning (#103)

### 🌀 Miscellaneous

- Fix opensearch test badge (#97)
- Move package under haystack_integrations/* (#212)

## [integrations/opensearch-v0.1.1] - 2023-12-05

### 🐛 Bug Fixes

- Document Stores: fix protocol import (#77)

## [integrations/opensearch-v0.1.0] - 2023-12-04

### 🐛 Bug Fixes

- Fix license headers

### 🌀 Miscellaneous

- Remove Document Store decorator (#76)

## [integrations/opensearch-v0.0.2] - 2023-11-30

### 🚀 Features

- Extend OpenSearch params support (#70)

### 🌀 Miscellaneous

- Bump OpenSearch integration version to 0.0.2 (#71)

## [integrations/opensearch-v0.0.1] - 2023-11-30

### 🚀 Features

- [OpenSearch] add document store, BM25Retriever and EmbeddingRetriever (#68)

<!-- generated by git-cliff -->
