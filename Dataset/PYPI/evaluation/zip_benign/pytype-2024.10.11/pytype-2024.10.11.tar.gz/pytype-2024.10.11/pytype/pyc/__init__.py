"""pyc file format parser."""
