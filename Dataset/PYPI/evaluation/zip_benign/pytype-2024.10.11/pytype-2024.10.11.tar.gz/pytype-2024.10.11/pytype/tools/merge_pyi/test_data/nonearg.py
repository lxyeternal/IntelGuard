def f(x):
    pass
