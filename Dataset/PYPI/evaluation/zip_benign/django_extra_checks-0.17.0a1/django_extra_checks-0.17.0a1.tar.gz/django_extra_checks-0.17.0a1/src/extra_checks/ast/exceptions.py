class MissingASTError(Exception):
    pass
