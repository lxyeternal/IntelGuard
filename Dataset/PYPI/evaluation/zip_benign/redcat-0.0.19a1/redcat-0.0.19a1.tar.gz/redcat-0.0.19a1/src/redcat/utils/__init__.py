r"""Contain utility functions."""
