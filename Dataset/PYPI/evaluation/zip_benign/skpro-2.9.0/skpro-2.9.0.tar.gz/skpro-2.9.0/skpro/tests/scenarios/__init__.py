"""Test scenarios for estimators."""
