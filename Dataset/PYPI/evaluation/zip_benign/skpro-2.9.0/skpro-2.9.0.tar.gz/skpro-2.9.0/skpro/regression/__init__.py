"""Probabilitistic supervised regression estimators."""
