.. automodule:: skmisc.loess
