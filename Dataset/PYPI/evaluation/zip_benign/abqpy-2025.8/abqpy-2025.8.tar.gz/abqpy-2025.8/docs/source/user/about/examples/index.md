# Simple examples

Programming with the Abaqus Scripting Interface is straightforward and logical. This section includes two simple Abaqus Scripting Interface scripts to illustrate how easy it is to write your own programs. You are not expected to understand every line of the examples; the terminology and the syntax will become clearer as you read the detailed explanations in the following chapters. This section also includes a description of some of the principles behind programming with Python and the Abaqus Scripting Interface.

```{toctree}
:caption: Contents
:maxdepth: 1

create-part
read-output
summary
```
