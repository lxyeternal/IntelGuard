## Typing stubs for passlib

This is a [PEP 561](https://peps.python.org/pep-0561/)
type stub package for the [`passlib`](https://foss.heptapod.net/python-libs/passlib) package.
It can be used by type-checking tools like
[mypy](https://github.com/python/mypy/),
[pyright](https://github.com/microsoft/pyright),
[pytype](https://github.com/google/pytype/),
[Pyre](https://pyre-check.org/),
PyCharm, etc. to check code that uses `passlib`. This version of
`types-passlib` aims to provide accurate annotations for
`passlib==1.7.*`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/passlib`](https://github.com/python/typeshed/tree/main/stubs/passlib)
directory.

This package was tested with
mypy 1.15.0,
pyright 1.1.398,
and pytype 2024.10.11.
It was generated from typeshed commit
[`87f599dc8312ac67b941b5f2b47274534a1a2d3a`](https://github.com/python/typeshed/commit/87f599dc8312ac67b941b5f2b47274534a1a2d3a).