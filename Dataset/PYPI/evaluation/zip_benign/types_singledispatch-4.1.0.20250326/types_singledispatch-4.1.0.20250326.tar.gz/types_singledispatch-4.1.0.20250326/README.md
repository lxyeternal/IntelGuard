## Typing stubs for singledispatch

This is a [PEP 561](https://peps.python.org/pep-0561/)
type stub package for the [`singledispatch`](https://github.com/jaraco/singledispatch) package.
It can be used by type-checking tools like
[mypy](https://github.com/python/mypy/),
[pyright](https://github.com/microsoft/pyright),
[pytype](https://github.com/google/pytype/),
[Pyre](https://pyre-check.org/),
PyCharm, etc. to check code that uses `singledispatch`. This version of
`types-singledispatch` aims to provide accurate annotations for
`singledispatch==4.1.*`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/singledispatch`](https://github.com/python/typeshed/tree/main/stubs/singledispatch)
directory.

This package was tested with
mypy 1.15.0,
pyright 1.1.397,
and pytype 2024.10.11.
It was generated from typeshed commit
[`4fff7b7d0165120bf79928534c88dffffdcb5da2`](https://github.com/python/typeshed/commit/4fff7b7d0165120bf79928534c88dffffdcb5da2).