# hyper-moni

![build status](https://img.shields.io/travis/com/JohnTitor/hyper-moni.svg?style=for-the-badge)
![version](https://img.shields.io/npm/v/hyper-moni.svg?style=for-the-badge)
![downloads](https://img.shields.io/npm/dt/hyper-moni.svg?style=for-the-badge)
![release date](https://img.shields.io/github/release-date/JohnTitor/hyper-moni.svg?style=for-the-badge)

わたしは強いぞ！（いきり）

npm: https://www.npmjs.com/package/hyper-moni

## What's this?

Compiling Rust without any errors or warnings is difficult, you know.

When compiling is failed, this plugin plays Yoshimochi voice.

I hope you calm down by hearing her voice.

## Install

You can install Hyper [here](https://hyper.is/#installation).

```bash
hyper install hyper-moni
```

## Usage

1. Run `cargo check`, `cargo build` or `cargo run`
2. Feel **Yoshimochi**

### Config

```js
config: {
  // ...
  hyperMoni: {
    volume: 0.5 // Specifies the volume setting of the voice, in a range from 0.0 to 1.0.
  },
  // ...
}
```

## LICENSE

hyper-moni is licensed under Apache-2.0 except for audio files.

![license](https://img.shields.io/github/license/JohnTitor/hyper-moni.svg?style=for-the-badge)

音声ファイルの権利はすべて由持もにさんに帰属します．
