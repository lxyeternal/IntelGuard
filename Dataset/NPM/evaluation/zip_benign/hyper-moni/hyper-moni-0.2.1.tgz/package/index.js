const defaultConfig = 0.5;
let userConfig;

const detectCheckFailed = data => {
  return /Could not compile `(.*?)`\./.test(data);
};

module.exports.onRendererWindow = async window => {
  userConfig = window.config.getConfig() || {};
};

// eslint-disable-next-line no-unused-vars
exports.middleware = store => next => action => {
  if (action.type === "SESSION_ADD_DATA") {
    const { data } = action;
    const max = 5;
    const randomNumber = Math.floor(Math.random() * max) + 1;
    if (detectCheckFailed(data)) {
      const moni = new Audio(`${__dirname}/voices/failed${randomNumber}.wav`);
      let volumeConfig = defaultConfig;
      if (userConfig !== undefined) {
        if (userConfig.volume !== undefined) {
          if (userConfig.volume > 1) {
            userConfig.volume = 1;
          }
          if (userConfig.volume < 0) {
            userConfig.volume = 0;
          }
          volumeConfig = userConfig.volume;
        }
      }
      moni.volume = volumeConfig;
      moni.play();
    }
  }
  next(action);
};
