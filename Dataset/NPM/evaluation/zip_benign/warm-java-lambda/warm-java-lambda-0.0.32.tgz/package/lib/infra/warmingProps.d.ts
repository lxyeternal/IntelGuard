import { Duration } from 'aws-cdk-lib';
export interface WarmingProps {
    /**
     * Pause between invocations of the trigger lambda
     */
    readonly pauseBetweenInvocations: Duration;
    readonly triggerLambdaLogLevel?: string;
}
