import { Function, FunctionProps } from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
import { WarmingProps } from './warmingProps';
export declare class WarmFunction extends Function {
    private id;
    private readonly props;
    private readonly warmingProps;
    constructor(scope: Construct, id: string, props: FunctionProps, warmingProps: WarmingProps);
    private createTriggerLambda;
    private createTriggerScheduler;
    private checkFunctionIsJavaRuntime;
}
