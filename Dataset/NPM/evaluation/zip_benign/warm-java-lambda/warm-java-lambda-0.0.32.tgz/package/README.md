# This AWS CDK construct is under construction. Please do not use it.

### AWS CDK Warmup Lambda Construct for Java Lambda Functions

AWS Lambda written in Java is awesome. Java syntax is very clear and execution time of Java Lambda(for usual business
use-cases) very low. But there is one big problem with it, it is the cold start latency.
If you have a Java Lambda function that is not triggered very often, it will go to sleep the client of the Lambda will
have to wait for a long time until the Lambda is ready to process the request.
This is because the Java Lambda function has to be initialized and the JVM has to be started. This can take up to 10
seconds. For UI applications, this is a no-go.
Also, if you have multiply Java functions executed after each other, but not often triggered this will have a cumulative
effect on the latency.

This Construct is an extension of the standard AWS Lambda Function Construct that
enables you to keep infrequently triggered Java Lambda functions warm by scheduling periodic invocations. In this way
you can reduce the latency of your Java Lambda functions.

### AWS Costs

This construct uses two Lambda functions. The first one is your Java Lambda function that you want to keep warm.
The second one is a Lambda function that triggers your Java Lambda function periodically.
So you have to pay for two Lambda functions. But **do not be afraid of lambda costs**. Here is some simple calculation:

#### Assumptions for your Java Lambda:

- Architecture: x86_64
- Lambda function memory size: 512MB
- Lambda function average execution time pre request: 500ms
- AWS Region: eu-central-1(Frankfurt) -> 0.0000166667$ per invocation
- Number of requests per hour for your Java Lambda: 5(enough that your Java lambda go to sleep
  between invocations)

#### Assumptions for the Trigger-Lambda that is built in this construct:

- Architecture: x86_64
- Lambda function memory size: 256MB
- Lambda function average execution time pre request: 100ms
- Number of requests per hour for the second Lambda: every 5 minutes or 12 invocations/hour.
  In reality, it will be fewer because the second Lambda will be triggered only if your Java Lambda didn't run in
  between.
- AWS Region: eu-central-1(Frankfurt) -> 0.0000166667$ per invocation

Calculations are done via the AWS Lambda Pricing Calculator: https://calculator.aws/#/createCalculator/Lambda

#### Calculation for Java Lambda:

3,650 requests x 500 ms x 0.001 ms to sec conversion factor = 1,825.00 total compute (seconds)
0.50 GB x 1,825.00 seconds = 912.50 total compute (GB-s)
912.50 GB-s x 0.0000166667 USD = 0.02 USD (monthly compute charges)
3,650 requests x 0.0000002 USD = 0.00 USD (monthly request charges)
0.50 GB - 0.5 GB (no additional charge) = 0.00 GB billable ephemeral storage per function
Lambda costs - Without Free Tier (monthly): **0.02 USD**

#### Calculation for Trigger Lambda:

8,760 requests x 100 ms x 0.001 ms to sec conversion factor = 876.00 total compute (seconds)
0.25 GB x 876.00 seconds = 219.00 total compute (GB-s)
219.00 GB-s x 0.0000166667 USD = 0.00 USD (monthly compute charges)
8,760 requests x 0.0000002 USD = 0.00 USD (monthly request charges)
0.50 GB - 0.5 GB (no additional charge) = 0.00 GB billable ephemeral storage per function
Lambda costs - Without Free Tier (monthly): **0.00 USD**

Features
Time-Based Warmup Scheduling: Automatically schedule periodic invocations of your Java Lambda function to keep it warm.
Customizable Schedule: Configure the warmup schedule according to your needs, specifying the frequency and timing of
invocations.
Seamless Integration: Easily incorporate the Time-Based Warmup Lambda Construct into your AWS CDK applications.

## What is Lambda doing:
