<template>
  <div class="LineAndBarCommonChart">
    <div :id="chartDomId" class= "lineBarChartWrapper"></div>
    <div v-if="isHasRightContent" class="rightContent">
      <slot name="rightContent"></slot>
    </div>
  </div>
</template>

<script>
import * as echarts from 'echarts'
import baseOptions from './lineAndBarCommonOptions'
import { merge, debounce } from 'lodash'
import { uuid } from './utils'
export default {
  name: 'LineAndBarCommonChart',
  props: {
    // 右上角自定义内容
    isHasRightContent: {
      type: Boolean,
      default: false
    },
    // 图表配置信息(详细配置见README.md)
    optionsConfig: {
      type: Object,
      default: () => ({})
    }
  },
  data () {
    return {
      chartDomId: '',
      chart: ''
    }
  },
  computed: {
    // 合并配置对象
    option () {
      let _combileOption = merge({}, baseOptions, this.optionsConfig)
      this.optionsConfig.series &&
        Array.isArray(this.optionsConfig.series) &&
        this.optionsConfig.series.map((s, i) => {
        // 过滤x轴名称
          if (s.data && Array.isArray(s.data) && i === 0) {
            _combileOption.xAxis.data = s.data.map(v => v.name)
          }
          if (s.type === 'bar' && !s.barWidth) {
            _combileOption.series[i].barWidth = 20 // 在柱状图宽度未设置的情况下，默认宽度为20
          }
          if (s.type === 'line') {
            _combileOption.series[i].smooth = true
            _combileOption.series[i].symbol = 'none'
            if (s.isLinkHasShadow &&
            _combileOption.series[i].shadowColor &&
              Array.isArray(_combileOption.series[i].shadowColor)) {
              _combileOption.series[i].itemStyle = { // 当前折线下面的渐变色配置项
                normal: {
                  areaStyle: {
                    color: new echarts.graphic.LinearGradient(0, 1, 0, 0.1, [
                      {
                        offset: 0.7,
                        color: _combileOption.series[i].shadowColor[0]
                      },
                      {
                        offset: 1,
                        color: _combileOption.series[i].shadowColor[1]
                      }
                    ])
                  }
                }
              }
            }
          }
        })
        // 图标标题
      if (this.optionsConfig.titleText) {
        _combileOption.title.text = this.optionsConfig.titleText
      }
      // 图例图标
      if (this.optionsConfig.legendIcon) {
        _combileOption.legend.icon = this.optionsConfig.legendIcon
      }
      // tooltip显示
      _combileOption.tooltip = {
        ..._combileOption.tooltip,
        formatter: function (params) {
          let res = params[0].data.name + '<br>'
          for (let i = 0; i < params.length; i++) {
            res += `<div class='tootip' style="display:flex;">
              <div style='margin-right:2px'>${params[i].marker}</div>
              <span style='color:#666;margin-right:16px'>${params[i].seriesName}</span>
              <span style='margin-right:6px;color: #999'>${params[i].data.value}</span></div>`
          }
          return res
        }
      }

      return _combileOption
    }
  },
  created () {
    this.chartDomId = uuid()
  },
  mounted () {
    this.$nextTick(() => {
      this.initChart()
    })
  },
  beforeDestroy () {
    if (!this.chart) return
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart () {
      if (!document.getElementById(this.chartDomId)) return
      if (this.chart) this.chart.clear()
      this.chart = echarts.init(document.getElementById(this.chartDomId))
      this.chart.setOption(this.option)
      const that = this
      window.addEventListener('resize',
        debounce(() => { // 引入debounce，防止频繁更改浏览页尺寸出现页面抖动
          if (that.chart) {
            that.chart.resize()
          }
        }, 100)
      )
    }
  },
  watch: {
    // 监听父组件传过来option的变化
    optionsConfig: {
      handler (newValue) {
        this.initChart()
      },
      deep: true
    }
  }
}
</script>
<style lang="less" type="text/less"  scoped>
.LineAndBarCommonChart {
  width: 100%;
  height: 100%;
  position: relative;
  .lineBarChartWrapper {
    width: 100%;
    height: 500px;
  }
  .rightContent {
    position: absolute;
    right: 40px;
    top: 0;
    width: auto;
    height: auto;
  }
}

</style>
