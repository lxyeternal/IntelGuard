<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style lang="less">
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  height: 600px;
}
#nav {
  padding: 30px;
  a {
    font-weight: bold;
    color: #2c3e50;
    &.router-link-exact-active {
      color: #42b983;
    }
  }
}
.tables {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr 1fr;
  row-gap: 20px;
  column-gap: 20px;
  margin-top: 20px;
  overflow: auto;
  // padding-bottom: 11%;
  height: 500px;
  border: 1px solid red;
}
.card {
    background: #eee;
    box-shadow: 0 0 20px 0 rgb(0 0 0 / 5%);
    border-radius: 12px;
    display: flex;
    flex-direction: column;
    padding: 0 20px 20px 20px;
    box-sizing: border-box;
    min-height: 200px;
    max-height: 204px;
}
</style>
