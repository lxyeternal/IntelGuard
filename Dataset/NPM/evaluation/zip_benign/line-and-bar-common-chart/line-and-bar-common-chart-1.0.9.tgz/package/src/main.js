import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import LineAndBarCommonChart from './views/index'

Vue.config.productionTip = false

Vue.use(ElementUI)
Vue.use(LineAndBarCommonChart)

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
