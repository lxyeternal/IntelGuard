<template>
  <div class="home">
    <div class="title">图表</div>
    <div class="content">
      <LineAndBarCommonChart
      :optionsConfig="optionsConfig"
      :isHasRightContent="true"
      >
        <template v-slot:rightContent>
          <el-button type="primary" @click="refreshChart()"> 刷新图表</el-button>
        </template>
      </LineAndBarCommonChart>
    </div>
  </div>
</template>

<script>
export default {
  name: 'home',
  components: {
  },
  data () {
    return {
      optionsConfig: {
        titleText: '数据统计',
        color: [
          '#0780ED',
          '#FFB449',
          '#AC94FF'
        ],
        // legendIcon: 'circle',
        series: [
          {
            name: '数据源',
            type: 'bar',
            barWidth: 20,
            data: [
              { value: 1048, name: '搜索引擎' },
              { value: 735, name: '直接访问' },
              { value: 580, name: '邮件营销' },
              { value: 484, name: '联盟广告' },
              { value: 300, name: '视频广告' }
            ]
          },
          {
            name: '访问源',
            type: 'line',
            isLinkHasShadow: true,
            shadowColor: ['rgba(255,180,73, 0)', 'rgba(255,180,73,0.4)'],
            data: [
              { value: 548, name: '搜索引擎' },
              { value: 735, name: '直接访问' },
              { value: 580, name: '邮件营销' },
              { value: 584, name: '联盟广告' },
              { value: 600, name: '视频广告' }
            ]
          },
          {
            name: '访问方式',
            type: 'bar',
            data: [
              { value: 1048, name: '搜索引擎' },
              { value: 735, name: '直接访问' },
              { value: 580, name: '邮件营销' },
              { value: 484, name: '联盟广告' },
              { value: 300, name: '视频广告' }
            ]
          }
        ]
      }
    }
  },
  methods: {
    refreshChart () {
      this.optionsConfig = { ...this.optionsConfig }
    }
  }
}
</script>
<style scoped>
.title {
  font-size: 22px;
  height: 40px;
  line-height: 40px;
  margin-bottom: 10px;
}
.content {
  width: 100%;
  height:500px;
}
</style>
