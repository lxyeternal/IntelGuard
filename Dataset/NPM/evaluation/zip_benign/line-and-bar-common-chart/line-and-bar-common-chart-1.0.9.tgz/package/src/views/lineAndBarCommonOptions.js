// 公共样式定义，为了统一折线图和柱状图图表的基础样式，比如轴线、图各板块配色等（规定好的不需要重新变更）
export default {
  color: [
    '#41A5FF',
    '#FFB449',
    '#0AE7B4',
    '#FF7A3D',
    '#AC94FF',
    '#FFD55D',
    '#6EEBFF',
    '#AA00FF',
    '#822A07',
    '#00BBD4',
    '#FFD100',
    '#FE6021'
  ], // 折线/柱状图配色(m默认)
  grid: {
    left: 60,
    right: 40,
    top: 80,
    bottom: 60
  },
  title: {
    textStyle: {
      fontSize: 16,
      fontWeight: 500,
      color: '#343A40'
    },
    left: '10'
  },
  tooltip: {
    trigger: 'axis',
    axisPointer: { type: 'shadow' },
    textStyle: {
      align: 'left'
    }
  },
  legend: {
    orient: 'horizontal',
    x: 'center',
    y: 'top',
    itemWidth: 15,
    itemHeight: 15,
    textStyle: {
      color: '#343A40',
      fontSize: 12
    }
  },
  yAxis: {
    name: '',
    axisLine: {
      lineStyle: {
        color: '#E4E4E4',
        width: 1
      }
    },
    axisLabel: {
      color: '#999',
      textStyle: {
        fontSize: 10
      }
    },
    axisTick: false,
    splitLine: {
      lineStyle: {
        color: '#E4E4E4',
        width: 1
      }
    },
    nameTextStyle: {
      color: '#999999',
      fontSize: 10,
      padding: [0, 20, 10, 0]
    }
  },
  xAxis: {
    name: '',
    axisLine: {
      lineStyle: {
        color: '#E4E4E4',
        width: 1
      }
    },
    axisTick: false,
    splitLine: {
      show: false
    },
    axisLabel: {
      color: '#ADB5BD',
      textStyle: {
        fontSize: 12,
        padding: [10, 0, 0, 0]
      }
    },
    nameTextStyle: {
      color: '#ADB5BD',
      fontSize: 12
    },
    data: []
  },
  series: []
}
