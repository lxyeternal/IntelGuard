// 导入封装的组件
import LineAndBarCommonChart from './LineAndBarCommonChart.vue'

const components = {
  // 通过install来安装组件
  install (Vue) {
    Vue.component(
      'LineAndBarCommonChart', LineAndBarCommonChart
    )
  }
}

// 导出组件库
export default components
